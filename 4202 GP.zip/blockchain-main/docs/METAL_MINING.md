# Apple Metal proof-of-work mining

The node can mine with its default CPU worker or with an Apple GPU using Metal. Backend selection changes execution only; block contents, proof-of-work validation, difficulty, and the chain format stay the same. The API process verifies a Metal worker's winning block with the shared CPU implementation.

## Platform support

The Metal helper requires Apple Silicon (`arm64`) on macOS and Xcode command-line tools that provide `xcrun swiftc`. It uses the local Metal device. Linux, the checked-in Linux Docker runtime, and the Compose stack do not support this backend. There is no CPU fallback when Metal is selected: an unsupported platform, missing helper, or failed GPU preflight refuses node startup before it opens the chain data directory.

## Build and start

For automatic local setup, run `./demo.sh` from the repository root. On native Apple Silicon macOS it prepares dependencies, builds and verifies Metal, and starts the API and explorer together. `./demo.sh metal` explicitly requires this backend. Ctrl+C stops both apps and retains data. See [easy setup](SETUP.md) for automatic allocation and overrides.

For manual operation, build and start separately as follows.

Run these commands from the repository root on the Mac that will run the node:

```sh
pnpm install
pnpm --filter @conference-chain/node build:metal
```

The build compiles the native helper to `apps/node/native/build/metal-pow`. Start a Metal node with the usual required node settings and explicitly select the backend:

```sh
mkdir -p apps/node/data
PROFILE=demo \
CONFERENCE_ID=conf-demo-2026 \
DATA_DIR=./data \
SESSIONS_FILE="$PWD/apps/node/sessions.example.json" \
ENABLE_DEMO_ROUTES=true \
MINING_BACKEND=metal \
MINING_WORKERS=2 \
METAL_BATCH_SIZE=16384 \
pnpm --filter @conference-chain/node start
```

The package start command runs with `apps/node` as its working directory, so `DATA_DIR=./data` resolves to `apps/node/data`. `CONFERENCE_ID` is required; adjust the demo profile and routes for the environment you are running.

| Variable | Default | Accepted values | Meaning |
|---|---:|---|---|
| `MINING_BACKEND` | `cpu` | `cpu`, `metal` | Selects the CPU or Apple Metal worker. |
| `MINING_WORKERS` | `1` | `1`–`32` | Number of disjoint nonce lanes. Each Metal worker starts a helper process; all helpers share the same GPU. |
| `METAL_BATCH_SIZE` | `16384` | `1`–`65536` | Maximum nonce batch sent to the Metal kernel at a time. |

More workers are not guaranteed to improve throughput. Measure on the target Mac before changing the default. The Compose setting `CHAIN_MINING_WORKERS` configures CPU workers inside Linux; it does not enable Metal.

## Profiler traces

Build the Metal helper first, then run the bounded profiling workload from the repository root:

```sh
pnpm --filter @conference-chain/node build:metal
PROFILE_ATTEMPTS=65536 \
PROFILE_RECORDS=1 \
PROFILE_CPU_WORKERS=1,2,4 \
PROFILE_GPU_WORKERS=1,2 \
pnpm --filter @conference-chain/node profile:mining
```

The runner makes a unique `evidence/pow-profile-*` directory by default. It contains `summary.json`, V8 `.cpuprofile` files that can be opened in Chrome or DevTools, and `.gputrace` bundles that can be opened in Xcode. Keep the whole `.gputrace` directory when copying evidence. `PROFILE_OUTPUT_ROOT` overrides the output directory; relative paths are resolved from `apps/node`, where the package script runs.

| Variable | Default | Range or format |
|---|---:|---|
| `PROFILE_ATTEMPTS` | `65536` | Integer from `1` to `1000000` per backend/worker-count trial. |
| `PROFILE_RECORDS` | `1` | Integer from `0` to the node's maximum records per block; controls the synthetic candidate payload size. |
| `PROFILE_CPU_WORKERS` | `1,2,4` | Comma-separated worker counts from `1` to `32`. |
| `PROFILE_GPU_WORKERS` | `1,2` | Comma-separated worker counts from `1` to `32`. |
| `PROFILE_OUTPUT_ROOT` | `../../evidence` | Output directory, relative to the `apps/node` working directory unless absolute. |

The diagnostic candidate uses difficulty 64 and a fixed number of nonce attempts; it does not wait for a normal proof, submit records, or modify the live chain. Signed sample records and keys exist only in memory. Timing runs are separate from the trace captures, so profiler overhead is excluded from reported rates. Wall time includes worker/helper startup. CPU hashing includes canonical serialization while Metal hashes a precomputed canonical prefix and suffix, so the results are not an isolated CPU-versus-GPU SHA-256 comparison and are not a production throughput guarantee.

See [mining performance](MINING_PERFORMANCE.md) for the recorded trace analysis and measurements.
