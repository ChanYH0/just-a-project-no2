# Presentation and Report Outline

Course: blockchain group project. Presentation Nov 24, 2026; report Dec 1, 2026. Sources: `docs/SPEC.md` (v3.3), `README.md`, `docs/THREAT_MODEL.md`, `docs/course/Project_Assignment4-1.pdf`. Anything not verifiable from the repo is marked TODO.

## 0. Constraint check (read first)

- The assignment slides say: **8 minutes per group (2 presentation, 4 demo, 2 Q&A), at most 5 slides**, all members speak in presentation and Q&A, demo is emphasized, "get straight to the point". SPEC section 17 repeats this.
- The 11-slide table in section 1 is a content bank. The talk itself uses the five-slide plan in section 1.1, which fits the stated 8 minutes. TODO: confirm with the instructor/TA whether a longer slot or more slides is allowed; do not assume it.
- Grading (course PDF): 80 conference registration system, 20 dynamic difficulty. Presentation 50%, report 50%.
- Scope is the 1~2 student tier: F1, F2, two queries (F4), no F3 minting/rewards (SPEC section 1).

## 1. Slide outline (11 slides, ~10 min)

Presenters: A = Alvin (implementation), B = Joey (report/security matrix) per SPEC section 16. Both must be able to answer Q&A. TODO: confirm who presents which slide.

| # | Title | Min | Who |
|---|---|---|---|
| 1 | Problem and scope | 0.5 | B |
| 2 | Architecture | 1 | A |
| 3 | Identity and signed records | 1 | A |
| 4 | Block, PoW and validation | 1 | A |
| 5 | LIVE DEMO part 1: register, check in, query | 2 | A drives, B narrates |
| 6 | Dynamic difficulty algorithm | 1 | B |
| 7 | LIVE DEMO part 2: validate, tamper, difficulty | 1.5 | A drives, B narrates |
| 8 | Security and threat model | 0.75 | B |
| 9 | Testing evidence | 0.5 | B |
| 10 | Limitations and honest scope | 0.5 | B |
| 11 | Q&A | rest | both |

**1. Problem and scope**
- Blockchain conference registration: attendees register a key, check in to sessions, anyone can query.
- Implemented: F1 registration, F2 attendance, F4 two queries (Q1, Q2), PoW blocks, dynamic difficulty (20%).
- Not built on purpose: F3 minting/rewards, P2P, forks (SPEC section 1).
- Note: "Single node; the pending pool is the mempool."
- Demo: none.

**2. Architecture**
- Explorer (Vite + React, WebCrypto) -> `/api/*` -> Fastify node -> mempool -> miner worker -> `chain.jsonl` (README diagram).
- `packages/shared` holds schemas, canonicalize, crypto, block, difficulty, `validateChain`; imported by node and explorer.
- `./up.sh` = two containers (node internal, nginx explorer on 127.0.0.1:8080).
- Note: one value, one home (SPEC section 3); apps import from shared.
- Demo: show `docker compose ps` output or skip (TODO decide).

**3. Identity and signed records**
- Browser generates RSA-2048 pair; private key non-extractable in IndexedDB.
- `attendeeId = sha256(SPKI DER public key)`; `alias` is pseudonymous; no email/name (the slide allows "a unique identifier").
- Attendance cert = `{type, chainId, attendeeId, sessionId, timestamp}` signed over `canonicalize(payload)`.
- Note: pseudonymous and linkable, NOT anonymous (SPEC 5.2). `chainId` binds a signature to one deployment.
- Demo: none (shown on slide 5).

**4. Block, PoW and validation**
- Block hash = SHA-256 of canonical `{index, timestamp, previousHash, difficulty, nonce, records}`; PoW = `difficulty` leading hex zeros.
- Miner verifies every signature before inclusion; attendance needs registration in an EARLIER block.
- One `validateChain` used at boot, `/chain/validate`, and tamper demo; historical validation reads no clock and no session catalog.
- Note: this is the "validation split" (SPEC section 7); Joey must be able to explain it.
- Demo: none.

**5. LIVE DEMO 1** (script in section 3 steps 1-6)
- Register, wait for block, check in, wait for block, Q1 and Q2.
- Say aloud: "real mined blocks, live chain".

**6. Dynamic difficulty algorithm**
- Every `I` mined blocks (demo/production I=5, test I=3): compare `actual = ts[i-1]-ts[i-I]` with `expected = target*(I-1)`; faster +1, slower -1, equal keep; clamp to [min,max].
- Genesis is never in a window; boundaries at blocks I+1, 2I+1, ... (SPEC section 8).
- Demo profile: initial 2, range 1..4, target 3000 ms, so expected window 12 000 ms.
- Note: the slides' 10/20 blocks are "e.g."; ours is a config value. `validateChain` recomputes difficulty, so a miner cannot choose it.

**7. LIVE DEMO 2** (script steps 7-9)
- `/chain/validate` ok; tamper `edit-record` -> `BAD_BLOCK_HASH`; difficulty simulation fast vs slow.
- Say aloud: "SYNTHETIC simulation on an isolated in-memory chain, not measured hash rate".

**8. Security and threat model**
- Strict zod schemas on every input; unknown fields rejected; canonical bytes only; 16 KB body cap; no stack traces.
- Rate limits per IP: writes 30/min, validate and demo 6/min; replay and duplicate rejected; fail-closed persistence with process lock.
- Container: read-only rootfs, cap_drop ALL, no-new-privileges, non-root (compose.yaml, README).
- Note: threat model is in `docs/THREAT_MODEL.md`; TODO pick 2-3 rows (e.g. L4 Sybil, I1 privacy) to quote.

**9. Testing evidence**
- README 2026-11-03: shared 259 tests, node 188 tests, explorer 41 tests, all passed; Playwright e2e 4 of 4 passed. Later run 2026-11-04: node 194, shared 259, explorer 48, e2e 4 of 4 (refresh again before Nov 24).
- Adversarial A1-A9 and RC1-RC15 named in SPEC section 14.
- TODO: re-run all suites before Nov 24 and refresh the numbers; `pnpm audit` was not captured (16 findings listed in README, dev tooling only).

**10. Limitations**
- Single node, no consensus; operator can delete records and re-mine undetectably (`delete-record-and-remine` shows this); anchor head hash externally (U4, report text only).
- No identity proofing/physical presence; Q1/Q2 public; no key recovery; timestamps only monotonic in history; mempool lost on restart.

**11. Q&A**: see section 4.

### 1.1 Five-slide plan (USE THIS: it fits the stated 8 min and 5-slide limit)

The 11-slide table above is the content bank; the talk uses these five slides. Slide order puts the 2 presentation minutes first, then the 4-minute demo, then Q&A.

| # | Slide | Merges | Time | Who | Must say |
|---|---|---|---|---|---|
| 1 | Scope and architecture | 1, 2 | 0:45 | B | F1, F2, F4 and dynamic difficulty are built; F3 and P2P are not; single node, the pending pool is the mempool |
| 2 | Identity, records, blocks, validation | 3, 4 | 0:45 | A | key never leaves the browser; signed bytes include `chainId`, `sessionId`, `timestamp`; one `validateChain` for boot, API and tamper demo |
| 3 | Dynamic difficulty rule | 6 | 0:30 | B | every `I` blocks compare actual vs `target*(I-1)`, +1/-1/keep, clamped; genesis excluded; the validator recomputes it |
| LIVE DEMO | Section 3 steps 1-4, 6, 7, 8, 9 (skip step 5) | 5, 7 | 4:00 | A drives, B narrates | "real mined block", "validator is real, live chain untouched", "SYNTHETIC simulation" |
| 4 | Security, tests, limitations | 8-10 | 0:30 | B | pseudonymous not anonymous; tests and e2e numbers; operator can censor |
| 5 | Q&A | 11 | 2:00 | both | section 4 below |

Total 8:30 with a tight handover; cut slide 3 to 20 s if the demo overruns. The demo is the part that is graded hardest, so shorten slides before the demo.

Demo flow notes for the new UI (since 2026-11-04): the browser key is the login. After Register the nav switches to Check in only when the registration is confirmed. Do not use "Hide identity" mid-demo; if used, press "Use identity" again before checking in. Pre-register in a separate browser profile as a fallback.

## 2. Report chapter outline

Course-suggested contents: overview; design and implementation with key code snippets; testing and results (screenshots/outputs); contributions and references. SPEC section 17 adds mandatory items.

| Ch | Title | Content |
|---|---|---|
| 1 | Project overview | Objectives, implemented F1/F2/F4/difficulty, non-goals (F3, P2P) and why |
| 2 | Requirements and scope | Tier (1~2 students), mapping table below, decision U1 (`attendeeId` as the unique identifier; TODO record instructor reply) |
| 3 | System design | Architecture, repo layout, stack, config profiles, `chainId`, data model, canonicalization |
| 4 | Implementation | Signing flow, validation split (submission vs in-block), mining and worker cancellation, record lifecycle, persistence, API, explorer; key code snippets |
| 5 | Dynamic difficulty | Rule, genesis exclusion, worked example (test profile), synthetic simulation vs real mined blocks (label each), timestamp caveats |
| 6 | Security and privacy | Threat model summary, tamper demo table, pseudonymous-not-anonymous, A1-A9 |
| 7 | Testing and results | Test counts, RC/A mapping, screenshots of demo, e2e, `pnpm audit` table |
| 8 | Limitations and future work | README Limitations list; single-node mempool justification; head-hash anchoring |
| 9 | Contributions and references | Per-member work from git history, ChainKey reuse note (README: permission rests on author's authorization, license file is an unfinished draft), references |

### 2.1 Traceability: requirement -> SPEC -> code

| Requirement (course slides) | SPEC section | Code |
|---|---|---|
| Attendee generates key pair; private key in wallet | 12 (Register), 6 | `apps/explorer/src/wallet.ts`, `packages/shared/src/crypto-browser.ts` |
| F1 register unique identifier + public key | 5.1, 5.2, 7 | `packages/shared/src/schemas.ts`, `identity.ts`, `chain.ts` (`verifyRecordIntegrity`) |
| F2 signed attendance cert (attendee, session, timestamp) | 5.3, 7 | `schemas.ts`, `identity.ts` (`signPayload`), `apps/node/src/app.ts` (`POST /attendance`), `apps/explorer/src/pages/CheckInPage.tsx` |
| Pending transaction pool | 9 (lifecycle) | `apps/node/src/mempool.ts` |
| Blocks and PoW | 5.4, 6 | `packages/shared/src/block.ts`, `apps/node/src/miner.ts`, `mine-worker.ts` |
| Verify signature before inclusion (miner) | 7, 9 | `chain.ts` (`validateRecordInBlock`), `miner.ts` |
| Chain integrity / tamper detection | 7, 10 | `chain.ts` (`validateChain`), `apps/node/src/validation-routes.ts`, `packages/shared/src/mutations.ts` |
| F4 Q1 sessions by participant | 10 | `apps/node/src/ledger.ts`, `app.ts` (`GET /attendees/:id/sessions`) |
| F4 Q2 participants by session | 10 | `ledger.ts`, `app.ts` (`GET /sessions/:id/attendees`) |
| Dynamic difficulty (20%) | 8 | `packages/shared/src/difficulty.ts`, `config.ts`; sim in `validation-routes.ts`, `apps/explorer/src/pages/DifficultyDemoPage.tsx` |
| Persistence and restart safety | 9 | `apps/node/src/store.ts`, `main.ts` |
| Rate limiting | 10 | `apps/node/src/limiter.ts`, `app.ts` |
| Demo/UI pages | 12 | `apps/explorer/src/pages/*` |
| Tests | 14 | `packages/shared/test`, `apps/node/test`, `apps/explorer`, `apps/e2e/tests` (17-20) |

TODO: verify that `ledger.ts` is where Q1/Q2 lookups live (not read in this pass) and that `mutations.ts` holds the tamper mutations.

## 3. Live demo script

Preconditions (do before the talk; do not run on stage if slow):
- Docker running. `./up.sh` builds and starts. **Gotcha:** `chain.env.example` ships `CHAIN_ENABLE_DEMO_ROUTES=false`, and compose passes it as `ENABLE_DEMO_ROUTES`, so `/demo/*` (tamper, difficulty) are ABSENT until you set `CHAIN_ENABLE_DEMO_ROUTES=true` in `chain.env` and re-run `./up.sh`. Profile must be `demo` (`CHAIN_PROFILE=demo`; production refuses demo routes).
- README states that the UI in a browser against this stack and a register/check-in flow through the proxy were NOT verified (2026-11-04). TODO: do a full dry run on the demo machine and record the result.
- Fresh chain: `./up.sh down` keeps the data volume. TODO decide whether to wipe the `chain-data` volume for a clean start (a wipe command is not documented in the repo).
- Rate limits: validate and `/demo/*` are 6/min per IP total. Budget: validate x1, tamper x1-2, simulation x2-3. Do not rehearse on stage.
- Browser: open `http://127.0.0.1:8080/`. Pre-open tabs; use one browser profile (the key lives in IndexedDB).

Steps (timings from README demo table; demo profile mines about 1 s after a record enters the pool):
1. Chain page: show `chainId`, empty mempool, genesis block. Say: "live chain".
2. Register page: enter an alias that is NOT a real name, submit. Expect `202` with a `recordId`.
3. Chain page: record in mempool, then block 1 appears. Open Block detail: `hashValid` and `powValid` true. Say: "real mined block".
4. Check-in page: pick a session (catalog in `config/sessions.json`: `opening-keynote`, `workshop-blockchain-101`, `closing-panel`), submit, wait for status `confirmed`. Attendance requires registration in an EARLIER block, so do not submit it before step 3 finishes (else `ATTENDEE_NOT_REGISTERED`).
5. Chain page: block 2 holds the attendance record.
6. Query: Attendee page (Q1) lists the session; Session page (Q2) lists the alias.
7. Validate page: run chain validation, expect ok.
8. Tamper panel: mutation `edit-record`, block index 1 -> `BAD_BLOCK_HASH`. Optional second: `rehash-after-edit` -> `INVALID_SIGNATURE` (shows PoW alone does not save an editor). Say: "validator is real, live chain untouched".
9. Difficulty demo, labelled "Simulation (isolated chain)":
   - Run A: count 30, intervalMs 0 -> difficulty rises 2 -> 3 (block 6) -> 4 (block 11), then clamps at 4 (derived from SPEC rule and demo profile; TODO confirm on screen).
   - Run B: count 30, intervalMs 120000 -> falls 2 -> 1 and clamps at 1.
   - Optional Run C: intervalMs 3000 -> actual equals expected (12 000 ms), difficulty unchanged.
   - Say: "synthetic timestamps, nothing measured, live chain unaffected".

Fallback if validate fails or hangs:
- Validation runs in a worker with a 30 s timeout; `RATE_LIMITED` (429) means the 6/min budget is spent: wait one minute.
- `CHAIN_STORE_MISMATCH`: the disk file differs from memory (should not happen unless edited). Restart with `./up.sh down && ./up.sh`; the node revalidates at boot and refuses to start on a corrupt file (`CHAIN_FILE_CORRUPT`).
- Demo panels missing: demo routes are off; see the gotcha above. Show the pre-captured screenshots/recording instead. TODO capture screenshots and a screen recording of a passing run (`docs/course/` contains only course files).
- Always have a terminal backup: `curl http://127.0.0.1:8080/api/health` and `curl http://127.0.0.1:8080/api/chain/validate` (the proxy strips `/api`; README says `/api/*` is proxied to the node).
- Last resort: show the e2e results (4 of 4 passed, `apps/e2e/tests/17-20`) and unit test output.

## 4. Likely examiner questions

**Consensus: is this a real blockchain without consensus?**
It is a single-node, tamper-evident hash chain with PoW. There is no peer-to-peer network, no fork choice and no distributed agreement; the assignment's F3 (minting) tier is out of scope and the "pending pool" is one node's mempool (SPEC section 1, 17). The chain stops edits by invalidating hashes and signatures, but an operator who controls the data can rewrite or censor (shown by `delete-record-and-remine`). Mitigation proposed: anchor the head hash outside the node (U4, report text only).

**Why PoW if one node mines?**
The assignment requires mining, and dynamic difficulty needs mined blocks. PoW here makes block production cost work and drives the difficulty demo; it is not a Sybil defence across nodes.

**How does difficulty adjustment work? Why this window?**
Every `I` mined blocks, compare actual time across the window to `target*(I-1)`; faster means +1, slower means -1, equal means unchanged, clamped to the profile's min and max. Genesis (fixed 2023 timestamp) is excluded, so boundaries are blocks I+1, 2I+1, .... Windows do not overlap. I=5 in demo/production, 3 in test, configurable (slides said 10 or 20 only as "e.g."). Every node recomputes it in `validateChain`, so a miner cannot pick its own difficulty.

**Is the difficulty demo real?**
Two things, labelled separately: the simulation uses synthetic timestamps on an isolated in-memory chain to show the rule instantly; the live chain shows difficulty reacting to real wall-clock block spacing within 1..4 (demo profile). TODO: confirm live-chain behaviour on the demo machine before claiming it.

**Can a miner cheat the timestamps?**
Partly. Historically only monotonic order is enforced (no future upper bound, no median-time-past); an operator controlling chain data can steer difficulty one step per boundary within the clamp. New blocks are limited to now + 5 s on admission. Accepted limitation U6 (SPEC section 8).

**How do you detect tampering?**
`validateChain` checks in fixed order: genesis equality, index, `previousHash`, recomputed hash, PoW, difficulty, timestamp order, record count, then each record. Edit a record -> `BAD_BLOCK_HASH`; edit `previousHash` -> `BAD_PREVIOUS_HASH`; edit and re-mine that block -> `INVALID_SIGNATURE` (the attendee's key signed the old bytes); lower difficulty -> `BAD_DIFFICULTY`. Deleting a whole valid record and re-mining later blocks is NOT detected locally.

**Can someone forge or replay an attendance?**
No forge without the private key (RSA-2048, SHA-256, RSASSA-PKCS1-v1_5). `sessionId` and `timestamp` are inside the signed bytes, so a signature cannot be moved to another session; `chainId` blocks cross-deployment replay (only if `conferenceId` is unique); the same `(attendeeId, sessionId)` is rejected as `DUPLICATE_ATTENDANCE`, including concurrent submissions.

**How is rate limiting done?**
In-house fixed-window limiter per client IP with an injectable clock (`apps/node/src/limiter.ts`): writes 30/min, `/chain/validate` and `/demo/*` 6/min, then 429 `RATE_LIMITED`. Behind the compose nginx, `TRUST_PROXY=true` takes the client IP from `X-Forwarded-For`; that is safe only because the node is reachable solely through the proxy. Limits are per IP, so a shared NAT shares a budget and a distributed attacker is not stopped. TODO: confirm nginx overwrites the header (stated in `compose.yaml` comment, not inspected).

**Threat model summary?**
Attacker goals: forge or replay records, tamper history, deanonymize attendees, exhaust the node, abuse demo routes. Controls: strict schemas, signatures, canonical bytes, validation split, fail-closed persistence with process lock, rate/body limits, demo routes off by default and refused in production, hardened containers. Residual: operator censorship, Sybil registration (no identity proofing), linkable pseudonyms, public queries, XSS can still use the non-extractable key. TODO: cite specific IDs from `docs/THREAT_MODEL.md` (not read in full in this pass; SPEC references L4 and I1).

**Is it private?**
Pseudonymous, linkable, not anonymous. No email/name collected, but `attendeeId` persists across sessions, alias can identify, queries are public, and an immutable chain cannot honour deletion. No legal compliance review has been done (README).

**What happens on restart or crash?**
The chain reloads from `chain.jsonl` with full validation; a corrupt or torn file refuses to start (no silent repair). The mempool is memory only: pending records are lost, `GET /records/:id` gives 404, clients resubmit (same `recordId`).

**Who did what?**
Alvin: implementation and automated tests; Joey: report, slides, demo script, test evidence, security matrix (SPEC section 16). TODO: verify against git history (`git shortlog -sn`) before claiming it in the report.

## 5. Open TODOs (before Nov 24)

1. Confirm slot length and slide limit with the instructor (8 min, 5 slides stated).
2. Email instructor to confirm U1 (`attendeeId` instead of name/email) and record the reply.
3. Full dry run of `./up.sh` with `CHAIN_ENABLE_DEMO_ROUTES=true`, in a browser (README: not yet verified).
4. Re-run all test suites and `pnpm audit`; refresh counts on slide 9.
5. Capture screenshots/recording of the passing demo and the tamper/difficulty panels.
6. Assign presenters per slide; confirm contributions via git history.
