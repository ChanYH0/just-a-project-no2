# Easy local setup

Install Node.js 22 or newer, then run from the repository root:

```sh
./demo.sh
```

The launcher prepares the exact pnpm version pinned by `package.json` when needed, installs dependencies from the frozen lockfile, detects the mining backend, and starts the API and explorer together. It prints the actual explorer, API and interactive API documentation URLs once both services are listening. The first run needs network access for dependencies; it does not install pnpm globally or open a browser automatically.

The default explorer address is `http://127.0.0.1:5173/` and its API reference is at `http://127.0.0.1:5173/api/docs`. Ctrl+C stops both services, releases the chain lock and retains chain data. Run the same command to resume.

## Automatic hardware allocation

| Host / selection | Mining backend | Automatic allocation |
|---|---|---|
| Native Apple Silicon macOS | Metal | One helper on the default Metal device; the kernel sizes threadgroups from the device pipeline |
| Other hosts, including Linux VMs | CPU | Available CPU cores minus one, at least one worker, capped at the node's worker limit |

Native Apple Silicon detection selects Metal, builds its helper, and verifies a known GPU/CPU hash vector before opening the chain. A missing compiler or failed GPU preflight stops setup with an error. It does not silently change backends. If Xcode tools are missing, run `xcode-select --install`, finish installation, and retry.

Multiple Metal helpers share one GPU. The measured workload sometimes slowed down with extra helpers, so automatic allocation uses one helper rather than treating GPU cores as separate workers. The Metal batch size retains the node's validated default. See [Metal mining](METAL_MINING.md) for bounds and [performance evidence](MINING_PERFORMANCE.md) for traces and limitations.

Explicit choices and overrides:

```sh
./demo.sh cpu                      # CPU workers, even on an Apple GPU Mac
./demo.sh metal                    # require Apple Silicon Metal
MINING_WORKERS=4 ./demo.sh cpu      # override automatic worker allocation
METAL_BATCH_SIZE=8192 ./demo.sh     # override the Metal batch size
./demo.sh --help
```

`MINING_BACKEND=cpu|metal|auto` also selects the backend when no argument is supplied. An argument takes precedence. Worker and batch-size limits remain owned by the node's normal environment validation.

## Ports, sessions and data

The API uses its normal `PORT` default; the explorer uses its Vite default. Occupied ports fail explicitly instead of moving the wallet to a different origin. To use other ports:

```sh
PORT=3010 EXPLORER_PORT=5180 ./demo.sh
```

The launcher wires the explorer proxy to the actual API listener, including when `PORT=0` requests an ephemeral API port. Both services bind to loopback. This launcher always uses the demo profile, enables demo routes, and disables proxy-header trust. It is intended for local development and demonstrations.

Defaults are conference `conf-demo-2026`, the checked-in example session catalog, and persistent data in `apps/node/data`. Existing files are preserved. Override them when you need an isolated demo:

```sh
DATA_DIR=./data/my-demo CONFERENCE_ID=my-demo-2026 ./demo.sh
```

`DATA_DIR` and `SESSIONS_FILE` overrides resolve relative to the repository root. The default session catalog is read directly; no user catalog is overwritten. A changed conference ID against an existing chain is rejected. Use a separate data directory for a different conference. Do not delete a chain or lock file merely to get past startup errors.

## Containers and manual operation

For the Linux CPU container stack, use `./up.sh`; it prepares `chain.env` and a demo session catalog. `./up.sh down` retains the data volume. Set `CHAIN_MINING_WORKERS` in `chain.env` to change container CPU allocation. Host Apple Metal is available through the native launcher only.

Manual API/explorer commands and production configuration remain in [README.md](../README.md). Browser validation is documented in [apps/e2e/README.md](../apps/e2e/README.md). Repository ownership and agent checks are in [AGENTS.md](../AGENTS.md).

## Recorded setup validation (2026-11-08)

On the Apple M4, automatic setup selected Metal with one helper; explicit CPU setup allocated nine workers from ten available CPU cores. Each setup passed browser tests 22 and 23 (real mining/live difficulty and interactive API docs): 2/2 per backend. Workspace typechecks and launcher syntax checks passed.

Additional checks covered restart with retained mined blocks, an ephemeral API port through the explorer proxy, occupied-port failure with lock/API cleanup, invalid arguments/allocation, and bootstrap with no pnpm on PATH. The latter used the pinned pnpm through npm and honored a two-worker override. All test services were stopped and locks/ports released. Local screenshots and mining JSON are retained under ignored `evidence/setup-launcher-validation/`. Other operating systems' automatic selection was not run in this validation.
