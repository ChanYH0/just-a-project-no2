# Review and demo validation — 2026-11-07

For the later real-worker batch-boundary tests, live difficulty changes, restart evidence, and oversized-PoW fix, see [Mining validation](MINING_VALIDATION.md).

Validated application source: `57e1904` (`fix(explorer): reject contradictory miner health reports`). This is local acceptance evidence, not a production deployment or instructor acceptance of the assignment design.

## Review outcome

Three reviewers checked node lifecycle, spec implementation, and explorer/E2E behavior. Fixes were committed separately:

| Commit | Change |
|---|---|
| `0e03ec9` | Prevent pending expiry during asynchronous candidate validation from making the miner fatal. |
| `9e8453a` | Check record integrity before in-block record age, matching spec precedence. |
| `805d626` | Reject noncanonical JSONL block lines at boot and disk validation. |
| `84b0cfd` | Log only worker error codes and job IDs. |
| `ae7e368` | Enforce shared response primitives and reject unexpected fields. |
| `6951aa6` | Show Difficulty demo navigation when demo endpoints exist. |
| `386b08b` | Reject inconsistent statuses, unknown codes/states/profiles, and unsafe cursors. Share miner state names between node and browser. |
| `cea23f4` | Share demo discovery across concurrent callers and navigation; retry network failures. |
| `d8c8834` | Add external-stack browser testing and wallet lifecycle regression coverage. |
| `57e1904` | Reject contradictory `ok`/miner-health responses. |

The miner race was reproduced with deferred crypto and a clock-driven expiry through a read request. Its regression checks subsequent successful mining. Focused tests reproduced validation precedence, persistence formatting, and logging failures before their fixes. A follow-up review found no additional confirmed node lifecycle, persistence, or cancellation bug within the inspected scope.

## Automated checks

| Check | Result |
|---|---|
| Shared Vitest | 18 files, 261 tests passed |
| Node Vitest | 21 files, 199 tests passed |
| Explorer Vitest | 6 files, 69 tests passed |
| Workspace TypeScript checks | All four packages passed |
| Container builds | Both node and explorer targets passed; explorer production Vite build passed |
| Real Chromium through container nginx `/api` proxy | All five specs passed |
| Diff whitespace check | Passed |

The five browser specs cover registration and mining, check-in and both queries, real-validator tamper detection without changing the live chain, rising/falling isolated difficulty simulations followed by normal registration/check-in, and wallet reload/hide/restore with duplicate-attendance rejection. Difficulty testing clicks the actual navigation link.

Two complete external-stack runs passed at the default heavy limit of six requests/minute, including one at `d8c8834` in 3.6 minutes. After the final defensive health-response guard, all five passed again at `57e1904` in 51.5 seconds with a temporary limit of 60/minute. The higher limit only avoided repeated waits; the default-limit runs remain separate evidence. No checked-in rate-limit configuration was changed.

Commands used for application checks:

```bash
pnpm -r typecheck
pnpm --filter @conference-chain/shared test
pnpm --filter @conference-chain/node test
pnpm --filter @conference-chain/explorer test
git diff --check
```

External-stack browser mode:

```bash
CHAIN_ENABLE_DEMO_ROUTES=true EXPLORER_PORT=18080 \
  docker compose --env-file chain.env.example -p conference-review-20261107 up --build -d
E2E_EXTERNAL_URL=http://127.0.0.1:18080 pnpm --filter @conference-chain/e2e test
```

The isolated project used a new named volume, the example session catalog, demo profile, non-root containers with read-only root filesystems, and the built static explorer. Existing project data was not used. Recreating the containers also exercised loading the mined chain from their retained volume. Final image IDs:

- Node: `sha256:92da81706b58625460f3206dcf7669e84fc2225461d474c7e011e29a36620ee5`
- Explorer: `sha256:8aa0957f122e41959309e767605dbae7add25fa216f01e7d353d8d87acbdc96a`

## Additional browser checks and artifacts

On the final build with demo routes disabled and the default rate limit restored:

- The tamper probe and difficulty simulation endpoint returned HTTP 404.
- Difficulty navigation and the tamper panel were absent.
- At a 390×844 viewport with reduced motion requested, document width was 390px, with no page overflow.
- Dark theme persisted through reload.

Real browser screenshots and a JSON check summary are retained locally under the ignored `evidence/review-2026-11-07/` directory: `wallet-duplicate.png`, `mobile-dark-chain.png`, `demo-disabled-validate.png`, `browser-checks.json`, and `manifest.json`. The screenshots were captured from the actual container-served application. The manifest records source revision, image IDs, and artifact SHA-256 hashes. Artifacts are not included in a clean checkout.

The temporary Compose stack was stopped with its named test-data volume retained. No changes were pushed remotely.

## Limits

This was a bounded review and local container/browser validation, not an exhaustive proof or public-host deployment test. Each full page reload still spends one heavy-request unit discovering demo availability; SPA navigation shares the cached result. Repeated reloads can therefore delay a demo under the default limit. Instructor confirmation of the identifier design remains separate from software validation, as documented in SPEC U1.
