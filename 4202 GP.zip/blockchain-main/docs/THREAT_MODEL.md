# Threat Model — Conference Registration Blockchain

Companion to `docs/SPEC.md`. Method: asset and trust-boundary analysis, then STRIDE per component. Scope: single-node deployment (API + miner + explorer), coursework and portfolio demo. Residual risks are listed explicitly instead of hidden.

## 1. System summary

- Attendees hold RSA-2048 key pairs in the browser. They sign registrations and attendance certificates.
- The node validates signed records, queues them in a mempool, mines blocks (SHA-256 PoW, dynamic difficulty), persists to `data/chain.jsonl`, and serves queries.
- The explorer is a read-mostly web UI plus wallet flows (key generation, signing).
- There is no P2P network, no fork choice, no tokens.

## 2. Assets

| ID | Asset | Why it matters |
|---|---|---|
| AS1 | Attendee private keys | Anyone holding one can act as that attendee |
| AS2 | Chain integrity (blocks, links, PoW) | The audit trail is the product |
| AS3 | Attendance record truth | Records must reflect who actually attended |
| AS4 | Attendee pseudonymous data (`attendeeId`, alias, attendance history) | No email or real name is collected, but the data is pseudonymous and linkable, not anonymous: `attendeeId` is a persistent identifier, an alias can identify its owner, attendance history reveals behaviour, and the chain is immutable |
| AS5 | Node availability | Demo and hosted site must stay up |
| AS6 | Chain file `data/chain.jsonl` | Persistence and restart integrity |

## 3. Actors

- **Honest attendee**: registers and checks in.
- **Malicious attendee**: tries to forge, replay, impersonate, or claim attendance they did not earn.
- **Anonymous internet user**: can reach the public API and explorer.
- **Malicious web content**: XSS or a hostile page targeting the explorer origin.
- **Node operator / host admin**: can read and modify files on the host. Assumed to be one of the two group members (trusted but fallible).
- **Organizer**: queries records. No special write power in v1.

## 4. Trust boundaries

1. Browser to API (untrusted input crosses here).
2. API process to disk (`chain.jsonl`).
3. Explorer origin to the rest of the web (XSS surface, key storage).
4. Demo endpoints (`/demo/*`) to production: opt-in via `ENABLE_DEMO_ROUTES=true`, default off, boot refuses it with `PROFILE=production`.
5. Main thread to worker threads (mining, tamper-check): messages are typed and the main thread re-validates every mined block.

## 5. Threats and mitigations (STRIDE)

Status: **M** = mitigated by spec, **P** = partially mitigated, **R** = residual, accepted and documented.

### Spoofing

| # | Threat | Mitigation | Status |
|---|---|---|---|
| S1 | Attacker submits attendance for another attendee | Attendance must carry a valid RSA signature from the key registered under `attendeeId` | M |
| S2 | Attacker registers an alias that impersonates someone | Registration proves key possession only; alias is a free pseudonymous label with no identity meaning. UI states this | R |
| S8 | Attendance verified against a key supplied by the attacker, or against a registration still in the mempool | The key is looked up from an earlier confirmed registration only; `ATTENDEE_NOT_REGISTERED` precedes signature verification. Test RC3b | M |
| S3 | Attacker registers with a victim's public key | Registration is self-signed, so they cannot sign without the private key. Duplicate key rejected | M |
| S4 | `attendeeId` forged to collide | `attendeeId = sha256(SPKI)` is derived and checked on every record | M |
| S5 | Same key registered twice via different DER or base64 encodings (duplicate bypass) | Keys must be 2048-bit RSA, e=65537, canonical DER round trip; strict base64. One key has one encoding. Test 3 | M |
| S6 | Weak or malformed key (small modulus, odd exponent) accepted | `INVALID_KEY` on anything outside the fixed parameters | M |
| S7 | Signature replayed on another deployment of the same protocol | `chainId = hash(protocol, conferenceId, consensus params)` is inside every signed payload (genesis hash is NOT used: it is identical across deployments of one profile). Holds only if deployments use distinct `conferenceId`; same id and params share a `chainId` (residual). Tests RC4, A2 | P |

### Tampering

| # | Threat | Mitigation | Status |
|---|---|---|---|
| T1 | Edit a past record or block | Hash links plus PoW. `validateChain` fails with the exact block index | M |
| T2 | Edit a block and recompute its hash | Next block's `previousHash` breaks. Attacker must re-mine all later blocks | M |
| T3 | Operator deletes valid records and re-mines the chain (censorship) | Single node has no peers to compare against. Removing a valid attendance record and re-mining later blocks keeps all remaining signatures valid, so `validateChain` accepts it (RC3 / A7). EDITING a record is always detected: its signature fails (`INVALID_SIGNATURE`). Hash links plus PoW are tamper-evident, not distributed consensus. Report may suggest publishing the head hash outside the node | R |
| T9 | Chain becomes invalid with the passage of time (validator reads wall clock) | Historical validation never reads the clock; submission and in-block validators are separate. Test A5 advances the clock a year | M |
| T10 | Modified genesis or genesis from another profile loaded | Genesis regenerated from config and compared, never trusted from the file. Test A6. Genesis is the same across deployments of one profile, so it gives no deployment identity | M |
| T4 | Modify payload after signing (change `sessionId`, timestamp) | All fields are inside the signed canonical bytes. Any change fails verification | M |
| T5 | Ambiguous serialization lets two different payloads share one signed byte string | Single `canonicalize` path, strict schemas (`.strict()`), integers only | M |
| T6 | Miner picks easy difficulty | `validateChain` recomputes `nextDifficulty` and rejects mismatches | M |
| T7 | Manipulated timestamps to game difficulty | Only these bounds exist: non-decreasing versus parent (consensus), `now + maxBlockSkewMs` for a node's own new blocks (admission only), record-vs-block age (consensus). NO historical upper bound. Protection that holds: difficulty moves at most one step per boundary and stays in `[min, max]`. An operator controlling timestamps can steer difficulty over several intervals. Test RC7/A8 asserts exactly this and no more | P |
| T11 | Two registrations of the same key in one block, or concurrent identical submissions, both pass | Async integrity check runs before the lock; state rules plus mempool-index insert run synchronously inside the writer lock; both validators include earlier records of the same block. Tests A1, 13 | M |
| T13 | Editing `sessions.json` retroactively invalidates history or changes boot validation | Catalog is an admission policy only; `validateRecordInBlock` and `validateChain` never read it. Test RC5 | M |
| T14 | Sync mining loop cannot be aborted by message, blocking head updates or shutdown | Mining worker is cancelled by `terminate()`; stale results ignored by `jobId`. Test RC6 | M |
| T15 | Browser/Node crypto mismatch produces unverifiable signatures | Async `IdentityCrypto` shared contract; sync `HashFn` Node-only; interop and equality tests RC2, 16 | M |
| T12 | Attendance accepted with registration in the same block or only in mempool | Registration must be in an earlier confirmed block. Test 5 | M |
| T8 | Corrupt `chain.jsonl` | Startup runs `validateChain` and refuses to boot with an error code. No silent repair | M |

### Repudiation

| # | Threat | Mitigation | Status |
|---|---|---|---|
| R1 | Attendee denies having checked in | Signed certificate in an immutable block is non-repudiable, assuming the key was not stolen | M |
| R2 | Organizer disputes a record | Block detail shows signature, signer key, block hash, PoW verification | M |

### Information disclosure

| # | Threat | Mitigation | Status |
|---|---|---|---|
| I1 | Public, permanent, pseudonymous records enable OSINT correlation and profiling | Reduced, not removed. No email, real name, commitment or pepper is collected; identity is `attendeeId = sha256(public key)` plus a free alias. Remaining risks: persistent identifier makes attendance linkable across sessions, an alias can identify its owner, public Q1/Q2, and the immutable chain cannot honour deletion or retention limits. Mitigations: UI alias warning, fresh key per conference, demo data only. Tests RC1, RC12 | P |
| I6 | (removed) Email commitment brute force | Not applicable: the email/HMAC design was dropped (RC1) | — |
| I7 | Alias or `attendeeId` correlated across sessions to profile someone | Records are pseudonymous by design. A user who picks a real-name alias exposes themselves, so the UI warns. A fresh key per conference limits linkage | R |
| I2 | Private key leaves the browser | Key generated and used client-side only. Server never receives private keys. Non-extractable WebCrypto `CryptoKey` stored in IndexedDB (not localStorage). This prevents export, not use: script running in the page (XSS) can still sign, so residual risk E2 stays | P |
| I3 | Secrets or bodies in logs | Never log request bodies, keys, signatures. Structured logs with error codes only | M |
| I4 | Stack traces in responses | Generic error body with code only | M |
| I5 | (removed) Email enumeration / HMAC oracle | Not applicable: no email field exists and `/registrations/prepare` does not exist. Test RC1 asserts both | — |
| I8 | Extra personal fields smuggled through request bodies into blocks or logs | `.strict()` schemas reject unknown fields; bodies are never logged; test 12 | M |

### Denial of service

| # | Threat | Mitigation | Status |
|---|---|---|---|
| D1 | Flood write endpoints | Rate limit (30/min writes), 16 KB body cap, `MAX_RECORDS_PER_BLOCK`, mempool capped at `MEMPOOL_MAX_RECORDS` with TTL (`MEMPOOL_FULL`). Test 11 | M |
| D7 | Expensive `/chain/validate` and `/demo/tamper-check` abused as CPU DoS | 6/min rate limit, run in a worker one at a time, results cached by `chainId + headHash` (tamper-check: plus `mutation` + `blockIndex`), bounded to 64 entries, demo routes off by default, mutation inputs bounded | P |
| D8 | `/demo/difficulty-simulation` with huge count or interval, or used to corrupt live timestamps | `count` 1..30, `intervalMs` 0..120000, demo-only, rate limited, runs in a worker with timeout on an isolated in-memory chain. No simulated clock exists in the live node, so live timestamps cannot be contaminated. Test RC10 | M |
| D9 | Genesis timestamp (2023) skews the first difficulty window and drives difficulty to the minimum or maximum | Genesis is excluded from every timing window; first boundary is block `I + 1`. Test RC9 | M |
| D2 | Expensive verification as an attack (RSA verify per request) | Schema check first (cheap), then signature check, rate limited | P |
| D3 | Invalid-record spam filling mempool | Records validated before queueing and again at mining time | M |
| D4 | Difficulty pushed to max, making demo unusable | Per-profile `maxDifficulty` clamp (production 5, demo 4, test 3) | M |
| D6 | Synchronous PoW blocks the API event loop | Mining runs in a worker thread, cancelled by `terminate()` on shutdown, a test-only `cancelCurrentJob()`, or a stale-parent result (not by a message). Test RC6 | M |
| D10 | Cache poisoning or stale answers: a validation result served for different inputs (other mutation, other block, other head) or shared with the simulation | Cache keys contain every result-relevant input (`chainId + headHash [+ mutation + blockIndex]`), caches are bounded and cleared on head change, and the difficulty simulation is never cached. Test RC14 | M |
| D11 | Record loss, stale block append, or a corrupt chain file across mempool, miner crash, cancel and failed persistence | Explicit record lifecycle (`pending`, `reserved`, `confirmed`, `expired`, `rejected`); append only for the current job and current head; non-cancellable `persisting` phase; on append/fsync failure the file is truncated back to the recorded offset and verified, else the node goes `fatal` (fail closed, never resumes mining); torn last line refuses boot; exclusive `DATA_DIR` lock. Mempool loss on node restart is an accepted limitation. Test RC13 | P |
| D12 | A tamper demo that silently changes nothing and reports a false "detected" result | Mutations must differ from the original and stay schema-valid, else 400 or `INTERNAL`. Test RC15 | M |
| D13 | `/chain/validate` reports `ok` for a chain that differs on disk from memory, or reads a file mid-append | Validation runs on a byte-size-bounded snapshot of the disk file and compares its head with memory (`CHAIN_STORE_MISMATCH`); cache key includes the snapshot hash and consensus config hash. Test RC14 | M |
| D14 | Honest records expire between admission and mining (clock skew + TTL + batch delay exceed the age window) | Config validation requires `maxRecordSkewMs + mempoolTtlMs + MINER_BATCH_DELAY_MS < maxRecordAgeInBlockMs`; TTL counts from admission; over-age at candidate build is `expired`. Test RC9 config checks, RC13 | M |
| D5 | Large chain slows queries | In-memory indexes by attendee and session built at boot. Pagination on lists | M |

### Elevation of privilege

| # | Threat | Mitigation | Status |
|---|---|---|---|
| E1 | `/demo/*` abused in production | Routes registered only when `ENABLE_DEMO_ROUTES=true` (default off, independent of `NODE_ENV`); boot refuses the flag with `PROFILE=production`. Test 15 | M |
| E2 | XSS steals key or acts as the user | Strict CSP, no `dangerouslySetInnerHTML`, all chain text rendered as text, non-extractable keys | P |
| E3 | Container escape or root in container | Pinned Node image tag, non-root user, read-only root filesystem except `DATA_DIR` (Dockerfile, tier 3) | P |
| E4 | Supply-chain compromise | Few dependencies, lockfile committed, pinned versions, `pnpm audit` | P |

### Application-logic threats (specific to this product)

| # | Threat | Mitigation | Status |
|---|---|---|---|
| L1 | Registered attendee claims attendance at a session they never attended (the system proves key possession, not physical presence) | v1: only registered attendees, one check-in per session, timestamp window. Optional hardening: per-session check-in code or organizer-signed session challenge included in the signed payload | R (see OD2) |
| L2 | Replay of a signature on another session | `sessionId` and `timestamp` are inside signed bytes. Duplicate `(attendeeId, sessionId)` rejected | M |
| L3 | Attendance before registration | Record validated against chain state plus earlier records in the same block | M |
| L4 | Sybil: one person registers many keys (no identity binding) | No identity proofing. Out of scope for coursework | R |
| L5 | Lost private key | No recovery. Attendee must register a new key. Stated in UI | R |

## 6. Cryptographic choices and limits

- RSA-2048 with SHA-256, PKCS#1 v1.5 signatures via `node:crypto` and WebCrypto. Chosen to match Assignment 4. Adequate for this scope.
- PKCS#1 v1.5 is older than PSS. PSS would be the production default. Switching is a localized change in `identity.ts`, the two crypto adapters and the browser wallet, and must be done together.
- SHA-256 is used for block hashes, PoW and `attendeeId`. These are integrity uses, not password hashing. MD5 and SHA-1 are not used.
- PoW here provides tamper cost and demonstrates the mechanism. With one miner it gives no security against the operator.

## 7. Open decisions

- **OD1 — Identifying data on chain. DECIDED (revised):** collect no email or real name; the remaining data is pseudonymous and linkable. Identity is `attendeeId` plus a free alias (SPEC section 5.2); the email/HMAC design was removed because the browser cannot compute a server-pepper commitment without an oracle. Open point U1 in SPEC section 18: confirm with the instructor that the slides' "unique identifier" option covers this.
- **OD2 — Presence proof.** Add a per-session check-in code signed or shared by the organizer? Recommendation: skip in v1, document L1 in the report, and add only if time remains.

## 8. Security tests to add (map to SPEC tests)

Mapped to SPEC section 14 numbering:

1. Tampered payload field fails verification for each field (A2, test 2).
2. Replay with a different `sessionId` or `chainId` fails (A2).
3. Registration with mismatched `attendeeId` rejected; extra PII fields rejected (tests 4, 12, RC1).
4. Duplicate attendance or key rejected, including concurrently and within one block (A1, test 13).
5. Edited block, edited-and-rehashed block, wrong previous hash, wrong difficulty each fail `validateChain` with the right code and index (A3, A4, test 7).
6. Unknown extra fields and non-canonical keys or base64 rejected (tests 3, 9).
7. Oversized body returns 413, rate limit 429, full mempool 503, none crash (test 11).
8. Demo routes absent unless `ENABLE_DEMO_ROUTES=true`; boot refuses the flag in production (test 15).
9. Error responses contain no stack trace and no field outside the schema appears in logs, blocks or responses (tests 11, 12).
10. Corrupted or truncated `chain.jsonl`, or foreign genesis, makes startup fail (test 14, A6).
11. Chain stays valid after a simulated year (A5); full rewrite is accepted and documented (A7).
12. Cache keys, record lifecycle, persistence fault injection and mutation guarantees (RC13, RC14, RC15); attendance key lookup precedence (RC3b); alias with bidi or zero-width characters rejected (test 9, RC3b). The RC6 stress candidate is a test-only fixture, never reachable from `src/`.

## 9. Residual risk summary

Accepted for this project: operator can censor by deleting records and re-mining (T3), timestamps only monotonic historically (T7), `chainId` unique only if `conferenceId` is unique (S7), no identity proofing (S2, L4), no proof of physical presence (L1), public pseudonymous Q1/Q2 queries with no organizer authentication, alias correlation (I7; invisible or direction-reversing alias characters are rejected, but visually similar printable aliases can still impersonate, S2), no key recovery (L5), mempool records lost on node restart (D11). Each should be stated in the report as a limitation, with the production-grade fix noted.
