# Conference Registration Blockchain — Implementation Spec

Status: v3.3 (frozen for Codex; findings from the v3.2 review applied), final consistency patch (corrections RC1-RC15, section 14.2). U1-U6 accepted at their defaults (section 18). Language: English. Scope: 2-person group. Companion: `docs/THREAT_MODEL.md`.

User-requested execution and API documentation extensions dated 2026-11-08 are specified in section 9; they preserve the v3.3 wire protocol and consensus rules.

**Implementation gate:** do not start implementation until section 19 (P0 gate) is accepted. Every P0 contract has a written acceptance test in section 14.

## 1. Goals, non-goals, priority tiers

Build a blockchain-based conference registration system with a block-explorer style web UI, runnable locally and easy to host.

Required by the assignment (1~2 student group):
- F1 Attendee information registration
- F2 Session attendance recording
- F4 Record querying (two queries: sessions attended by a participant; participants who attended a session)
- Enhancement (20%): dynamic mining difficulty

Non-goals (do NOT build):
- F3 minting with miner rewards (3~4 student scope). A minimal block + PoW miner is still required, because dynamic difficulty needs mined blocks. The miner verifies every record signature before including it.
- Peer-to-peer networking, consensus between nodes, forks, token economics. The "pending pool" is a single-node mempool; the report must justify this.
- Collecting email, real name or other directly identifying fields. The attendee identity is a public-key-derived `attendeeId` plus a pseudonymous `alias`. This reduces, but does not remove, privacy risk (section 5.2).
- Production attack tooling. Automated adversarial tests and a gated tamper demo that runs the real validator ARE in scope.
- A CLI. The web explorer plus HTTP API is the only interface.
- Any feature added only to compensate for a protocol inconsistency. Inconsistencies are fixed in the contract, not patched with new features.

Main demo path (the priority above everything else): **Register -> Mine -> Attend -> Mine -> Query -> Validate -> Dynamic Difficulty Demo.** Every section below exists to make this path work and be provable.

Priority tiers (do not reorder; a lower tier must never delay a higher one):
1. **Core (satisfies the rubric):** F1, F2, F4, blocks, PoW, dynamic difficulty, validation tests, minimal explorer (Register, Check-in, Chain, Block, Attendee, Session pages).
2. **Hardening:** adversarial tests A1-A9, remaining regression tests, tamper demo endpoint. (The difficulty simulation is tier 1: it is the 20% enhancement demo.)
3. **Optional:** Playwright e2e, ChainKey component port, difficulty chart, Dockerfile.

## 2. Stack

| Concern | Choice |
|---|---|
| Language | TypeScript, strict mode, no `any` (use `unknown` + guards) |
| Runtime | Node >= 22 |
| Workspace | pnpm workspace, version pinned via `packageManager` |
| Schemas | zod 4, used for STRUCTURAL validation only (section 5.1) |
| Crypto | RSA-2048, SHA-256, RSASSA-PKCS1-v1_5 (matches Assignment 4 which uses the `rsa` lib with SHA-256). Two separate abstractions (section 6): async `IdentityCrypto` (Node and browser) and sync `HashFn` (Node only). |
| API server | Fastify with zod validation on every input |
| Mining and validation workers | `worker_threads`, cancelled by `terminate()` (section 9) |
| Explorer UI | Vite + React |
| Browser key storage | IndexedDB holding a non-extractable `CryptoKey` (not `localStorage`) |
| Tests | vitest (unit, integration), Playwright (e2e, tier 3) |
| Packaging | One Dockerfile (tier 3), exact pinned base image tag, no `latest`, non-root user |

No other crypto or blockchain libraries. Any other dependency must be flagged before adding.

## 3. Repository layout

```
packages/shared/   schemas, canonicalization, identity, chain logic, config, crypto adapters
apps/node/         HTTP API, mempool, miner worker, persistence
apps/explorer/     web UI (Vite dev port 5173, proxies API calls to the node on port 3000)
apps/e2e/          Playwright tests (tier 3)
docs/              SPEC.md, THREAT_MODEL.md
```

`packages/shared` module split. The browser-safe set may be imported by the explorer; the Node-only set must never be imported by it.

```
Browser-safe (sync unless noted):
  schemas.ts        zod schemas, structural validation only
  canonical.ts      canonicalize()
  errors.ts         ErrorCode + ChainError
  config.ts         protocol constants, ChainConfig, profiles, Clock
  crypto.ts         types only: IdentityCrypto (async), HashFn (sync)
  identity.ts       (async) validatePublicKey, deriveAttendeeId, signPayload, verifyPayload
  crypto-browser.ts (async) WebCrypto implementation of IdentityCrypto
  difficulty.ts     nextDifficulty (no crypto)
Node-only:
  block.ts          computeBlockHash, mineBlock, verifyBlockPow, deriveChainId, makeGenesis (take HashFn)
  chain.ts          (async) state index, validators, validateChain (take ChainCrypto)
  crypto-node.ts    node:crypto implementation of IdentityCrypto and HashFn
  index.ts          re-exports (two entry points: shared/browser and shared/node)
```

Rules:
- Pure modules receive crypto as an argument and never import `node:crypto` or `crypto.subtle` directly.
- `sha256` has two definitions with distinct roles, not duplicates: `IdentityCrypto.sha256Hex` (async, for `attendeeId`, usable in the browser) and `HashFn` (sync, for block hashing and mining, Node only). Both must return identical output for identical bytes (test RC2).
- A value is defined in exactly one place. Schemas, constants, config and error codes live in `packages/shared`. Apps import them and never redeclare them.
- Scaffolding (tsconfig, scripts, Vitest config) already exists for `packages/shared`; mirror it in the apps.

## 4. Protocol constants and config profiles (`config.ts`)

Fixed protocol constants (never overridden):

```ts
export const PROTOCOL_VERSION = "conference-chain/1";
export const RSA_MODULUS_BITS = 2048;
export const RSA_PUBLIC_EXPONENT = 65537;
export const RSA_SPKI_DER_LENGTH = 294;      // canonical SPKI DER size for RSA-2048, e=65537
export const GENESIS_PREVIOUS_HASH = "0".repeat(64);
export const GENESIS_TIMESTAMP = 1_700_000_000_000;
export const MAX_RECORDS_PER_BLOCK = 50;
export const MEMPOOL_MAX_RECORDS = 1000;
```

Tunable parameters live in a `ChainConfig` chosen by profile and passed explicitly to every function that needs it. Never edit source constants to speed up a test.

| Field | production | demo | test |
|---|---|---|---|
| `initialDifficulty` / `minDifficulty` / `maxDifficulty` (leading hex zeros) | 3 / 1 / 5 | 2 / 1 / 4 | 1 / 1 / 3 |
| `targetBlockTimeMs` | 10 000 | 3 000 | 1 000 |
| `adjustmentInterval` (blocks) | 5 | 5 | 3 |
| `maxRecordSkewMs` (record time vs server time, admission only) | 300 000 | 300 000 | 5 000 |
| `mempoolTtlMs` (counted from ADMISSION time; record dropped from mempool after this) | 300 000 | 300 000 | 5 000 |
| `maxRecordAgeInBlockMs` (consensus: record time vs block time, symmetric) | 900 000 | 900 000 | 15 000 |
| `maxBlockSkewMs` (block time vs server time, admission only, upper bound only) | 5 000 | 5 000 | 1 000 |

Difficulty 6 (about 16M hashes) is excluded on purpose: it can stall a demo.

`ChainConfig` also carries `conferenceId` (from env `CONFERENCE_ID`, section 9). Config validation (else boot refuses): `adjustmentInterval` is an integer `>= 2`; `minDifficulty <= initialDifficulty <= maxDifficulty`; and `maxRecordSkewMs + mempoolTtlMs + MINER_BATCH_DELAY_MS < maxRecordAgeInBlockMs` (an honest record admitted at the edge of the skew window must still be minable inside the age window; `MINER_BATCH_DELAY_MS = 1000` is a fixed constant in `config.ts`). Both listed TTL values satisfy it.

`Clock = { now(): number }`. Every function that needs "now" takes a `Clock`. Tests inject a controllable clock; no test sleeps. The live node uses only a real system clock, in every profile. There is no node-wide simulated clock: difficulty simulation runs on an isolated in-memory chain (section 8), so simulated time can never reach live timestamps.

**Deployment identity (`chainId`).** The genesis block is deterministic for a given profile, so it is NOT unique per deployment and is not used as identity. Identity is explicit:

```
chainId = sha256Hex( canonicalize({
  protocol: PROTOCOL_VERSION,
  conferenceId,                                   // /^[a-z0-9][a-z0-9-]{2,63}$/, operator-chosen
  consensus: { initialDifficulty, minDifficulty, maxDifficulty, targetBlockTimeMs,
               adjustmentInterval, maxRecordAgeInBlockMs, maxRecordsPerBlock: MAX_RECORDS_PER_BLOCK }
}) )
```

`chainId` is a field inside every signed payload. What it provides: a signature made for one conference/parameter set is rejected (`CHAIN_ID_MISMATCH`) by a deployment with a different `conferenceId` or consensus parameters. What it does NOT provide: two deployments configured with the same `conferenceId` and parameters share a `chainId`, and signatures replay between them; it also proves nothing about the operator. Operators must choose a unique `conferenceId` per deployment. Clients obtain `chainId` from `GET /chain/info`.

Genesis: block index 0, no records, `previousHash = GENESIS_PREVIOUS_HASH`, `difficulty = config.initialDifficulty`, `timestamp = GENESIS_TIMESTAMP`, nonce found by searching from 0 (deterministic). It is regenerated from config at boot and compared to the first line of the chain file by exact string equality of `canonicalize(block)`; never trusted from the file (`GENESIS_MISMATCH`). A chain file containing records signed for a different `chainId` fails at the first such record (`CHAIN_ID_MISMATCH`).

## 5. Data model (`schemas.ts`)

### 5.1 Validation layers: structural vs semantic

Two layers, never mixed:

1. **Structural (sync, `schemas.ts`, zod).** Types, regexes, lengths, ranges, `.strict()` objects, canonical base64 form. Failure code: `INVALID_SCHEMA`. Needs no crypto and can run in the browser.
2. **Semantic (async, `identity.ts` and `chain.ts`).** Anything that needs cryptography or state: RSA key parameters, DER round trip, `attendeeId` derivation, signature, `chainId` equality, uniqueness, registration order, time rules. Failure codes: `INVALID_KEY`, `ATTENDEE_ID_MISMATCH`, `INVALID_SIGNATURE`, `CHAIN_ID_MISMATCH`, and the state codes in section 7.

Structural primitives. All REJECT non-conforming input; none silently transform it (the signed bytes always equal what the client sent):
- `HexSha256`: `/^[0-9a-f]{64}$/`.
- `Base64Std`: `^[A-Za-z0-9+/]+={0,2}$`, length multiple of 4, decode-then-re-encode equals the input.
- `PublicKey`: `Base64Std` whose decoded length is exactly `RSA_SPKI_DER_LENGTH` (294). Structure only; the key is NOT known to be a valid RSA key at this layer.
- `Signature`: `Base64Std`, decoded length exactly 256 bytes.
- Two integer schemas, both requiring `Number.isSafeInteger` and `!Object.is(x, -0)` (negative zero is always invalid, including a JSON `-0` body):
  - `PositiveInt` (`>= 1`): `timestamp`, `difficulty`, `count`, `limit`.
  - `NonNegativeInt` (`>= 0`): block `index` (genesis is 0), `nonce` (0 is a valid nonce), `intervalMs` (0 is valid), `blockIndex` query values.
  Never reuse one for the other.
- `AttendeeId`: `HexSha256`.
- `SessionId`: `/^[A-Za-z0-9_-]{1,64}$/`.
- `Alias`: 1 to 50 Unicode code points, already NFC-normalized, no leading or trailing whitespace, and none of Unicode categories C (control, format such as bidi overrides U+202E and zero-width characters, unassigned, private use, surrogate), Zl or Zp (`/[\p{C}\p{Zl}\p{Zp}]/u` must NOT match). This blocks invisible or direction-reversing characters used to impersonate another alias in the explorer. Non-normalized input is rejected, not trimmed.
- All objects `.strict()`, including the `{ payload, signature }` envelope. Unknown fields such as `email` are rejected.

Semantic key validation (`validatePublicKey(publicKey, identity): Promise<boolean>`): `identity.inspectPublicKey` parses the SPKI DER as RSA and returns `{ modulusBits, publicExponent, canonicalSpki }`; valid only if `modulusBits == 2048`, `publicExponent == 65537`, and `canonicalSpki == publicKey`. Anything else (including unparsable input) returns `false` and the caller reports `INVALID_KEY`. This gives one key exactly one encoding, hence one `attendeeId`.

### 5.2 Registration (F1)

```ts
RegistrationPayload = {
  type: "register", chainId: HexSha256, attendeeId: AttendeeId,
  alias: Alias, publicKey: PublicKey, timestamp: Timestamp,
}
SignedRegistration = { payload: RegistrationPayload, signature: Signature }   // also the HTTP body
```

There is no email, name, commitment, pepper or HMAC anywhere. The assignment slides ask for "name and email (or a unique identifier)"; this system uses the permitted **unique identifier**: `attendeeId = sha256(SPKI DER bytes)`. `alias` is a pseudonymous display label; the UI warns users not to use a real name. Privacy position (do not overclaim): the protocol collects no directly identifying field, which removes the email/name leak and the HMAC machinery. The data is pseudonymous, NOT anonymous or risk-free. `attendeeId` is a persistent identifier, so a person's attendance across sessions is linkable; an alias can itself identify someone if they choose it badly; attendance history reveals behaviour; Q1/Q2 are public; and an immutable chain cannot honour deletion or retention limits. Mitigations are limited to: no PII fields, a UI warning about aliases, a fresh key per conference, and using demo data only. Trade-off in the other direction: identity is not tied to a real person (Sybil registrations are possible; threat L4).

Semantic checks for a registration (`verifyRecordIntegrity`): `chainId` equals the node's (`CHAIN_ID_MISMATCH`); `validatePublicKey` (`INVALID_KEY`); `attendeeId == sha256(publicKey bytes)` (`ATTENDEE_ID_MISMATCH`); signature verifies against `payload.publicKey`, which proves key possession (`INVALID_SIGNATURE`). Then state rules in section 7.

### 5.3 Attendance certificate (F2)

```ts
AttendancePayload = { type: "attend", chainId, attendeeId, sessionId, timestamp }
SignedAttendance = { payload: AttendancePayload, signature: Signature }
```

Signed with the attendee's private key over `canonicalize(payload)` UTF-8 bytes. `sessionId` and `timestamp` inside the signed bytes prevent replaying a signature for another session. The attendee must be registered in an EARLIER confirmed block (not the mempool, not the same block). `sessionId` is checked against the session catalog at submission only (section 7, RC5).

### 5.4 Records and blocks

```ts
ChainRecord = SignedRegistration | SignedAttendance      // discriminated on payload.type
BlockHeader = { index: NonNegativeInt, timestamp: PositiveInt, previousHash: HexSha256,
                difficulty: PositiveInt, nonce: NonNegativeInt }
Block = BlockHeader & { records: ChainRecord[] (<= MAX_RECORDS_PER_BLOCK), hash: HexSha256 }
```

- Block hash = `hash( canonicalize({ index, timestamp, previousHash, difficulty, nonce, records }) )`, with `hash` the sync `HashFn`. The `hash` field itself is excluded. Each record is the full `{ payload, signature }`.
- PoW rule: `hash` starts with `"0".repeat(difficulty)`.
- Record order inside a block = FIFO order of mempool admission. Validation replays records in that order.
- Block timestamp chosen by the miner: `max(previous.timestamp, clock.now())`.

Export TypeScript types with `z.infer`. Never hand-write a type that duplicates a schema.

## 6. Shared helpers and crypto abstractions

`canonicalize(value: unknown): string` — the only path to signed or hashed bytes:
- Objects: keys sorted by UTF-16 code unit order, no whitespace. Strings: `JSON.stringify` escaping. Arrays: order preserved. Booleans allowed.
- Zero is a valid number (`0` serializes as `0`); only `-0` is rejected.
- Rejects (throws `ChainError(INVALID_SCHEMA)`): `null`, `undefined`, non-safe-integer numbers, `-0`, `NaN`, `Infinity`, `bigint`, functions, symbols, non-plain objects.

`IdentityCrypto` (async; implemented by `crypto-node.ts` and `crypto-browser.ts`; used for identity, signatures and key checks):
- `generateKeyPair(): Promise<{ publicKey: string /* canonical base64 SPKI */, privateKey: PrivateKeyHandle }>`; `PrivateKeyHandle` is opaque (PEM string on Node, non-extractable `CryptoKey` in the browser).
- `sign(bytes: Uint8Array, privateKey): Promise<string /* base64 */>`
- `verify(bytes, signatureBase64, publicKeyBase64): Promise<boolean>`: false on any bad signature or malformed key, never throws.
- `inspectPublicKey(publicKeyBase64): Promise<{ modulusBits: number; publicExponent: number; canonicalSpki: string } | null>`: null if unparsable.
- `sha256Hex(bytes: Uint8Array): Promise<string>`.

`HashFn = (data: string | Uint8Array) => string` (sync, lowercase hex SHA-256). Implemented only in `crypto-node.ts`. Used by `block.ts`, genesis, `recordId`, `deriveChainId`, and the mining worker. Mining must be synchronous because it loops millions of times; an async hash per nonce would be unusable. The browser never mines or recomputes block hashes.

`ChainCrypto = { identity: IdentityCrypto; hash: HashFn }`, passed to `chain.ts` functions.

`identity.ts` (async): `validatePublicKey`, `deriveAttendeeId(publicKey, identity)`, `signPayload(payload, key, identity)`, `verifyPayload(payload, signature, publicKey, identity)`.

`block.ts` (sync): `computeBlockHash(block, hash)`, `mineBlock(candidate, hash, shouldAbort?, search?)` — pure loop, checks the optional `shouldAbort` callback every 10 000 attempts and returns `null` if aborted. Optional `search` assigns a nonnegative safe-integer start and positive safe-integer stride; defaults are 0 and 1, and exhaustion fails explicitly. The callback exists only for in-process unit tests; the production worker does NOT use it (it is cancelled by `terminate()`, section 9). `verifyBlockPow(block, hash)`, `deriveChainId(config, hash)`, `makeGenesis(config, hash)`.

`difficulty.ts` (sync): `nextDifficulty(chainPrefix, config)` (section 8).

`chain.ts` (async): `buildState`, `verifyRecordIntegrity`, `validateRecordAtSubmission`, `validateRecordInBlock`, `validateBlock`, `validateBlockAdmission`, `validateChain` (section 7). All results are `{ ok: true } | { ok: false, code, blockIndex? }`.

The explorer shows PoW and hash status from the server's `verification` field on `GET /blocks/:index` (computed by the node). The explorer is a thin client, not a light client; this is stated in the UI and report.

## 7. Validation contract

State index (built by replaying blocks in order, and maintained incrementally by the node):
- `registrations: Map<attendeeId, { alias, publicKey, blockIndex, timestamp }>`
- `attendance: Set<attendeeId + "|" + sessionId>`

Because the public key is canonical, `attendeeId` uniqueness is key uniqueness.

State rules (same logic in both validators):
- Registration: `attendeeId` not already registered (`KEY_ALREADY_REGISTERED`).
- Attendance: attendee registered in an EARLIER block (`ATTENDEE_NOT_REGISTERED`); `(attendeeId, sessionId)` not in `attendance` (`DUPLICATE_ATTENDANCE`).
- These checks include records earlier in the SAME block, so one block cannot contain two registrations of one key, two identical attendances, or an attendance whose registration is in the same block.

**Session catalog rule (RC5).** The session list in `SESSIONS_FILE` is an admission policy, not consensus. `UNKNOWN_SESSION` is raised ONLY by `validateRecordAtSubmission`. `validateRecordInBlock` and `validateChain` never read the catalog: they check `sessionId` structurally only. Editing or shrinking `sessions.json` therefore cannot invalidate any block already mined, nor change a boot-time chain validation.

**Integrity and error precedence.** `verifyRecordIntegrity(record, keyLookup, config, crypto)` is async and reads no mutable state except through `keyLookup(attendeeId) -> publicKey | undefined`, which the caller binds to a snapshot of CONFIRMED registrations (earlier blocks plus, in history, earlier blocks only; never the mempool and never the same block). Fixed order, first failure wins:
- `register`: (1) `chainId` equals config (`CHAIN_ID_MISMATCH`); (2) `validatePublicKey` (`INVALID_KEY`); (3) `attendeeId == sha256(publicKey)` (`ATTENDEE_ID_MISMATCH`); (4) signature over the payload using the payload's own `publicKey` (`INVALID_SIGNATURE`).
- `attend`: (1) `chainId` (`CHAIN_ID_MISMATCH`); (2) `keyLookup(attendeeId)` finds a confirmed registration, else `ATTENDEE_NOT_REGISTERED`; (3) signature verified with THAT registered key (`INVALID_SIGNATURE`).
Then the state rules (`KEY_ALREADY_REGISTERED`, `DUPLICATE_ATTENDANCE`) apply. The mempool union applies ONLY to these uniqueness checks, never to the registration lookup: an attendance whose registration is still pending is rejected with `ATTENDEE_NOT_REGISTERED`.

Two record validators (the split is mandatory). Both first call `verifyRecordIntegrity`, then apply state rules synchronously:

1. `validateRecordAtSubmission(record, state, mempoolIndex, catalog, config, clock, crypto)`: used only when a record enters the mempool. State rules run against confirmed state UNION mempool index. Also: `sessionId` in the current catalog (`UNKNOWN_SESSION`); `|clock.now() - payload.timestamp| <= config.maxRecordSkewMs` (`TIMESTAMP_OUT_OF_RANGE`); at most `MEMPOOL_MAX_RECORDS` pending (`MEMPOOL_FULL`). Concurrency: the async integrity check runs BEFORE taking the writer lock; the state rules and the mempool-index insert run synchronously inside the lock, so two concurrent identical submissions cannot both pass. Mempool records expire after `mempoolTtlMs`.
2. `validateRecordInBlock(record, block, state, config, crypto)`: used when mining and when reloading or re-validating a stored chain. MUST NOT read the current time or the catalog. Uses only block data: `|block.timestamp - payload.timestamp| <= config.maxRecordAgeInBlockMs` (`TIMESTAMP_OUT_OF_RANGE`), integrity, state rules against earlier blocks plus earlier records in this block.

Reason for the split: if historical validation read the clock or a mutable file, a valid chain could become invalid after a restart.

`validateChain(blocks, config, crypto)` — fixed check order per block, so error codes are deterministic:
1. `blocks[0]` equals the regenerated genesis byte for byte (`GENESIS_MISMATCH`).
2. For each later block, structure first: `index == previous.index + 1` (`BAD_INDEX`); `previousHash == previous.hash` (`BAD_PREVIOUS_HASH`); recomputed hash equals stored `hash` (`BAD_BLOCK_HASH`); PoW (`BAD_POW`); `difficulty == nextDifficulty(prefix, config)` (`BAD_DIFFICULTY`); `timestamp >= previous.timestamp` (`BAD_TIMESTAMP_ORDER`); `records.length <= MAX_RECORDS_PER_BLOCK` (`TOO_MANY_RECORDS`).
3. Then records, in order: each passes `validateRecordInBlock`.
4. At block admission only (a newly mined block, never on reload): `block.timestamp <= clock.now() + config.maxBlockSkewMs` (`TIMESTAMP_OUT_OF_RANGE`).

Function boundaries (no clock inside `validateChain`):
- `validateBlock(block, prefix, state, config, crypto)`: steps 2 and 3 for one block. `validateChain` calls only this.
- `validateBlockAdmission(block, prefix, state, config, clock, crypto)`: `validateBlock` plus step 4. The node calls this for a mined block; lifecycle step 3 (section 9) uses it.

## 8. Dynamic difficulty (20%)

Let `I = config.adjustmentInterval` (`>= 2`). The genesis block (index 0) has the fixed timestamp `GENESIS_TIMESTAMP` (2023) and is NEVER part of a timing window; measuring from it would make the first real block look years slow. Timing windows contain mined blocks only (index >= 1).

For the block at index `i`:
1. `i == 0` (genesis): `difficulty = initialDifficulty`.
2. Adjustment boundary: `i >= I + 1` and `(i - 1) % I == 0` (first boundary is block `I + 1`, then `2I + 1`, `3I + 1`, ...). The window is the `I` mined blocks `blocks[i - I .. i - 1]`; since `i - I >= 1` genesis is excluded by construction.
   - `actual = blocks[i-1].timestamp - blocks[i-I].timestamp` (spans `I - 1` gaps)
   - `expected = config.targetBlockTimeMs * (I - 1)`
   - `actual < expected`: previous difficulty + 1 (blocks came faster than expected)
   - `actual > expected`: previous difficulty - 1 (slower)
   - `actual == expected`: unchanged
   - clamp to `[minDifficulty, maxDifficulty]`.
3. Every other block (including block 1 and blocks `2 .. I`): difficulty equals the previous block's difficulty.

Worked example, `test` profile (`I = 3`, target 1 000 ms, expected 2 000 ms): boundaries at blocks 4 and 7. Block 4 uses window blocks 1..3 (`ts3 - ts1`); block 7 uses window blocks 4..6 (`ts6 - ts4`). Blocks 1-3 and 5-6 inherit difficulty. The gap between block 3 and block 4 is not measured (windows do not overlap).

The slides give "10 or 20 blocks" and Bitcoin's 2016 as examples ("e.g."), so the window size is a tunable parameter, not a fixed rubric number; the profiles use 5 (demo, production) and 3 (test) so the effect is visible in a short demo, and `adjustmentInterval` can be set to 10 or 20 in config with no code change. U1 (instructor confirmation) still covers this reading. The rule follows the slide literally with no dead band. A smoother Bitcoin-style ratio is a possible extension, not required.

`validateChain` recomputes this for every block, so a miner cannot choose its own difficulty.

**Timestamp rules and what they actually protect (RC7).** Exactly these bounds exist:

| Bound | Where enforced | Value |
|---|---|---|
| Block lower bound | consensus (historical) | `timestamp >= previous.timestamp` (equal allowed) |
| Block upper bound vs wall clock | admission of a new block only | `timestamp <= now + maxBlockSkewMs` |
| Block upper bound in history | NONE | a far-future but non-decreasing timestamp validates |
| Record vs block time | consensus (historical), symmetric | `abs(block.timestamp - payload.timestamp) <= maxRecordAgeInBlockMs` |
| Record vs wall clock | admission only | `abs(now - payload.timestamp) <= maxRecordSkewMs` |

Consequences, stated honestly:
- Timestamps are miner-chosen and, historically, only monotonic. Anyone who controls the chain data (the operator) can steer difficulty by choosing timestamps, for example equal timestamps give `actual = 0` and +1 at each boundary until `maxDifficulty`.
- The protection that DOES hold: the difficulty can move by at most one step per adjustment boundary and never outside `[minDifficulty, maxDifficulty]`; and a node's own new blocks cannot be dated more than `maxBlockSkewMs` ahead of its clock.
- There is no historical upper bound on block timestamps. No median-time-past rule is implemented either (not required by the rubric). Listed as an accepted limitation.

The live miner uses wall-clock timestamps (`max(previous.timestamp, clock.now())`).

Testing without waiting: build chains with chosen timestamps in the `test` profile and assert `nextDifficulty`. No test sleeps.

**Difficulty simulation (isolated).** With demo routes enabled, `POST /demo/difficulty-simulation` builds a brand-new in-memory chain from the profile's genesis, mines `count` empty blocks with synthetic timestamps `GENESIS_TIMESTAMP + k * intervalMs` for block `k` (so `intervalMs = 0` gives equal timestamps), runs `validateChain` on the result (no clock is involved), and returns the blocks and each adjustment (`atIndex`, `actualMs`, `expectedMs`, `from`, `to`). A small `intervalMs` shows difficulty rising, a large one shows it falling. The simulation:
- never reads or advances the live clock, never touches the live chain, mempool, writer lock or `chain.jsonl`;
- runs in the validation worker (one at a time, 30 s timeout, rate limited) and is discarded after the response;
- cannot affect any live timestamp, so ordinary registration, attendance and mining continue unchanged before, during and after it (test RC10).

**Synthetic vs real (state this in the demo and the report).** The simulation uses synthetic timestamps to show the algorithm instantly; block time there stands in for network hash rate and nothing is "measured". Real mined-block behaviour is shown separately: in the `demo` profile the explorer's blocks table has a difficulty column, and submitting records in batches shows the live chain's difficulty respond to the actual wall-clock spacing of blocks (bounded by the `demo` profile range 1..4). Neither one replaces the other; the report must label which is which.

## 9. Node behavior

Environment variables (all validated at boot; any invalid value refuses to start with an error code):

| Var | Default | Notes |
|---|---|---|
| `PROFILE` | `production` | `production`, `demo` or `test` |
| `CONFERENCE_ID` | required | `/^[a-z0-9][a-z0-9-]{2,63}$/`; feeds `chainId` |
| `PORT` | `3000` | |
| `DATA_DIR` | `./data` | holds `chain.jsonl` |
| `SESSIONS_FILE` | `./sessions.json` | `[{ "id": SessionId, "title": string }]`; must parse at boot; admission catalog only |
| `ENABLE_DEMO_ROUTES` | `false` | must be exactly `true` to register `/demo/*`; independent of `NODE_ENV`. Boot refuses if `PROFILE=production` and this is `true`. |

Mining (executable cancellation, RC6):
- `mine-worker.ts` is a plain synchronous worker. It receives ONE message `{ jobId, candidate, nonceStart?, nonceStride? }`, runs `mineBlock` on the assigned lane (no abort callback, no abort message, because a synchronous loop never reads its message queue), and posts `{ jobId, block }`.
- Cancellation is done by the main thread: `worker.terminate()`, then a fresh worker is spawned for the next job. `terminate()` stops the worker thread even inside a tight loop.
- `Miner` takes a `workerFactory` (real `mine-worker` by default, a double in tests) and exposes an internal, unrouted `startJob(candidate)` used by tests to submit a fixture candidate; production code only builds candidates from the mempool.
- A job is cancelled on shutdown, on a test-only `cancelCurrentJob()`, or when a result would be stale (rules in the record lifecycle below).
- The main thread tracks `currentJobId`. A result whose `jobId` differs from `currentJobId` is ignored (a worker may post just before it is terminated).
- Unexpected worker `error`/`exit` (not caused by us): restart with exponential backoff (1 s, 2 s, ... max 30 s); `/health` reports `miner: "restarting"`. No record is lost (lifecycle below).
- A mining job starts when the mempool is non-empty, after a 1 s batching delay, taking up to `MAX_RECORDS_PER_BLOCK` records in admission order. The live chain never contains empty blocks; difficulty demonstration uses the isolated simulation (section 8).
- Mempool admission and block append are serialized under one writer lock.

**Execution extension (user-requested, 2026-11-08).** The frozen consensus, genesis, record schemas and persistence contract remain unchanged. `MINING_BACKEND=cpu` and `MINING_WORKERS=1` preserve the default execution path. `MINING_WORKERS` accepts 1..32; a pool assigns worker i the disjoint lane i, i+N, i+2N, ... . The pool independently checks the candidate, canonical CPU hash, PoW and winning lane, and awaits every child termination before publishing a result. It does not promise the globally smallest nonce. Genesis still searches deterministically from zero without the pool.

`MINING_BACKEND=metal` explicitly selects the native macOS Metal SHA-256 helper. Startup executes a known CPU/GPU vector before acquiring the data lock; unavailable or broken Metal refuses startup with no CPU fallback. `METAL_BATCH_SIZE` accepts 1..65536 (default 16384). Each helper hashes canonical prefix + ASCII decimal nonce + suffix, and the main process verifies the winning block with the shared CPU implementation. Multiple helpers share the same GPU. Cancellation terminates the native process and awaits exit, with a bounded grace period before SIGKILL; it does not claim instantaneous cancellation inside a dispatched GPU batch. Validation/demo workers retain the original worker-thread contract. Tests: shared block nonce-lane tests, node `multi-worker.test.ts`, `metal-worker.test.ts`, and `mining-env.test.ts`; real GPU tests require `RUN_METAL_TESTS=true`. See [Metal mining](METAL_MINING.md) and [profiler evidence](MINING_PERFORMANCE.md).

**API documentation extension (2026-11-08).** Read-only `GET /openapi.json` serves OpenAPI 3.1 and `GET /docs` serves self-hosted Swagger UI and local assets. Relative URLs support the explorer's `/api` proxy. Demo operations appear only when enabled. No authentication or consensus behavior is added by documentation; its interactive requests use the existing routes and rate limits. Tests: `api-docs.test.ts` and browser test 23.

**Record lifecycle (atomic transitions).** Mempool state is in memory only. Each admitted record is in exactly one state:

| State | Meaning |
|---|---|
| `pending` | in the mempool, not part of a running job |
| `reserved(jobId)` | in the mempool and part of the running job's snapshot; still counted by the admission index, so duplicates are rejected while mining |
| `confirmed` | in an appended block (terminal) |
| `expired` | dropped by `mempoolTtlMs` while `pending` (terminal) |
| `rejected(code)` | failed `validateRecordInBlock` at candidate build or re-validation (terminal; the code is kept for `GET /records/:id`) |

Transitions (each is one synchronous critical section under the writer lock; no `await` inside):
1. Admit: `none -> pending` (after the async integrity check, then state rules + index insert).
2. Start job: `pending -> reserved(jobId)` for the snapshot (up to `MAX_RECORDS_PER_BLOCK`, admission order). Records stay in the mempool storage; `parentHash`, `parentIndex` and `jobId` are recorded on the job. Records failing `validateRecordInBlock` at this step go `pending -> rejected(code)`.
3. A job result is classified first:
   - `result.jobId != currentJobId` (stale): discard, NO state change.
   - `jobId` matches but `block.previousHash != head.hash` or `block.index != head.index + 1`, or the block's records are not exactly the reserved snapshot: treat as a cancel (step 5): job cleared, `reserved -> pending`, a new job is scheduled.
   - `jobId` matches and parent and snapshot are right: `validateBlockAdmission` runs (clock is the live clock); on failure go to step 6.
   - All pass: step 4.
4. Persist (fail-closed). Miner state becomes `persisting(jobId)`, which is NON-CANCELLABLE: `cancelCurrentJob()` is deferred until it ends, and shutdown awaits it. Procedure: take the exclusive process lock on `DATA_DIR` (acquired at boot, see below); record the current file size `offset`; append the block line; `fsync`. On success, one synchronous critical section updates the in-memory chain and state index, removes the records from the mempool, sets `reserved -> confirmed`, clears the job. On any append or fsync failure: `ftruncate(offset)`, `fsync`, verify the file size equals `offset`; only if that rollback succeeds do the records return `reserved -> pending` and the miner enters `error` with exponential backoff before retry (the same file offset, the same records). If the rollback fails or the post-rollback check fails, the node enters `fatal`: the miner stops permanently, `/health` reports `miner: "fatal"`, write routes return 503 `MINER_UNAVAILABLE`, and the process exits non-zero after logging the code. It never returns to mining with a possibly corrupt file. A torn last line found at boot is NOT repaired: boot refuses (`CHAIN_FILE_CORRUPT`).
5. Cancel (shutdown, `cancelCurrentJob()` outside `persisting`, a stale-parent result) and worker crash: `reserved(jobId) -> pending`, job cleared, worker terminated or restarted. No record is dropped.
6. Admission or re-validation failure of a current-job result: the block is discarded; each reserved record is re-checked individually: valid ones go back to `pending`, invalid ones to `rejected(code)`. The job is cleared and the miner continues.
7. TTL is counted from admission time. Only `pending` records expire. A `reserved` record is not expired while its job runs; its TTL is re-checked when it returns to `pending`. At candidate build a record whose age against the candidate block timestamp would exceed `maxRecordAgeInBlockMs` becomes `expired` (not `rejected`): it is an honest record that waited too long.
8. Node crash or restart loses the mempool (`pending` and `reserved` records are not persisted). Clients see 404 from `GET /records/:id` and resubmit; resubmission is safe because duplicates are only rejected against confirmed state and the live mempool. This is a stated limitation.
9. Re-admission and retention. Signing is deterministic, so a resubmitted record has the same `recordId`. A record in `expired` or `rejected` may be admitted again (`-> pending`, a new epoch of the same id); `confirmed` and live (`pending`, `reserved`) ids are rejected as duplicates. Terminal statuses (`expired`, `rejected`) are kept in a bounded LRU of 10 000 entries; beyond that `GET /records/:id` returns 404. `confirmed` status is derived from the chain index and is not evicted.

MinerState (defined once, reported by `/health`): `idle | mining | persisting | restarting | error | fatal`. Transitions: `idle -> mining` (job starts); `mining -> persisting` (valid result); `persisting -> idle` (success); `persisting -> error -> idle` (rollback ok, retried after backoff); `persisting -> fatal` (rollback failed); `mining -> idle` (cancel or discarded result); `mining -> restarting -> idle` (worker crash, backoff). `fatal` is terminal.

Process lock: boot creates `DATA_DIR/chain.lock` with exclusive create (`wx`) containing the pid; a second node on the same directory refuses to start; a stale lock is NOT removed automatically (operator removes it; documented). The lock is removed on clean shutdown.

Invariants (asserted after every step in test RC13 through a test-only `assertInvariants()`):
- I1: every admitted record is in exactly one state.
- I2: no record is both in the mempool and confirmed.
- I3: `admitted = pending + reserved + confirmed + expired + rejected`.
- I4: the chain file on disk and the in-memory chain are identical after every transition; a block is never in memory but missing from the file.
- I5: a block is appended only through step 4, and only for the current job whose parent equals the current head.
- I6: after any failed persist, the file size equals the pre-append offset, or the node is `fatal`.

Persistence is behind a small injectable `ChainStore { size(): Promise<number>; append(line): Promise<void>; fsync(): Promise<void>; truncate(offset): Promise<void> }` so tests can inject faults at each call; there is no other storage abstraction.

- Validation, tamper-check and simulation jobs run in a separate worker, one at a time, with a 30 s timeout enforced by `terminate()`. Result caching (validity-relevant inputs only):
  - `/chain/validate`: validates a consistent snapshot of the DISK file (below). Cache key `chainId + configHash + sha256(snapshot bytes)` where `configHash = sha256Hex(canonicalize(consensus params))`; an edit to the file therefore misses the cache.
  - `/demo/tamper-check`: cache key `chainId + configHash + headHash + mutation + blockIndex`. Any missing component is a cache miss.
  - `/demo/difficulty-simulation`: NEVER cached and never shares a cache with the others.
  - Caches are in memory, bounded to 64 entries (oldest evicted), and cleared whenever the head changes.

Persistence (`DATA_DIR/chain.jsonl`):
- One line per block: `canonicalize(block) + "\n"`. Append, then `fsync`, then update in-memory state.
- At boot: regenerate genesis and compare line 0 byte for byte, then `validateChain` with the historical validator (no clock, no catalog). A truncated or unparsable last line, invalid chain, genesis mismatch or `chainId` mismatch: refuse to start, print the error code and block index. Never repair silently.
- A valid chain stays valid after any amount of real time passes, and after any edit to `sessions.json` (tests A5, RC5).

## 10. HTTP API (`apps/node`)

All bodies are validated with schemas from `packages/shared` and body size is capped at 16 KB (`BODY_TOO_LARGE`, 413). Rate limits per IP: writes 30/min, `/chain/validate` and `/demo/*` 6/min (`RATE_LIMITED`, 429).

Error body (all errors): `{ "error": { "code": ErrorCode, "message": string } }`. No stack traces. HTTP mapping lives only in `apps/node`:
- 400: `INVALID_SCHEMA`, `INVALID_KEY`, `INVALID_SIGNATURE`, `ATTENDEE_ID_MISMATCH`, `CHAIN_ID_MISMATCH`, `TIMESTAMP_OUT_OF_RANGE`, `ATTENDEE_NOT_REGISTERED`, `UNKNOWN_SESSION`
- 404: `NOT_FOUND`; 409: `KEY_ALREADY_REGISTERED`, `DUPLICATE_ATTENDANCE`
- 413: `BODY_TOO_LARGE`; 429: `RATE_LIMITED`; 503: `MEMPOOL_FULL`, `MINER_UNAVAILABLE`; 500: `INTERNAL`, `CHAIN_STORE_MISMATCH`

| Method + path | Purpose | Request | Response |
|---|---|---|---|
| `GET /chain/info` | deployment identity for clients | | `{ chainId, conferenceId, profile, protocol }` |
| `POST /registrations` | F1 | `SignedRegistration` | `202 { recordId }` |
| `POST /attendance` | F2 | `SignedAttendance` | `202 { recordId }` |
| `GET /records/:recordId` | confirmation status | | `{ status: "pending" \| "confirmed" \| "expired" \| "rejected", blockIndex?, code? }` (`reserved` is reported as `pending`; unknown id, including after a node restart, is 404); `recordId = hash(canonicalize(signedRecord))` |
| `GET /sessions` | current catalog | | `{ id, title }[]` |
| `GET /mempool` | pending records (oldest first, max 100) | | `ChainRecord[]` |
| `GET /blocks?limit&cursor` | explorer list | | `{ blocks, nextCursor }`: newest first, `limit` default 20 max 100, `cursor` = decimal block index of the last item returned, `nextCursor` null at the end, invalid cursor 400 |
| `GET /blocks/:index` | block detail | | `Block & { verification: { hashValid, powValid } }`, 404 if missing |
| `GET /chain/validate` | re-validate whole chain from the DISK file | | `{ ok, code?, blockIndex? }` |

`/chain/validate` takes a consistent snapshot: it runs in the validation worker, reads `chain.jsonl` up to the byte size recorded at request start (one `stat`, then a bounded read; bytes appended afterwards are ignored), parses it, and runs `validateChain`. Then it compares the snapshot's head hash and block count with the in-memory chain as of the same size; a difference (file edited behind the node's back) returns `{ ok: false, code: "CHAIN_STORE_MISMATCH" }`. A torn or unparsable snapshot returns the parse failure code, never a partial `ok`.
| `GET /attendees/:attendeeId` | registration status | | `{ attendeeId, alias, registeredAt, blockIndex }`, 404 if not registered |
| `GET /attendees/:attendeeId/sessions` | **Q1** | | `{ attendeeId, sessions: { sessionId, timestamp, blockIndex }[] }`, 404 if not registered |
| `GET /sessions/:sessionId/attendees` | **Q2** | | `{ sessionId, attendees: { attendeeId, alias, timestamp, blockIndex }[] }`. 404 only if the session is neither in the current catalog NOR present in any attendance record on chain; otherwise 200 (empty list if none) |
| `GET /health` | liveness and miner state | | `{ ok, miner, headIndex, profile }` |
| `POST /demo/difficulty-simulation` | demo only, isolated in-memory chain (section 8) | `{ count: PositiveInt 1..30, intervalMs: NonNegativeInt 0..120000 }` | `{ valid, blocks: { index, hash, difficulty, timestamp }[], adjustments: { atIndex, actualMs, expectedMs, from, to }[] }` |
| `POST /demo/tamper-check` | demo only | `{ mutation, blockIndex: NonNegativeInt }` | `{ ok, code?, blockIndex?, note }` |

Q1 and Q2 are public (no organizer authentication); this is a stated limitation. Responses contain only pseudonymous data (alias, attendeeId, session, time). No query by email or name exists because neither is collected.

`/demo/tamper-check` copies the live chain in memory, applies one mutation in a worker, runs the real `validateChain`, and never touches the live chain or file. `blockIndex` must satisfy `1 <= blockIndex < chain length`, else 400.

Record-type-aware edit (`mutateFirstRecord`, shared by `edit-record` and `rehash-after-edit`). It never assumes a field exists; it switches on `payload.type` of the FIRST record in the block:
- `register`: set `payload.alias` to `"tampered"`; if the current alias already equals `"tampered"`, use `"tampered2"`.
- `attend`: set `payload.sessionId` to `"tampered"`; if it already equals `"tampered"`, use `"tampered2"`. Both values are structurally valid, so the failure is signature/hash, not schema.
- Post-condition (checked inside the function, throws `INTERNAL` if violated): `canonicalize(mutated) !== canonicalize(original)` and the mutated record still passes the structural schema. A mutation that changes nothing must never be reported as a tamper result.
- A block with no records is rejected with 400 `INVALID_SCHEMA`.

The other mutations obey the same rule (a no-op is a 400, never a result):
- `edit-previous-hash`: replace the first hex character with a different one (`"0"` becomes `"1"`, anything else becomes `"0"`); the result differs and is still a valid `HexSha256`.
- `lower-difficulty`: requires the block's required difficulty to be `> minDifficulty`; the new difficulty is `required - 1`. Otherwise 400 `INVALID_SCHEMA`.
- `delete-record-and-remine`: requires an attendance record in the block (below).

Mutations (expected results are asserted by tests A3, A7, RC11):
- `edit-record`: apply `mutateFirstRecord` and leave the hash alone. Expect `BAD_BLOCK_HASH` at that index.
- `edit-previous-hash`: change `previousHash`. Expect `BAD_PREVIOUS_HASH` at that index.
- `rehash-after-edit`: apply `mutateFirstRecord` and re-mine ONLY that block so its hash and PoW are valid. Expect `INVALID_SIGNATURE` at that index (the edited record's signature no longer matches), for both record types.
- `lower-difficulty`: set the block's difficulty lower than required and re-mine only that block. Expect `BAD_DIFFICULTY` at that index.
- `delete-record-and-remine`: remove the last attendance record from the block, fix every later `previousHash` and re-mine blocks `blockIndex..head`. The block must contain an attendance record and at most 10 blocks may need re-mining, else 400; profile `demo` or `test` only. Remaining signatures stay valid. Expect `ok: true` with a `note`: a local hash chain plus PoW is tamper-evident, not distributed consensus, so whoever controls the data can censor records undetectably unless the head hash is anchored outside the node.

## 11. Error codes (`errors.ts`)

`INVALID_SCHEMA`, `INVALID_KEY`, `INVALID_SIGNATURE`, `ATTENDEE_ID_MISMATCH`, `CHAIN_ID_MISMATCH`, `KEY_ALREADY_REGISTERED`, `ATTENDEE_NOT_REGISTERED`, `DUPLICATE_ATTENDANCE`, `UNKNOWN_SESSION`, `TIMESTAMP_OUT_OF_RANGE`, `BAD_PREVIOUS_HASH`, `BAD_BLOCK_HASH`, `BAD_POW`, `BAD_DIFFICULTY`, `BAD_INDEX`, `BAD_TIMESTAMP_ORDER`, `GENESIS_MISMATCH`, `TOO_MANY_RECORDS`, `NOT_FOUND`, `BODY_TOO_LARGE`, `RATE_LIMITED`, `MEMPOOL_FULL`, `MINER_UNAVAILABLE`, `CHAIN_FILE_CORRUPT` (boot only), `CHAIN_STORE_MISMATCH`, `INTERNAL`.

`TIMESTAMP_OUT_OF_RANGE` covers admission record skew, block admission skew, and in-block record age. Codes are defined once here.

## 12. Explorer UI (`apps/explorer`)

Pages:
- **Chain**: latest blocks (index, hash prefix, record count, difficulty, time), mempool above.
- **Block detail**: header, records, previous and next links, server-computed hash/PoW verification.
- **Attendee**: registration status, sessions attended (Q1).
- **Session**: attendees (Q2).
- **Register**: fetch `chainId` from `GET /chain/info`; generate a key pair in the browser (WebCrypto RSASSA-PKCS1-v1_5, SHA-256, modulus 2048, e = 65537, `extractable: false` for the private key); derive `attendeeId`; ask for an alias with a warning not to use a real name; sign and POST the `SignedRegistration`. Store in IndexedDB database `wallet`, object store `keys`, record `current = { attendeeId, publicKey, privateKey: CryptoKey, alias }`. Registering again warns that the old key (and identity) is lost and replaces it only after confirmation. Non-extractable prevents key export, not use: script in the page (XSS) can still call `sign`. State this in the UI and report. No key download in v1, so no recovery.
- **Check in**: choose a session from `GET /sessions`, sign attendance with the stored key, POST it, then poll `GET /records/:recordId`.
- **Validate**: calls `/chain/validate`; a demo panel (only when demo routes are enabled) calls `/demo/tamper-check` and shows the real validator's result. The browser never fakes a failure.
- **Difficulty demo**: form for `count` and `intervalMs`, calls `/demo/difficulty-simulation` (demo routes only) and plots difficulty per block with each adjustment annotated. It is labelled "Simulation (isolated chain)" and never mixes with the live chain view. A live-chain difficulty chart is optional (tier 3).

The explorer imports only the browser-safe modules (section 3) and uses `IdentityCrypto` async calls. Browser WebCrypto and `node:crypto` must interoperate: same key format (canonical SPKI DER base64), same signed bytes (`canonicalize(payload)` UTF-8), RSASSA-PKCS1-v1_5 with SHA-256.

ChainKey reuse (tier 3): port presentation components only (layout, graph, inspector, event list). Do not port ChainKey verification semantics or its native Rust verifier; the protocol differs. All data comes from this project's API. The report and README must say which UI parts come from the existing ChainKey work and that its license permits reuse; do not present them as written from scratch.

## 13. Security requirements

- Every external input is parsed with a strict zod schema before use (structural), then checked semantically (section 5.1). Unknown fields are rejected everywhere, including the request envelopes.
- Canonical serialization is the only signing and hashing path. Verification runs over the canonical bytes of the parsed, un-transformed payload.
- Signature verification never throws for bad input; it returns false.
- Never use MD5 or SHA-1.
- No secrets, keys, signatures or request bodies in logs. Log error codes and ids only.
- No stack traces in HTTP responses.
- Demo routes are opt-in (`ENABLE_DEMO_ROUTES=true`), default off, absent in production.
- Strict Content-Security-Policy on the explorer, no `dangerouslySetInnerHTML`, all chain text rendered as text.
- Dockerfile (tier 3): pinned image tag, non-root user, read-only root filesystem except `DATA_DIR`.
- `pnpm audit` and a committed lockfile.

## 14. Tests — acceptance criteria

### 14.1 Base tests

`packages/shared` (vitest, `test` profile, injected clock):
1. `canonicalize` is stable under key reordering, rejects floats, `null`, `undefined`, `-0`, unsafe integers.
2. Sign/verify round trip passes. Changing any payload field fails verification. Malformed key or signature returns false.
3. `deriveAttendeeId` is deterministic and differs per key. Structurally valid but semantically invalid keys (not 2048-bit, `e != 65537`, non-canonical DER) are rejected with `INVALID_KEY`; wrong-length or non-canonical base64 is rejected with `INVALID_SCHEMA`.
4. Registration with mismatched `attendeeId` is rejected with `ATTENDEE_ID_MISMATCH`.
5. Attendance: unregistered attendee, registration only in the same block, duplicate `(attendeeId, sessionId)` each rejected with the right code; unknown session rejected at submission only (RC5).
6. `mineBlock` yields `verifyBlockPow` true; changing the nonce makes it false.
7. `validateChain` fails with the right code and index for: edited record, edited `previousHash`, edited hash, wrong difficulty, wrong index.
8. `nextDifficulty`: faster window raises, slower lowers, equal keeps, results clamp, non-boundary blocks keep difficulty (full window/boundary matrix in RC9).
9. Non-normalized alias (leading space, non-NFC) is rejected, not transformed. `.strict()` rejects extra fields in payloads and envelopes.

`apps/node`:
10. Full HTTP flow: `GET /chain/info`, register, attend, mine, Q1, Q2, validate, `GET /records/:id` pending then confirmed.
11. Invalid bodies return the error body shape with a code and no stack trace; oversize body returns 413; rate limit returns 429; mempool cap returns 503.
12. PII absence: a body containing `email`, `name` or `emailCommitment` is rejected with `INVALID_SCHEMA`; no block, API response or log line contains any field other than the schema fields.
13. Duplicate key is rejected across mempool and chain, and two registrations of one key cannot share one block.
14. Restart loads `chain.jsonl`; a corrupted or truncated file, or a different profile's genesis, refuses to start.
15. Demo routes: absent unless `ENABLE_DEMO_ROUTES=true`; boot refuses `PROFILE=production` with the flag.

### 14.2 Regression tests for review corrections (RC1-RC15)

Each is a vitest file; the file name is part of the contract. All use the `test` profile and an injected clock; no sleeps except where stated.

**RC1 — No email/HMAC surface** (`apps/node/test/rc1-no-pii.test.ts`; resolves review item 1)
- `POST /registrations` with a valid registration plus an extra `email` field → 400 `INVALID_SCHEMA`.
- A payload containing `emailCommitment` → 400 `INVALID_SCHEMA`.
- `GET /registrations/prepare` → 404.
- Boot succeeds with no `EMAIL_PEPPER` in the environment; setting it has no effect.
- Registering two different keys with the same alias succeeds (alias is not an identifier).
- The browser flow needs only `GET /chain/info` before signing (checked in e2e 17).

**RC2 — Async identity vs sync hashing; structural vs semantic** (`packages/shared/test/rc2-crypto-split.test.ts`; item 2)
- Static check: `packages/shared/src/{schemas,canonical,errors,config,crypto,identity,crypto-browser,difficulty}.ts` contain no import of `node:crypto`, `block`, `chain` or `crypto-node` (a test greps the source).
- `IdentityCrypto.sha256Hex(bytes)` (node adapter) equals `HashFn(bytes)` for 100 random byte arrays.
- Structural vs semantic: a 294-byte base64 string that is NOT valid DER → passes schema, `validatePublicKey` false, API code `INVALID_KEY`. A 100-byte string → `INVALID_SCHEMA` (never reaches key validation).
- `mineBlock` and `computeBlockHash` are synchronous (return non-Promise values; asserted with `!(x instanceof Promise)`).
- Browser adapter interop (e2e/explorer test 16): browser-signed registration accepted by node; node-signed payload verifies via the browser adapter.

**RC3 — A7 correctness** (`packages/shared/test/rc3-rewrite.test.ts`; item 3)
- Build a chain of ≥ 4 blocks with attendance records. Remove one valid attendance record from block k, recompute `previousHash` and re-mine blocks k..head. `validateChain` returns `ok: true`. (The signatures of the remaining records are untouched.)
- Edit the alias of a registration in block k, re-mine blocks k..head with fixed links → `INVALID_SIGNATURE` at block k. (Signatures defeat content edits even with a full re-mine.)
- Remove a registration that a later attendance depends on, re-mine everything → `ATTENDEE_NOT_REGISTERED` at the later block.
- The HTTP behaviour of `rehash-after-edit` and `delete-record-and-remine` is asserted in RC11 (`apps/node`), because `packages/shared` cannot import the node. Here only the shared `validateChain` results are asserted.

**RC3b — Integrity precedence** (`packages/shared/test/rc3b-precedence.test.ts`; review item 3)
- Attendance for an attendee registered only in the mempool or only in the same block: `ATTENDEE_NOT_REGISTERED`.
- Attendance signed by a different key than the registered one, for a registered attendee: `INVALID_SIGNATURE` (the key comes from the earlier confirmed registration, never from the payload).
- Attendance for an unknown attendee with a garbage signature: `ATTENDEE_NOT_REGISTERED` (lookup precedes the signature check).
- Registration with wrong `chainId`, invalid key, mismatched `attendeeId` and bad signature simultaneously: `CHAIN_ID_MISMATCH`; remove them one at a time and the codes follow the section 7 order (`INVALID_KEY`, `ATTENDEE_ID_MISMATCH`, `INVALID_SIGNATURE`).
- Alias with U+202E, U+200B, U+2028 or an unassigned code point: `INVALID_SCHEMA` (added to test 9 as well).

**RC4 — Deployment identity** (`packages/shared/test/rc4-chain-id.test.ts`; item 4)
- Same profile, different `conferenceId` → different `chainId`.
- Same profile, same `conferenceId` → same `chainId` (asserted and documented as the limitation).
- Different consensus parameter (e.g. `adjustmentInterval`) with same `conferenceId` → different `chainId`.
- A registration signed for chain X is rejected by chain Y with `CHAIN_ID_MISMATCH`.
- A `chain.jsonl` containing records from conference X makes a node booted with conference Y refuse to start with `CHAIN_ID_MISMATCH`.
- Genesis hashes of two different conferences with the same profile are EQUAL (documents why genesis is not the identity).

**RC5 — Session catalog is not consensus** (`apps/node/test/rc5-sessions.test.ts`; item 5)
- Admit and mine an attendance for session `s1`; then restart the node with a `sessions.json` that no longer lists `s1`. Boot succeeds, `/chain/validate` is `ok`, Q2 for `s1` still returns the attendee (200, not 404).
- Submitting a new attendance for `s1` after removal → 400 `UNKNOWN_SESSION`.
- `validateChain` called with no catalog argument validates the same chain (the function signature has no catalog parameter; asserted by a type test).
- Q2 for a session in neither catalog nor chain → 404.
- A `sessions.json` that does not parse → boot refuses to start.

**RC6 — Executable mining cancellation** (`apps/node/test/rc6-mining-cancel.test.ts`; item 6). No wall-clock assertions: every wait is on an event or promise, with one generous CI safety timeout (30 s, failure message only) that never decides pass/fail by speed.
- Stress fixture: `apps/node/test/fixtures/infeasible-candidate.ts` exports a candidate whose `difficulty` is 64 (an unreachable target). It lives ONLY under `test/fixtures`, is imported only by tests, is not a profile difficulty, is not accepted by `config.ts` (`maxDifficulty` stays within its profile range), and `validateChain`/`validateRecordInBlock` never see it. A static check asserts that no file under `src/` imports `fixtures/`.
- Event-loop and cancellation sub-tests use the REAL `mine-worker` (workerFactory default) fed through the internal `startJob(candidate)`; the stale-result and crash sub-tests use the double.
- Event-loop free: with the infeasible job running, the test awaits `GET /health` through `app.inject()` and requires it to resolve with 200 and `miner: "mining"`. Resolution at all (before the 30 s safety timeout) proves the loop is not blocked; its latency is not asserted.
- Cancellation: call `cancelCurrentJob()`; await the worker `exit` event (or the double's `terminate()` promise). Assert the job is cleared and `miner` is `idle`. No duration is asserted.
- A result message with a stale `jobId` (injected through a worker double) is ignored and does not append a block.
- A new job after cancellation starts a fresh worker and mines a difficulty-1 block successfully.
- Simulated worker crash (the double emits `error`): miner state becomes `restarting`; the restart delay uses an injected timer (fake timers), the test advances it and awaits the recovered state; mempool contents unchanged.
- Static check: `mine-worker.ts` contains no `abort` message handler.

**RC7 — Timestamp honesty** (`packages/shared/test/rc7-timestamps.test.ts`, also A8/A9; item 7)
- Admission (`validateBlockAdmission`, injected clock): block with `timestamp = now + maxBlockSkewMs` accepted; `+1 ms` rejected (`TIMESTAMP_OUT_OF_RANGE`).
- History: a chain with non-decreasing far-future timestamps (year 2100) passes `validateChain` (documents the missing historical upper bound).
- Equal timestamps for the whole chain: difficulty rises by exactly +1 per boundary and never exceeds `maxDifficulty`.
- Huge gaps: difficulty falls by exactly 1 per boundary and never goes below `minDifficulty`.
- Record age: `abs(block.timestamp - payload.timestamp)` of `maxRecordAgeInBlockMs` passes, `+1 ms` fails in both directions (record older and record newer than the block).
- Decreasing timestamp → `BAD_TIMESTAMP_ORDER` (A9).
- The documentation check (lives in the package test, see RC12): section 8 contains the exact sentence "There is no historical upper bound on block timestamps." (guards against the spec over-claiming again).

**RC8 — Integer schemas** (`packages/shared/test/rc8-integers.test.ts`; P0-1)
- Genesis (`index: 0`, `nonce: 0`) parses with the block schema and passes `validateChain`.
- `nonce: 0` and `nonce: 7` valid; `nonce: -1`, `1.5`, `2**53` invalid.
- `index: 0` valid; `index: -1` invalid. `timestamp: 0` and `difficulty: 0` invalid (positive only).
- `-0` is invalid for every integer field, including via `JSON.parse("-0")` in a request body (`INVALID_SCHEMA`).
- `POST /demo/difficulty-simulation` accepts `intervalMs: 0` and rejects `intervalMs: -0`, `-1`, `120001`; rejects `count: 0` and `31`.
- `canonicalize({ n: 0 })` returns `{"n":0}`; `canonicalize({ n: -0 })` throws.

**RC9 — Difficulty windows, genesis excluded** (`packages/shared/test/rc9-difficulty-windows.test.ts`; P0-2). Use the `test` profile (`I = 3`, expected window 2 000 ms) and chains built with chosen timestamps:
- Genesis timestamp is 2023; block 1 is dated 2026 and blocks 1..3 are exactly 1 000 ms apart. Block 4 keeps the difficulty (it does NOT fall). Fails if the window includes genesis.
- No adjustment at blocks 1, 2, 3 (inherit); first adjustment is exactly block 4 (`I + 1`); next exactly block 7 (`2I + 1`); blocks 5, 6, 8, 9 inherit.
- Block 4 window is `ts3 - ts1`; block 7 window is `ts6 - ts4` (assert by changing only `ts4` or `ts3` and observing which block's difficulty changes).
- `actual = 1 999` raises (+1), `2 000` keeps, `2 001` lowers (-1).
- Clamp at `minDifficulty` and `maxDifficulty`; `adjustmentInterval = 1` fails config validation; so does `initialDifficulty` outside `[min, max]`, and `maxRecordSkewMs + mempoolTtlMs + MINER_BATCH_DELAY_MS >= maxRecordAgeInBlockMs`; all three shipped profiles pass.
- `validateChain` rejects a block carrying the wrong difficulty at a boundary and at a non-boundary (`BAD_DIFFICULTY`).
- Same assertions run once with `I = 5` (demo) to guard against hard-coded 3.

**RC10 — Simulation isolation** (`apps/node/test/rc10-simulation-isolation.test.ts`; P0-3)
- Setup: demo profile node with injected live clock, one registered attendee and one mined block.
- Run `POST /demo/difficulty-simulation` with `intervalMs: 0` (difficulty rises), then with `intervalMs: 120000` (falls). Responses have `valid: true` and the expected adjustments.
- After each run: live head index and hash, mempool contents, and `chain.jsonl` bytes are unchanged; the injected live clock's `now()` was never called by the simulation handler (spy count unchanged).
- Ordinary flow still works afterwards: register a new attendee, mine, attend, mine; both new blocks have timestamps within `[previous.timestamp, liveClock.now() + maxBlockSkewMs]` and nowhere near `GENESIS_TIMESTAMP + k * intervalMs`; Q1 and Q2 return the new records; `/chain/validate` is `ok`.
- Concurrency: a live registration submitted while a simulation is running is admitted and mined normally.
- The route is absent when `ENABLE_DEMO_ROUTES` is not `true`; no `DemoClock` symbol exists in the code base (grep).

**RC11 — Record-type-aware tamper mutations** (`apps/node/test/rc11-mutations.test.ts`; P1-1)
- Block containing only a registration: `edit-record` -> `BAD_BLOCK_HASH`; `rehash-after-edit` -> `INVALID_SIGNATURE`.
- Block containing only an attendance: same two results (no crash from a missing `alias`).
- Mixed block: the mutation applies to the FIRST record by type, and the result codes are as above.
- Empty block or `blockIndex` 0 or beyond head -> 400.
- `delete-record-and-remine` on a block with no attendance record -> 400; on a block with one -> `ok: true`.
- The live chain bytes are identical before and after every call.
- `rehash-after-edit` returns `INVALID_SIGNATURE` at that index; `delete-record-and-remine` returns `ok: true` with a non-empty `note` (moved from RC3).

**RC12 — Privacy claims agree across documents** (`packages/shared/test/docs-rc7-rc12.test.ts`, which reads `../../../docs/*.md`; P1-2; holds the RC7 sentence check and the RC12 scan so a vitest run picks them up)
- Neither `SPEC.md` nor `THREAT_MODEL.md` contains an overclaim: claims that the system has no personal data, no personal information, nothing to leak, or is free of privacy risk (case-insensitive regexes kept in the test file only, so the scan cannot match its own description). The scan is sentence-level and skips a sentence that contains a negation word ("not", "never", "no claim") before the matched phrase, so statements such as "not anonymous" or "not risk-free" pass.
- Both documents contain the words "pseudonymous" and "linkable", and SPEC section 5.2 and THREAT_MODEL I1 both mention that the chain is immutable so deletion/retention limits cannot be honoured.
- THREAT_MODEL I1 status is not `M`.

### 14.3 Adversarial and historical tests (tier 2)

- **A1 Replay:** submit the exact same signed attendance twice, sequentially and concurrently (parallel requests). Exactly one is accepted. It is also rejected once confirmed in a block.
- **A2 Signature tampering:** change `sessionId`, `timestamp`, or `attendeeId` but keep the old signature: `INVALID_SIGNATURE` (or `ATTENDEE_ID_MISMATCH` when `attendeeId` no longer matches the key). A signature made for a different `chainId` is rejected with `CHAIN_ID_MISMATCH`.
- **A3 Chain tampering:** edit a record, `previousHash`, or a block hash: `validateChain` fails with the right code and index.
- **A4 Difficulty bypass:** a block valid for a lower difficulty than `nextDifficulty` requires gets `BAD_DIFFICULTY`; insufficient PoW gets `BAD_POW`.
- **A5 Historical validity:** build a chain with the injected clock, advance the clock one year, reload from the file: still valid. Fails if any historical check reads wall-clock time.
- **A6 Genesis:** modified genesis or another profile's genesis is rejected at load.
- **A7 Rewrite limits:** covered by RC3. Result: deleting a valid record and re-mining is accepted (censorship undetectable locally); editing a record is always detected by its signature.
- **A8 Timestamp manipulation:** covered by RC7; asserts only the bounds in the section 8 table, not stronger protection.
- **A9 Bad ordering:** block timestamp earlier than its parent → `BAD_TIMESTAMP_ORDER`.

### 14.4 Explorer and end-to-end

`apps/explorer`:
16. Interop: browser-signed registration accepted by the node; node-signed payloads verify in the browser adapter and the reverse (identical canonical bytes). The IndexedDB wallet survives reload and `exportKey` on the private key throws.

End-to-end (Playwright, tier 3, real node plus explorer, temp `DATA_DIR`, `demo` profile, demo routes on):
17. Register in the UI (uses `GET /chain/info`), wait for the block, Attendee page shows registered.
18. Check in, then Q1 and Q2 both show the record.
19. Tamper demo returns a real-validator failure with the right block index and leaves the live chain unchanged.
20. Difficulty demo with `intervalMs = 0` shows rising difficulty and with `120000` falling difficulty; afterwards registering and checking in still works and the live chain is unchanged.

**RC13 — Record lifecycle and atomic transitions** (`apps/node/test/rc13-lifecycle.test.ts`; GPT item 3). Uses worker and `ChainStore` doubles; `assertInvariants()` (I1-I5) runs after every step.
- Admit 3 records: all `pending`. Start a job: all `reserved`; a duplicate submission of a reserved record is rejected as a duplicate.
- Worker crash mid-job: all 3 return to `pending`, none lost, none confirmed, chain file unchanged; after restart the next job mines them.
- `cancelCurrentJob()` mid-job: same outcome as the crash.
- Stale result (wrong `jobId`): discarded, no append, NO state change. Right `jobId` but `previousHash` not equal to the head: treated as cancel, records back to `pending`, job cleared, a new job is scheduled (the miner does not stall).
- Result whose block does not match the reserved snapshot (extra or missing record): discarded; records back to `pending`.
- Re-validation failure: one reserved record made invalid (state changed under it): the block is discarded, the valid records return to `pending`, the invalid one becomes `rejected(code)` and `GET /records/:id` reports it.
- Persistence fault injection (a `ChainStore` double, one test per row; after each, I4 and I6 hold):
  - `append` rejects before writing: no in-memory change, file size unchanged, records `pending`, miner `error`, retry after backoff; on retry success the block is appended exactly once.
  - `append` writes then `fsync` rejects: `truncate(offset)` is called, file size equals `offset`, records `pending`, retry appends exactly one line.
  - `append` writes partially (half line) then rejects: same rollback; the file has no torn line.
  - `truncate` rejects (rollback fails) or the post-rollback size differs: miner `fatal`, `/health` reports `fatal`, `POST /registrations` returns 503 `MINER_UNAVAILABLE`, mining never restarts.
  - `cancelCurrentJob()` and shutdown while `persisting`: cancel is deferred until persisting ends and the block is confirmed once; shutdown awaits it.
  - Boot with a torn last line: boot refuses (`CHAIN_FILE_CORRUPT`); a second node on the same `DATA_DIR` refuses to start (lock).
- Active-job failures: a current-job result with the right parent whose records are not the snapshot; and one that fails `validateBlockAdmission` (clock moved so the block is too far ahead): the first behaves as cancel, the second discards the block, valid records `pending`, invalid ones `rejected(code)`; the miner continues in both.
- Re-admission: an `expired` and a `rejected` record resubmitted get the same `recordId` and return to `pending`; a `confirmed` or `reserved` one is a duplicate. The terminal LRU holds 10 000 entries, the 10 001st oldest becomes 404 (use a small injected limit in the test).
- Record aged past `maxRecordAgeInBlockMs` at candidate build becomes `expired`, not `rejected`.
- Crash between fsync and in-memory update is simulated by re-booting from the file: the block is present and the records are not re-minted (their resubmission is rejected as duplicates).
- Node restart: mempool is empty, `GET /records/:id` for a prior `pending` id is 404, resubmission succeeds.
- TTL: a `pending` record past `mempoolTtlMs` becomes `expired`; a `reserved` record past its TTL is not expired during the job and is re-checked on return to `pending`.
- Counting: after a randomized sequence of 50 admit/cancel/crash/mine steps (seeded PRNG), I3 holds and every admitted record ends in exactly one terminal or live state.

**RC14 — Cache keys** (`apps/node/test/rc14-cache-keys.test.ts`; GPT item 1). Uses a counting validation-worker double.
- Two tamper-checks with the same `headHash` but different `mutation` run the worker twice (no cross-hit); same mutation but different `blockIndex` run twice; identical triple runs once (second is a hit).
- A tamper-check result never answers `/chain/validate` and vice versa, even with the same head.
- `/demo/difficulty-simulation` is never cached: two identical calls run the worker twice and never read or write the validation caches (the cache object is not reachable from the simulation handler; asserted by spying on cache access).
- `/chain/validate` cache: editing one byte of `chain.jsonl` on disk (head unchanged in memory) misses the cache and returns `CHAIN_STORE_MISMATCH` or the specific validation code; a different `configHash` (different profile) misses the cache; bytes appended after the request-start `stat` do not affect that response.
- A head change clears all caches; a tamper-check repeated afterwards re-runs.
- The cache is bounded: 65 distinct keys leave 64 entries, oldest evicted.

**RC15 — Mutations always change the record** (`apps/node/test/rc15-mutation-change.test.ts`; GPT item 2)
- Register a record whose alias is exactly `"tampered"`: `edit-record` mutated alias is `"tampered2"`, differs from the original (`canonicalize` differs), still passes the structural schema; result `BAD_BLOCK_HASH`.
- Same for an attendance whose `sessionId` is `"tampered"`.
- Table-driven property test over 50 seeded records (including alias length 50 and sessionIds at the regex limit): mutated record deep-differs from the original and always passes the structural schema.
- `edit-previous-hash`: starting hash beginning with `0` and with another digit both change and stay a valid `HexSha256`.
- `lower-difficulty` on a block already at `minDifficulty` -> 400, not a result.
- A deliberately broken mutator (test double returning the same record) makes the endpoint fail with `INTERNAL` instead of reporting a tamper result.

## 15. Handoff plan for Codex

Small, reviewable commits, one logical change each, tests run after each step, no large mixed diff. Write the named test file first (red), then the implementation.

Tier 1 (core):
1. `packages/shared`: config and profiles, errors, schemas (structural), `canonicalize`, `crypto.ts` types, `crypto-node`, `identity`. Tests 1, 2, 3, 4, 9, RC1 (shared part), RC2.
2. `packages/shared`: `block`, `difficulty`, `deriveChainId`, genesis. Tests 6, 8, RC4 (shared part), RC8, RC9.
3. `packages/shared`: state index, both record validators, `validateBlock`, `validateBlockAdmission`, `validateChain`. Tests 5, 7, RC3, RC3b, RC7, RC8, RC9, and the docs test (RC7 sentence, RC12).
4. `apps/node`: API, mempool, miner worker (terminate-based cancellation), persistence, sessions, Q1, Q2, and the isolated `/demo/difficulty-simulation` (the 20% enhancement must be demonstrable in tier 1). Tests 10-15, RC1, RC4, RC5, RC6, RC10, RC13 (lifecycle and persistence fault injection).
5. `apps/explorer`: core pages, `crypto-browser`, IndexedDB wallet, difficulty demo page. Test 16.

Tier 2:
6. Adversarial tests A1-A9 and `/demo/tamper-check`. Tests RC11, RC14, RC15.

Tier 3, only after the core demo works:
7. Playwright e2e 17-20, live-chain difficulty chart, ChainKey port, Dockerfile.
8. README with a 4-minute demo script and report-ready design and test-evidence notes.

The P0 gate (section 19) means the CONTRACT and its acceptance test are written, not that every test is tier 1.

Codex must flag, not guess: any change to protocol constants, profile values, key format, error codes or HTTP mapping; any library beyond section 2.

## 16. Work split

- **Member A (Alvin)**: implementation (steps 1-8) and the automated tests.
- **Member B (Joey)**: report, slides, documentation, test evidence (screenshots, outputs, logs), the demo script, the Contributions section. Also owns the security test matrix: writes A1-A9 and RC1-RC15 in plain language, reviews the adversarial tests, runs them, and should commit at least one complete adversarial test.
- **Both**: demonstration, code review of each other's work, presentation and Q&A.

The assignment requires fairly equal workload and every member must answer Q&A. Member B must be able to explain the signing flow, the validation split and the difficulty algorithm. Record each person's real contribution in git history and in the report.

## 17. Assignment notes

Rubric: 80 for the conference registration system, 20 for dynamic difficulty.

Report must:
- Present `attendeeId` (derived from the public key) as the unique identifier the slides allow ("name and email, or a unique identifier"), explain that no email or real name is collected on purpose (OSINT and retention risk), state that the remaining data is pseudonymous and linkable, not anonymous (section 5.2), and state the trade-off (no real-world identity binding).
- Justify the single-node mempool as the "pending pool", and list limitations: operator can censor by deleting and re-mining (A7), no identity proofing, no proof of physical presence, public pseudonymous queries, no key recovery, timestamps only monotonic historically (section 8), `chainId` unique only if `conferenceId` is unique.
- Explain difficulty adjustment (literal rule from the slides) and show the isolated difficulty simulation (and a real-time run if time permits), including the genesis-excluded window rule. Label clearly which run is the synthetic simulation and which is real mined-block behaviour (section 8). Note that the slide's 10 or 20 block window is an example ("e.g."); ours is the configurable `adjustmentInterval`.
- Include key code snippets, test evidence, contributions and references, and the ChainKey reuse note.

Presentation: 8 minutes (2 presentation, 4 demonstration, 2 Q&A), at most 5 slides, all members speak, demonstration is emphasized.

Deadlines:
- Group form (Excel with both names, upload to Canvas): Nov 3, 2026, 23:59.
- Presentation: Nov 24, 2026.
- Report: by Dec 1, 2026.

## 18. Decisions U1-U6 (accepted at their defaults)

| ID | Decision | Accepted default | Note |
|---|---|---|---|
| U1 | `attendeeId` + alias as the "unique identifier" instead of name and email | Accepted. Still subject to instructor confirmation (email before Nov 24); does NOT block implementation | If rejected, a design change is needed; report must record the outcome |
| U2 | `CONFERENCE_ID` | `conf-demo-2026` in demo/test; real value chosen at deploy time | |
| U3 | Explorer trusts the node's `verification` flag | Accepted, thin client, stated in UI | |
| U4 | Anchoring head hash outside the node | Report text only, no feature | Owner: Joey |
| U5 | Q1/Q2 public, no organizer authentication | Accepted, listed as limitation | |
| U6 | No historical timestamp upper bound / median-time-past | Accepted, documented in section 8 | Outside the rubric |

## 19. P0 gate (implementation may start only when all rows are accepted)

| P0 item | Contract | Acceptance test | Contract status |
|---|---|---|---|
| 1. Remove email/HMAC; use `attendeeId` | 4, 5.2, 9, 10, 11 | RC1, 12 | written |
| 2. Async identity vs sync hashing; structural vs key validation | 3, 5.1, 6 | RC2, 3 | written |
| 3. A7 uses deletion + re-mine; edits fail by signature | 10 (mutations), 14.3 | RC3 | written |
| 4. Explicit deployment identity (`conferenceId`, `chainId`) | 4, 9, 10 | RC4 | written |
| 5. Session catalog is not consensus | 7, 9, 10 | RC5 | written |
| 6. Terminate-based mining cancellation; test-only stress fixture, no wall-clock assertions | 9 | RC6 | written |
| 7. Honest timestamp bounds | 8 | RC7 | written |
| 8. Zero-valued integers valid, `-0` invalid (`PositiveInt` / `NonNegativeInt`) | 5.1, 5.4, 6 | RC8 | written |
| 9. Genesis excluded from timing; exact boundaries `I+1`, `2I+1`, ... | 4, 8 | RC9 | written |
| 10. Isolated difficulty simulation, no `DemoClock`, live clock untouched | 4, 8, 10 | RC10 | written |
| 11. Record-type-aware tamper mutations | 10 | RC11 | written |
| 12. Privacy claims: pseudonymous, linkable, immutable; documents agree | 1, 5.2, 17; THREAT_MODEL AS4, I1 | RC12 | written |
| 13. Atomic record lifecycle across mempool, mining, confirmed, failure | 9 (record lifecycle) | RC13 | written |
| 14. Cache keys include every result-relevant input; no sharing with simulation | 9 | RC14 | written |
| 15. Tamper mutations always change the record and stay schema-valid | 10 | RC15 | written |
| 16. Fail-closed persistence (non-cancellable persisting, rollback, `fatal`), process lock | 9 | RC13 | written |
| 17. Attendance key comes from an earlier confirmed registration; deterministic error precedence | 7 | RC3b | written |
| 18. Disk-backed `/chain/validate` on a consistent snapshot; cache key includes file bytes and config | 9, 10 | RC14 | written |

All 18 rows are written with acceptance tests. Handoff to Codex is cleared. U1 is open for instructor confirmation but is not a gate item.

Gate rule: if any row changes, update its contract section and its test in the same commit.
