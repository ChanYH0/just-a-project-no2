# Mining profiler evidence — 2026-11-08

Real Apple M4 Metal captures and Node CPU profiles were collected on this Mac. These results describe bounded diagnostic hashing, not conference transaction throughput or a production capacity guarantee. Usage and backend selection: [Metal mining](METAL_MINING.md).

## Method and artifacts

Host: Apple M4 (10 GPU cores), Node v24.20.0, Swift 6.4, arm64 macOS 27 SDK. The helper runs an actual Metal SHA-256 compute kernel; CPU independently verifies winning proofs. Two Metal workers are two helper processes sharing one GPU.

From the repository root:

```sh
pnpm --filter @conference-chain/node build:metal
pnpm --filter @conference-chain/node profile:mining
```

Each run creates an ignored `evidence/pow-profile-*` directory containing `summary.json`, Chrome/DevTools-compatible `.cpuprofile` files and Xcode `.gputrace` directory bundles. Import a CPU file in DevTools' Performance panel, or open a GPU bundle in Xcode to inspect the captured commands and dispatches. Keep the entire GPU bundle. GPU capture is enabled for the capture subprocess by the runner; normal node mining does not record traces.

Timing passes run **without profiling**. Separate passes collect traces, so trace overhead is excluded from the reported rates. CPU workers synchronize before timing and before profiling. Overall wall time includes worker/helper startup; GPU template preparation and signed workload generation occur outside that timer. CPU work includes production canonical serialization and SHA-256 per nonce; Metal uses a precomputed canonical prefix/suffix. The comparison therefore includes a serialization advantage and does not isolate SHA-256 hardware speed. Native `elapsedMs` excludes helper startup/kernel compilation and must not be compared directly with overall CPU wall time.

The diagnostic target is 64 leading zero hex digits, forcing a bounded search. The runner hashes a fixed nonce count rather than waiting for ordinary chain PoW. No chain is modified, no private keys are saved, and no speed threshold is asserted. Runs were sequential with no concurrent build/test workload; an idle isolated container stack remained running. This is a small local sample, without thermal or power control.

## One-record workload

Three runs each hashed 65,536 nonces with one signed registration: 35 prefix bytes and 1,123 suffix bytes. Rates below are hashes/second including startup, rounded to integers.

| Backend | Workers | Trial 1 | Trial 2 | Trial 3 | Median |
|---|---:|---:|---:|---:|---:|
| CPU | 1 | 62,521 | 62,045 | 52,343 | 62,045 |
| CPU | 2 | 103,419 | 116,777 | 71,295 | 103,419 |
| CPU | 4 | 88,817 | 121,473 | 100,272 | 100,272 |
| Metal | 1 | 448,645 | 597,505 | 393,593 | 448,645 |
| Metal | 2 | 539,605 | 699,289 | 356,693 | 539,605 |

Raw runs, in table order: `evidence/pow-profile-ZclCDj`, `evidence/pow-profile-rlqs1F`, `evidence/pow-profile-1M2Kap`. Each contains seven CPU profiles and three GPU capture bundles. Two GPU helpers lost to one in trial 3; more workers are not a guaranteed improvement. Defaults remain CPU with one worker.

In trial 1's CPU single-worker trace, 454 samples included `canonicalizeObject` (110), `canonicalizeValue` (103), hash `update` (75), garbage collection (37), `Hash` (26), and `digest` (17). The two canonicalization functions account for 46.9% of self samples. This identifies serialization as a useful optimization candidate, but sampling and a single trace do not establish a universal percentage.

## Full 50-record workload

```sh
PROFILE_ATTEMPTS=4096 PROFILE_RECORDS=50 \
PROFILE_CPU_WORKERS=1,4 PROFILE_GPU_WORKERS=1,2 \
pnpm --filter @conference-chain/node profile:mining
```

One bounded run, `evidence/pow-profile-umYJOt`, produced five CPU profiles and three GPU capture bundles with 35 prefix bytes and 50,261 suffix bytes. It uses signed synthetic registrations, not live admission or mining throughput.

| Backend | Workers | Overall hashes/s | CPU work-only hashes/s |
|---|---:|---:|---:|
| CPU | 1 | 2,475 | 3,325 |
| CPU | 4 | 5,798 | 11,525 |
| Metal | 1 | 22,660 | — |
| Metal | 2 | 18,114 | — |

The larger payload makes serialization cost visible, while the small nonce count makes startup significant. This single run is exploratory; it supports neither a stable scaling factor nor choosing two GPU helpers by default.

## Correctness and demo evidence

Final multi-agent review found and fixed two lifecycle failures: an invalid same-job pool result could leave the miner waiting indefinitely, and a Metal helper stdin error could reject before terminating its process. Invalid results now fail after pool cleanup (stale job IDs remain ignored); input-pipe failures terminate the helper and wait for close. Regression tests exercise both paths and successful subsequent mining.

On the integrated implementation, 267 shared tests, 238 node tests (including 14 Metal bridge tests with `RUN_METAL_TESTS=true`), and 69 explorer tests passed. Final review added coverage for invalid pool results and helper input-pipe cleanup; the complete node suite passed after those fixes. Workspace typechecks also passed. Native vectors matched Node SHA-256 at nonce digit boundaries 10 through 1,000,000 and for Unicode/multi-block inputs. A separate full-record GPU vector also matched CPU bytes. The browser suite passed 7/7 against real Metal with two workers and 7/7 against a built Linux container stack with four CPU workers. The browser runs exercised registration, attendance, live PoW/difficulty, validation/demo flows and the self-hosted Swagger UI's health request through `/api`.

Retained local browser artifacts: `evidence/gpu-integration-2026-11-08` and `evidence/cpu-integration-2026-11-08`. They contain screenshots and `mining-evidence.json`. The CPU container run preceded final error-path hardening; the native Metal browser suite was rerun after both fixes (7/7, 54.2 seconds), with artifacts in `evidence/gpu-final-2026-11-08`. Bulky traces and screenshots are intentionally ignored by Git; preserve them separately when transferring this checkout. A local evidence manifest records source references, validation boundaries and artifact SHA-256 hashes after integration. Earlier [mining validation](MINING_VALIDATION.md) remains historical evidence for its original CPU runs.
