# Mining review and live demo — 2026-11-07

Validated source: `3d81a6f`. Mining starts automatically after the one-second batching delay when pending records exist; it does not need a browser Mine button. This review checked real worker startup, record validation, FIFO batching, nonce search, PoW validation, actual difficulty windows, cancellation, and persisted-chain reload.

## Finding and fix

A corrupted stored block could contain a structurally valid but enormous difficulty. PoW validation then attempted an oversized `"0".repeat(difficulty)` allocation and threw `RangeError`, producing generic `INTERNAL` instead of the specified block verdict.

Commit `b16c25d` bounds target checks by the computed digest length. `verifyBlockPow` returns false and chain validation returns `BAD_POW` with the block index, preserving precedence before `BAD_DIFFICULTY`. Regression tests reproduced the exception before the fix and now pass, including a boot test with a rehashed corrupted block. Mining profiles, protocol constants, the nonce loop, and the cancellation stress fixture were not changed.

No additional confirmed defect was found in normal worker startup, signature checks, or live difficulty computation within this bounded review.

## Real container mining

A separate Compose project, `conference-mining-review-20261107`, used a new named volume, the demo profile, default rate limits, and demo routes disabled. Requests passed through the built nginx explorer proxy. The node image uses Node 22.12.0 and real worker threads.

The first live run admitted eight valid registrations and mined six blocks. A bad signature was rejected. At block 6, the actual timing window was 7,138 ms against an expected 12,000 ms, so difficulty rose from 2 to 3.

The containers were rebuilt and recreated with the PoW guard. Before and after restart, the head remained:

- Index: `6`
- Hash: `00077007bad0ed998822c58532daa25ee25ddaa7da3e45329888d39e00d075e9`
- Difficulty: `3`
- Disk-backed `/chain/validate`: `{ "ok": true }`

The final mining-only Playwright run then passed in 13.7 seconds, including browser startup. It admitted another eight records, checked their FIFO order across blocks, recomputed every new block hash, checked PoW and expected difficulty, and validated the complete chain and signatures in the test process. All records confirmed and left the mempool. The explorer displayed valid hash and PoW flags for the resulting block.

| Live boundary | Observed window | Expected window | Difficulty |
|---|---:|---:|---|
| Block 6 | 7,138 ms | 12,000 ms | 2 → 3 |
| Block 11 | 175,071 ms | 12,000 ms | 3 → 2 |

These are real block timestamps, not the isolated difficulty simulation. The second window includes the idle/rebuild gap; the rule responds to total block spacing, not only CPU hashing time. Final height was 12, with 16 admitted registrations across the two runs. The screenshot and JSON evidence contain actual hashes, nonces, difficulty values, and timestamps.

Final built image IDs:

- Node: `sha256:186b52c5e2055c07ec03a22a9faff958c52dc373529c7dc3a2081fa7cd50010c`
- Explorer: `sha256:a89e66a6ef3a7adbc20e64ebb01439e8e698420da03e4203fe2e3380f320d4a4`

## Controlled worker checks

Commit `94c0d37` adds a real-worker integration test for `MAX_RECORDS_PER_BLOCK + 1` attendance records. The first worker mines exactly the first 50 records in FIFO order; the 51st remains pending and is mined by the next worker. Both blocks pass PoW checks and storage invariants. This test uses injected clock/timers and direct admission to avoid the HTTP write-rate limit; it is not live throughput evidence.

The real-worker cancellation suite also passes: a deliberately infeasible test-only candidate leaves the HTTP event loop responsive, termination clears the job, and a fresh worker mines successfully afterward. Crash recovery, stale results, persistence rollback, and lifecycle tests pass. The live HTTP polling sampled pending and confirmed records but missed the brief active mining phases; it is not used as proof of responsiveness during a busy worker.

## Checks and reproduction

- Shared: 263 tests passed.
- Node: 201 tests passed.
- Explorer: 69 tests passed.
- All four workspace type checks passed.
- Both container targets built successfully.
- Mining-only Playwright passed against the rebuilt containers; this follow-up did not rerun the other five browser specs.
- Diff whitespace check passed.

```bash
pnpm -r typecheck
pnpm --filter @conference-chain/shared test
pnpm --filter @conference-chain/node test
pnpm --filter @conference-chain/explorer test

CHAIN_ENABLE_DEMO_ROUTES=false EXPLORER_PORT=18081 \
  docker compose --env-file chain.env.example -p conference-mining-review-20261107 up --build -d
E2E_EXTERNAL_URL=http://127.0.0.1:18081 \
  pnpm --filter @conference-chain/e2e exec playwright test tests/22-mining.spec.ts
```

Local artifacts are in ignored `evidence/mining-review-2026-11-07/`: `before-restart.json`, `after-restart.json`, `chain-summary.json`, `mining-evidence.json`, `real-mined-block.png`, and `manifest.json`. These contain local demo evidence and are not included in a clean checkout. The manifest records source revision, image IDs, and SHA-256 artifact hashes.

The isolated containers were stopped after testing. Their named test-data volume was retained; existing project data was not used. This is local demo acceptance, not production deployment or a performance guarantee.
