#!/usr/bin/env bash
# Local demo: prepare dependencies, detect mining hardware, and start both apps.
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22 or newer, then run ./demo.sh again." >&2
  exit 1
fi
exec node scripts/demo.mjs "$@"
