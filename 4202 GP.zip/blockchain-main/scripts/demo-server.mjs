// Runs under the node package's tsx loader after bootstrap has prepared dependencies.
import { availableParallelism } from "node:os";
import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { ChainError } from "../packages/shared/src/index.ts";
import { createNode } from "../apps/node/src/app.ts";
import { BootError } from "../apps/node/src/boot-error.ts";
import { parseEnv } from "../apps/node/src/env.ts";
import { loadSessions } from "../apps/node/src/sessions.ts";
import { MINING_WORKERS_MAX } from "../apps/node/src/mining-config.ts";

const root = fileURLToPath(new URL("../", import.meta.url));
const nodeDir = resolve(root, "apps/node");
const explorerDir = resolve(root, "apps/explorer");
const host = "127.0.0.1";
const backend = process.argv[2];
const cores = availableParallelism();
// Metal schedules GPU threads itself. Extra helper processes share the same GPU.
const allocatedWorkers = backend === "metal" ? 1 : Math.max(1, Math.min(MINING_WORKERS_MAX, cores - 1));
let node;
let explorer;
let startupComplete = false;
let requestedExit;
let closing;

function stop(code) {
  requestedExit = requestedExit === 1 ? 1 : code;
  if (startupComplete) void close();
}
async function close() {
  if (closing) return closing;
  closing = (async () => {
    const results = await Promise.allSettled([explorer?.close(), node?.close()]);
    if (results.some((result) => result.status === "rejected")) {
      console.error("Demo shutdown failed; check the chain lock before restarting.");
      requestedExit = 1;
    }
    process.exitCode = requestedExit ?? 0;
  })();
  return closing;
}
for (const name of ["SIGINT", "SIGTERM"]) process.on(name, () => stop(0));

try {
  const rawUiPort = process.env.EXPLORER_PORT;
  if (rawUiPort !== undefined && (!/^[1-9][0-9]{0,4}$/.test(rawUiPort) || Number(rawUiPort) > 65535)) {
    throw new BootError("INVALID_SCHEMA", "EXPLORER_PORT must be an integer from 1 to 65535");
  }
  const settings = parseEnv({
    ...process.env,
    PROFILE: "demo", ENABLE_DEMO_ROUTES: "true", TRUST_PROXY: "false",
    CONFERENCE_ID: process.env.CONFERENCE_ID ?? "conf-demo-2026",
    DATA_DIR: resolve(process.env.DATA_DIR ?? resolve(nodeDir, "data")),
    SESSIONS_FILE: resolve(process.env.SESSIONS_FILE ?? resolve(nodeDir, "sessions.example.json")),
    MINING_BACKEND: backend,
    MINING_WORKERS: process.env.MINING_WORKERS ?? String(allocatedWorkers),
  });
  const sessions = await loadSessions(settings.sessionsFile);
  // Preflight occurs inside createNode, before opening the chain directory.
  node = await createNode({ settings, sessions, clock: { now: () => Date.now() }, onFatal: (code) => {
    console.error(`Miner stopped: ${code}`);
    stop(1);
  } });
  if (requestedExit === undefined) {
    const origin = await node.app.listen({ host, port: settings.port });
    process.env.NODE_API_ORIGIN = origin;
    const explorerRequire = createRequire(resolve(explorerDir, "package.json"));
    const vitePackagePath = explorerRequire.resolve("vite/package.json");
    const vitePackage = JSON.parse(await readFile(vitePackagePath, "utf8"));
    const { createServer } = await import(pathToFileURL(resolve(dirname(vitePackagePath), vitePackage.main)).href);
    if (requestedExit === undefined) {
      explorer = await createServer({ root: explorerDir, server: {
        host, strictPort: true, ...(rawUiPort === undefined ? {} : { port: Number(rawUiPort) }),
      } });
      if (requestedExit === undefined) {
        await explorer.listen();
        const ui = explorer.resolvedUrls?.local[0];
        if (!ui) throw new Error("Explorer did not report its listening URL");
        console.log(`\nDemo ready — ${settings.miningBackend}, ${settings.miningWorkers} mining worker(s), ${cores} CPU cores available.`);
        console.log(`Explorer: ${ui}\nAPI docs: ${new URL("api/docs", ui)}\nAPI: ${origin}`);
        console.log("Demo routes enabled. Listening locally. Ctrl+C stops both apps; chain data is kept.");
      }
    }
  }
  startupComplete = true;
  if (requestedExit !== undefined) await close();
} catch (error) {
  startupComplete = true;
  const occupiedPort = error?.code === "EADDRINUSE" || (error instanceof Error && /^Port \d+ is already in use$/.test(error.message));
  const code = error instanceof BootError || error instanceof ChainError ? error.code : occupiedPort ? "EADDRINUSE" : "INTERNAL";
  console.error(`Demo refused: ${code}. ${code === "EADDRINUSE" ? "Choose free PORT and EXPLORER_PORT values." : error instanceof BootError ? error.message : "Check the configuration and preceding messages; no backend fallback was used."}`);
  stop(1);
  await close();
}
