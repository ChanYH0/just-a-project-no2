// Bootstrap with Node built-ins so a fresh checkout needs no global pnpm install.
import { spawn, spawnSync } from "node:child_process";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const mode = process.argv[2] ?? process.env.MINING_BACKEND ?? "auto";
if (mode === "--help" || mode === "-h") {
  console.log(`Usage: ./demo.sh [auto|cpu|metal]
Default: detect Apple Silicon Metal; otherwise use CPU workers.
Prepares dependencies and starts the demo API, explorer and API docs.
Ctrl+C stops both apps and keeps chain data.
Overrides: MINING_WORKERS, METAL_BATCH_SIZE, PORT, EXPLORER_PORT,
           DATA_DIR, SESSIONS_FILE, CONFERENCE_ID.
For the Linux container stack, use ./up.sh instead.`);
  process.exit(0);
}
if (process.argv.length > 3 || !["auto", "cpu", "metal"].includes(mode)) {
  console.error("Usage: ./demo.sh [auto|cpu|metal]");
  process.exit(2);
}
let project;
try {
  project = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
} catch {
  console.error("Could not read the repository package.json.");
  process.exit(1);
}
const minimumNode = /^>=(\d+)$/.exec(project.engines?.node ?? "");
if (!minimumNode) {
  console.error("package.json must declare the minimum Node major version as >=N.");
  process.exit(1);
}
if (Number(process.versions.node.split(".")[0]) < Number(minimumNode[1])) {
  console.error(`Install Node.js ${minimumNode[1]} or newer, then run ./demo.sh again.`);
  process.exit(1);
}
const appleSilicon = process.platform === "darwin" && process.arch === "arm64";
const backend = mode === "auto" ? (appleSilicon ? "metal" : "cpu") : mode;
if (backend === "metal") {
  if (!appleSilicon) {
    console.error("Metal requires native Apple Silicon macOS. Use ./demo.sh cpu on this machine.");
    process.exit(1);
  }
  if (spawnSync("xcrun", ["--find", "swiftc"], { stdio: "ignore" }).status !== 0) {
    console.error("Metal needs Xcode command-line tools. Run xcode-select --install, then retry.");
    process.exit(1);
  }
}

let child;
let signal;
for (const name of ["SIGINT", "SIGTERM"]) {
  process.on(name, () => { signal = name; child?.kill(name); });
}
async function run(command, args) {
  if (signal) throw new Error("Setup interrupted");
  await new Promise((resolve, reject) => {
    child = spawn(command, args, { cwd: root, stdio: "inherit" });
    child.once("error", () => reject(new Error(`Could not start ${command}. Check that it is installed.`)));
    child.once("close", (code) => {
      child = undefined;
      if (code === 0) resolve();
      else reject(new Error(`${command} failed; see the output above.`));
    });
  });
}

try {
  const { packageManager } = project;
  if (typeof packageManager !== "string" || !/^pnpm@\d+\.\d+\.\d+$/.test(packageManager)) {
    throw new Error("package.json must pin an exact pnpm version.");
  }
  const version = spawnSync("pnpm", ["--version"], { cwd: root, encoding: "utf8" });
  const installed = version.status === 0 && version.stdout.trim() === packageManager.slice("pnpm@".length);
  const command = installed ? "pnpm" : "npm";
  const prefix = installed ? [] : ["exec", "--yes", `--package=${packageManager}`, "--", "pnpm"];
  if (!installed) console.log(`Preparing ${packageManager} with npm (no global installation).`);
  console.log(`Hardware: ${process.platform}/${process.arch}; selected ${backend}${mode === "auto" ? " automatically" : " explicitly"}.`);
  await run(command, [...prefix, "install", "--frozen-lockfile"]);
  if (backend === "metal") await run(command, [...prefix, "--filter", "@conference-chain/node", "build:metal"]);
  const nodeRequire = createRequire(new URL("../apps/node/package.json", import.meta.url));
  await run(process.execPath, ["--import", nodeRequire.resolve("tsx"), fileURLToPath(new URL("./demo-server.mjs", import.meta.url)), backend]);
} catch (error) {
  if (!signal) console.error(error instanceof Error ? error.message : "Demo setup failed.");
  process.exitCode = signal === "SIGINT" ? 130 : signal === "SIGTERM" ? 143 : 1;
}
