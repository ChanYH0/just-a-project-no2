# Conference Registration Blockchain

A small, single-node blockchain for conference registration and session attendance, with a block-explorer style web UI. Attendees register a browser-generated RSA key, check in to sessions with signed records, and anyone can query the chain.

Source of truth for behaviour: [`docs/SPEC.md`](docs/SPEC.md). Threat model: [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md).

## Scope

- **F1 Registration**: signed `register` record binding `attendeeId = sha256(SPKI DER public key)` and a pseudonymous `alias`. No email, name or other directly identifying field.
- **F2 Attendance**: signed `attend` record for a session, from a key with a confirmed registration.
- **F4 Queries** (two, public): Q1 sessions attended by an attendee (`GET /attendees/:attendeeId/sessions`); Q2 attendees of a session (`GET /sessions/:sessionId/attendees`).
- **Blocks and PoW**: records are mined into blocks with a proof-of-work target. Records are verified before inclusion.
- **Dynamic difficulty (20% enhancement)**: difficulty moves by one step per adjustment window, bounded by min and max.
- **Explorer**: Chain, Block, Attendee, Session, Register, Check-in, Validate and Difficulty demo pages.

Out of scope: F3 minting or rewards, P2P networking, consensus between nodes, forks, a CLI.

## Architecture

```
  Browser                                   Node app  (apps/node, Fastify)
 +----------------------------+  /api/*   +-----------------------------------+
 | Explorer (Vite + React)    | --------> | routes -> mempool -> miner        |
 | WebCrypto key pair         |  (proxy)  |   miner = worker_threads          |
 | private key: IndexedDB,    |           |   validation/demo = worker_thread |
 |   non-extractable          |           +----------------+------------------+
 +-------------+--------------+                            | append + fsync
               |                                           v
               | browser-safe imports        +-----------------------------------+
               v                             | DATA_DIR/chain.jsonl  (1 line/block)
 +----------------------------+              | DATA_DIR/chain.lock   (process lock)
 | packages/shared            | <-- used by --+-----------------------------------+
 | schemas, canonicalize,     |   node and explorer
 | crypto, block, difficulty, |
 | validateChain              |
 +----------------------------+
```

- The explorer only calls `/api/...`. The Vite proxy strips `/api` and forwards to the node.
- The node serves a self-hosted API reference at `/docs` and its OpenAPI 3.1 document at `/openapi.json`; through the explorer proxy they are `/api/docs` and `/api/openapi.json`. The explorer UI itself remains a separate static app.

## Quick start

Requires Node.js 22 or newer. From the repository root:

```sh
./demo.sh
```

This prepares locked dependencies, detects native Apple Silicon Metal or CPU mining, allocates workers, and starts the API and explorer together. On this Mac it builds and verifies the Apple GPU helper automatically. CPU allocation leaves one available core free; Metal uses one helper sharing the GPU's own parallel scheduler. It prints the explorer and interactive API docs links. Ctrl+C stops both apps and keeps the chain.

Use `./demo.sh cpu` to require CPU, or `MINING_WORKERS=4 ./demo.sh cpu` to override worker allocation. See [easy setup](docs/SETUP.md) for ports, data, prerequisites and troubleshooting. For the Linux CPU container stack, use `./up.sh`.

### Manual startup

If you prefer separate processes, pnpm is pinned by `packageManager` in root `package.json`. Install that version, then:

```bash
pnpm install                       # may need network access; see note below
```

Run the node (demo profile, demo routes enabled, port 3000):

```bash
mkdir -p apps/node/data
PROFILE=demo \
CONFERENCE_ID=conf-demo-2026 \
DATA_DIR=./data \
SESSIONS_FILE="$PWD/apps/node/sessions.example.json" \
ENABLE_DEMO_ROUTES=true \
pnpm --filter @conference-chain/node start
```

`pnpm --filter ... start` runs the script with `apps/node` as the working directory, so `DATA_DIR=./data` resolves to `apps/node/data`. A relative `SESSIONS_FILE` would resolve under `apps/node`, which is why the example uses an absolute path.

Open the API reference at `http://localhost:3000/docs`, or through the explorer proxy at `http://localhost:5173/api/docs`. The raw OpenAPI document is at `/openapi.json` (or `/api/openapi.json` through the proxy). The API UI and its assets are served locally by the node.

Run the explorer on port 5173 (dev server, proxies `/api` to `http://localhost:3000`):

```bash
pnpm --filter @conference-chain/explorer dev
# open http://localhost:5173
```

Production-style explorer. `apps/explorer/package.json` has no `preview` script, so call Vite directly:

```bash
pnpm --filter @conference-chain/explorer build
pnpm --filter @conference-chain/explorer exec vite preview --port 5173 --strictPort
```

Explorer env: `NODE_API_ORIGIN` (read by `apps/explorer/vite.config.ts` at config time, default `http://localhost:3000`) sets the proxy target for both dev and preview.

Playwright tests 17-23 live in `apps/e2e`. The latest recorded browser suite passed 7/7 against both the native Metal2 setup and the isolated Linux CPU4 Compose setup on 2026-11-08; see the [E2E README](apps/e2e/README.md) and [evidence](#test-evidence).

For Apple Silicon GPU mining setup, limits, and profiler commands, see [Metal mining](docs/METAL_MINING.md). Profiler measurements and trace artifacts are summarized separately in [mining performance](docs/MINING_PERFORMANCE.md).

## Configuration (node environment)

Validated at boot. Any invalid value refuses to start with an error code.

| Variable | Default | Notes |
|---|---|---|
| `PROFILE` | `production` | `production`, `demo` or `test` |
| `CONFERENCE_ID` | required | `/^[a-z0-9][a-z0-9-]{2,63}$/`; feeds `chainId` |
| `PORT` | `3000` | integer 0-65535 |
| `DATA_DIR` | `./data` | holds `chain.jsonl` and `chain.lock` |
| `SESSIONS_FILE` | `./sessions.json` | `[{ "id", "title" }]`; admission catalog only, not consensus |
| `ENABLE_DEMO_ROUTES` | `false` | must be exactly `true` to expose `/demo/*`; refused with `PROFILE=production` |
| `HOST` | `127.0.0.1` | bind address; not in SPEC section 9, read in `apps/node/src/main.ts`. Set `0.0.0.0` in containers |
| `TRUST_PROXY` | `false` | `true` takes the client IP for rate limits from `X-Forwarded-For`. Only set it when all traffic comes through a proxy that overwrites that header (the compose stack does); otherwise clients can spoof their IP |
| `HEAVY_RATE_LIMIT` | `6` | per-IP requests/min for `/chain/validate` and `/demo/*`; default is the SPEC value, positive integer only |
| `WRITE_RATE_LIMIT` | `30` | per-IP write requests/min; default is the SPEC value |
| `MINING_BACKEND` | `cpu` | `cpu` or `metal`; Metal requires native Apple Silicon macOS and the built helper |
| `MINING_WORKERS` | `1` | integer 1–32; disjoint nonce lanes |
| `METAL_BATCH_SIZE` | `16384` | integer 1–65536; Metal kernel batch limit |

The SPEC environment table and dated execution extension describe the protocol and mining settings. `HOST` is an extra knob flagged in the source.

## Docker

The `Dockerfile` has two runnable targets from one build graph: `runtime` (default, the node API) and `explorer` (static build behind unprivileged nginx on port 8080, `/api/*` proxied to a host named `chain-node`). Base images are exact tags; pnpm is installed from npm at the version in `package.json`. BuildKit cache mounts (`--mount=type=cache`) keep the pnpm store and npm cache between builds, so a rebuild after a source change does not redownload packages. Both images run non-root; nothing secret or `.env` goes in (see `.dockerignore`).

Status: both targets build (verified 2026-11-04); see the full-stack section for what was run.

```bash
docker build --target runtime  -t conference-chain/node .
docker build --target explorer -t conference-chain/explorer .
```

Node only:

```bash
docker run --rm -p 3000:3000 \
  -e PROFILE=demo -e CONFERENCE_ID=conf-demo-2026 -e ENABLE_DEMO_ROUTES=true \
  -e SESSIONS_FILE=/config/sessions.json \
  -v "$PWD/apps/node/sessions.example.json:/config/sessions.json:ro" \
  -v conference-data:/data \
  conference-chain/node
```

### Full stack (one command)

```bash
./up.sh          # init (chain.env, config/sessions.json in demo profile), build, start, wait for healthy
./up.sh logs
./up.sh down     # data volume is kept
```

`compose.yaml` runs `chain-node` (reachable only on the internal compose network) and `chain-explorer` (nginx, published on `127.0.0.1:${EXPLORER_PORT:-8080}`; `/api/*` is proxied to the node). Settings live in `chain.env` (created from `chain.env.example`; separate from the helper's `.env`). Outside the demo profile a missing session catalog is a hard error. Verified 2026-11-04 (OrbStack): both containers reach healthy with read-only root filesystems, and `GET /api/health` through the explorer proxy returns `{"ok":true,...}`. That historical run did not cover the browser UI. The isolated CPU4 Compose browser run on 2026-11-08 subsequently passed registration, check-in, real mining and the API reference through this proxy (see Test evidence).

### Archived: shared-project-helper integration

The earlier helper-based setup (nginx edge, TLS, monitoring plugins) is archived, unsupported, in `archive/helper-edge/`: the `./setup` launcher, the project-local plugin `plugins/conference-chain/`, and the generated state. It needs `flock`, refuses group-writable plugin directories, enables extra components such as loki by default, and its compose paths assume the repository root, so it does not run from that location without edits. The third-party template `archive/helper-edge/shared-project-helper/` is not tracked in git. Use `./up.sh`.

## Known dependency advisories (`pnpm audit`, 2026-11-03)

The 2026-11-03 audit snapshot reported 16 findings (1 low, 12 moderate, 1 high, 2 critical). That snapshot predates the self-hosted Swagger UI dependency added on 2026-11-08, so it does not describe the current production dependency graph; rerun `pnpm audit` for a current result. The explorer ships as static files and the production image contains no vite or vitest. It does include esbuild (a dependency of tsx, version outside the advisory range).

| Package | Severity | Why accepted for now |
|---|---|---|
| tinypool (via vitest 3) | critical x2 | Prototype-pollution gadget in worker pool options. Needs attacker-controlled options; vitest runs only our own tests locally. Fix: vitest 4. |
| vite 5 (and esbuild, launch-editor) | 1 high, moderate, low | Dev-server issues (cross-origin reads, `server.fs`, Windows-only launch-editor paths). Only while `pnpm dev` runs on a developer machine; production serves the built `dist` via nginx. Fix: vite 6.4.4+ (major upgrade). |
| `@vitest/mocker` (via vitest 3) | moderate | Mock registration and path traversal in the test runner only. Fix: vitest 4. |
| react-router 6 | moderate x2 | SSR hydration issue (no SSR here) and an open redirect through backslashes in `<Link>` / `useNavigate`. All navigation targets are fixed internal routes, none come from user input. Fix: react-router 7.18+. |

Not fixed before the deadline because each fix is a major-version upgrade (vitest 4, vite 6, react-router 7) that would need a full retest. Planned after the presentation. Playwright was already upgraded (1.64.1), which removed one finding.

## Test commands

Each package has its own scripts. There is no root test script.

```bash
pnpm --filter @conference-chain/shared test
pnpm --filter @conference-chain/shared typecheck

pnpm --filter @conference-chain/node test
pnpm --filter @conference-chain/node typecheck

pnpm --filter @conference-chain/explorer test
pnpm --filter @conference-chain/explorer typecheck
pnpm --filter @conference-chain/explorer build

pnpm audit
```

### Test evidence

For the 2026-11-07 review, fixes, container-browser demo runs, and evidence limits, see [Review and demo validation](docs/REVIEW_VALIDATION.md).

On 2026-11-08, Playwright tests 17-23 passed **7/7** with the node using native macOS Metal and two workers (Playwright started Vite locally), and **7/7** against an isolated built Linux Compose stack using four CPU workers. The Metal run is native macOS; Metal is not available in the Linux Compose runtime. Captured browser evidence is in [`evidence/gpu-integration-2026-11-08`](evidence/gpu-integration-2026-11-08/) and [`evidence/cpu-integration-2026-11-08`](evidence/cpu-integration-2026-11-08/), including real-mined-block screenshots and mining-evidence JSON. These are end-to-end browser results, not profiler throughput claims; see [mining performance](docs/MINING_PERFORMANCE.md) for the separate trace run.

The earlier 2026-11-03 Playwright run covered tests 17-20 only (4 passed) and is historical.

Captured in the authoring sandbox on 2026-11-03 (vitest and `tsc --noEmit` run directly, because `pnpm` was blocked there).

```
shared:   tsc exit 0; vitest 18 files, 259 tests passed
node:     tsc exit 0; vitest 20 files, 188 tests passed
explorer: tsc exit 0; vitest 5 files, 41 tests passed; vite build succeeded
```

Not captured: `pnpm audit`. Run it outside the sandbox. The Docker build and container start were run outside the sandbox (see Docker section). The Playwright e2e in `apps/e2e` was run outside the sandbox: 4 passed (1.3 min).

## Demo script (4 minutes)

Order: Register -> Mine -> Attend -> Mine -> Query -> Validate -> Dynamic Difficulty Demo. Start the node (demo profile, demo routes on) and the explorer first.

| Time | Step | Page / action | Label |
|---|---|---|---|
| 0:00-0:30 | Orientation | Chain page: `chainId`, empty mempool, latest block | live chain |
| 0:30-1:10 | **Register** | Register: generate key in browser, enter alias (not a real name), submit; note `202 recordId` | live |
| 1:10-1:30 | **Mine** | Record appears in mempool; after the ~1 s batching delay a block is mined. Open Block detail: `hashValid`, `powValid` | **real mined block** |
| 1:30-2:00 | **Attend** | Check-in: pick a session, sign with the stored key, poll `GET /records/:recordId` until `confirmed` | live |
| 2:00-2:20 | **Mine** | The attendance record is mined into the next block | **real mined block** |
| 2:20-2:45 | **Query** | Attendee page: Q1 sessions for the attendee. Session page: Q2 attendees | live, public |
| 2:45-3:20 | **Validate** | Validate page: `/chain/validate` returns ok. Tamper demo: `edit-record` on block 1 is rejected with `BAD_BLOCK_HASH` | live validator, demo route |
| 3:20-4:00 | **Dynamic Difficulty Demo** | Difficulty page: run with a small `intervalMs`, then a large one. Difficulty rises, then falls | **SYNTHETIC simulation** (isolated chain) |

Say the labels out loud. The simulation uses synthetic timestamps (`GENESIS_TIMESTAMP + k * intervalMs`) on a separate in-memory chain. It does not measure real hash rate and does not touch the live chain. Real difficulty behaviour is only what the live chain shows after mined blocks.

## Tamper demo

`POST /demo/tamper-check` (demo routes only) copies the live chain in memory, applies one mutation, and runs the real `validateChain`. It never touches the live chain or `chain.jsonl`.

| Mutation | Effect | Expected result |
|---|---|---|
| `edit-record` | change a record, keep hash | `BAD_BLOCK_HASH` |
| `edit-previous-hash` | change `previousHash` | `BAD_PREVIOUS_HASH` |
| `rehash-after-edit` | change a record and re-mine that block only | `INVALID_SIGNATURE` |
| `lower-difficulty` | lower the block's difficulty and re-mine that block | `BAD_DIFFICULTY` |
| `delete-record-and-remine` | delete an attendance record and re-mine (profile `demo`/`test` only) | `ok: true` with a note: censorship is undetectable without an external head-hash anchor |

The last row is the honest limitation: the chain detects edits, not an operator who rewrites history from scratch.

## Dynamic difficulty

- `I = adjustmentInterval` (`>= 2`). Genesis is never in a timing window.
- At blocks `I+1`, `2I+1`, ...: `actual = ts[i-1] - ts[i-I]` against `expected = targetBlockTimeMs * (I-1)`. Faster: +1. Slower: -1. Equal: unchanged. Clamped to `[minDifficulty, maxDifficulty]`.
- The `demo` and `production` profiles use `I = 5`; `test` uses `I = 3`. The slides' 10 or 20 are examples; set `adjustmentInterval` to change it.
- `validateChain` recomputes difficulty for every block, so a miner cannot choose it.

## Protocol notes

- Signing and hashing use canonical JSON (`canonicalize`), RSASSA-PKCS1-v1_5 with SHA-256, RSA-2048.
- `recordId = hash(canonicalize(signedRecord))`. Signing is deterministic, so resubmitting the same record gives the same id.
- The mempool is in memory only. A node restart loses pending records; clients get 404 from `GET /records/:id` and resubmit.
- Writes are rate limited (30/min per IP); `/chain/validate` and `/demo/*` are limited to 6/min.

## Privacy position

- The protocol collects no email, name, or other directly identifying field. `attendeeId` is a public-key-derived identifier, and `alias` is a display label.
- The data is **pseudonymous and linkable, not anonymous**. `attendeeId` is persistent, so one person's attendance across sessions can be linked. A poorly chosen alias can identify someone. Attendance history reveals behaviour.
- Q1 and Q2 are public, with no organizer authentication.
- The chain is append-only. It cannot honour deletion or retention limits once a block is written.
- Browser keys are non-extractable, which prevents key export but not use. Script running in the page (XSS) can still sign.
- Nothing here has been reviewed for legal compliance. Do not describe this build as anonymous or as compliant with any privacy regulation.

## Limitations

- **Single-node mempool**: the "pending pool" is one process. A restart loses pending records.
- **Censorship**: the operator can delete records and re-mine (`delete-record-and-remine`), undetectable without an external anchor of the head hash.
- **No identity proofing**: anyone can register any key. There is no proof of physical presence.
- **Pseudonymous, linkable, not anonymous** (see Privacy position).
- **Public queries**: Q1 and Q2 need no authentication.
- **No key recovery**: losing the browser key means losing the identity.
- **Timestamps**: historically only monotonic (`ts[i] >= ts[i-1]`). No upper bound in history and no median-time-past. The operator can steer difficulty with chosen timestamps, within the clamp.
- **`chainId`** is unique only if `CONFERENCE_ID` is unique across deployments.

## ChainKey reuse

The block graph on the Chain page (`apps/explorer/src/components/BlockGraph.tsx`, `src/blockGraph.css`) is a presentation port of ChainKey's `clients/explorer/src/ChainGraph.tsx` and `graph.css` (chainkey-core, the same author's project, used here with the author's authorization for this course project). What was reused: the SVG node/edge layout and constants, the zoom, find and paging controls, and the keyboard and forced-colors accessibility pattern. What is ours: `src/blockGraph.ts` (previousHash link model and its tests), the mapping from events to blocks, and all data, which comes from this project's `/blocks` API.

Not ported: ChainKey's verification semantics, the Rust verifier, `@chainkey/sdk` types, the checkpoint lanes and the audit workbench. The graph shows hash references only and states that it does not verify the chain. The ChainKey repository's `LICENSE` is still an unfinished draft (placeholders for year and holder), so the permission rests on the author's own authorization, not on a license text. Say so in the report.

## Repository layout

```
apps/node/         Fastify API, miner, persistence, validation worker, demo routes
apps/explorer/     Vite + React explorer
packages/shared/   schemas, canonical JSON, crypto, block, difficulty, validateChain
docs/              SPEC.md, THREAT_MODEL.md (do not edit without updating the contract)
Dockerfile         multi-stage image (see Docker section)
.dockerignore      keeps secrets, data, tests and docs out of the build context
```
