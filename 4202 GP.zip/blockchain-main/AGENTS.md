# Repository agent guide

## Read order and ownership

Read this guide, then the sections of [docs/SPEC.md](docs/SPEC.md) relevant to the change. The spec owns the protocol, genesis, record lifecycle, persistence and API behavior. Its dated execution extensions cover worker pools, Metal and API documentation. [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md) describes trust boundaries.

- `packages/shared/src`: canonical schemas, constants, serialization, signing, hashing, difficulty and chain validation. Import these contracts; do not duplicate them in consumers.
- `apps/node/src`: HTTP admission, mempool/miner lifecycle, storage, execution settings and backend adapters. `mining-config.ts` owns mining execution limits and defaults.
- `apps/node/native`: optional Apple Metal helper and kernel. TypeScript independently verifies winning proofs. Native build output is ignored.
- `apps/explorer/src`: browser wallet and explorer. Node verification flags are displayed, not independently verified by the browser.
- `scripts/demo.mjs`: dependency bootstrap and automatic backend selection. `scripts/demo-server.mjs`: local resource allocation and joint API/explorer lifecycle.
- `up.sh`, `compose.yaml`, `chain.env.example`: Linux CPU container setup. The container cannot use the host Mac's Metal GPU.

## Local operation

Use [docs/SETUP.md](docs/SETUP.md) for commands and overrides. `./demo.sh` installs locked dependencies, selects Metal on native Apple Silicon macOS or CPU elsewhere, and starts both apps. It always uses the demo profile and exposes demo routes on loopback. Do not use it as a production launcher.

Keep hardware selection explicit in logs. A selected Metal backend must pass the real GPU preflight; build/preflight failure must not silently switch to CPU. CPU automatic allocation leaves one available core free and respects the canonical worker limit. Metal uses one helper by default; helpers share the GPU, not one physical device each. Explicit `MINING_WORKERS` overrides allocation and is validated by the node's environment parser.

Preserve existing chains and configuration. Never delete data, remove volumes, change conference identity to bypass a mismatch, or rewrite genesis to make a demo start. Startup errors must release owned resources. Ctrl+C must stop both local servers and release the chain lock while retaining data. Avoid automatic browser opening and global package-manager changes.

## Validation

Use RTK for commands by default. Run checks proportionate to the changed owners:

```sh
pnpm --filter @conference-chain/shared test
pnpm --filter @conference-chain/node test
pnpm --filter @conference-chain/explorer test
pnpm -r typecheck
pnpm --filter @conference-chain/explorer build
```

For Metal changes on an Apple Silicon Mac:

```sh
pnpm --filter @conference-chain/node build:metal
node apps/node/native/verify-metal.mjs
RUN_METAL_TESTS=true pnpm --filter @conference-chain/node test
```

For setup changes, exercise actual startup, the explorer proxy's health/docs endpoints, shutdown, and restart against an isolated data directory. Verify both automatic Metal and explicit CPU modes where supported. Check invalid arguments/configuration and occupied-port cleanup. Full browser commands and external-stack requirements live in [apps/e2e/README.md](apps/e2e/README.md); these tests write registrations and attendance, so never point them at user data.

Use [docs/METAL_MINING.md](docs/METAL_MINING.md) for profiler commands and [docs/MINING_PERFORMANCE.md](docs/MINING_PERFORMANCE.md) for measurement limits. Keep bulky traces/screenshots in ignored `evidence/`. Record source references and artifact hashes when preserving validation evidence. Synthetic hashing is not live transaction throughput; local/container success is not production deployment evidence.

## Change boundaries

Preserve unrelated dirty work. Stage explicit paths and keep logical commits separate. Do not push or deploy without authorization. Write code and commit messages in English, without AI co-author trailers. Keep setup documentation current when changing launcher behavior, defaults or overrides. Do not revive `archive/helper-edge` as the supported setup path.
