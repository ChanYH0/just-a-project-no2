#!/usr/bin/env bash
# One-command start of the full stack. Init layer: chain.env, session catalog, then build + up + health wait.
#   ./up.sh          start (build if needed)
#   ./up.sh down     stop (data volume kept)
#   ./up.sh logs     follow logs
# Settings live in chain.env, not .env: .env belongs to shared-project-helper (./setup) if you use it.
# chain.env is parsed, never sourced, so its contents cannot run as shell code.
set -euo pipefail
cd "$(dirname "$0")"

compose() { docker compose --env-file chain.env "$@"; }

case "${1:-up}" in
  down) [ -f chain.env ] || cp chain.env.example chain.env; exec docker compose --env-file chain.env down ;;
  logs) [ -f chain.env ] || cp chain.env.example chain.env; exec docker compose --env-file chain.env logs -f ;;
  up) ;;
  *) echo "usage: $0 [up|down|logs]" >&2; exit 2 ;;
esac

[ -f chain.env ] || { cp chain.env.example chain.env; echo "created chain.env from chain.env.example"; }

get() { # get KEY DEFAULT -> last KEY=value line of chain.env
  local v
  v="$(grep -E "^$1=" chain.env | tail -n 1 | cut -d= -f2-)" || true
  printf '%s' "${v:-$2}"
}

# compose strips quotes; this parser does not, so refuse quoted values instead of misreading them.
if grep -Eq "^(CHAIN_PROFILE|CHAIN_SESSIONS_FILE|EXPLORER_PORT)=[\"']" chain.env; then
  echo "error: chain.env: do not quote CHAIN_PROFILE, CHAIN_SESSIONS_FILE or EXPLORER_PORT" >&2; exit 1
fi

sessions="$(get CHAIN_SESSIONS_FILE ./config/sessions.json)"
if [ ! -f "$sessions" ]; then
  [ "$(get CHAIN_PROFILE demo)" = demo ] ||
    { echo "error: session catalog missing: $sessions (not seeded outside the demo profile)" >&2; exit 1; }
  mkdir -p "$(dirname "$sessions")"
  cp apps/node/sessions.example.json "$sessions"
  echo "seeded $sessions from apps/node/sessions.example.json"
fi

compose up -d --build --wait
port="$(get EXPLORER_PORT 8080)"
case "$port" in *[!0-9]*|"") echo "error: EXPLORER_PORT must be a number" >&2; exit 1 ;; esac
curl -fsS "http://127.0.0.1:${port}/api/health" && echo
echo "explorer: http://127.0.0.1:${port}/"
