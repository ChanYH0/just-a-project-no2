## Mitigates
| Threat | Control |
|---|---|
| Direct access to the node API from outside | `chain-node` sits on the internal `chain` network only; the explorer container is the single route in (`compose.yaml`) |
| Code or config tampering at run time | Both containers run `read_only` with `cap_drop: ALL` and `no-new-privileges`; only `/data` (chain) and `/tmp` (tmpfs) are writable |
| Secrets baked into images | Images contain no `.env`; settings come from the project `.env` at run time (`.dockerignore`) |
| Cross-origin calls and framing of the explorer | Same-origin `/api` proxy, strict CSP meta in `index.html`, `frame-ancestors 'none'` header (`deploy/explorer.nginx.conf`) |
| Demo routes in a real deployment | The node refuses `ENABLE_DEMO_ROUTES=true` when `PROFILE=production` (SPEC section 9) |

## Trade-offs
- The node image keeps tsx (a devDependency), because the node app runs TypeScript directly; it is smaller than before but not minimal.
- Rate limiting and TLS come from the helper's edge plugins, not from this plugin.

## Gaps
- No Prometheus metrics or log shipping for the node yet; only `/health` is checked.
- Chain data lives in one named volume with no backup job.
