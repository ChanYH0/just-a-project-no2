# shellcheck shell=bash disable=SC2154 # base/expect/hcurl come from scripts/cmd/check.sh, which sources this file
# Sourced by ./setup check: expect LABEL GOT WANT, hcurl, $base (main site).
expect "chain api health via the edge" "$(hcurl -s -o /dev/null -w '%{http_code}' "$base/api/health")" 200
expect "explorer index via the edge" "$(hcurl -s -o /dev/null -w '%{http_code}' "$base/")" 200
