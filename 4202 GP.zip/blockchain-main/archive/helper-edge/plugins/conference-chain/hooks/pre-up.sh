#!/usr/bin/env bash
# Init layer for the chain app: point the edge at the explorer and make sure the session catalog exists.
# Runs before `docker compose up` with .env exported (PLUGIN_HOME = this plugin's folder).
set -euo pipefail
. "$ROOT/scripts/lib/common.sh"

upstream="http://chain-explorer:8080"
if [ "$(env_get APP_UPSTREAM)" != "$upstream" ]; then
    env_set APP_UPSTREAM "$upstream"
    say "conference-chain: APP_UPSTREAM set to $upstream"
fi

sessions="${CHAIN_SESSIONS_FILE:-./config/sessions.json}"
case "$sessions" in /*) ;; *) sessions="$SHP_PROJECT_ROOT/${sessions#./}" ;; esac
if [ ! -f "$sessions" ]; then
    [ "${CHAIN_PROFILE:-production}" = demo ] ||
        die "session catalog missing: $sessions (create it; no default is seeded outside the demo profile)"
    mkdir -p "$(dirname "$sessions")"
    cp "$SHP_PROJECT_ROOT/apps/node/sessions.example.json" "$sessions"
    say "conference-chain: seeded $sessions from apps/node/sessions.example.json (demo profile)"
fi
