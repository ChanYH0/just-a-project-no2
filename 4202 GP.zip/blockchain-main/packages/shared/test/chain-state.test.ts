// SPEC 14.1 tests 5 and 7; state index; genesis; TOO_MANY_RECORDS; validateChain signature (RC5 type part).

import { describe, expect, it } from "vitest";
import { getProfile, GENESIS_TIMESTAMP } from "../src/config.js";
import {
  applyBlockToState,
  attendanceKey,
  buildState,
  cloneState,
  emptyState,
  emptyUniquenessIndex,
  validateBlock,
  validateChain,
  validateRecordAtSubmission,
  type ChainState,
  type MempoolIndex,
} from "../src/chain.js";
import type { Block, ChainRecord } from "../src/schemas.js";
import {
  BASE_TIME,
  CONFERENCE_ID,
  CRYPTO,
  TEST_PROFILE,
  buildChain,
  genesisFor,
  makeKeys,
  mineOn,
  signedAttendance,
  signedRegistration,
  type TestKeys,
} from "./helpers.js";

const T = (step: number): number => BASE_TIME + step * 1_000;
const CATALOG: ReadonlySet<string> = new Set(["s1", "s2"]);

function requireBlock(chain: readonly Block[], index: number): Block {
  const block = chain[index];
  if (block === undefined) {
    throw new Error(`no block at ${index}`);
  }
  return block;
}

function recordAt(block: Block, position: number): ChainRecord {
  const record = block.records[position];
  if (record === undefined) {
    throw new Error(`no record at ${position}`);
  }
  return record;
}

function withBlock(chain: readonly Block[], index: number, change: Partial<Block>): Block[] {
  return chain.map((block, position) => (position === index ? { ...block, ...change } : block));
}

function withRecordPayload(
  block: Block,
  position: number,
  change: Record<string, unknown>,
): Partial<Block> {
  const record = recordAt(block, position);
  const changed: ChainRecord = { ...record, payload: { ...record.payload, ...change } } as ChainRecord;
  return { records: block.records.map((r, i) => (i === position ? changed : r)) };
}

describe("test 5: attendance rules", () => {
  it("an attendance after an earlier confirmed registration validates", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      { timestamp: T(2), records: [await signedAttendance(alice, "s1", T(2))] },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("unregistered attendee: ATTENDEE_NOT_REGISTERED at the block", async () => {
    const alice = await makeKeys();
    const chain = buildChain([{ timestamp: T(1), records: [await signedAttendance(alice, "s1", T(1))] }]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_NOT_REGISTERED",
      blockIndex: 1,
    });
  });

  it("registration only in the same block: ATTENDEE_NOT_REGISTERED", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      {
        timestamp: T(1),
        records: [await signedRegistration(alice, T(1)), await signedAttendance(alice, "s1", T(1))],
      },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_NOT_REGISTERED",
      blockIndex: 1,
    });
  });

  it("duplicate (attendeeId, sessionId) across blocks: DUPLICATE_ATTENDANCE", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      { timestamp: T(2), records: [await signedAttendance(alice, "s1", T(2))] },
      { timestamp: T(3), records: [await signedAttendance(alice, "s1", T(3))] },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "DUPLICATE_ATTENDANCE",
      blockIndex: 3,
    });
  });

  it("two identical attendances in one block: DUPLICATE_ATTENDANCE", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      {
        timestamp: T(2),
        records: [await signedAttendance(alice, "s1", T(2)), await signedAttendance(alice, "s1", T(2))],
      },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "DUPLICATE_ATTENDANCE",
      blockIndex: 2,
    });
  });

  it("two registrations of one key in one block: KEY_ALREADY_REGISTERED", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      {
        timestamp: T(1),
        records: [await signedRegistration(alice, T(1)), await signedRegistration(alice, T(1), { alias: "a2" })],
      },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "KEY_ALREADY_REGISTERED",
      blockIndex: 1,
    });
  });

  it("re-registration of a confirmed key in a later block: KEY_ALREADY_REGISTERED", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      { timestamp: T(2), records: [await signedRegistration(alice, T(2), { alias: "again" })] },
    ]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "KEY_ALREADY_REGISTERED",
      blockIndex: 2,
    });
  });

  it("unknown session is rejected at submission only (RC5): validateChain accepts it", async () => {
    const alice = await makeKeys();
    const registration = await signedRegistration(alice, T(1));
    const attendance = await signedAttendance(alice, "retired-session", T(2));
    const state = emptyState();
    const chain = buildChain([
      { timestamp: T(1), records: [registration] },
      { timestamp: T(2), records: [attendance] },
    ]);
    applyBlockToState(state, requireBlock(chain, 1));

    const submission = await validateRecordAtSubmission(
      attendance,
      state,
      emptyUniquenessIndex(),
      CATALOG,
      TEST_PROFILE,
      { now: () => T(2) },
      CRYPTO,
    );
    expect(submission).toEqual({ ok: false, code: "UNKNOWN_SESSION" });
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("mempool rules: a pending registration does not satisfy the lookup, and a pending key blocks re-registration", async () => {
    const alice = await makeKeys();
    const registration = await signedRegistration(alice, T(1));
    const mempool: MempoolIndex = emptyUniquenessIndex();
    mempool.registrations.add(alice.attendeeId);
    const clock = { now: () => T(1) };

    const attendance = await validateRecordAtSubmission(
      await signedAttendance(alice, "s1", T(1)),
      emptyState(),
      mempool,
      CATALOG,
      TEST_PROFILE,
      clock,
      CRYPTO,
    );
    expect(attendance).toEqual({ ok: false, code: "ATTENDEE_NOT_REGISTERED" });

    const reRegistration = await validateRecordAtSubmission(
      registration,
      emptyState(),
      mempool,
      CATALOG,
      TEST_PROFILE,
      clock,
      CRYPTO,
    );
    expect(reRegistration).toEqual({ ok: false, code: "KEY_ALREADY_REGISTERED" });
  });
});

describe("test 7: validateChain fails with the right code and index", () => {
  async function baseChain(): Promise<{ chain: Block[]; alice: TestKeys }> {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      { timestamp: T(2), records: [await signedAttendance(alice, "s1", T(2))] },
      { timestamp: T(3), records: [await signedAttendance(alice, "s2", T(3))] },
    ]);
    return { chain, alice };
  }

  it("the untouched chain is valid", async () => {
    const { chain } = await baseChain();
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("edited record without re-hashing: BAD_BLOCK_HASH at that block", async () => {
    const { chain } = await baseChain();
    const edited = withBlock(chain, 2, withRecordPayload(requireBlock(chain, 2), 0, { sessionId: "s9" }));
    expect(await validateChain(edited, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_BLOCK_HASH",
      blockIndex: 2,
    });
  });

  it("edited previousHash: BAD_PREVIOUS_HASH at that block", async () => {
    const { chain } = await baseChain();
    const current = requireBlock(chain, 2).previousHash;
    const replacement = current.startsWith("0") ? "1" + current.slice(1) : "0" + current.slice(1);
    const edited = withBlock(chain, 2, { previousHash: replacement });
    expect(await validateChain(edited, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_PREVIOUS_HASH",
      blockIndex: 2,
    });
  });

  it("edited stored hash: BAD_BLOCK_HASH at that block", async () => {
    const { chain } = await baseChain();
    const current = requireBlock(chain, 2).hash;
    const replacement = current.startsWith("0") ? "1" + current.slice(1) : "0" + current.slice(1);
    const edited = withBlock(chain, 2, { hash: replacement });
    expect(await validateChain(edited, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_BLOCK_HASH",
      blockIndex: 2,
    });
  });

  it("wrong index: BAD_INDEX at the block's chain position", async () => {
    const { chain } = await baseChain();
    const edited = withBlock(chain, 2, { index: 5 });
    expect(await validateChain(edited, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_INDEX",
      blockIndex: 2,
    });
  });

  it("wrong difficulty, lower than required (re-mined, valid PoW): BAD_DIFFICULTY at block 1", async () => {
    const config = getProfile("test", CONFERENCE_ID);
    const lowerConfig = { ...config, initialDifficulty: 2 };
    const alice = await makeKeys();
    const genesis = genesisFor(lowerConfig);
    const block = mineOn([genesis], [await signedRegistration(alice, T(1))], T(1), lowerConfig, 1);
    expect(await validateChain([genesis, block], lowerConfig, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_DIFFICULTY",
      blockIndex: 1,
    });
  });

  it("wrong difficulty, higher than required (re-mined, valid PoW): BAD_DIFFICULTY at block 1", async () => {
    const config = getProfile("test", CONFERENCE_ID);
    const genesis = genesisFor(config);
    const block = mineOn([genesis], [], T(1), config, 2);
    expect(await validateChain([genesis, block], config, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_DIFFICULTY",
      blockIndex: 1,
    });
  });
});

describe("state index", () => {
  it("applying blocks incrementally equals buildState over the same blocks", async () => {
    const alice = await makeKeys();
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      { timestamp: T(2), records: [await signedAttendance(alice, "s1", T(2))] },
    ]);
    const incremental = emptyState();
    for (const block of chain) {
      applyBlockToState(incremental, block);
    }
    expect(incremental).toEqual(buildState(chain));
    expect(incremental.attendance.has(attendanceKey(alice.attendeeId, "s1"))).toBe(true);
    expect(incremental.registrations.get(alice.attendeeId)).toEqual({
      alias: "alice",
      publicKey: alice.publicKey,
      blockIndex: 1,
      timestamp: T(1),
    });
  });

  it("cloneState copies independently", async () => {
    const alice = await makeKeys();
    const state = buildState(buildChain([{ timestamp: T(1), records: [await signedRegistration(alice, T(1))] }]));
    const copy: ChainState = cloneState(state);
    copy.attendance.add("x|y");
    expect(state.attendance.has("x|y")).toBe(false);
  });

  it("validateBlock does not mutate the state it is given", async () => {
    const alice = await makeKeys();
    const chain = buildChain([{ timestamp: T(1), records: [await signedRegistration(alice, T(1))] }]);
    const state = buildState(chain);
    const before = cloneState(state);
    const candidate = mineOn(chain, [await signedRegistration(alice, T(2))], T(2));
    expect(await validateBlock(candidate, chain, state, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "KEY_ALREADY_REGISTERED",
      blockIndex: 2,
    });
    expect(state).toEqual(before);
  });
});

describe("genesis and chain edges", () => {
  it("genesis alone passes validateChain", async () => {
    expect(await validateChain([genesisFor()], TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("an empty array is GENESIS_MISMATCH", async () => {
    expect(await validateChain([], TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "GENESIS_MISMATCH",
      blockIndex: 0,
    });
  });

  it("a modified genesis timestamp is GENESIS_MISMATCH", async () => {
    const genesis = genesisFor();
    const modified = { ...genesis, timestamp: GENESIS_TIMESTAMP + 1 };
    expect(await validateChain([modified], TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "GENESIS_MISMATCH",
      blockIndex: 0,
    });
  });

  it("TOO_MANY_RECORDS: a 51-record block is rejected by validateBlock before any record is checked", async () => {
    const alice = await makeKeys();
    const genesis = genesisFor();
    const record = await signedRegistration(alice, T(1));
    const block = mineOn([genesis], Array.from({ length: 51 }, () => record), T(1));
    expect(block.records).toHaveLength(51);
    expect(await validateBlock(block, [genesis], emptyState(), TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "TOO_MANY_RECORDS",
      blockIndex: 1,
    });
  });

});

describe("validateChain signature (RC5 type part)", () => {
  it("validateChain takes exactly three parameters: blocks, config, crypto (no clock, no catalog)", () => {
    expect(validateChain.length).toBe(3);
    const arity: Parameters<typeof validateChain>["length"] = 3;
    expect(arity).toBe(3);
  });
});

