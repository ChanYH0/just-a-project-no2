import { generateKeyPairSync } from "node:crypto";
import { beforeAll, describe, expect, it } from "vitest";
import type { IdentityCrypto, PublicKeyInfo } from "../src/crypto.js";
import { nodeIdentityCrypto } from "../src/crypto-node.js";
import {
  deriveAttendeeId,
  signPayload,
  validatePublicKey,
  verifyPayload,
} from "../src/identity.js";
import { RegistrationPayload, PublicKey, Signature } from "../src/schemas.js";
import { ChainError } from "../src/errors.js";

const identity: IdentityCrypto = nodeIdentityCrypto;
const CHAIN_ID = "a".repeat(64);

interface Fixture {
  publicKey: string;
  privateKey: string;
}

let alice: Fixture;
let bob: Fixture;

beforeAll(async () => {
  const a = await identity.generateKeyPair();
  const b = await identity.generateKeyPair();
  alice = { publicKey: a.publicKey, privateKey: requireString(a.privateKey) };
  bob = { publicKey: b.publicKey, privateKey: requireString(b.privateKey) };
});

function requireString(value: unknown): string {
  if (typeof value !== "string") {
    throw new Error("expected PEM string private key");
  }
  return value;
}

function registrationPayload(publicKey: string, attendeeId: string, alias = "Alice"): RegistrationPayload {
  return {
    type: "register",
    chainId: CHAIN_ID,
    attendeeId,
    alias,
    publicKey,
    timestamp: 1_700_000_000_001,
  };
}

describe("key generation (crypto-node)", () => {
  it("produces a canonical 294-byte SPKI and a PKCS8 PEM private key", () => {
    expect(PublicKey.safeParse(alice.publicKey).success).toBe(true);
    expect(alice.privateKey.startsWith("-----BEGIN PRIVATE KEY-----")).toBe(true);
  });

  it("inspectPublicKey reports RSA-2048, e=65537 and the canonical encoding", async () => {
    const info = await identity.inspectPublicKey(alice.publicKey);
    expect(info).toEqual<PublicKeyInfo>({
      modulusBits: 2048,
      publicExponent: 65537,
      canonicalSpki: alice.publicKey,
    });
  });
});

describe("sign / verify (test 2)", () => {
  it("round trip passes", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const signature = await signPayload(payload, alice.privateKey, identity);
    expect(await verifyPayload(payload, signature, alice.publicKey, identity)).toBe(true);
  });

  it("changing any payload field fails verification", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const signature = await signPayload(payload, alice.privateKey, identity);
    const mutations: RegistrationPayload[] = [
      { ...payload, chainId: "c".repeat(64) },
      { ...payload, alias: "Mallory" },
      { ...payload, timestamp: payload.timestamp + 1 },
      { ...payload, attendeeId: "d".repeat(64) },
    ];
    for (const mutated of mutations) {
      expect(await verifyPayload(mutated, signature, alice.publicKey, identity)).toBe(false);
    }
  });

  it("a signature from another key fails", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const signature = await signPayload(payload, bob.privateKey, identity);
    expect(await verifyPayload(payload, signature, alice.publicKey, identity)).toBe(false);
  });

  it("malformed key returns false", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const signature = await signPayload(payload, alice.privateKey, identity);
    expect(await verifyPayload(payload, signature, "not base64!", identity)).toBe(false);
    expect(await verifyPayload(payload, signature, "", identity)).toBe(false);
    const garbageDer = Buffer.alloc(294, 7).toString("base64");
    expect(await verifyPayload(payload, signature, garbageDer, identity)).toBe(false);
  });

  it("malformed signature returns false", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    expect(await verifyPayload(payload, "", alice.publicKey, identity)).toBe(false);
    expect(await verifyPayload(payload, "AAAA", alice.publicKey, identity)).toBe(false);
    expect(await verifyPayload(payload, "!!!!", alice.publicKey, identity)).toBe(false);
    const wrongLength = Buffer.alloc(255, 1).toString("base64");
    expect(await verifyPayload(payload, wrongLength, alice.publicKey, identity)).toBe(false);
  });

  it("signed bytes are the UTF-8 of canonicalize(payload): key order does not change the signature", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const reordered: RegistrationPayload = {
      timestamp: payload.timestamp,
      publicKey: payload.publicKey,
      alias: payload.alias,
      attendeeId: payload.attendeeId,
      chainId: payload.chainId,
      type: payload.type,
    };
    const signature = await signPayload(payload, alice.privateKey, identity);
    expect(await verifyPayload(reordered, signature, alice.publicKey, identity)).toBe(true);
  });

  it("the signature is a canonical 256-byte value", async () => {
    const payload = registrationPayload(alice.publicKey, "b".repeat(64));
    const signature = await signPayload(payload, alice.privateKey, identity);
    expect(Signature.safeParse(signature).success).toBe(true);
  });
});

describe("deriveAttendeeId (test 3)", () => {
  it("is deterministic and differs per key", async () => {
    const first = await deriveAttendeeId(alice.publicKey, identity);
    const again = await deriveAttendeeId(alice.publicKey, identity);
    const other = await deriveAttendeeId(bob.publicKey, identity);
    expect(first).toBe(again);
    expect(first).not.toBe(other);
    expect(first).toMatch(/^[0-9a-f]{64}$/);
  });

  it("equals sha256 of the SPKI DER bytes", async () => {
    const der = Buffer.from(alice.publicKey, "base64");
    expect(await deriveAttendeeId(alice.publicKey, identity)).toBe(await identity.sha256Hex(der));
  });

  it("throws INVALID_SCHEMA for a non-canonical base64 key", async () => {
    let caught: unknown = null;
    try {
      await deriveAttendeeId("not canonical", identity);
    } catch (error: unknown) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(ChainError);
    expect(caught instanceof ChainError ? caught.code : null).toBe("INVALID_SCHEMA");
  });
});

describe("validatePublicKey (test 3, semantic layer)", () => {
  it("accepts the canonical RSA-2048 e=65537 key", async () => {
    expect(await validatePublicKey(alice.publicKey, identity)).toBe(true);
  });

  it("rejects a 1024-bit RSA key (not 2048-bit)", async () => {
    const { publicKey } = generateKeyPairSync("rsa", {
      modulusLength: 1024,
      publicExponent: 65537,
      publicKeyEncoding: { type: "spki", format: "der" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    expect(await validatePublicKey(publicKey.toString("base64"), identity)).toBe(false);
  });

  it("rejects a 2048-bit RSA key with e != 65537", async () => {
    const { publicKey } = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      publicExponent: 3,
      publicKeyEncoding: { type: "spki", format: "der" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    expect(await validatePublicKey(publicKey.toString("base64"), identity)).toBe(false);
  });

  it("rejects unparsable input", async () => {
    expect(await validatePublicKey(Buffer.alloc(294, 3).toString("base64"), identity)).toBe(false);
    expect(await validatePublicKey("", identity)).toBe(false);
  });

  it("rejects a key whose canonical re-encoding differs from the input (non-canonical DER)", async () => {
    const nonCanonicalIdentity: IdentityCrypto = {
      ...identity,
      async inspectPublicKey() {
        return { modulusBits: 2048, publicExponent: 65537, canonicalSpki: "different" };
      },
    };
    expect(await validatePublicKey(alice.publicKey, nonCanonicalIdentity)).toBe(false);
  });

  it("structurally valid registration with mismatched attendeeId is detectable by comparison (test 4 inputs)", async () => {
    // The ATTENDEE_ID_MISMATCH code itself is produced by verifyRecordIntegrity (tier 1 step 3).
    const correct = await deriveAttendeeId(alice.publicKey, identity);
    const wrong = await deriveAttendeeId(bob.publicKey, identity);
    expect(correct).not.toBe(wrong);
    expect(RegistrationPayload.safeParse(registrationPayload(alice.publicKey, wrong)).success).toBe(true);
  });
});
