import { describe, expect, it } from "vitest";
import {
  MINER_BATCH_DELAY_MS,
  PROFILE_NAMES,
  getProfile,
  validateConfig,
  type ChainConfig,
} from "../src/config.js";
import { ChainError } from "../src/errors.js";

function testConfig(overrides: Partial<ChainConfig> = {}): ChainConfig {
  return { ...getProfile("test", "test-conf"), ...overrides };
}

describe("shipped profiles", () => {
  it("all three profiles pass validation", () => {
    for (const name of PROFILE_NAMES) {
      expect(validateConfig(getProfile(name, "test-conf")).ok).toBe(true);
    }
  });

  it("match the section 4 table", () => {
    expect(getProfile("production", "c-1")).toEqual({
      conferenceId: "c-1",
      initialDifficulty: 3,
      minDifficulty: 1,
      maxDifficulty: 5,
      targetBlockTimeMs: 10_000,
      adjustmentInterval: 5,
      maxRecordSkewMs: 300_000,
      mempoolTtlMs: 300_000,
      maxRecordAgeInBlockMs: 900_000,
      maxBlockSkewMs: 5_000,
    });
    expect(getProfile("demo", "c-1")).toEqual({
      conferenceId: "c-1",
      initialDifficulty: 2,
      minDifficulty: 1,
      maxDifficulty: 4,
      targetBlockTimeMs: 3_000,
      adjustmentInterval: 5,
      maxRecordSkewMs: 300_000,
      mempoolTtlMs: 300_000,
      maxRecordAgeInBlockMs: 900_000,
      maxBlockSkewMs: 5_000,
    });
    expect(getProfile("test", "c-1")).toEqual({
      conferenceId: "c-1",
      initialDifficulty: 1,
      minDifficulty: 1,
      maxDifficulty: 3,
      targetBlockTimeMs: 1_000,
      adjustmentInterval: 3,
      maxRecordSkewMs: 5_000,
      mempoolTtlMs: 5_000,
      maxRecordAgeInBlockMs: 15_000,
      maxBlockSkewMs: 1_000,
    });
  });

  it("getProfile returns a fresh object each call", () => {
    const first = getProfile("test", "test-conf");
    first.maxDifficulty = 99;
    expect(getProfile("test", "test-conf").maxDifficulty).toBe(3);
  });

  it("uses the fixed batch delay constant of 1000 ms", () => {
    expect(MINER_BATCH_DELAY_MS).toBe(1000);
  });
});

describe("validateConfig rules", () => {
  it("adjustmentInterval = 1 fails", () => {
    const result = validateConfig(testConfig({ adjustmentInterval: 1 }));
    expect(result.ok).toBe(false);
  });

  it("adjustmentInterval must be an integer", () => {
    expect(validateConfig(testConfig({ adjustmentInterval: 2.5 })).ok).toBe(false);
  });

  it("adjustmentInterval = 2 passes", () => {
    expect(validateConfig(testConfig({ adjustmentInterval: 2 })).ok).toBe(true);
  });

  it("initialDifficulty below minDifficulty fails", () => {
    expect(validateConfig(testConfig({ initialDifficulty: 0, minDifficulty: 1 })).ok).toBe(false);
  });

  it("initialDifficulty above maxDifficulty fails", () => {
    expect(validateConfig(testConfig({ initialDifficulty: 4, maxDifficulty: 3 })).ok).toBe(false);
  });

  it("minDifficulty above maxDifficulty fails", () => {
    expect(validateConfig(testConfig({ minDifficulty: 3, maxDifficulty: 2, initialDifficulty: 2 })).ok).toBe(false);
  });

  it("minDifficulty must be at least 1", () => {
    expect(validateConfig(testConfig({ minDifficulty: 0, initialDifficulty: 1 })).ok).toBe(false);
  });

  it("skew + ttl + batch >= age fails (equality included)", () => {
    // test profile: 5000 + 5000 + 1000 = 11000
    expect(validateConfig(testConfig({ maxRecordAgeInBlockMs: 11_000 })).ok).toBe(false);
    expect(validateConfig(testConfig({ maxRecordAgeInBlockMs: 10_999 })).ok).toBe(false);
    expect(validateConfig(testConfig({ maxRecordAgeInBlockMs: 11_001 })).ok).toBe(true);
  });

  it("skew + ttl + batch is enforced with a raised mempool TTL", () => {
    expect(validateConfig(testConfig({ mempoolTtlMs: 20_000 })).ok).toBe(false);
  });

  it("non-integer or negative time fields fail", () => {
    expect(validateConfig(testConfig({ targetBlockTimeMs: 1.5 })).ok).toBe(false);
    expect(validateConfig(testConfig({ maxBlockSkewMs: -1 })).ok).toBe(false);
  });

  it("reports every violation found", () => {
    const result = validateConfig(testConfig({ adjustmentInterval: 1, maxDifficulty: 0 }));
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.errors.length).toBeGreaterThanOrEqual(2);
    }
  });
});

describe("getProfile input checks", () => {
  it("rejects an invalid conferenceId", () => {
    let caught: unknown = null;
    try {
      getProfile("test", "Bad_ID");
    } catch (error: unknown) {
      caught = error;
    }
    expect(caught).toBeInstanceOf(ChainError);
    expect(caught instanceof ChainError ? caught.code : null).toBe("INVALID_SCHEMA");
  });

  it("accepts a conferenceId at the regex boundaries", () => {
    expect(getProfile("test", "abc").conferenceId).toBe("abc");
    expect(getProfile("test", "a" + "b".repeat(63)).conferenceId).toHaveLength(64);
  });
});
