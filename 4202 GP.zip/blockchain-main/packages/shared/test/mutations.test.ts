// Tamper mutations (SPEC 10, RC15 shared part). The full-chain consequences of delete-and-remine and of edits with a
// re-mine are already covered by rc3-rewrite.test.ts; here only the mutation functions themselves are exercised, with
// validateChain used to confirm the results of the functions that build chains.

import { describe, expect, it } from "vitest";
import { canonicalize } from "../src/canonical.js";
import { validateChain } from "../src/chain.js";
import { ChainError } from "../src/errors.js";
import {
  MAX_REMINE_BLOCKS,
  MUTATIONS,
  applyMutation,
  assertMutationApplicable,
  editPreviousHash,
  mutateFirstRecord,
  type RecordMutator,
} from "../src/mutations.js";
import { ChainRecord, HexSha256, SessionId, type Block } from "../src/schemas.js";
import { nodeHash } from "../src/crypto-node.js";
import {
  BASE_TIME,
  CRYPTO,
  TEST_PROFILE,
  buildChain,
  makeKeys,
  signedAttendance,
  signedRegistration,
  type PlannedBlock,
  type TestKeys,
} from "./helpers.js";

const T = (step: number): number => BASE_TIME + step * 1_000;

function expectChainError(action: () => unknown, code: string): void {
  let caught: unknown;
  try {
    action();
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(ChainError);
  expect((caught as ChainError).code).toBe(code);
}

function seededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function blockWith(records: Block["records"]): Block {
  return {
    index: 1,
    timestamp: T(1),
    previousHash: "a".repeat(64),
    difficulty: 1,
    nonce: 7,
    hash: "b".repeat(64),
    records,
  };
}

let keysPromise: Promise<TestKeys> | null = null;
function keys(): Promise<TestKeys> {
  keysPromise ??= makeKeys();
  return keysPromise;
}

describe("mutateFirstRecord (RC15 shared part)", () => {
  it("alias 'tampered' becomes 'tampered2': differs, still schema-valid", async () => {
    const original = await signedRegistration(await keys(), T(1), { alias: "tampered" });
    const mutated = mutateFirstRecord(blockWith([original])).records[0];
    expect(mutated?.payload.type).toBe("register");
    expect(mutated?.payload.type === "register" ? mutated.payload.alias : null).toBe("tampered2");
    expect(canonicalize(mutated)).not.toBe(canonicalize(original));
    expect(ChainRecord.safeParse(mutated).success).toBe(true);
  });

  it("any other alias becomes 'tampered'", async () => {
    const original = await signedRegistration(await keys(), T(1), { alias: "alice" });
    const mutated = mutateFirstRecord(blockWith([original])).records[0];
    expect(mutated?.payload.type === "register" ? mutated.payload.alias : null).toBe("tampered");
  });

  it("sessionId 'tampered' becomes 'tampered2' and any other becomes 'tampered'", async () => {
    const k = await keys();
    const same = mutateFirstRecord(blockWith([await signedAttendance(k, "tampered", T(1))])).records[0];
    expect(same?.payload.type === "attend" ? same.payload.sessionId : null).toBe("tampered2");
    const other = mutateFirstRecord(blockWith([await signedAttendance(k, "keynote", T(1))])).records[0];
    expect(other?.payload.type === "attend" ? other.payload.sessionId : null).toBe("tampered");
    expect(ChainRecord.safeParse(same).success && ChainRecord.safeParse(other).success).toBe(true);
  });

  it("mutates only the FIRST record by type and leaves hash, nonce and the other records alone", async () => {
    const k = await keys();
    const first = await signedAttendance(k, "s1", T(1));
    const second = await signedRegistration(k, T(1), { alias: "bob" });
    const block = blockWith([first, second]);
    const mutated = mutateFirstRecord(block);
    expect(mutated.records[1]).toEqual(second);
    expect(mutated.records[0]?.signature).toBe(first.signature);
    expect(mutated.hash).toBe(block.hash);
    expect(mutated.nonce).toBe(block.nonce);
    // the input is not modified
    expect(block.records[0]).toEqual(first);
  });

  it("a block without records is a validation error (INVALID_SCHEMA), not an INTERNAL failure", () => {
    expectChainError(() => mutateFirstRecord(blockWith([])), "INVALID_SCHEMA");
  });

  it("table-driven: 50 seeded records (alias length 1..50, sessionId length 1..64) always change and stay schema-valid", async () => {
    const k = await keys();
    const random = seededRandom(20260101);
    const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
    const sessionAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
    const pick = (chars: string, length: number): string =>
      Array.from({ length }, () => chars.charAt(Math.floor(random() * chars.length))).join("");

    const cases: { kind: "register" | "attend"; value: string }[] = [
      { kind: "register", value: "a".repeat(50) },
      { kind: "register", value: "tampered" },
      { kind: "register", value: "tampered2" },
      { kind: "register", value: "x" },
      { kind: "attend", value: "s".repeat(64) },
      { kind: "attend", value: "-".repeat(64) },
      { kind: "attend", value: "tampered" },
      { kind: "attend", value: "tampered2" },
      { kind: "attend", value: "_" },
    ];
    while (cases.length < 50) {
      const isRegister = cases.length % 2 === 0;
      cases.push(
        isRegister
          ? { kind: "register", value: pick(alphabet, 1 + Math.floor(random() * 50)) }
          : { kind: "attend", value: pick(sessionAlphabet, 1 + Math.floor(random() * 64)) },
      );
    }
    expect(cases).toHaveLength(50);

    for (const { kind, value } of cases) {
      const original =
        kind === "register"
          ? await signedRegistration(k, T(1), { alias: value })
          : await signedAttendance(k, value, T(1));
      expect(SessionId.safeParse(kind === "attend" ? value : "ok").success).toBe(true);
      const mutated = mutateFirstRecord(blockWith([original])).records[0];
      expect(canonicalize(mutated), `${kind}:${value}`).not.toBe(canonicalize(original));
      expect(mutated).not.toEqual(original);
      expect(ChainRecord.safeParse(mutated).success, `${kind}:${value}`).toBe(true);
    }
  });

  it("a broken mutator (returns the same record) throws INTERNAL, never a result", async () => {
    const original = await signedRegistration(await keys(), T(1));
    const identity: RecordMutator = (record) => record;
    expectChainError(() => mutateFirstRecord(blockWith([original]), identity), "INTERNAL");
  });

  it("a mutator whose output breaks the structural schema throws INTERNAL", async () => {
    const original = await signedRegistration(await keys(), T(1));
    const breaksSchema: RecordMutator = (record) =>
      record.payload.type === "register"
        ? { payload: { ...record.payload, alias: " padded " }, signature: record.signature }
        : record;
    expectChainError(() => mutateFirstRecord(blockWith([original]), breaksSchema), "INTERNAL");
  });
});

describe("editPreviousHash (RC15 shared part)", () => {
  it.each([
    ["0", "1"],
    ["1", "0"],
    ["9", "0"],
    ["a", "0"],
    ["f", "0"],
  ])("a hash starting with %s changes its first character to %s and stays a valid HexSha256", (first, expected) => {
    const previousHash = `${first}${"c".repeat(63)}`;
    const mutated = editPreviousHash({ ...blockWith([]), previousHash });
    expect(mutated.previousHash).toBe(`${expected}${"c".repeat(63)}`);
    expect(mutated.previousHash).not.toBe(previousHash);
    expect(HexSha256.safeParse(mutated.previousHash).success).toBe(true);
  });
});

// genesis, 1 register alice, 2 attend alice s1, 3 attend alice s2, 4 register bob (difficulty 2 after 3 instant blocks)
async function fixture(): Promise<{ chain: Block[]; alice: TestKeys }> {
  const alice = await makeKeys();
  const bob = await makeKeys();
  const chain = buildChain([
    { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
    { timestamp: T(1), records: [await signedAttendance(alice, "s1", T(1))] },
    { timestamp: T(1), records: [await signedAttendance(alice, "s2", T(1))] },
    { timestamp: T(1), records: [await signedRegistration(bob, T(1), { alias: "bob" })] },
  ]);
  return { chain, alice };
}

// A block index of the fixture where each mutation applies, and what the real validator must answer.
const APPLICABLE: [(typeof MUTATIONS)[number], number, string | null][] = [
  ["edit-record", 2, "BAD_BLOCK_HASH"],
  ["edit-previous-hash", 2, "BAD_PREVIOUS_HASH"],
  ["rehash-after-edit", 1, "INVALID_SIGNATURE"],
  ["lower-difficulty", 4, "BAD_DIFFICULTY"],
  ["delete-record-and-remine", 2, null],
];

describe("applyMutation", () => {
  it("fixture: equal timestamps raise the required difficulty at block 4 (test profile, I = 3)", async () => {
    const { chain } = await fixture();
    expect(chain.map((block) => block.difficulty)).toEqual([1, 1, 1, 1, 2]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("never modifies its input chain", async () => {
    const { chain } = await fixture();
    const before = canonicalize(chain);
    for (const [mutation, index] of APPLICABLE) {
      applyMutation(chain, mutation, index, TEST_PROFILE, nodeHash);
    }
    expect(canonicalize(chain)).toBe(before);
  });

  it("each mutation yields the validator code of SPEC 10", async () => {
    const { chain } = await fixture();
    for (const [mutation, index, code] of APPLICABLE) {
      const result = await validateChain(applyMutation(chain, mutation, index, TEST_PROFILE, nodeHash), TEST_PROFILE, CRYPTO);
      expect(result, mutation).toEqual(code === null ? { ok: true } : { ok: false, code, blockIndex: index });
    }
  });

  it("rehash-after-edit re-mines ONLY the edited block and keeps valid PoW with the required difficulty", async () => {
    const { chain } = await fixture();
    const mutated = applyMutation(chain, "rehash-after-edit", 4, TEST_PROFILE, nodeHash);
    expect(mutated[4]?.difficulty).toBe(2);
    expect(mutated[4]?.hash.startsWith("00")).toBe(true);
    expect(mutated[4]?.hash).not.toBe(chain[4]?.hash);
    expect(mutated.slice(0, 4)).toEqual(chain.slice(0, 4));
    expect(await validateChain(mutated, TEST_PROFILE, CRYPTO)).toEqual({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 4 });
  });

  it("lower-difficulty re-mines only that block at required - 1", async () => {
    const { chain } = await fixture();
    const mutated = applyMutation(chain, "lower-difficulty", 4, TEST_PROFILE, nodeHash);
    expect(mutated[4]?.difficulty).toBe(1);
    expect(mutated.slice(0, 4)).toEqual(chain.slice(0, 4));
    expect(mutated[4]?.records).toEqual(chain[4]?.records);
  });

  it("lower-difficulty on a block whose required difficulty is the minimum is a validation error (INVALID_SCHEMA)", async () => {
    const { chain } = await fixture();
    expect(chain[2]?.difficulty).toBe(TEST_PROFILE.minDifficulty);
    expectChainError(() => applyMutation(chain, "lower-difficulty", 2, TEST_PROFILE, nodeHash), "INVALID_SCHEMA");
    expectChainError(() => assertMutationApplicable(chain, "lower-difficulty", 2, TEST_PROFILE), "INVALID_SCHEMA");
  });

  it.each([0, 5, 6, -1, 1.5, Number.NaN])("blockIndex %s is out of range for a 5 block chain (INVALID_SCHEMA)", async (index) => {
    const { chain } = await fixture();
    for (const mutation of MUTATIONS) {
      expectChainError(() => applyMutation(chain, mutation, index, TEST_PROFILE, nodeHash), "INVALID_SCHEMA");
    }
  });

  it("a block with no records is refused for every mutation", async () => {
    const chain = buildChain([{ timestamp: T(1), records: [] }]);
    for (const mutation of MUTATIONS) {
      expectChainError(() => applyMutation(chain, mutation, 1, TEST_PROFILE, nodeHash), "INVALID_SCHEMA");
    }
  });

  it("a broken record mutator makes edit-record and rehash-after-edit fail with INTERNAL", async () => {
    const { chain } = await fixture();
    const identity: RecordMutator = (record) => record;
    expectChainError(() => applyMutation(chain, "edit-record", 1, TEST_PROFILE, nodeHash, { recordMutator: identity }), "INTERNAL");
    expectChainError(
      () => applyMutation(chain, "rehash-after-edit", 1, TEST_PROFILE, nodeHash, { recordMutator: identity }),
      "INTERNAL",
    );
  });
});

describe("delete-record-and-remine", () => {
  it("removes the LAST attendance record, re-mines blockIndex..head with fixed links and the required difficulty", async () => {
    const alice = await makeKeys();
    const bob = await makeKeys();
    // block 2 holds [attend alice s1, register bob, attend alice s2]: the last attendance is the third record.
    const chain = buildChain([
      { timestamp: T(1), records: [await signedRegistration(alice, T(1))] },
      {
        timestamp: T(1),
        records: [
          await signedAttendance(alice, "s1", T(1)),
          await signedRegistration(bob, T(1), { alias: "bob" }),
          await signedAttendance(alice, "s2", T(1)),
        ],
      },
      { timestamp: T(1), records: [await signedAttendance(bob, "s1", T(1))] },
      { timestamp: T(1), records: [await signedAttendance(bob, "s2", T(1))] },
    ]);
    const mutated = applyMutation(chain, "delete-record-and-remine", 2, TEST_PROFILE, nodeHash);
    expect(mutated).toHaveLength(chain.length);
    expect(mutated[2]?.records).toEqual([chain[2]?.records[0], chain[2]?.records[1]]);
    expect(mutated.slice(0, 2)).toEqual(chain.slice(0, 2));
    for (let i = 2; i < mutated.length; i += 1) {
      expect(mutated[i]?.previousHash).toBe(mutated[i - 1]?.hash);
      expect(mutated[i]?.hash).not.toBe(chain[i]?.hash);
    }
    // the difficulty rises at block 4 (equal timestamps): the re-mined block 4 carries the required value.
    expect(mutated.map((block) => block.difficulty)).toEqual(chain.map((block) => block.difficulty));
    expect(mutated[4]?.difficulty).toBe(2);
    expect(await validateChain(mutated, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("requires an attendance record in the block", async () => {
    const { chain } = await fixture();
    expectChainError(() => applyMutation(chain, "delete-record-and-remine", 1, TEST_PROFILE, nodeHash), "INVALID_SCHEMA");
  });

  it(`refuses when more than ${MAX_REMINE_BLOCKS} blocks would need re-mining and accepts exactly ${MAX_REMINE_BLOCKS}`, async () => {
    const alice = await makeKeys();
    const plan: PlannedBlock[] = [{ timestamp: T(1), records: [await signedRegistration(alice, T(1))] }];
    for (let i = 0; i < 11; i += 1) {
      plan.push({ timestamp: T(1 + i), records: [await signedAttendance(alice, `s${i}`, T(1 + i))] });
    }
    const chain = buildChain(plan);
    expect(chain).toHaveLength(13);
    // blockIndex 2 -> blocks 2..12 = 11 blocks
    expectChainError(() => applyMutation(chain, "delete-record-and-remine", 2, TEST_PROFILE, nodeHash), "INVALID_SCHEMA");
    // blockIndex 3 -> blocks 3..12 = 10 blocks
    const mutated = applyMutation(chain, "delete-record-and-remine", 3, TEST_PROFILE, nodeHash);
    expect(await validateChain(mutated, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });
});
