// browserIdentityCrypto (WebCrypto) against nodeIdentityCrypto (node:crypto).
// Node's global WebCrypto is the browser implementation under test; node:crypto is used in tests only.

import { randomBytes, generateKeyPairSync } from "node:crypto";
import { describe, expect, it } from "vitest";
import { browserIdentityCrypto } from "../src/crypto-browser.js";
import { nodeHash, nodeIdentityCrypto } from "../src/crypto-node.js";
import { canonicalize } from "../src/canonical.js";
import { deriveAttendeeId, signPayload, validatePublicKey, verifyPayload } from "../src/identity.js";
import { verifyRecordIntegrity } from "../src/chain.js";
import { ChainError } from "../src/errors.js";
import type { RegistrationPayload, SignedRegistration } from "../src/schemas.js";
import { CHAIN_ID, CRYPTO, TEST_PROFILE } from "./helpers.js";

const encoder = new TextEncoder();

function registrationPayload(publicKey: string, attendeeId: string, alias: string): RegistrationPayload {
  return {
    type: "register",
    chainId: CHAIN_ID,
    attendeeId,
    alias,
    publicKey,
    timestamp: 1_767_225_600_000,
  };
}

function nodeSpkiBase64(modulusLength: number, publicExponent: number): string {
  const { publicKey } = generateKeyPairSync("rsa", {
    modulusLength,
    publicExponent,
    publicKeyEncoding: { type: "spki", format: "der" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
  return publicKey.toString("base64");
}

describe("browser adapter: interop with node adapter", () => {
  it("a browser-signed registration payload verifies with nodeIdentityCrypto", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, browserIdentityCrypto);
    const payload = registrationPayload(pair.publicKey, attendeeId, "browser-alice");
    const signature = await signPayload(payload, pair.privateKey, browserIdentityCrypto);

    expect(await verifyPayload(payload, signature, pair.publicKey, nodeIdentityCrypto)).toBe(true);
    expect(await verifyPayload(payload, signature, pair.publicKey, browserIdentityCrypto)).toBe(true);
  });

  it("a node-signed registration payload verifies with the browser adapter", async () => {
    const pair = await nodeIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, nodeIdentityCrypto);
    const payload = registrationPayload(pair.publicKey, attendeeId, "node-alice");
    const signature = await signPayload(payload, pair.privateKey, nodeIdentityCrypto);

    expect(await verifyPayload(payload, signature, pair.publicKey, browserIdentityCrypto)).toBe(true);
    expect(await verifyPayload(payload, signature, pair.publicKey, nodeIdentityCrypto)).toBe(true);
  });

  it("both adapters verify the same canonical bytes, and reject a changed payload", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, browserIdentityCrypto);
    const payload = registrationPayload(pair.publicKey, attendeeId, "bytes");
    const bytes = encoder.encode(canonicalize(payload));
    const signature = await browserIdentityCrypto.sign(bytes, pair.privateKey);

    expect(await nodeIdentityCrypto.verify(bytes, signature, pair.publicKey)).toBe(true);
    expect(await browserIdentityCrypto.verify(bytes, signature, pair.publicKey)).toBe(true);

    const changed = encoder.encode(canonicalize({ ...payload, alias: "bytez" }));
    expect(await nodeIdentityCrypto.verify(changed, signature, pair.publicKey)).toBe(false);
    expect(await browserIdentityCrypto.verify(changed, signature, pair.publicKey)).toBe(false);
  });
});

describe("browser adapter: private key handling", () => {
  it("generateKeyPair returns a non-extractable private CryptoKey and an SPKI public key", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    expect(pair.privateKey).toBeInstanceOf(CryptoKey);
    expect((pair.privateKey as CryptoKey).extractable).toBe(false);
    expect((pair.privateKey as CryptoKey).type).toBe("private");
    const info = await browserIdentityCrypto.inspectPublicKey(pair.publicKey);
    expect(info?.canonicalSpki).toBe(pair.publicKey);
  });

  it("exportKey('pkcs8') on the browser private key throws", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    await expect(globalThis.crypto.subtle.exportKey("pkcs8", pair.privateKey as CryptoKey)).rejects.toThrow();
  });

  it("sign rejects a handle that is not a browser private key", async () => {
    const pem = (await nodeIdentityCrypto.generateKeyPair()).privateKey;
    await expect(browserIdentityCrypto.sign(encoder.encode("x"), pem)).rejects.toThrow(ChainError);
  });
});

describe("browser adapter: inspectPublicKey", () => {
  it("returns 2048 bits and e=65537 for a browser-generated key", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    expect(await browserIdentityCrypto.inspectPublicKey(pair.publicKey)).toEqual({
      modulusBits: 2048,
      publicExponent: 65537,
      canonicalSpki: pair.publicKey,
    });
  });

  it("results equal across adapters for the same node-generated key", async () => {
    const pair = await nodeIdentityCrypto.generateKeyPair();
    const viaNode = await nodeIdentityCrypto.inspectPublicKey(pair.publicKey);
    const viaBrowser = await browserIdentityCrypto.inspectPublicKey(pair.publicKey);
    expect(viaBrowser).not.toBeNull();
    expect(viaBrowser).toEqual(viaNode);
  });

  it("results equal across adapters for a browser-generated key", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    expect(await browserIdentityCrypto.inspectPublicKey(pair.publicKey)).toEqual(
      await nodeIdentityCrypto.inspectPublicKey(pair.publicKey),
    );
  });

  it("returns null for non-canonical base64 and for garbage DER in both adapters", async () => {
    const garbage = Buffer.alloc(294, 0x5a).toString("base64");
    const nonCanonical = "AAAA\n";
    for (const adapter of [nodeIdentityCrypto, browserIdentityCrypto]) {
      expect(await adapter.inspectPublicKey(garbage)).toBeNull();
      expect(await adapter.inspectPublicKey(nonCanonical)).toBeNull();
    }
  });

  it("returns null for a non-RSA (EC) SPKI in both adapters", async () => {
    const { publicKey } = generateKeyPairSync("ec", {
      namedCurve: "P-256",
      publicKeyEncoding: { type: "spki", format: "der" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    const ecSpki = publicKey.toString("base64");
    expect(await nodeIdentityCrypto.inspectPublicKey(ecSpki)).toBeNull();
    expect(await browserIdentityCrypto.inspectPublicKey(ecSpki)).toBeNull();
  });
});

describe("browser adapter: sha256Hex", () => {
  it("equals nodeHash for random byte arrays", async () => {
    for (let i = 0; i < 100; i += 1) {
      const bytes = new Uint8Array(randomBytes(i * 7));
      expect(await browserIdentityCrypto.sha256Hex(bytes)).toBe(nodeHash(bytes));
    }
  });

  it("matches the known SHA-256 of the empty input", async () => {
    expect(await browserIdentityCrypto.sha256Hex(new Uint8Array())).toBe(
      "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    );
  });
});

describe("browser adapter: registration pipeline", () => {
  it("a registration produced entirely with the browser adapter passes verifyRecordIntegrity", async () => {
    const browserCrypto = { identity: browserIdentityCrypto, hash: CRYPTO.hash };
    const pair = await browserIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, browserIdentityCrypto);
    const payload = registrationPayload(pair.publicKey, attendeeId, "browser-only");
    const signature = await signPayload(payload, pair.privateKey, browserIdentityCrypto);
    const record: SignedRegistration = { payload, signature };

    const result = await verifyRecordIntegrity(record, () => undefined, TEST_PROFILE, browserCrypto);
    expect(result).toEqual({ ok: true });
  });

  it("the same browser-built record with a tampered alias fails with INVALID_SIGNATURE", async () => {
    const browserCrypto = { identity: browserIdentityCrypto, hash: CRYPTO.hash };
    const pair = await browserIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, browserIdentityCrypto);
    const payload = registrationPayload(pair.publicKey, attendeeId, "original");
    const signature = await signPayload(payload, pair.privateKey, browserIdentityCrypto);
    const record: SignedRegistration = { payload: { ...payload, alias: "forged" }, signature };

    expect(await verifyRecordIntegrity(record, () => undefined, TEST_PROFILE, browserCrypto)).toEqual({
      ok: false,
      code: "INVALID_SIGNATURE",
    });
  });
});

describe("browser adapter: invalid keys match node adapter", () => {
  const cases: ReadonlyArray<{ name: string; modulusLength: number; publicExponent: number; bits: number; e: number }> = [
    { name: "RSA-2048 with e=3", modulusLength: 2048, publicExponent: 3, bits: 2048, e: 3 },
    { name: "RSA-1024 with e=65537", modulusLength: 1024, publicExponent: 65537, bits: 1024, e: 65537 },
  ];

  for (const testCase of cases) {
    it(`${testCase.name}: inspect and validatePublicKey agree`, async () => {
      const spki = nodeSpkiBase64(testCase.modulusLength, testCase.publicExponent);
      const viaNode = await nodeIdentityCrypto.inspectPublicKey(spki);
      const viaBrowser = await browserIdentityCrypto.inspectPublicKey(spki);
      expect(viaNode).toEqual({ modulusBits: testCase.bits, publicExponent: testCase.e, canonicalSpki: spki });
      expect(viaBrowser).toEqual(viaNode);

      expect(await validatePublicKey(spki, nodeIdentityCrypto)).toBe(false);
      expect(await validatePublicKey(spki, browserIdentityCrypto)).toBe(false);
    });

    it(`${testCase.name}: a valid signature still verifies in both adapters`, async () => {
      const { publicKey, privateKey } = generateKeyPairSync("rsa", {
        modulusLength: testCase.modulusLength,
        publicExponent: testCase.publicExponent,
        publicKeyEncoding: { type: "spki", format: "der" },
        privateKeyEncoding: { type: "pkcs8", format: "pem" },
      });
      const spki = publicKey.toString("base64");
      const bytes = encoder.encode("odd-key message");
      const signature = await nodeIdentityCrypto.sign(bytes, privateKey.toString());
      expect(await nodeIdentityCrypto.verify(bytes, signature, spki)).toBe(true);
      expect(await browserIdentityCrypto.verify(bytes, signature, spki)).toBe(true);
    });
  }

  it("verify returns false in both adapters for malformed inputs, never throwing", async () => {
    const pair = await browserIdentityCrypto.generateKeyPair();
    const bytes = encoder.encode("message");
    const signature = await browserIdentityCrypto.sign(bytes, pair.privateKey);
    const ecSpki = generateKeyPairSync("ec", {
      namedCurve: "P-256",
      publicKeyEncoding: { type: "spki", format: "der" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    }).publicKey.toString("base64");
    const shortSignature = Buffer.alloc(10, 1).toString("base64");
    const garbageSpki = Buffer.alloc(294, 0x5a).toString("base64");

    const badInputs: ReadonlyArray<readonly [string, string, string]> = [
      ["non-canonical signature base64", "AAAA\n", pair.publicKey],
      ["non-canonical key base64", signature, "AAAA\n"],
      ["truncated signature", shortSignature, pair.publicKey],
      ["garbage key DER", signature, garbageSpki],
      ["EC key", signature, ecSpki],
    ];
    for (const [, sig, key] of badInputs) {
      expect(await nodeIdentityCrypto.verify(bytes, sig, key)).toBe(false);
      expect(await browserIdentityCrypto.verify(bytes, sig, key)).toBe(false);
    }
  });
});
