import { describe, expect, it } from "vitest";
import { canonicalize } from "../src/canonical.js";
import { ChainError } from "../src/errors.js";

function expectInvalidSchema(fn: () => unknown): void {
  let caught: unknown = null;
  try {
    fn();
  } catch (error: unknown) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(ChainError);
  expect(caught instanceof ChainError ? caught.code : null).toBe("INVALID_SCHEMA");
}

describe("canonicalize (test 1)", () => {
  it("is stable under key reordering", () => {
    expect(canonicalize({ b: 1, a: { d: 2, c: [3, 4] } })).toBe(
      canonicalize({ a: { c: [3, 4], d: 2 }, b: 1 }),
    );
  });

  it("sorts keys by UTF-16 code unit order and emits no whitespace", () => {
    expect(canonicalize({ b: 1, a: "x", "\uFFFF": 0, "\u{1F600}": 0 })).toBe(
      '{"a":"x","b":1,"\u{1F600}":0,"\uFFFF":0}',
    );
  });

  it("preserves array order", () => {
    expect(canonicalize([3, 1, 2])).toBe("[3,1,2]");
  });

  it("serializes strings with JSON escaping and booleans", () => {
    expect(canonicalize({ s: 'a"b\\c\n', t: true, f: false })).toBe('{"f":false,"s":"a\\"b\\\\c\\n","t":true}');
  });

  it("accepts zero and returns 0 for it", () => {
    expect(canonicalize({ n: 0 })).toBe('{"n":0}');
    expect(canonicalize(0)).toBe("0");
  });

  it("accepts the largest and smallest safe integers", () => {
    expect(canonicalize(Number.MAX_SAFE_INTEGER)).toBe("9007199254740991");
    expect(canonicalize(Number.MIN_SAFE_INTEGER)).toBe("-9007199254740991");
  });

  it("rejects floats", () => {
    expectInvalidSchema(() => canonicalize(1.5));
    expectInvalidSchema(() => canonicalize({ x: 0.1 }));
  });

  it("rejects null and undefined, including nested", () => {
    expectInvalidSchema(() => canonicalize(null));
    expectInvalidSchema(() => canonicalize(undefined));
    expectInvalidSchema(() => canonicalize({ a: null }));
    expectInvalidSchema(() => canonicalize({ a: undefined }));
    expectInvalidSchema(() => canonicalize([1, undefined]));
  });

  it("rejects -0 both top-level and nested", () => {
    expectInvalidSchema(() => canonicalize(-0));
    expectInvalidSchema(() => canonicalize({ n: -0 }));
    expectInvalidSchema(() => canonicalize([-0]));
  });

  it("rejects unsafe integers", () => {
    expectInvalidSchema(() => canonicalize(2 ** 53));
    expectInvalidSchema(() => canonicalize(-(2 ** 53)));
  });

  it("rejects NaN and Infinity", () => {
    expectInvalidSchema(() => canonicalize(Number.NaN));
    expectInvalidSchema(() => canonicalize(Number.POSITIVE_INFINITY));
    expectInvalidSchema(() => canonicalize(Number.NEGATIVE_INFINITY));
  });

  it("rejects bigint, functions and symbols", () => {
    expectInvalidSchema(() => canonicalize(1n));
    expectInvalidSchema(() => canonicalize(() => 1));
    expectInvalidSchema(() => canonicalize(Symbol("s")));
  });

  it("rejects non-plain objects", () => {
    expectInvalidSchema(() => canonicalize(new Date(0)));
    expectInvalidSchema(() => canonicalize(new Map()));
    class Thing {
      readonly a = 1;
    }
    expectInvalidSchema(() => canonicalize(new Thing()));
  });

  it("rejects sparse arrays and cyclic structures", () => {
    const sparse: unknown[] = [];
    sparse[1] = 1;
    expectInvalidSchema(() => canonicalize(sparse));
    const cyclic: Record<string, unknown> = {};
    cyclic["self"] = cyclic;
    expectInvalidSchema(() => canonicalize(cyclic));
  });
});
