// RC8 integer schemas (shared part). The /demo/difficulty-simulation HTTP checks live in apps/node.
import { describe, expect, it } from "vitest";
import { canonicalize } from "../src/canonical.js";
import { Block, BlockHeader, NonNegativeInt, PositiveInt } from "../src/schemas.js";

const HASH = "0".repeat(64);

const genesis = {
  index: 0,
  timestamp: 1_700_000_000_000,
  previousHash: HASH,
  difficulty: 1,
  nonce: 0,
  records: [],
  hash: "0".repeat(64),
};

describe("RC8 block integers", () => {
  it("genesis-shaped block (index 0, nonce 0) parses with the block schema", () => {
    expect(Block.safeParse(genesis).success).toBe(true);
  });

  it("nonce 0 and nonce 7 are valid; -1, 1.5 and 2**53 are invalid", () => {
    const withNonce = (nonce: unknown) => Block.safeParse({ ...genesis, nonce }).success;
    expect(withNonce(0)).toBe(true);
    expect(withNonce(7)).toBe(true);
    expect(withNonce(-1)).toBe(false);
    expect(withNonce(1.5)).toBe(false);
    expect(withNonce(2 ** 53)).toBe(false);
  });

  it("index 0 is valid; index -1 is invalid", () => {
    const header = {
      index: 0,
      timestamp: genesis.timestamp,
      previousHash: HASH,
      difficulty: 1,
      nonce: 0,
    };
    const withIndex = (index: unknown) => BlockHeader.safeParse({ ...header, index }).success;
    expect(withIndex(0)).toBe(true);
    expect(withIndex(-1)).toBe(false);
  });

  it("timestamp 0 and difficulty 0 are invalid (positive only)", () => {
    expect(PositiveInt.safeParse(0).success).toBe(false);
    expect(Block.safeParse({ ...genesis, timestamp: 0 }).success).toBe(false);
    expect(Block.safeParse({ ...genesis, difficulty: 0 }).success).toBe(false);
  });

  it("-0 is invalid for every integer field", () => {
    expect(NonNegativeInt.safeParse(-0).success).toBe(false);
    expect(PositiveInt.safeParse(-0).success).toBe(false);
    expect(Block.safeParse({ ...genesis, index: -0 }).success).toBe(false);
    expect(Block.safeParse({ ...genesis, nonce: -0 }).success).toBe(false);
    expect(Block.safeParse({ ...genesis, timestamp: -0 }).success).toBe(false);
    expect(Block.safeParse({ ...genesis, difficulty: -0 }).success).toBe(false);
  });

  it("-0 from a JSON request body (JSON.parse) is invalid", () => {
    const parsed: unknown = JSON.parse('{"index":0,"timestamp":1,"previousHash":"' + HASH + '","difficulty":1,"nonce":-0,"records":[],"hash":"' + HASH + '"}');
    expect(Block.safeParse(parsed).success).toBe(false);
  });
});

describe("RC8 canonicalize integers", () => {
  it("canonicalize({ n: 0 }) returns {\"n\":0}", () => {
    expect(canonicalize({ n: 0 })).toBe('{"n":0}');
  });

  it("canonicalize({ n: -0 }) throws", () => {
    expect(() => canonicalize({ n: -0 })).toThrow();
  });
});
