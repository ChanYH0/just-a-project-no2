// RC4 (shared part): deployment identity. The node-level restart and cross-chain rejection checks live in apps/node.

import { describe, expect, it } from "vitest";
import { deriveChainId, makeGenesis } from "../src/block.js";
import { canonicalize } from "../src/canonical.js";
import { getProfile, MAX_RECORDS_PER_BLOCK, PROTOCOL_VERSION, type ChainConfig } from "../src/config.js";
import { nodeHash } from "../src/crypto-node.js";

const alpha = getProfile("test", "conf-alpha-2026");
const beta = getProfile("test", "conf-beta-2026");

describe("RC4 chainId", () => {
  it("is 64 lowercase hex characters", () => {
    expect(deriveChainId(alpha, nodeHash)).toMatch(/^[0-9a-f]{64}$/);
  });

  it("matches the section 4 formula exactly", () => {
    const expected = nodeHash(
      canonicalize({
        protocol: PROTOCOL_VERSION,
        conferenceId: "conf-alpha-2026",
        consensus: {
          initialDifficulty: alpha.initialDifficulty,
          minDifficulty: alpha.minDifficulty,
          maxDifficulty: alpha.maxDifficulty,
          targetBlockTimeMs: alpha.targetBlockTimeMs,
          adjustmentInterval: alpha.adjustmentInterval,
          maxRecordAgeInBlockMs: alpha.maxRecordAgeInBlockMs,
          maxRecordsPerBlock: MAX_RECORDS_PER_BLOCK,
        },
      }),
    );
    expect(deriveChainId(alpha, nodeHash)).toBe(expected);
  });

  it("differs for a different conferenceId with the same profile", () => {
    expect(deriveChainId(alpha, nodeHash)).not.toBe(deriveChainId(beta, nodeHash));
  });

  it("is equal for the same conferenceId and parameters", () => {
    expect(deriveChainId(alpha, nodeHash)).toBe(
      deriveChainId(getProfile("test", "conf-alpha-2026"), nodeHash),
    );
  });

  it("differs for a different adjustmentInterval with the same conferenceId", () => {
    const changed: ChainConfig = { ...alpha, adjustmentInterval: 4 };
    expect(deriveChainId(changed, nodeHash)).not.toBe(deriveChainId(alpha, nodeHash));
  });

  it("changes with every consensus field", () => {
    const base = deriveChainId(alpha, nodeHash);
    const consensusFields = [
      "initialDifficulty",
      "minDifficulty",
      "maxDifficulty",
      "targetBlockTimeMs",
      "adjustmentInterval",
      "maxRecordAgeInBlockMs",
    ] as const;
    for (const field of consensusFields) {
      const changed: ChainConfig = { ...alpha, [field]: alpha[field] + 1 };
      expect(deriveChainId(changed, nodeHash), field).not.toBe(base);
    }
  });

  it("ignores settings that are not consensus parameters", () => {
    const base = deriveChainId(alpha, nodeHash);
    const operational: ChainConfig = {
      ...alpha,
      maxRecordSkewMs: alpha.maxRecordSkewMs + 1,
      mempoolTtlMs: alpha.mempoolTtlMs + 1,
      maxBlockSkewMs: alpha.maxBlockSkewMs + 1,
    };
    expect(deriveChainId(operational, nodeHash)).toBe(base);
  });
});

describe("RC4 genesis is not the identity", () => {
  it("genesis hashes of two conferences with the same profile are equal, while chainIds differ", () => {
    const genesisAlpha = makeGenesis(alpha, nodeHash);
    const genesisBeta = makeGenesis(beta, nodeHash);
    expect(canonicalize(genesisAlpha)).toBe(canonicalize(genesisBeta));
    expect(genesisAlpha.hash).toBe(genesisBeta.hash);
    expect(deriveChainId(alpha, nodeHash)).not.toBe(deriveChainId(beta, nodeHash));
  });
});
