// RC7 and RC12 (SPEC 14.2): documentation checks. Reads docs read-only via import.meta.url; never edits them.

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const SPEC_PATH = fileURLToPath(new URL("../../../docs/SPEC.md", import.meta.url));
const THREAT_PATH = fileURLToPath(new URL("../../../docs/THREAT_MODEL.md", import.meta.url));
const spec = readFileSync(SPEC_PATH, "utf8");
const threat = readFileSync(THREAT_PATH, "utf8");

const EXACT_TIMESTAMP_SENTENCE = "There is no historical upper bound on block timestamps.";

// Words that claim more privacy than the protocol provides.
const OVERCLAIM_TERMS = /\b(anonymous|anonymity|untraceable|unlinkable|fully private|completely private|GDPR[- ]compliant)\b/i;
// A sentence containing an overclaim term is acceptable only when it also negates it.
const NEGATION = /\b(not|no|nor|never|without|cannot|isn't|doesn't|does not|NOT|NO)\b/;

function sentencesOf(text: string): string[] {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+(?=[A-Z"`(])/);
}

function overclaims(text: string): string[] {
  return sentencesOf(text).filter((sentence) => OVERCLAIM_TERMS.test(sentence) && !NEGATION.test(sentence));
}

describe("RC7 documentation: no historical upper bound is stated exactly", () => {
  it("SPEC section 8 contains the exact timestamp sentence", () => {
    expect(spec).toContain(EXACT_TIMESTAMP_SENTENCE);
  });
});

describe("RC12 documentation: privacy claims agree across documents", () => {
  it("both documents use the words 'pseudonymous' and 'linkable'", () => {
    for (const text of [spec, threat]) {
      expect(text.toLowerCase()).toContain("pseudonymous");
      expect(text.toLowerCase()).toContain("linkable");
    }
  });

  it("SPEC section 5.2 mentions immutability and deletion/retention limits", () => {
    const section = spec.slice(spec.indexOf("### 5.2"), spec.indexOf("### 5.3"));
    expect(section.length).toBeGreaterThan(0);
    expect(section).toMatch(/immutable/i);
    expect(section).toMatch(/deletion|retention/i);
  });

  it("THREAT_MODEL I1 row mentions immutability and deletion, and its status is P (partially mitigated), not M", () => {
    const row = threat.split("\n").find((line) => line.startsWith("| I1 |"));
    expect(row).toBeDefined();
    expect(row).toMatch(/immutable/i);
    expect(row).toMatch(/deletion|retention/i);
    const cells = (row ?? "").split("|").map((cell) => cell.trim()).filter((cell) => cell.length > 0);
    expect(cells.at(-1)).toBe("P");
  });

  it("no document overclaims anonymity without negation (sentence-level scan)", () => {
    expect(overclaims(spec)).toEqual([]);
    expect(overclaims(threat)).toEqual([]);
  });

  it("the overclaim scan does catch a bare anonymity claim, and accepts a negated one", () => {
    expect(overclaims("The data is anonymous.")).toHaveLength(1);
    expect(overclaims("The data is NOT anonymous or risk-free.")).toEqual([]);
  });
});
