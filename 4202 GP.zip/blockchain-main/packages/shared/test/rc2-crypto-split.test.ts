// RC2: async identity vs sync hashing; structural vs semantic.
// Excludes the browser adapter interop and the mineBlock sync checks (later steps).

import { randomBytes } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { nodeHash, nodeIdentityCrypto } from "../src/crypto-node.js";
import { PublicKey, Signature, SignedRegistration } from "../src/schemas.js";
import { validatePublicKey } from "../src/identity.js";
import { ChainError } from "../src/errors.js";

const SRC = new URL("../src/", import.meta.url);

// Browser-safe modules named in RC2. Modules that do not exist yet are skipped
// here and checked when they are added. browser.ts is the browser entry point.
const BROWSER_SAFE = [
  "schemas",
  "canonical",
  "errors",
  "config",
  "crypto",
  "identity",
  "crypto-browser",
  "difficulty",
  "browser",
];

describe("RC2 static check: browser-safe source does not import Node-only modules", () => {
  const present = BROWSER_SAFE.filter((name) => existsSync(new URL(`${name}.ts`, SRC)));

  it("the already-built browser-safe modules exist", () => {
    expect(present).toEqual(
      expect.arrayContaining(["schemas", "canonical", "errors", "config", "crypto", "identity", "difficulty", "browser"]),
    );
  });

  it.each(present)("%s.ts does not import node:crypto, block, chain or crypto-node", (name) => {
    const source = readFileSync(new URL(`${name}.ts`, SRC), "utf8");
    const importPattern = /(?:import|export)\s[^;]*?from\s*["']([^"']+)["']|import\s*\(\s*["']([^"']+)["']\s*\)/g;
    const specifiers: string[] = [];
    for (const match of source.matchAll(importPattern)) {
      const specifier = match[1] ?? match[2];
      if (specifier !== undefined) {
        specifiers.push(specifier);
      }
    }
    const forbidden = specifiers.filter((s) => {
      const base = (s.split("/").pop() ?? s).replace(/\.js$/, "");
      return s.startsWith("node:") || s === "crypto" || ["block", "chain", "crypto-node"].includes(base);
    });
    expect(forbidden).toEqual([]);
  });
});

describe("RC2 hashing: IdentityCrypto.sha256Hex equals HashFn", () => {
  it("returns identical output for 100 random byte arrays", async () => {
    for (let i = 0; i < 100; i += 1) {
      const bytes = new Uint8Array(randomBytes(i * 3));
      expect(await nodeIdentityCrypto.sha256Hex(bytes)).toBe(nodeHash(bytes));
    }
  });

  it("HashFn accepts strings as UTF-8 and matches the byte form", async () => {
    const text = "conference-chain é \u{1F600}";
    expect(nodeHash(text)).toBe(nodeHash(new TextEncoder().encode(text)));
    expect(nodeHash(text)).toBe(await nodeIdentityCrypto.sha256Hex(new TextEncoder().encode(text)));
  });

  it("HashFn returns lowercase 64-char hex", () => {
    expect(nodeHash("")).toBe("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  });
});

describe("RC2 structural vs semantic", () => {
  it("a 294-byte base64 string that is not valid DER passes the schema but fails validatePublicKey", async () => {
    const notDer = Buffer.alloc(294, 0x5a).toString("base64");
    expect(PublicKey.safeParse(notDer).success).toBe(true);
    expect(await validatePublicKey(notDer, nodeIdentityCrypto)).toBe(false);
  });

  it("a 100-byte base64 string fails at the schema layer (never reaches key validation)", () => {
    const short = Buffer.alloc(100, 0x5a).toString("base64");
    expect(PublicKey.safeParse(short).success).toBe(false);
    const parsed = SignedRegistration.safeParse({
      payload: {
        type: "register",
        chainId: "a".repeat(64),
        attendeeId: "b".repeat(64),
        alias: "Alice",
        publicKey: short,
        timestamp: 1,
      },
      signature: Buffer.alloc(256, 1).toString("base64"),
    });
    expect(parsed.success).toBe(false);
  });

  it("the signature schema is structural only and does not verify anything", () => {
    expect(Signature.safeParse(Buffer.alloc(256, 9).toString("base64")).success).toBe(true);
  });

  it("the schema-failure path is a ChainError with INVALID_SCHEMA code type", () => {
    const error = new ChainError("INVALID_SCHEMA", "example");
    expect(error.code).toBe("INVALID_SCHEMA");
  });
});
