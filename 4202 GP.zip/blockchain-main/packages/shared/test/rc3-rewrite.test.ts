// RC3 (SPEC 14.2): history rewrites. Only shared functions build chains; remineFrom re-mines with links fixed.

import { describe, expect, it } from "vitest";
import { validateChain } from "../src/chain.js";
import type { Block, ChainRecord } from "../src/schemas.js";
import {
  BASE_TIME,
  CRYPTO,
  TEST_PROFILE,
  buildChain,
  makeKeys,
  remineFrom,
  signedAttendance,
  signedRegistration,
  type TestKeys,
} from "./helpers.js";

const T = (step: number): number => BASE_TIME + step * 1_000;

interface Fixture {
  chain: Block[];
  alice: TestKeys;
  bob: TestKeys;
}

// genesis, then: 1 register alice, 2 attend alice s1, 3 register bob, 4 attend bob s1, 5 attend alice s2
async function fixture(): Promise<Fixture> {
  const alice = await makeKeys();
  const bob = await makeKeys();
  const chain = buildChain([
    { timestamp: T(1), records: [await signedRegistration(alice, T(1), { alias: "alice" })] },
    { timestamp: T(2), records: [await signedAttendance(alice, "s1", T(2))] },
    { timestamp: T(3), records: [await signedRegistration(bob, T(3), { alias: "bob" })] },
    { timestamp: T(4), records: [await signedAttendance(bob, "s1", T(4))] },
    { timestamp: T(5), records: [await signedAttendance(alice, "s2", T(5))] },
  ]);
  return { chain, alice, bob };
}

function withBlockRecords(chain: readonly Block[], index: number, records: readonly ChainRecord[]): Block[] {
  return chain.map((block, position) => (position === index ? { ...block, records: [...records] } : block));
}

describe("RC3 history rewrites", () => {
  it("the untouched fixture chain is valid", async () => {
    const { chain } = await fixture();
    expect(chain).toHaveLength(6);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("removing a valid attendance and re-mining from that block is accepted (signatures of the rest untouched)", async () => {
    const { chain } = await fixture();
    const block2 = chain[2];
    if (block2 === undefined) {
      throw new Error("fixture block 2 missing");
    }
    const edited = withBlockRecords(chain, 2, []);
    const rewritten = remineFrom(edited, 2, TEST_PROFILE);
    expect(rewritten).toHaveLength(chain.length);
    expect(rewritten[2]?.previousHash).toBe(rewritten[1]?.hash);
    expect(rewritten[2]?.records).toHaveLength(0);
    expect(await validateChain(rewritten, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("editing a registration alias and re-mining from that block fails with INVALID_SIGNATURE at that block", async () => {
    const { chain } = await fixture();
    const block1 = chain[1];
    const original = block1?.records[0];
    if (original === undefined || original.payload.type !== "register") {
      throw new Error("fixture block 1 must hold a registration");
    }
    const edited = withBlockRecords(chain, 1, [
      { ...original, payload: { ...original.payload, alias: "mallory" } },
    ]);
    const rewritten = remineFrom(edited, 1, TEST_PROFILE);
    expect(await validateChain(rewritten, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "INVALID_SIGNATURE",
      blockIndex: 1,
    });
  });

  it("removing a registration that a later attendance depends on, re-mining everything: ATTENDEE_NOT_REGISTERED at the later block", async () => {
    const { chain } = await fixture();
    const edited = withBlockRecords(chain, 1, []);
    const rewritten = remineFrom(edited, 1, TEST_PROFILE);
    expect(await validateChain(rewritten, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_NOT_REGISTERED",
      blockIndex: 2,
    });
  });
});
