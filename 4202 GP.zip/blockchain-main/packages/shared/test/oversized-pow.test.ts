import { describe, expect, it } from "vitest";
import { computeBlockHash, makeGenesis, verifyBlockPow } from "../src/block.js";
import { validateBlock, emptyState } from "../src/chain.js";
import { getProfile, GENESIS_TIMESTAMP } from "../src/config.js";
import { nodeHash, nodeIdentityCrypto } from "../src/crypto-node.js";
import { Block, type Block as BlockType } from "../src/schemas.js";

const config = getProfile("test", "oversized-pow-test");
const crypto = { hash: nodeHash, identity: nodeIdentityCrypto };
const genesis = makeGenesis(config, crypto.hash);

function blockWithDifficulty(difficulty: number): BlockType {
  const content = {
    index: 1,
    timestamp: GENESIS_TIMESTAMP + 1,
    previousHash: genesis.hash,
    difficulty,
    nonce: 0,
    records: [],
  };
  const block = { ...content, hash: computeBlockHash(content, crypto.hash) };
  return Block.parse(block);
}

describe("oversized proof-of-work difficulty", () => {
  it("verifyBlockPow returns false when difficulty exceeds the digest width", () => {
    expect(() => verifyBlockPow(blockWithDifficulty(Number.MAX_SAFE_INTEGER), crypto.hash)).not.toThrow();
    expect(verifyBlockPow(blockWithDifficulty(Number.MAX_SAFE_INTEGER), crypto.hash)).toBe(false);
  });

  it("validateBlock preserves BAD_POW before BAD_DIFFICULTY for an impossible target", async () => {
    await expect(
      validateBlock(blockWithDifficulty(Number.MAX_SAFE_INTEGER), [genesis], emptyState(), config, crypto),
    ).resolves.toEqual({ ok: false, code: "BAD_POW", blockIndex: 1 });
  });
});
