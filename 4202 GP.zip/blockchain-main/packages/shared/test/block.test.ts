import { describe, expect, it } from "vitest";
import { computeBlockHash, makeGenesis, mineBlock, verifyBlockPow, type BlockCandidate } from "../src/block.js";
import { canonicalize } from "../src/canonical.js";
import { getProfile, GENESIS_PREVIOUS_HASH, GENESIS_TIMESTAMP } from "../src/config.js";
import { nodeHash } from "../src/crypto-node.js";
import { Block } from "../src/schemas.js";
import type { Block as BlockType } from "../src/schemas.js";

const config = getProfile("test", "block-test-2026");
const genesis = makeGenesis(config, nodeHash);

const candidate: BlockCandidate = {
  index: 1,
  timestamp: GENESIS_TIMESTAMP + 1_000,
  previousHash: genesis.hash,
  difficulty: 2,
  records: [],
};

function mustMine(input: BlockCandidate, shouldAbort?: () => boolean): BlockType {
  const block = mineBlock(input, nodeHash, shouldAbort);
  if (block === null) {
    throw new Error("mineBlock returned null without an abort request");
  }
  return block;
}

// Deterministic search for a nonce that makes the PoW fail; bounded so a bug cannot hang the test.
function findFailingNonce(block: BlockType): number {
  for (let nonce = block.nonce + 1; nonce < block.nonce + 1_000; nonce += 1) {
    if (!verifyBlockPow({ ...block, nonce }, nodeHash)) {
      return nonce;
    }
  }
  throw new Error("no failing nonce found within 1000 tries");
}

describe("test 6: mineBlock and verifyBlockPow", () => {
  it("a mined block passes verifyBlockPow and the stored hash matches the recomputed one", () => {
    const block = mustMine(candidate);
    expect(Block.safeParse(block).success).toBe(true);
    expect(block.hash.startsWith("00")).toBe(true);
    expect(block.hash).toBe(computeBlockHash(block, nodeHash));
    expect(verifyBlockPow(block, nodeHash)).toBe(true);
  });

  it("changing the nonce makes verifyBlockPow false", () => {
    const block = mustMine(candidate);
    const nonce = findFailingNonce(block);
    expect(verifyBlockPow({ ...block, nonce }, nodeHash)).toBe(false);
  });
});

describe("synchronous block functions (RC2)", () => {
  it("computeBlockHash returns a string, not a Promise", () => {
    const block = mustMine(candidate);
    const result: unknown = computeBlockHash(block, nodeHash);
    expect(result).not.toBeInstanceOf(Promise);
    expect(typeof result).toBe("string");
  });

  it("mineBlock returns a block, not a Promise", () => {
    const result: unknown = mineBlock(candidate, nodeHash);
    expect(result).not.toBeInstanceOf(Promise);
    expect(result).not.toBeNull();
  });
});

describe("computeBlockHash", () => {
  it("hashes canonicalize of exactly the header fields, records and nonce", () => {
    const block = mustMine(candidate);
    const expected = nodeHash(
      canonicalize({
        index: block.index,
        timestamp: block.timestamp,
        previousHash: block.previousHash,
        difficulty: block.difficulty,
        nonce: block.nonce,
        records: block.records,
      }),
    );
    expect(computeBlockHash(block, nodeHash)).toBe(expected);
  });

  it("ignores the hash field", () => {
    const block = mustMine(candidate);
    const withBogusHash: BlockType = { ...block, hash: "f".repeat(64) };
    expect(computeBlockHash(withBogusHash, nodeHash)).toBe(computeBlockHash(block, nodeHash));
  });
});

describe("mineBlock shouldAbort", () => {
  it("returns null when shouldAbort reports true at the first check", () => {
    expect(mineBlock({ ...candidate, difficulty: 3 }, nodeHash, () => true)).toBeNull();
  });

  it("with shouldAbort reporting false, mines the same block as without the callback", () => {
    expect(mineBlock(candidate, nodeHash, () => false)).toEqual(mineBlock(candidate, nodeHash));
  });
});

describe("mineBlock nonce lanes", () => {
  it("searches a disjoint strided lane and returns a block with valid PoW", () => {
    const block = mineBlock(candidate, nodeHash, undefined, { startNonce: 1, stride: 4 });
    expect(block).not.toBeNull();
    expect(block?.nonce).toBeGreaterThanOrEqual(1);
    expect(((block?.nonce ?? 0) - 1) % 4).toBe(0);
    expect(block?.hash).toBe(computeBlockHash(block!, nodeHash));
    expect(verifyBlockPow(block!, nodeHash)).toBe(true);
  });

  it("preserves the historical nonce-zero result when no lane is supplied", () => {
    const serial = mineBlock(candidate, nodeHash);
    const explicit = mineBlock(candidate, nodeHash, undefined, { startNonce: 0, stride: 1 });
    expect(explicit).toEqual(serial);
  });

  it("checks cancellation by attempts in every nonce lane", () => {
    expect(mineBlock({ ...candidate, difficulty: 3 }, nodeHash, () => true, { startNonce: 1, stride: 2 })).toBeNull();
  });

  it("rejects invalid lane values and stops explicitly before unsafe nonce wrap", () => {
    expect(() => mineBlock(candidate, nodeHash, undefined, { startNonce: -1, stride: 1 })).toThrow(/nonce search lane/);
    expect(() => mineBlock(candidate, nodeHash, undefined, { startNonce: 0, stride: 0 })).toThrow(/nonce search lane/);
    const impossibleAtMax = { ...candidate, difficulty: 64 };
    expect(() => mineBlock(impossibleAtMax, nodeHash, undefined, {
      startNonce: Number.MAX_SAFE_INTEGER,
      stride: 1,
    })).toThrow(/nonce search lane exhausted/);
  });
});

describe("makeGenesis", () => {
  it("is deterministic", () => {
    expect(makeGenesis(config, nodeHash)).toEqual(genesis);
    expect(canonicalize(makeGenesis(config, nodeHash))).toBe(canonicalize(genesis));
  });

  it("has the section 4 fields and a valid PoW", () => {
    expect(genesis.index).toBe(0);
    expect(genesis.records).toEqual([]);
    expect(genesis.previousHash).toBe(GENESIS_PREVIOUS_HASH);
    expect(genesis.timestamp).toBe(GENESIS_TIMESTAMP);
    expect(genesis.difficulty).toBe(config.initialDifficulty);
    expect(genesis.hash).toBe(computeBlockHash(genesis, nodeHash));
    expect(verifyBlockPow(genesis, nodeHash)).toBe(true);
    expect(Block.safeParse(genesis).success).toBe(true);
  });
});
