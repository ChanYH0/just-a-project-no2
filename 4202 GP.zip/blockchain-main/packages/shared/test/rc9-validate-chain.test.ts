// RC9 (SPEC 14.2): validateChain enforces the difficulty rule at a boundary and a non-boundary block (BAD_DIFFICULTY);
// genesis alone is a valid chain. The window arithmetic itself is in rc9-difficulty-windows.test.ts.

import { describe, expect, it } from "vitest";
import { validateChain } from "../src/chain.js";
import { CRYPTO, TEST_PROFILE, BASE_TIME, buildChain, genesisFor, mineOn } from "./helpers.js";

const T = (step: number): number => BASE_TIME + step * 1_000;

describe("RC9 validateChain difficulty", () => {
  it("genesis alone passes validateChain", async () => {
    expect(await validateChain([genesisFor()], TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("non-boundary block: a block 1 with difficulty above the required one is BAD_DIFFICULTY at block 1", async () => {
    // Required difficulty for block 1 is initialDifficulty (1). Claim 2: PoW passes, the rule does not.
    const genesis = genesisFor();
    const block = mineOn([genesis], [], T(1), TEST_PROFILE, 2);
    expect(await validateChain([genesis, block], TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_DIFFICULTY",
      blockIndex: 1,
    });
  });

  it("non-boundary block: a block 2 with a wrong difficulty is BAD_DIFFICULTY at block 2", async () => {
    const genesis = genesisFor();
    const block1 = mineOn([genesis], [], T(1));
    const block2 = mineOn([genesis, block1], [], T(2), TEST_PROFILE, 2);
    expect(await validateChain([genesis, block1, block2], TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_DIFFICULTY",
      blockIndex: 2,
    });
  });

  it("boundary block 4: equal timestamps raise the required difficulty to 2; claiming 1 is BAD_DIFFICULTY at block 4", async () => {
    const plan = [T(1), T(1), T(1)].map((timestamp) => ({ timestamp }));
    const prefix = buildChain(plan);
    const wrong = mineOn(prefix, [], T(1), TEST_PROFILE, 1);
    expect(await validateChain([...prefix, wrong], TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_DIFFICULTY",
      blockIndex: 4,
    });
  });

  it("boundary block 4: the required difficulty 2 is accepted", async () => {
    const plan = [T(1), T(1), T(1), T(1)].map((timestamp) => ({ timestamp }));
    const chain = buildChain(plan);
    expect(chain[4]?.difficulty).toBe(2);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });
});
