// RC7 (SPEC 14.2, and A5, A8, A9 of 14.3): timestamp bounds exactly as SPEC section 8 table states them.
// Injected clocks only; no sleeps; no test asserts a bound stronger than the table.

import { describe, expect, it, vi } from "vitest";
import {
  emptyState,
  validateBlock,
  validateBlockAdmission,
  validateChain,
  validateRecordInBlock,
  emptyUniquenessIndex,
} from "../src/chain.js";
import { getProfile, type ChainConfig } from "../src/config.js";
import { nextDifficulty } from "../src/difficulty.js";
import {
  BASE_TIME,
  CRYPTO,
  TEST_PROFILE,
  buildChain,
  genesisFor,
  makeKeys,
  mineOn,
  pureDifficultyChain,
  signedRegistration,
} from "./helpers.js";

const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;
const T = (step: number): number => BASE_TIME + step * 1_000;

function difficultyAt(chain: readonly { difficulty: number }[], indices: readonly number[]): number[] {
  return indices.map((index) => {
    const block = chain[index];
    if (block === undefined) {
      throw new Error(`no block at ${index}`);
    }
    return block.difficulty;
  });
}

describe("RC7 admission bound (validateBlockAdmission, injected clock)", () => {
  const now = BASE_TIME;
  const clock = { now: () => now };

  it("block timestamp = now + maxBlockSkewMs is accepted", async () => {
    const genesis = genesisFor();
    const block = mineOn([genesis], [], now + TEST_PROFILE.maxBlockSkewMs);
    expect(
      await validateBlockAdmission(block, [genesis], emptyState(), TEST_PROFILE, clock, CRYPTO),
    ).toEqual({ ok: true });
  });

  it("block timestamp = now + maxBlockSkewMs + 1 ms is TIMESTAMP_OUT_OF_RANGE", async () => {
    const genesis = genesisFor();
    const block = mineOn([genesis], [], now + TEST_PROFILE.maxBlockSkewMs + 1);
    expect(
      await validateBlockAdmission(block, [genesis], emptyState(), TEST_PROFILE, clock, CRYPTO),
    ).toEqual({ ok: false, code: "TIMESTAMP_OUT_OF_RANGE", blockIndex: 1 });
  });

  it("admission does not apply to history: the same far-future block passes validateBlock", async () => {
    const genesis = genesisFor();
    const block = mineOn([genesis], [], now + TEST_PROFILE.maxBlockSkewMs + 1);
    expect(await validateBlock(block, [genesis], emptyState(), TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });
});

describe("RC7 history without an upper bound", () => {
  it("a chain with non-decreasing timestamps in year 2100 passes validateChain", async () => {
    const start = Date.UTC(2100, 0, 1);
    const chain = buildChain(
      [1, 2, 3, 4].map((step) => ({ timestamp: start + step * 1_000 })),
    );
    expect(new Date(chain.at(-1)?.timestamp ?? 0).getUTCFullYear()).toBe(2100);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("equal timestamps are allowed (lower bound is non-decreasing)", async () => {
    const chain = buildChain([{ timestamp: T(1) }, { timestamp: T(1) }]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("A9: a block timestamp earlier than its parent is BAD_TIMESTAMP_ORDER", async () => {
    const chain = buildChain([{ timestamp: T(2) }, { timestamp: T(1) }]);
    expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "BAD_TIMESTAMP_ORDER",
      blockIndex: 2,
    });
  });
});

describe("RC7 difficulty under extreme timestamps (pure difficulty chains, no mining)", () => {
  // I = 3, target 1 000 ms. Boundaries are blocks 4, 7, 10, 13.
  const boundaries = [4, 7, 10, 13];
  const equalTimestamps = Array.from({ length: 13 }, () => BASE_TIME);

  it("equal timestamps: difficulty rises by exactly +1 per boundary", () => {
    const config: ChainConfig = { ...TEST_PROFILE, initialDifficulty: 1, maxDifficulty: 5 };
    const chain = pureDifficultyChain(equalTimestamps, config);
    expect(difficultyAt(chain, boundaries)).toEqual([2, 3, 4, 5]);
    // Non-boundary blocks inherit the previous difficulty.
    expect(difficultyAt(chain, [1, 2, 3, 5, 6, 8, 9])).toEqual([1, 1, 1, 2, 2, 3, 3]);
  });

  it("equal timestamps never exceed maxDifficulty", () => {
    const config: ChainConfig = { ...TEST_PROFILE, initialDifficulty: 1, maxDifficulty: 3 };
    const chain = pureDifficultyChain(equalTimestamps, config);
    expect(difficultyAt(chain, boundaries)).toEqual([2, 3, 3, 3]);
    expect(Math.max(...chain.map((block) => block.difficulty))).toBe(3);
  });

  it("huge gaps: difficulty falls by exactly 1 per boundary and never goes below minDifficulty", () => {
    const config: ChainConfig = { ...TEST_PROFILE, initialDifficulty: 3, minDifficulty: 1, maxDifficulty: 3 };
    const gaps = Array.from({ length: 13 }, (_unused, offset) => BASE_TIME + (offset + 1) * 1_000_000_000);
    const chain = pureDifficultyChain(gaps, config);
    expect(difficultyAt(chain, boundaries)).toEqual([2, 1, 1, 1]);
    expect(Math.min(...chain.map((block) => block.difficulty))).toBe(1);
  });

  it("the function consulted for a boundary uses only the window (sanity: nextDifficulty agrees)", () => {
    const config: ChainConfig = { ...TEST_PROFILE, initialDifficulty: 1, maxDifficulty: 5 };
    const chain = pureDifficultyChain(equalTimestamps.slice(0, 3), config);
    expect(nextDifficulty(chain, config)).toBe(2);
  });
});

describe("RC7 record age vs block time (symmetric, consensus)", () => {
  const AGE = TEST_PROFILE.maxRecordAgeInBlockMs;
  const blockHeader = { index: 1, timestamp: BASE_TIME + 10_000 };

  async function validateAt(recordTimestamp: number) {
    const alice = await makeKeys();
    const record = await signedRegistration(alice, recordTimestamp);
    return validateRecordInBlock(
      record,
      blockHeader,
      { state: emptyState(), pending: emptyUniquenessIndex() },
      TEST_PROFILE,
      CRYPTO,
    );
  }

  it("record older than the block by exactly maxRecordAgeInBlockMs passes", async () => {
    expect(await validateAt(blockHeader.timestamp - AGE)).toEqual({ ok: true });
  });

  it("record older than the block by maxRecordAgeInBlockMs + 1 ms fails", async () => {
    expect(await validateAt(blockHeader.timestamp - AGE - 1)).toEqual({
      ok: false,
      code: "TIMESTAMP_OUT_OF_RANGE",
    });
  });

  it("record newer than the block by exactly maxRecordAgeInBlockMs passes", async () => {
    expect(await validateAt(blockHeader.timestamp + AGE)).toEqual({ ok: true });
  });

  it("record newer than the block by maxRecordAgeInBlockMs + 1 ms fails", async () => {
    expect(await validateAt(blockHeader.timestamp + AGE + 1)).toEqual({
      ok: false,
      code: "TIMESTAMP_OUT_OF_RANGE",
    });
  });

  it("the same rule at block level reports the block index", async () => {
    const alice = await makeKeys();
    const genesis = genesisFor();
    const stale = await signedRegistration(alice, T(1) - AGE - 1);
    const block = mineOn([genesis], [stale], T(1));
    expect(await validateBlock(block, [genesis], emptyState(), TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "TIMESTAMP_OUT_OF_RANGE",
      blockIndex: 1,
    });
  });
});

describe("RC7 A5 historical validity: validateChain reads no wall clock", () => {
  it("a chain validates after the system clock is advanced one year, and the function takes no clock", async () => {
    const chain = buildChain([{ timestamp: T(1) }, { timestamp: T(2) }, { timestamp: T(3) }]);
    vi.useFakeTimers({ now: BASE_TIME });
    try {
      vi.setSystemTime(BASE_TIME + ONE_YEAR_MS);
      expect(await validateChain(chain, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
    } finally {
      vi.useRealTimers();
    }
    expect(validateChain.length).toBe(3);
  });

  it("the test profile is the one these bounds were written for", () => {
    expect(TEST_PROFILE).toEqual(getProfile("test", TEST_PROFILE.conferenceId));
    expect(TEST_PROFILE.maxBlockSkewMs).toBe(1_000);
  });
});
