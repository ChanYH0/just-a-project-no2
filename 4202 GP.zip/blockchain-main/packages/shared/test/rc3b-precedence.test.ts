// RC3b (SPEC 14.2): integrity precedence and attendance key source (SPEC section 7, review item 3).

import { describe, expect, it } from "vitest";
import {
  emptyState,
  emptyUniquenessIndex,
  validateBlock,
  validateRecordAtSubmission,
  validateRecordInBlock,
  verifyRecordIntegrity,
  buildState,
  type KeyLookup,
} from "../src/chain.js";
import { Alias, type ChainRecord, type SignedRegistration } from "../src/schemas.js";
import {
  BASE_TIME,
  CHAIN_ID,
  CRYPTO,
  GARBAGE_SIGNATURE,
  TEST_PROFILE,
  buildChain,
  genesisFor,
  makeKeys,
  mineOn,
  signedAttendance,
  signedRegistration,
  type TestKeys,
} from "./helpers.js";

const T = (step: number): number => BASE_TIME + step * 1_000;
const CATALOG: ReadonlySet<string> = new Set(["s1"]);
const NO_KEYS: KeyLookup = () => undefined;

function lookupFor(keys: TestKeys): KeyLookup {
  return (attendeeId) => (attendeeId === keys.attendeeId ? keys.publicKey : undefined);
}

describe("RC3b attendance key source", () => {
  it("attendance for an attendee registered only in the mempool: ATTENDEE_NOT_REGISTERED", async () => {
    const alice = await makeKeys();
    const mempool = emptyUniquenessIndex();
    mempool.registrations.add(alice.attendeeId);
    const result = await validateRecordAtSubmission(
      await signedAttendance(alice, "s1", T(1)),
      emptyState(),
      mempool,
      CATALOG,
      TEST_PROFILE,
      { now: () => T(1) },
      CRYPTO,
    );
    expect(result).toEqual({ ok: false, code: "ATTENDEE_NOT_REGISTERED" });
  });

  it("attendance for an attendee registered only in the same block: ATTENDEE_NOT_REGISTERED", async () => {
    const alice = await makeKeys();
    const genesis = genesisFor();
    const block = mineOn(
      [genesis],
      [await signedRegistration(alice, T(1)), await signedAttendance(alice, "s1", T(1))],
      T(1),
    );
    expect(await validateBlock(block, [genesis], emptyState(), TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_NOT_REGISTERED",
      blockIndex: 1,
    });
  });

  it("attendance signed by a different key than the registered one: INVALID_SIGNATURE", async () => {
    const alice = await makeKeys();
    const mallory = await makeKeys();
    const forged = await signedAttendance(alice, "s1", T(2), { signWith: mallory.privateKey });
    const integrity = await verifyRecordIntegrity(forged, lookupFor(alice), TEST_PROFILE, CRYPTO);
    expect(integrity).toEqual({ ok: false, code: "INVALID_SIGNATURE" });
  });

  it("unknown attendee with a garbage signature: ATTENDEE_NOT_REGISTERED (lookup precedes signature)", async () => {
    const alice = await makeKeys();
    const record: ChainRecord = {
      payload: {
        type: "attend",
        chainId: CHAIN_ID,
        attendeeId: alice.attendeeId,
        sessionId: "s1",
        timestamp: T(1),
      },
      signature: GARBAGE_SIGNATURE,
    };
    expect(await verifyRecordIntegrity(record, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_NOT_REGISTERED",
    });
  });
});

describe("RC3b registration precedence: CHAIN_ID_MISMATCH, INVALID_KEY, ATTENDEE_ID_MISMATCH, INVALID_SIGNATURE", () => {
  it.each(["CHAIN_ID_MISMATCH", "INVALID_SIGNATURE"] as const)(
    "in-block integrity failure %s precedes an out-of-range timestamp",
    async (code) => {
      const alice = await makeKeys();
      const record = await signedRegistration(alice, T(1),
        code === "CHAIN_ID_MISMATCH" ? { chainId: "a".repeat(64) } : { signature: GARBAGE_SIGNATURE });
      expect(await validateRecordInBlock(record,
        { index: 1, timestamp: T(1) + TEST_PROFILE.maxRecordAgeInBlockMs + 1 },
        { state: emptyState(), pending: emptyUniquenessIndex() }, TEST_PROFILE, CRYPTO,
      )).toEqual({ ok: false, code });
    },
  );

  it("all four defects at once: CHAIN_ID_MISMATCH", async () => {
    const alice = await makeKeys();
    const record = await signedRegistration(alice, T(1), {
      chainId: "a".repeat(64),
      publicKey: Buffer.alloc(294, 0).toString("base64"),
      attendeeId: "b".repeat(64),
      signature: GARBAGE_SIGNATURE,
    });
    expect(await verifyRecordIntegrity(record, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "CHAIN_ID_MISMATCH",
    });
  });

  it("chainId fixed: INVALID_KEY (invalid key still present)", async () => {
    const alice = await makeKeys();
    const record = await signedRegistration(alice, T(1), {
      publicKey: Buffer.alloc(294, 0).toString("base64"),
      attendeeId: "b".repeat(64),
      signature: GARBAGE_SIGNATURE,
    });
    expect(await verifyRecordIntegrity(record, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "INVALID_KEY",
    });
  });

  it("valid key, wrong attendeeId, bad signature: ATTENDEE_ID_MISMATCH", async () => {
    const alice = await makeKeys();
    const record = await signedRegistration(alice, T(1), {
      attendeeId: "b".repeat(64),
      signature: GARBAGE_SIGNATURE,
    });
    expect(await verifyRecordIntegrity(record, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "ATTENDEE_ID_MISMATCH",
    });
  });

  it("attendeeId fixed, bad signature: INVALID_SIGNATURE, and a valid signature passes", async () => {
    const alice = await makeKeys();
    const bad = await signedRegistration(alice, T(1), { signature: GARBAGE_SIGNATURE });
    expect(await verifyRecordIntegrity(bad, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "INVALID_SIGNATURE",
    });
    const good = await signedRegistration(alice, T(1));
    expect(await verifyRecordIntegrity(good, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

  it("the signature is checked against the payload's own key (proof of possession)", async () => {
    const alice = await makeKeys();
    const mallory = await makeKeys();
    const stolen: SignedRegistration = await signedRegistration(mallory, T(1), {
      signWith: alice.privateKey,
    });
    expect(await verifyRecordIntegrity(stolen, NO_KEYS, TEST_PROFILE, CRYPTO)).toEqual({
      ok: false,
      code: "INVALID_SIGNATURE",
    });
  });
});

describe("RC3b alias schema rejects invisible and direction-reversing code points (also test 9)", () => {
  it.each([
    ["U+202E right-to-left override", "a‮b"],
    ["U+200B zero-width space", "a​b"],
    ["U+2028 line separator", "a b"],
    ["U+0378 unassigned code point", "a͸b"],
    ["leading space", " alice"],
    ["non-NFC input", "é"],
  ])("%s is INVALID_SCHEMA (rejected, not transformed)", (_label, alias) => {
    expect(Alias.safeParse(alias).success).toBe(false);
  });

  it("a plain alias passes", () => {
    expect(Alias.safeParse("alice").success).toBe(true);
  });
});

describe("RC3b in-block scope: pending uniqueness vs the lookup", () => {
  it("validateRecordInBlock: a registration in the block's pending view does not satisfy the lookup", async () => {
    const alice = await makeKeys();
    const block = { index: 1, timestamp: T(1) };
    const pending = emptyUniquenessIndex();
    pending.registrations.add(alice.attendeeId);
    const result = await validateRecordInBlock(
      await signedAttendance(alice, "s1", T(1)),
      block,
      { state: emptyState(), pending },
      TEST_PROFILE,
      CRYPTO,
    );
    expect(result).toEqual({ ok: false, code: "ATTENDEE_NOT_REGISTERED" });
  });

  it("validateBlock on a clean earlier chain: a later attendance uses the confirmed registration", async () => {
    const alice = await makeKeys();
    const chain = buildChain([{ timestamp: T(1), records: [await signedRegistration(alice, T(1))] }]);
    const block = mineOn(chain, [await signedAttendance(alice, "s1", T(2))], T(2));
    expect(await validateBlock(block, chain, buildState(chain), TEST_PROFILE, CRYPTO)).toEqual({ ok: true });
  });

});
