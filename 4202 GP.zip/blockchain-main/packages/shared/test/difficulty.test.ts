// Test 8 (SPEC 14.1): nextDifficulty basics. The full window and boundary matrix is in rc9-difficulty-windows.test.ts.

import { describe, expect, it } from "vitest";
import { adjustmentAt, nextDifficulty, type DifficultyBlock } from "../src/difficulty.js";
import { getProfile, GENESIS_TIMESTAMP, type ChainConfig } from "../src/config.js";
import { ChainError } from "../src/errors.js";

// test profile: I = 3, target 1 000 ms, expected window 2 000 ms.
const T0 = 1_800_000_000_000;

function testConfig(overrides: Partial<ChainConfig> = {}): ChainConfig {
  return { ...getProfile("test", "difficulty-test"), ...overrides };
}

// Genesis plus one block per timestamp; each difficulty comes from nextDifficulty over the prefix before it.
function buildChain(config: ChainConfig, minedTimestamps: readonly number[]): DifficultyBlock[] {
  const chain: DifficultyBlock[] = [
    { index: 0, timestamp: GENESIS_TIMESTAMP, difficulty: nextDifficulty([], config) },
  ];
  minedTimestamps.forEach((timestamp, offset) => {
    chain.push({ index: offset + 1, timestamp, difficulty: nextDifficulty(chain, config) });
  });
  return chain;
}

describe("test 8: nextDifficulty", () => {
  it("genesis takes initialDifficulty", () => {
    expect(nextDifficulty([], testConfig({ initialDifficulty: 2 }))).toBe(2);
  });

  it("a faster window raises difficulty", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const chain = buildChain(config, [T0, T0, T0]);
    expect(nextDifficulty(chain, config)).toBe(3);
  });

  it("a slower window lowers difficulty", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const chain = buildChain(config, [T0, T0 + 5_000, T0 + 10_000]);
    expect(nextDifficulty(chain, config)).toBe(1);
  });

  it("an on-target window keeps difficulty", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const chain = buildChain(config, [T0, T0 + 1_000, T0 + 2_000]);
    expect(nextDifficulty(chain, config)).toBe(2);
  });

  it("results clamp to min and max", () => {
    const low = testConfig({ initialDifficulty: 1 });
    expect(nextDifficulty(buildChain(low, [T0 + 1e9, T0 + 2e9, T0 + 3e9]), low)).toBe(1);
    const high = testConfig({ initialDifficulty: 3 });
    expect(nextDifficulty(buildChain(high, [T0, T0, T0]), high)).toBe(3);
  });

  it("non-boundary blocks keep the previous difficulty", () => {
    const config = testConfig({ initialDifficulty: 2 });
    // Blocks 1..4 are mined with equal timestamps: block 4 is a boundary and rises to 3.
    const chain = buildChain(config, [T0, T0, T0, T0]);
    expect(chain[4]?.difficulty).toBe(3);
    // Block 5 is not a boundary and must keep block 4's difficulty even though its window would be fast.
    expect(adjustmentAt(chain, config)).toBeNull();
    expect(nextDifficulty(chain, config)).toBe(3);
  });

  it("adjustmentAt rejects a window whose indices do not match the prefix", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const chain = buildChain(config, [T0, T0, T0]);
    const broken = chain.map((block, position) => (position === 1 ? { ...block, index: 7 } : block));
    expect(() => nextDifficulty(broken, config)).toThrow(ChainError);
  });
});
