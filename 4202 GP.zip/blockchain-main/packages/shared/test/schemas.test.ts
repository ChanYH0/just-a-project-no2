import { describe, expect, it } from "vitest";
import {
  Alias,
  AttendancePayload,
  Base64Std,
  Block,
  HexSha256,
  NonNegativeInt,
  PositiveInt,
  PublicKey,
  RegistrationPayload,
  SessionId,
  Signature,
  SignedAttendance,
  SignedRegistration,
} from "../src/schemas.js";

const HASH = "a".repeat(64);
const PUBLIC_KEY = Buffer.alloc(294, 1).toString("base64");
const SIGNATURE = Buffer.alloc(256, 2).toString("base64");

// Code points are built from their numeric values so no invisible characters live in source.
const cp = (codePoint: number): string => String.fromCodePoint(codePoint);

const registration = {
  type: "register" as const,
  chainId: HASH,
  attendeeId: "b".repeat(64),
  alias: "Alice",
  publicKey: PUBLIC_KEY,
  timestamp: 1_700_000_000_001,
};

const attendance = {
  type: "attend" as const,
  chainId: HASH,
  attendeeId: "b".repeat(64),
  sessionId: "s1",
  timestamp: 1_700_000_000_002,
};

const ok = (value: unknown, schema: { safeParse: (v: unknown) => { success: boolean } }): boolean =>
  schema.safeParse(value).success;

describe("alias (test 9)", () => {
  it("accepts ordinary aliases, non-Latin text and exactly 50 code points", () => {
    expect(ok("Alice", Alias)).toBe(true);
    expect(ok("愧麗絲", Alias)).toBe(true);
    expect(ok("a b", Alias)).toBe(true);
    expect(ok("a".repeat(50), Alias)).toBe(true);
    expect(ok(cp(0x1f600).repeat(50), Alias)).toBe(true);
  });

  it("rejects empty, 51 code points and whitespace-only", () => {
    expect(ok("", Alias)).toBe(false);
    expect(ok("a".repeat(51), Alias)).toBe(false);
    expect(ok(cp(0x1f600).repeat(51), Alias)).toBe(false);
    expect(ok("   ", Alias)).toBe(false);
  });

  it("rejects leading or trailing whitespace instead of trimming", () => {
    expect(ok(" Alice", Alias)).toBe(false);
    expect(ok("Alice ", Alias)).toBe(false);
    expect(ok("\tAlice", Alias)).toBe(false);
  });

  it("rejects non-NFC input (e + combining acute) instead of normalizing it; accepts NFC", () => {
    const decomposed = "e" + cp(0x0301);
    const composed = cp(0x00e9);
    expect(decomposed.normalize("NFC")).toBe(composed);
    expect(ok(decomposed, Alias)).toBe(false);
    expect(ok(composed, Alias)).toBe(true);
  });

  it("rejects bidi override U+202E", () => {
    expect(ok("Alice" + cp(0x202e), Alias)).toBe(false);
    expect(ok("Ali" + cp(0x202e) + "ce", Alias)).toBe(false);
  });

  it("rejects zero-width space U+200B", () => {
    expect(ok("Ali" + cp(0x200b) + "ce", Alias)).toBe(false);
  });

  it("rejects line separator U+2028 and paragraph separator U+2029", () => {
    expect(ok("Ali" + cp(0x2028) + "ce", Alias)).toBe(false);
    expect(ok("Ali" + cp(0x2029) + "ce", Alias)).toBe(false);
  });

  it("rejects an unassigned code point (U+0378)", () => {
    expect(ok("Ali" + cp(0x0378) + "ce", Alias)).toBe(false);
  });

  it("rejects private use (U+E000) and control characters", () => {
    expect(ok("Ali" + cp(0xe000) + "ce", Alias)).toBe(false);
    expect(ok("Ali" + cp(0x0007) + "ce", Alias)).toBe(false);
  });
});

describe("strict objects (test 9)", () => {
  it("rejects unknown fields in a registration payload (email, emailCommitment)", () => {
    expect(ok({ ...registration, email: "a@b.c" }, RegistrationPayload)).toBe(false);
    expect(ok({ ...registration, emailCommitment: HASH }, RegistrationPayload)).toBe(false);
  });

  it("rejects unknown fields in an attendance payload and in the signed envelopes", () => {
    expect(ok({ ...attendance, name: "x" }, AttendancePayload)).toBe(false);
    expect(ok({ payload: registration, signature: SIGNATURE, extra: 1 }, SignedRegistration)).toBe(false);
    expect(ok({ payload: attendance, signature: SIGNATURE, extra: 1 }, SignedAttendance)).toBe(false);
  });

  it("rejects unknown fields in a block", () => {
    const block = {
      index: 0,
      timestamp: 1,
      previousHash: HASH,
      difficulty: 1,
      nonce: 0,
      records: [],
      hash: HASH,
      extra: true,
    };
    expect(ok(block, Block)).toBe(false);
  });

  it("accepts a well-formed registration and attendance envelope", () => {
    expect(ok({ payload: registration, signature: SIGNATURE }, SignedRegistration)).toBe(true);
    expect(ok({ payload: attendance, signature: SIGNATURE }, SignedAttendance)).toBe(true);
  });
});

describe("structural primitives", () => {
  it("HexSha256 requires 64 lowercase hex characters", () => {
    expect(ok(HASH, HexSha256)).toBe(true);
    expect(ok("A".repeat(64), HexSha256)).toBe(false);
    expect(ok("a".repeat(63), HexSha256)).toBe(false);
  });

  it("Base64Std rejects non-canonical encodings", () => {
    expect(ok("AAAA", Base64Std)).toBe(true);
    expect(ok("AAA", Base64Std)).toBe(false); // length not a multiple of 4
    expect(ok("AA==", Base64Std)).toBe(true); // canonical single zero byte
    expect(ok("AB==", Base64Std)).toBe(false); // non-zero trailing bits
    expect(ok("AC==", Base64Std)).toBe(false); // non-zero trailing bits
    expect(ok("AA A", Base64Std)).toBe(false);
    expect(ok("AA-_", Base64Std)).toBe(false); // url-safe alphabet
  });

  it("PublicKey requires exactly 294 decoded bytes", () => {
    expect(ok(PUBLIC_KEY, PublicKey)).toBe(true);
    expect(ok(Buffer.alloc(100, 1).toString("base64"), PublicKey)).toBe(false);
  });

  it("Signature requires exactly 256 decoded bytes", () => {
    expect(ok(SIGNATURE, Signature)).toBe(true);
    expect(ok(Buffer.alloc(255, 1).toString("base64"), Signature)).toBe(false);
  });

  it("SessionId matches /^[A-Za-z0-9_-]{1,64}$/", () => {
    expect(ok("session_1-A", SessionId)).toBe(true);
    expect(ok("", SessionId)).toBe(false);
    expect(ok("a".repeat(65), SessionId)).toBe(false);
    expect(ok("a b", SessionId)).toBe(false);
  });

  it("integer schemas reject -0 and unsafe integers", () => {
    expect(ok(-0, PositiveInt)).toBe(false);
    expect(ok(-0, NonNegativeInt)).toBe(false);
    expect(ok(2 ** 53, NonNegativeInt)).toBe(false);
  });
});

describe("nonce 0 is a valid nonce", () => {
  it("Block accepts nonce 0 and rejects negative nonce", () => {
    const base = { index: 1, timestamp: 1, previousHash: HASH, difficulty: 1, records: [], hash: HASH };
    expect(ok({ ...base, nonce: 0 }, Block)).toBe(true);
    expect(ok({ ...base, nonce: -1 }, Block)).toBe(false);
  });
});
