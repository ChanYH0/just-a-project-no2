// RC9: difficulty windows, genesis excluded (SPEC sections 4, 8).
// Only the parts that need no validateChain. Config validation items are covered in config.test.ts.
// Chains are plain objects with chosen timestamps; no test sleeps and no test reads the wall clock.

import { describe, expect, it } from "vitest";
import { adjustmentAt, nextDifficulty, type DifficultyBlock } from "../src/difficulty.js";
import { getProfile, GENESIS_TIMESTAMP, type ChainConfig } from "../src/config.js";

// Block 1 is dated 2026, after the 2023 genesis timestamp.
const BLOCK_1_TIME = Date.UTC(2026, 0, 1);

function testConfig(overrides: Partial<ChainConfig> = {}): ChainConfig {
  return { ...getProfile("test", "rc9-conf"), ...overrides };
}

// Genesis at GENESIS_TIMESTAMP, then one block per mined timestamp. Each difficulty is computed from the blocks before it.
function buildChain(config: ChainConfig, minedTimestamps: readonly number[]): DifficultyBlock[] {
  const chain: DifficultyBlock[] = [
    { index: 0, timestamp: GENESIS_TIMESTAMP, difficulty: nextDifficulty([], config) },
  ];
  minedTimestamps.forEach((timestamp, offset) => {
    chain.push({ index: offset + 1, timestamp, difficulty: nextDifficulty(chain, config) });
  });
  return chain;
}

// Indices k (1..last) where the block at index k is an adjustment boundary.
function boundaries(chain: readonly DifficultyBlock[], config: ChainConfig): number[] {
  const found: number[] = [];
  for (let k = 1; k < chain.length; k += 1) {
    if (adjustmentAt(chain.slice(0, k), config) !== null) {
      found.push(k);
    }
  }
  return found;
}

function difficulties(chain: readonly DifficultyBlock[]): number[] {
  return chain.map((block) => block.difficulty);
}

describe("RC9 genesis is excluded from timing windows", () => {
  it("the genesis timestamp is in 2023", () => {
    expect(new Date(GENESIS_TIMESTAMP).getUTCFullYear()).toBe(2023);
  });

  it("2023 genesis with 2026 block 1 and 1 000 ms spacing: block 4 keeps difficulty", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const chain = buildChain(config, [BLOCK_1_TIME, BLOCK_1_TIME + 1_000, BLOCK_1_TIME + 2_000]);
    expect(difficulties(chain)).toEqual([2, 2, 2, 2]);
    expect(adjustmentAt(chain, config)).toEqual({ actualMs: 2_000, expectedMs: 2_000, from: 2, to: 2 });
    expect(nextDifficulty(chain, config)).toBe(2);
  });

  it("the genesis timestamp never affects a window", () => {
    const config = testConfig({ initialDifficulty: 2 });
    const mined = [BLOCK_1_TIME, BLOCK_1_TIME + 1_000, BLOCK_1_TIME + 2_000, BLOCK_1_TIME + 3_000, BLOCK_1_TIME + 4_000, BLOCK_1_TIME + 5_000];
    const base = buildChain(config, mined);
    for (const genesisTimestamp of [0, GENESIS_TIMESTAMP, GENESIS_TIMESTAMP + 365 * 86_400_000]) {
      const variant = base.map((block, position) =>
        position === 0 ? { ...block, timestamp: genesisTimestamp } : block,
      );
      expect(adjustmentAt(variant.slice(0, 4), config)?.actualMs).toBe(2_000);
      expect(adjustmentAt(variant.slice(0, 7), config)?.actualMs).toBe(2_000);
      expect(nextDifficulty(variant.slice(0, 7), config)).toBe(nextDifficulty(base.slice(0, 7), config));
    }
  });
});

describe("RC9 boundaries and inheritance, I = 3 (test profile)", () => {
  // Equal timestamps make every window "faster than expected", so each boundary raises by one.
  const config = testConfig({ initialDifficulty: 1, maxDifficulty: 5 });
  const chain = buildChain(config, Array.from({ length: 9 }, () => BLOCK_1_TIME));

  it("adjustments happen exactly at blocks 4 and 7 (I + 1 and 2I + 1)", () => {
    expect(boundaries(chain, config)).toEqual([4, 7]);
  });

  it("blocks 1, 2, 3, 5, 6, 8 and 9 inherit the previous difficulty", () => {
    expect(difficulties(chain)).toEqual([1, 1, 1, 1, 2, 2, 2, 3, 3, 3]);
  });

  it("the boundary at block 4 reports the expected adjustment", () => {
    expect(adjustmentAt(chain.slice(0, 4), config)).toEqual({ actualMs: 0, expectedMs: 2_000, from: 1, to: 2 });
  });
});

describe("RC9 window contents, I = 3", () => {
  const config = testConfig({ initialDifficulty: 2 });
  const T = BLOCK_1_TIME;
  // ts1..ts6 at 1 000 ms spacing: block 4 window ts3 - ts1, block 7 window ts6 - ts4.
  const even = [T, T + 1_000, T + 2_000, T + 3_000, T + 4_000, T + 5_000];

  function actualAt(mined: readonly number[], height: number): number | undefined {
    return adjustmentAt(buildChain(config, mined).slice(0, height), config)?.actualMs;
  }

  it("block 4 window is ts3 - ts1: changing ts2 (inside the span only) leaves it unchanged", () => {
    expect(actualAt(even, 4)).toBe(2_000);
    expect(actualAt([T, T + 9_000, T + 2_000, T + 3_000, T + 4_000, T + 5_000], 4)).toBe(2_000);
  });

  it("changing ts3 moves the block 4 window and leaves the block 7 window alone", () => {
    const changed = [T, T + 1_000, T + 2_500, T + 3_000, T + 4_000, T + 5_000];
    expect(actualAt(changed, 4)).toBe(2_500);
    expect(actualAt(changed, 7)).toBe(2_000);
  });

  it("block 7 window is ts6 - ts4: changing ts4 moves it and leaves the block 4 window alone", () => {
    const changed = [T, T + 1_000, T + 2_000, T + 3_500, T + 4_000, T + 5_000];
    expect(actualAt(changed, 7)).toBe(1_500);
    expect(actualAt(changed, 4)).toBe(2_000);
  });

  it("changing ts5 (not in either window's endpoints) leaves block 7 unchanged", () => {
    const changed = [T, T + 1_000, T + 2_000, T + 3_000, T + 4_500, T + 5_000];
    expect(actualAt(changed, 7)).toBe(2_000);
  });

  it("exact thresholds: actual 1 999 raises, 2 000 keeps, 2 001 lowers", () => {
    const at = (actual: number): number => nextDifficulty(buildChain(config, [T, T + 1_000, T + actual]), config);
    expect(at(1_999)).toBe(3);
    expect(at(2_000)).toBe(2);
    expect(at(2_001)).toBe(1);
  });
});

describe("RC9 clamping", () => {
  it("lowering from minDifficulty stays at minDifficulty", () => {
    const config = testConfig({ initialDifficulty: 1 });
    const T = BLOCK_1_TIME;
    const slow = Array.from({ length: 6 }, (_, k) => T + (k + 1) * 1_000_000_000);
    const chain = buildChain(config, slow);
    expect(chain[4]?.difficulty).toBe(1);
    expect(nextDifficulty(chain, config)).toBe(1); // block 7, boundary
    expect(adjustmentAt(chain, config)).toEqual({
      actualMs: 2_000_000_000,
      expectedMs: 2_000,
      from: 1,
      to: 1,
    });
  });

  it("raising from maxDifficulty stays at maxDifficulty", () => {
    const config = testConfig({ initialDifficulty: 3 });
    const chain = buildChain(config, [BLOCK_1_TIME, BLOCK_1_TIME, BLOCK_1_TIME]);
    expect(nextDifficulty(chain, config)).toBe(3);
    expect(adjustmentAt(chain, config)).toEqual({ actualMs: 0, expectedMs: 2_000, from: 3, to: 3 });
  });
});

describe("RC9 same rules with I = 5 (demo profile, guards against a hard-coded 3)", () => {
  const config = getProfile("demo", "rc9-demo-conf");
  const T = BLOCK_1_TIME;

  it("adjustments happen exactly at blocks 6 and 11 (I + 1 and 2I + 1)", () => {
    const chain = buildChain(config, Array.from({ length: 11 }, () => T));
    expect(boundaries(chain, config)).toEqual([6, 11]);
  });

  it("non-boundary blocks inherit and boundaries move by one step, clamped at maxDifficulty", () => {
    const chain = buildChain(config, Array.from({ length: 11 }, () => T));
    expect(difficulties(chain)).toEqual([2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4]);
  });

  it("window is ts5 - ts1 with expected 12 000 ms: 11 999 raises, 12 000 keeps, 12 001 lowers", () => {
    const at = (actual: number): number =>
      nextDifficulty(buildChain(config, [T, T + 3_000, T + 6_000, T + 9_000, T + actual]), config);
    expect(at(11_999)).toBe(3);
    expect(at(12_000)).toBe(2);
    expect(at(12_001)).toBe(1);
  });
});
