// Shared test fixtures for chain validation tests. Only shared package functions build records and blocks.
// Keys are real RSA-2048 pairs; blocks are mined with chosen timestamps and nextDifficulty unless a difficulty is given.

import { getProfile, GENESIS_TIMESTAMP, type ChainConfig } from "../src/config.js";
import { deriveChainId, makeGenesis, mineBlock, computeBlockHash } from "../src/block.js";
import { nextDifficulty, type DifficultyBlock } from "../src/difficulty.js";
import { nodeHash, nodeIdentityCrypto } from "../src/crypto-node.js";
import type { ChainCrypto, PrivateKeyHandle } from "../src/crypto.js";
import { deriveAttendeeId, signPayload } from "../src/identity.js";
import type {
  AttendancePayload,
  Block,
  ChainRecord,
  RegistrationPayload,
  SignedAttendance,
  SignedRegistration,
} from "../src/schemas.js";

export const CONFERENCE_ID = "conf-test-2026";
export const TEST_PROFILE = getProfile("test", CONFERENCE_ID);
export const CRYPTO: ChainCrypto = { identity: nodeIdentityCrypto, hash: nodeHash };
export const CHAIN_ID = deriveChainId(TEST_PROFILE, nodeHash);
// Block and record times in tests are offsets from this instant (2026, after the 2023 genesis).
export const BASE_TIME = Date.UTC(2026, 0, 1);

// 256 bytes of base64, structurally valid but not a signature over anything.
export const GARBAGE_SIGNATURE = Buffer.alloc(256, 1).toString("base64");

export interface TestKeys {
  attendeeId: string;
  publicKey: string;
  privateKey: PrivateKeyHandle;
}

export async function makeKeys(): Promise<TestKeys> {
  const pair = await nodeIdentityCrypto.generateKeyPair();
  return {
    attendeeId: await deriveAttendeeId(pair.publicKey, nodeIdentityCrypto),
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
  };
}

export interface RegistrationOptions {
  alias?: string;
  chainId?: string;
  attendeeId?: string;
  publicKey?: string;
  // Key used for the signature; defaults to the key's own private key.
  signWith?: PrivateKeyHandle;
  signature?: string;
}

// Signs a registration. Overrides let tests build deliberately wrong records; the signature is over the final payload.
export async function signedRegistration(
  keys: TestKeys,
  timestamp: number,
  options: RegistrationOptions = {},
): Promise<SignedRegistration> {
  const payload: RegistrationPayload = {
    type: "register",
    chainId: options.chainId ?? CHAIN_ID,
    attendeeId: options.attendeeId ?? keys.attendeeId,
    alias: options.alias ?? "alice",
    publicKey: options.publicKey ?? keys.publicKey,
    timestamp,
  };
  const signature =
    options.signature ?? (await signPayload(payload, options.signWith ?? keys.privateKey, nodeIdentityCrypto));
  return { payload, signature };
}

export interface AttendanceOptions {
  chainId?: string;
  attendeeId?: string;
  signWith?: PrivateKeyHandle;
  signature?: string;
}

export async function signedAttendance(
  keys: TestKeys,
  sessionId: string,
  timestamp: number,
  options: AttendanceOptions = {},
): Promise<SignedAttendance> {
  const payload: AttendancePayload = {
    type: "attend",
    chainId: options.chainId ?? CHAIN_ID,
    attendeeId: options.attendeeId ?? keys.attendeeId,
    sessionId,
    timestamp,
  };
  const signature =
    options.signature ?? (await signPayload(payload, options.signWith ?? keys.privateKey, nodeIdentityCrypto));
  return { payload, signature };
}

export function genesisFor(config: ChainConfig = TEST_PROFILE): Block {
  return makeGenesis(config, nodeHash);
}

// Mines the next block after prefix. Difficulty defaults to nextDifficulty(prefix), so it is the required value.
export function mineOn(
  prefix: readonly Block[],
  records: readonly ChainRecord[],
  timestamp: number,
  config: ChainConfig = TEST_PROFILE,
  difficulty?: number,
): Block {
  const previous = prefix.at(-1);
  if (previous === undefined) {
    throw new Error("mineOn needs a prefix; start from genesisFor()");
  }
  const block = mineBlock(
    {
      index: previous.index + 1,
      timestamp,
      previousHash: previous.hash,
      difficulty: difficulty ?? nextDifficulty(prefix, config),
      records: [...records],
    },
    nodeHash,
  );
  if (block === null) {
    throw new Error("mineBlock returned null without an abort callback");
  }
  return block;
}

export interface PlannedBlock {
  timestamp: number;
  records?: readonly ChainRecord[];
  difficulty?: number;
}

// Genesis followed by one mined block per plan entry.
export function buildChain(plan: readonly PlannedBlock[], config: ChainConfig = TEST_PROFILE): Block[] {
  const chain: Block[] = [genesisFor(config)];
  for (const step of plan) {
    chain.push(mineOn(chain, step.records ?? [], step.timestamp, config, step.difficulty));
  }
  return chain;
}

// Re-mines blocks[fromIndex..] with their current records and timestamps, linking each to the previous one.
// Earlier blocks are kept as they are. Difficulty is the required value (nextDifficulty), as a miner would choose.
export function remineFrom(blocks: readonly Block[], fromIndex: number, config: ChainConfig = TEST_PROFILE): Block[] {
  const result: Block[] = blocks.slice(0, fromIndex);
  for (let position = fromIndex; position < blocks.length; position += 1) {
    const original = blocks[position];
    if (original === undefined) {
      throw new Error("remineFrom: missing block");
    }
    result.push(mineOn(result, original.records, original.timestamp, config));
  }
  return result;
}

// Finds a nonce for which the block's recomputed hash misses the PoW target. The hash is recomputed, so the
// returned block is internally consistent apart from PoW.
export function withFailingPow(block: Block): Block {
  const target = "0".repeat(block.difficulty);
  for (let nonce = block.nonce + 1; nonce < block.nonce + 100_000; nonce += 1) {
    const content = { ...block, nonce };
    const digest = computeBlockHash(content, nodeHash);
    if (!digest.startsWith(target)) {
      return { ...content, hash: digest };
    }
  }
  throw new Error("no failing nonce found");
}

// Difficulty-only chain (no mining): index, timestamp and difficulty as nextDifficulty requires them.
export function pureDifficultyChain(timestamps: readonly number[], config: ChainConfig): DifficultyBlock[] {
  const chain: DifficultyBlock[] = [
    { index: 0, timestamp: GENESIS_TIMESTAMP, difficulty: nextDifficulty([], config) },
  ];
  timestamps.forEach((timestamp, offset) => {
    chain.push({ index: offset + 1, timestamp, difficulty: nextDifficulty(chain, config) });
  });
  return chain;
}
