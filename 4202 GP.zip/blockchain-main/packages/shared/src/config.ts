// Protocol constants, tunable config profiles and Clock (SPEC section 4).
// Never edit these values to speed up a test; tests use the `test` profile.

import { ChainError } from "./errors.js";

export const PROTOCOL_VERSION = "conference-chain/1";
export const RSA_MODULUS_BITS = 2048;
export const RSA_PUBLIC_EXPONENT = 65537;
export const RSA_SPKI_DER_LENGTH = 294; // canonical SPKI DER size for RSA-2048, e=65537
export const GENESIS_PREVIOUS_HASH = "0".repeat(64);
export const GENESIS_TIMESTAMP = 1_700_000_000_000;
export const MAX_RECORDS_PER_BLOCK = 50;
export const MEMPOOL_MAX_RECORDS = 1000;
// Alias length limit in Unicode code points (SPEC section 5.1 Alias).
export const ALIAS_MAX_CODE_POINTS = 50;

// Fixed batching delay before a mining job starts (SPEC section 9).
export const MINER_BATCH_DELAY_MS = 1000;

// SPEC section 9, CONFERENCE_ID. Feeds chainId (section 4).
export const CONFERENCE_ID_PATTERN = /^[a-z0-9][a-z0-9-]{2,63}$/;

export const PROFILE_NAMES = ["production", "demo", "test"] as const;
export type ProfileName = (typeof PROFILE_NAMES)[number];

export interface ChainTunables {
  initialDifficulty: number;
  minDifficulty: number;
  maxDifficulty: number;
  targetBlockTimeMs: number;
  adjustmentInterval: number;
  maxRecordSkewMs: number;
  mempoolTtlMs: number;
  maxRecordAgeInBlockMs: number;
  maxBlockSkewMs: number;
}

export interface ChainConfig extends ChainTunables {
  conferenceId: string;
}

export interface Clock {
  now(): number;
}

const PROFILE_TUNABLES: Readonly<Record<ProfileName, ChainTunables>> = {
  production: {
    initialDifficulty: 3,
    minDifficulty: 1,
    maxDifficulty: 5,
    targetBlockTimeMs: 10_000,
    adjustmentInterval: 5,
    maxRecordSkewMs: 300_000,
    mempoolTtlMs: 300_000,
    maxRecordAgeInBlockMs: 900_000,
    maxBlockSkewMs: 5_000,
  },
  demo: {
    initialDifficulty: 2,
    minDifficulty: 1,
    maxDifficulty: 4,
    targetBlockTimeMs: 3_000,
    adjustmentInterval: 5,
    maxRecordSkewMs: 300_000,
    mempoolTtlMs: 300_000,
    maxRecordAgeInBlockMs: 900_000,
    maxBlockSkewMs: 5_000,
  },
  test: {
    initialDifficulty: 1,
    minDifficulty: 1,
    maxDifficulty: 3,
    targetBlockTimeMs: 1_000,
    adjustmentInterval: 3,
    maxRecordSkewMs: 5_000,
    mempoolTtlMs: 5_000,
    maxRecordAgeInBlockMs: 15_000,
    maxBlockSkewMs: 1_000,
  },
};

export type ConfigValidation = { ok: true } | { ok: false; errors: string[] };

const TUNABLE_KEYS: readonly (keyof ChainTunables)[] = [
  "initialDifficulty",
  "minDifficulty",
  "maxDifficulty",
  "targetBlockTimeMs",
  "adjustmentInterval",
  "maxRecordSkewMs",
  "mempoolTtlMs",
  "maxRecordAgeInBlockMs",
  "maxBlockSkewMs",
];

const TIME_KEYS: readonly (keyof ChainTunables)[] = [
  "targetBlockTimeMs",
  "maxRecordSkewMs",
  "mempoolTtlMs",
  "maxRecordAgeInBlockMs",
  "maxBlockSkewMs",
];

// Config validation (SPEC section 4). Returns every violation found; boot refuses on any.
export function validateConfig(config: ChainConfig): ConfigValidation {
  const errors: string[] = [];

  if (!CONFERENCE_ID_PATTERN.test(config.conferenceId)) {
    errors.push("conferenceId must match /^[a-z0-9][a-z0-9-]{2,63}$/");
  }

  for (const key of TUNABLE_KEYS) {
    const value = config[key];
    if (!Number.isSafeInteger(value) || Object.is(value, -0)) {
      errors.push(`${key} must be a safe integer`);
    }
  }

  if (Number.isSafeInteger(config.adjustmentInterval) && config.adjustmentInterval < 2) {
    errors.push("adjustmentInterval must be an integer >= 2");
  }

  for (const key of TIME_KEYS) {
    if (config[key] < 0) {
      errors.push(`${key} must be >= 0`);
    }
  }

  if (config.minDifficulty < 1) {
    errors.push("minDifficulty must be >= 1");
  }
  if (!(config.minDifficulty <= config.initialDifficulty && config.initialDifficulty <= config.maxDifficulty)) {
    errors.push("require minDifficulty <= initialDifficulty <= maxDifficulty");
  }

  if (
    !(config.maxRecordSkewMs + config.mempoolTtlMs + MINER_BATCH_DELAY_MS < config.maxRecordAgeInBlockMs)
  ) {
    errors.push("require maxRecordSkewMs + mempoolTtlMs + MINER_BATCH_DELAY_MS < maxRecordAgeInBlockMs");
  }

  return errors.length === 0 ? { ok: true } : { ok: false, errors };
}

// Returns a fresh copy of the named profile bound to conferenceId.
// Throws ChainError(INVALID_SCHEMA) on an unknown profile name or an invalid resulting config.
export function getProfile(name: ProfileName, conferenceId: string): ChainConfig {
  if (!Object.hasOwn(PROFILE_TUNABLES, name)) {
    throw new ChainError("INVALID_SCHEMA", "unknown profile");
  }
  const config: ChainConfig = { ...PROFILE_TUNABLES[name], conferenceId };
  const result = validateConfig(config);
  if (!result.ok) {
    throw new ChainError("INVALID_SCHEMA", `invalid config: ${result.errors.join("; ")}`);
  }
  return config;
}
