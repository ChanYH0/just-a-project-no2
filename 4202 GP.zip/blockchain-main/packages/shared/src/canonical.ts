// canonicalize: the only path to signed or hashed bytes (SPEC section 6).

import { ChainError } from "./errors.js";

export function canonicalize(value: unknown): string {
  return canonicalizeValue(value, []);
}

function canonicalizeValue(value: unknown, ancestors: readonly unknown[]): string {
  if (value === null) {
    throw invalid("null is not allowed");
  }
  switch (typeof value) {
    case "string":
    case "boolean":
      return JSON.stringify(value);
    case "number":
      if (!Number.isSafeInteger(value)) {
        throw invalid("only safe integers are allowed");
      }
      if (Object.is(value, -0)) {
        throw invalid("negative zero is not allowed");
      }
      return String(value);
    case "object":
      return canonicalizeObject(value, ancestors);
    case "undefined":
      throw invalid("undefined is not allowed");
    case "bigint":
      throw invalid("bigint is not allowed");
    case "function":
      throw invalid("functions are not allowed");
    case "symbol":
      throw invalid("symbols are not allowed");
    default:
      throw invalid("unsupported value type");
  }
}

function canonicalizeObject(value: object, ancestors: readonly unknown[]): string {
  if (ancestors.includes(value)) {
    throw invalid("cyclic structures are not allowed");
  }
  const nextAncestors = [...ancestors, value];

  if (Array.isArray(value)) {
    const parts: string[] = [];
    for (let i = 0; i < value.length; i += 1) {
      if (!(i in value)) {
        throw invalid("sparse arrays are not allowed");
      }
      parts.push(canonicalizeValue(value[i], nextAncestors));
    }
    return `[${parts.join(",")}]`;
  }

  const proto: unknown = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) {
    throw invalid("only plain objects are allowed");
  }

  // Default Array.prototype.sort compares UTF-16 code units, as required.
  const record = value as Readonly<Record<string, unknown>>;
  const keys = Object.keys(record).sort();
  const entries = keys.map((key) => `${JSON.stringify(key)}:${canonicalizeValue(record[key], nextAncestors)}`);
  return `{${entries.join(",")}}`;
}

function invalid(message: string): ChainError {
  return new ChainError("INVALID_SCHEMA", `canonicalize: ${message}`);
}
