// Block hashing, mining, PoW verification, chainId derivation and genesis (SPEC sections 4, 5.4, 6).
// Synchronous and pure: the caller supplies a sync HashFn. No clock, no I/O.

import { canonicalize } from "./canonical.js";
import {
  GENESIS_PREVIOUS_HASH,
  GENESIS_TIMESTAMP,
  MAX_RECORDS_PER_BLOCK,
  PROTOCOL_VERSION,
  type ChainConfig,
} from "./config.js";
import type { HashFn } from "./crypto.js";
import { ChainError } from "./errors.js";
import type { Block } from "./schemas.js";

// SPEC section 6: shouldAbort is consulted once every 10 000 nonces.
const ABORT_CHECK_INTERVAL = 10_000;

export type BlockContent = Omit<Block, "hash">;
export type BlockCandidate = Omit<Block, "hash" | "nonce">;

export interface NonceSearch {
  startNonce: number;
  stride: number;
}

function contentOf(candidate: BlockCandidate, nonce: number): BlockContent {
  return {
    index: candidate.index,
    timestamp: candidate.timestamp,
    previousHash: candidate.previousHash,
    difficulty: candidate.difficulty,
    nonce,
    records: candidate.records,
  };
}

// hash(canonicalize({index, timestamp, previousHash, difficulty, nonce, records})). The `hash` field is never included.
export function computeBlockHash(block: BlockContent, hash: HashFn): string {
  const { index, timestamp, previousHash, difficulty, nonce, records } = block;
  return hash(canonicalize({ index, timestamp, previousHash, difficulty, nonce, records }));
}

// A digest cannot satisfy a target that asks for more zeroes than it has characters.
// Bound the target before repeat() so malformed persisted difficulty values cannot
// allocate an enormous string or throw during chain validation.
export function meetsProofOfWork(digest: string, difficulty: number): boolean {
  if (!Number.isSafeInteger(difficulty) || difficulty < 1 || difficulty > digest.length) {
    return false;
  }
  return digest.startsWith("0".repeat(difficulty));
}

// PoW is checked against the hash recomputed from the block's own fields, not the stored `hash` field.
// A stored hash that differs from the recomputed one is reported separately by the validator (BAD_BLOCK_HASH).
export function verifyBlockPow(block: Block, hash: HashFn): boolean {
  return meetsProofOfWork(computeBlockHash(block, hash), block.difficulty);
}

// Search a non-overlapping lane of the nonce space. With no lane, the historical
// search starts from nonce 0 and checks every nonce in order.
export function mineBlock(
  candidate: BlockCandidate,
  hash: HashFn,
  shouldAbort?: () => boolean,
  search: NonceSearch = { startNonce: 0, stride: 1 },
): Block | null {
  const { startNonce, stride } = search;
  if (!Number.isSafeInteger(startNonce) || startNonce < 0 || !Number.isSafeInteger(stride) || stride < 1) {
    throw new ChainError("INVALID_SCHEMA", "nonce search lane must use a non-negative safe start and positive safe stride");
  }
  const target = "0".repeat(candidate.difficulty);
  let attempts = 0;
  for (let nonce = startNonce; ; ) {
    if (shouldAbort !== undefined && attempts % ABORT_CHECK_INTERVAL === 0 && shouldAbort()) {
      return null;
    }
    const content = contentOf(candidate, nonce);
    const digest = computeBlockHash(content, hash);
    if (digest.startsWith(target)) {
      return { ...content, hash: digest };
    }
    attempts += 1;
    const nextNonce = nonce + stride;
    if (!Number.isSafeInteger(nextNonce)) {
      throw new ChainError("INVALID_SCHEMA", "nonce search lane exhausted the safe integer range");
    }
    nonce = nextNonce;
  }
}

// SPEC section 4. Consensus fields only: mempool, skew and block-skew settings are excluded on purpose.
export function deriveChainId(config: ChainConfig, hash: HashFn): string {
  return hash(
    canonicalize({
      protocol: PROTOCOL_VERSION,
      conferenceId: config.conferenceId,
      consensus: {
        initialDifficulty: config.initialDifficulty,
        minDifficulty: config.minDifficulty,
        maxDifficulty: config.maxDifficulty,
        targetBlockTimeMs: config.targetBlockTimeMs,
        adjustmentInterval: config.adjustmentInterval,
        maxRecordAgeInBlockMs: config.maxRecordAgeInBlockMs,
        maxRecordsPerBlock: MAX_RECORDS_PER_BLOCK,
      },
    }),
  );
}

// Deterministic genesis (SPEC section 4). Depends only on the profile's initialDifficulty, so it is not a deployment identity.
export function makeGenesis(config: ChainConfig, hash: HashFn): Block {
  const block = mineBlock(
    {
      index: 0,
      timestamp: GENESIS_TIMESTAMP,
      previousHash: GENESIS_PREVIOUS_HASH,
      difficulty: config.initialDifficulty,
      records: [],
    },
    hash,
  );
  if (block === null) {
    throw new ChainError("INTERNAL", "genesis mining returned no block without an abort callback");
  }
  return block;
}
