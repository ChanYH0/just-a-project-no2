// Crypto abstractions: types only (SPEC section 6). No implementation here.

// Opaque to shared code. Node: PEM string. Browser: non-extractable CryptoKey.
// Implementations must narrow it with a type guard before use.
export type PrivateKeyHandle = unknown;

export interface PublicKeyInfo {
  modulusBits: number;
  publicExponent: number;
  canonicalSpki: string;
}

// Async, used for identity, signatures and key checks. Implemented by crypto-node.ts and crypto-browser.ts.
export interface IdentityCrypto {
  // publicKey: canonical base64 SPKI DER
  generateKeyPair(): Promise<{ publicKey: string; privateKey: PrivateKeyHandle }>;
  sign(bytes: Uint8Array, privateKey: PrivateKeyHandle): Promise<string>;
  // false on any bad signature or malformed key; never throws
  verify(bytes: Uint8Array, signatureBase64: string, publicKeyBase64: string): Promise<boolean>;
  // null if unparsable
  inspectPublicKey(publicKeyBase64: string): Promise<PublicKeyInfo | null>;
  sha256Hex(bytes: Uint8Array): Promise<string>;
}

// Sync, lowercase hex SHA-256. Node only. Used for block hashing and mining.
export type HashFn = (data: string | Uint8Array) => string;

export interface ChainCrypto {
  identity: IdentityCrypto;
  hash: HashFn;
}
