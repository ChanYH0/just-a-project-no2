// Node-only implementation of IdentityCrypto and HashFn (SPEC section 6).
// Must never be imported by browser-safe modules.

import {
  constants,
  createHash,
  createPublicKey,
  createSign,
  createVerify,
  generateKeyPair,
} from "node:crypto";
import { ChainError } from "./errors.js";
import type { HashFn, IdentityCrypto, PrivateKeyHandle, PublicKeyInfo } from "./crypto.js";
import { RSA_MODULUS_BITS, RSA_PUBLIC_EXPONENT } from "./config.js";
import { decodeBase64Strict } from "./schemas.js";

function generateRsaKeyPair(): Promise<{ publicKey: string; privateKey: string }> {
  return new Promise((resolve, reject) => {
    generateKeyPair(
      "rsa",
      {
        modulusLength: RSA_MODULUS_BITS,
        publicExponent: RSA_PUBLIC_EXPONENT,
        publicKeyEncoding: { type: "spki", format: "der" },
        privateKeyEncoding: { type: "pkcs8", format: "pem" },
      },
      (error, publicKeyDer, privateKeyPem) => {
        if (error) {
          reject(error);
          return;
        }
        resolve({ publicKey: publicKeyDer.toString("base64"), privateKey: privateKeyPem });
      },
    );
  });
}

function requirePemHandle(privateKey: PrivateKeyHandle): string {
  if (typeof privateKey !== "string") {
    throw new ChainError("INTERNAL", "unsupported private key handle for node adapter");
  }
  return privateKey;
}

export const nodeHash: HashFn = (data) => createHash("sha256").update(data).digest("hex");

export const nodeIdentityCrypto: IdentityCrypto = {
  async generateKeyPair() {
    const pair = await generateRsaKeyPair();
    return { publicKey: pair.publicKey, privateKey: pair.privateKey };
  },

  async sign(bytes, privateKey) {
    const pem = requirePemHandle(privateKey);
    return createSign("SHA256")
      .update(bytes)
      .sign({ key: pem, padding: constants.RSA_PKCS1_PADDING })
      .toString("base64");
  },

  // Never throws: any malformed input or key yields false.
  async verify(bytes, signatureBase64, publicKeyBase64) {
    const signature = decodeBase64Strict(signatureBase64);
    const spki = decodeBase64Strict(publicKeyBase64);
    if (signature === null || spki === null) {
      return false;
    }
    let key;
    try {
      key = createPublicKey({ key: Buffer.from(spki), format: "der", type: "spki" });
    } catch {
      // Unparsable key material is the documented false result, not an error.
      return false;
    }
    if (key.asymmetricKeyType !== "rsa") {
      return false;
    }
    return createVerify("SHA256")
      .update(bytes)
      .verify({ key, padding: constants.RSA_PKCS1_PADDING }, signature);
  },

  // null if unparsable (including non-canonical base64). Never throws.
  async inspectPublicKey(publicKeyBase64): Promise<PublicKeyInfo | null> {
    const der = decodeBase64Strict(publicKeyBase64);
    if (der === null) {
      return null;
    }
    let key;
    try {
      key = createPublicKey({ key: Buffer.from(der), format: "der", type: "spki" });
    } catch {
      // Unparsable key material is the documented null result, not an error.
      return null;
    }
    if (key.asymmetricKeyType !== "rsa") {
      return null;
    }
    const details = key.asymmetricKeyDetails;
    if (details?.modulusLength === undefined || details.publicExponent === undefined) {
      return null;
    }
    return {
      modulusBits: details.modulusLength,
      publicExponent: Number(details.publicExponent),
      canonicalSpki: key.export({ type: "spki", format: "der" }).toString("base64"),
    };
  },

  async sha256Hex(bytes) {
    return nodeHash(bytes);
  },
};
