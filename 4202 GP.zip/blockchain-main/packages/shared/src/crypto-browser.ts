// Browser-safe WebCrypto implementation of IdentityCrypto (SPEC sections 3, 6).
// Uses only globalThis.crypto.subtle. Must never import node:crypto or use Buffer.

import { RSA_MODULUS_BITS, RSA_PUBLIC_EXPONENT } from "./config.js";
import { ChainError } from "./errors.js";
import type { IdentityCrypto, PrivateKeyHandle, PublicKeyInfo } from "./crypto.js";
import { decodeBase64Strict } from "./schemas.js";

const RSA_ALGORITHM = "RSASSA-PKCS1-v1_5" as const;
const HASH_ALGORITHM = "SHA-256" as const;

// WebCrypto requires ArrayBuffer-backed views; copying also detaches the caller from later mutation.
function toBufferSource(bytes: Uint8Array): Uint8Array<ArrayBuffer> {
  return new Uint8Array(bytes);
}

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary);
}

// Big-endian minimal encoding of a non-negative integer (65537 -> [1, 0, 1]).
function bigEndianBytes(value: number): Uint8Array {
  const bytes: number[] = [];
  for (let rest = value; rest > 0; rest = Math.floor(rest / 256)) {
    bytes.unshift(rest % 256);
  }
  return new Uint8Array(bytes);
}

// Narrows the opaque handle to a private RSASSA CryptoKey. Anything else is an internal error.
function isRsaPrivateKey(handle: PrivateKeyHandle): handle is CryptoKey {
  return (
    handle instanceof CryptoKey &&
    handle.type === "private" &&
    handle.algorithm.name === RSA_ALGORITHM
  );
}

function requirePrivateKey(handle: PrivateKeyHandle): CryptoKey {
  if (!isRsaPrivateKey(handle)) {
    throw new ChainError("INTERNAL", "unsupported private key handle for browser adapter");
  }
  return handle;
}

// Imports canonical SPKI DER as an RSASSA-PKCS1-v1_5 SHA-256 public key.
// Returns null when WebCrypto rejects the bytes (malformed DER, non-RSA key).
// Key size and exponent are not policed here; callers decide via inspectPublicKey / validatePublicKey.
async function importRsaPublicKey(spki: Uint8Array, extractable: boolean): Promise<CryptoKey | null> {
  try {
    return await globalThis.crypto.subtle.importKey(
      "spki",
      toBufferSource(spki),
      { name: RSA_ALGORITHM, hash: HASH_ALGORITHM },
      extractable,
      ["verify"],
    );
  } catch {
    // Unparsable key material is the documented null / false result, not an error.
    return null;
  }
}

export const browserIdentityCrypto: IdentityCrypto = {
  async generateKeyPair() {
    const pair = await globalThis.crypto.subtle.generateKey(
      {
        name: RSA_ALGORITHM,
        modulusLength: RSA_MODULUS_BITS,
        publicExponent: toBufferSource(bigEndianBytes(RSA_PUBLIC_EXPONENT)),
        hash: HASH_ALGORITHM,
      },
      false,
      ["sign", "verify"],
    );
    // WebCrypto always keeps the public half exportable; the private half is non-extractable.
    const spki = await globalThis.crypto.subtle.exportKey("spki", pair.publicKey);
    return { publicKey: toBase64(new Uint8Array(spki)), privateKey: pair.privateKey };
  },

  async sign(bytes, privateKey) {
    const key = requirePrivateKey(privateKey);
    const signature = await globalThis.crypto.subtle.sign(RSA_ALGORITHM, key, toBufferSource(bytes));
    return toBase64(new Uint8Array(signature));
  },

  // Never throws: any malformed input or key yields false.
  async verify(bytes, signatureBase64, publicKeyBase64) {
    const signature = decodeBase64Strict(signatureBase64);
    const spki = decodeBase64Strict(publicKeyBase64);
    if (signature === null || spki === null) {
      return false;
    }
    const key = await importRsaPublicKey(spki, false);
    if (key === null) {
      return false;
    }
    try {
      return await globalThis.crypto.subtle.verify(RSA_ALGORITHM, key, toBufferSource(signature), toBufferSource(bytes));
    } catch {
      // WebCrypto reports a malformed signature as an error; the contract is false.
      return false;
    }
  },

  // null if unparsable (including non-canonical base64). Never throws.
  async inspectPublicKey(publicKeyBase64): Promise<PublicKeyInfo | null> {
    const spki = decodeBase64Strict(publicKeyBase64);
    if (spki === null) {
      return null;
    }
    const key = await importRsaPublicKey(spki, true);
    if (key === null) {
      return null;
    }
    const algorithm: unknown = key.algorithm;
    if (
      typeof algorithm !== "object" ||
      algorithm === null ||
      !("modulusLength" in algorithm) ||
      typeof algorithm.modulusLength !== "number" ||
      !("publicExponent" in algorithm) ||
      !(algorithm.publicExponent instanceof Uint8Array)
    ) {
      return null;
    }
    let publicExponent = 0;
    for (const byte of algorithm.publicExponent) {
      publicExponent = publicExponent * 256 + byte;
    }
    const canonical = await globalThis.crypto.subtle.exportKey("spki", key);
    return {
      modulusBits: algorithm.modulusLength,
      publicExponent,
      canonicalSpki: toBase64(new Uint8Array(canonical)),
    };
  },

  async sha256Hex(bytes) {
    const digest = await globalThis.crypto.subtle.digest(HASH_ALGORITHM, toBufferSource(bytes));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  },
};
