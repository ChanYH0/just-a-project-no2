// Dynamic difficulty (SPEC section 8). Pure and synchronous: no crypto, no clock, no I/O.
// Browser-safe. This module is the single implementation of the adjustment rule.

import type { ChainConfig } from "./config.js";
import { ChainError } from "./errors.js";
import type { BlockHeader } from "./schemas.js";

// The only fields the rule reads from a chain prefix.
export type DifficultyBlock = Pick<BlockHeader, "index" | "timestamp" | "difficulty">;

export interface DifficultyAdjustment {
  // blocks[i-1].timestamp - blocks[i-I].timestamp (spans I - 1 gaps)
  actualMs: number;
  // targetBlockTimeMs * (I - 1)
  expectedMs: number;
  // difficulty of block i-1 before the adjustment
  from: number;
  // clamped difficulty required for block i
  to: number;
}

// Returns the adjustment for the block at index chainPrefix.length, or null if that index is not a boundary.
// Boundary: i >= I + 1 and (i - 1) % I == 0. The window is blocks[i-I .. i-1]; genesis (index 0) is never inside it.
export function adjustmentAt(
  chainPrefix: readonly DifficultyBlock[],
  config: ChainConfig,
): DifficultyAdjustment | null {
  const height = chainPrefix.length;
  const interval = config.adjustmentInterval;
  if (height < interval + 1 || (height - 1) % interval !== 0) {
    return null;
  }

  const first = chainPrefix[height - interval];
  const last = chainPrefix[height - 1];
  if (
    first === undefined ||
    last === undefined ||
    first.index !== height - interval ||
    last.index !== height - 1
  ) {
    throw new ChainError("INTERNAL", "difficulty window indices do not match the chain prefix");
  }

  const actualMs = last.timestamp - first.timestamp;
  const expectedMs = config.targetBlockTimeMs * (interval - 1);
  let step = 0;
  if (actualMs < expectedMs) {
    step = 1;
  } else if (actualMs > expectedMs) {
    step = -1;
  }
  const to = Math.min(config.maxDifficulty, Math.max(config.minDifficulty, last.difficulty + step));
  return { actualMs, expectedMs, from: last.difficulty, to };
}

// Required difficulty for the block at index chainPrefix.length.
// An empty prefix is the genesis block and gets initialDifficulty.
export function nextDifficulty(chainPrefix: readonly DifficultyBlock[], config: ChainConfig): number {
  if (chainPrefix.length === 0) {
    return config.initialDifficulty;
  }
  const adjustment = adjustmentAt(chainPrefix, config);
  if (adjustment !== null) {
    return adjustment.to;
  }
  const previous = chainPrefix.at(-1);
  if (previous === undefined) {
    throw new ChainError("INTERNAL", "non-empty chain prefix has no last block");
  }
  return previous.difficulty;
}
