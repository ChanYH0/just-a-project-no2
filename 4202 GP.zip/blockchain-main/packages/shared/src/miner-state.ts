// Public miner states returned by /health. Keep the node and its clients on one contract.
export const MINER_STATES = ["idle", "mining", "persisting", "restarting", "error", "fatal"] as const;
export type MinerState = (typeof MINER_STATES)[number];
