// Chain state index and validators (SPEC sections 5.3, 5.4, 7, 8). Async: identity checks use IdentityCrypto.
// Node-only in practice: block hashing uses the sync HashFn (block.ts), so this module is exported from node.ts only.
//
// Design rules (all validators are pure with respect to their inputs):
// - No validator mutates state, a mempool index, a block-local index or the prefix. A caller applies a block with
//   applyBlockToState only after validateBlock (or validateBlockAdmission) succeeded.
// - Only validateRecordAtSubmission (catalog + clock) and validateBlockAdmission (clock) read time or the session
//   catalog. validateRecordInBlock, validateBlock and validateChain take neither.
// - Lookup vs uniqueness: attendance needs a registration in CONFIRMED state (keyLookup). Pending registrations never
//   satisfy that lookup. Uniqueness (KEY_ALREADY_REGISTERED, DUPLICATE_ATTENDANCE) checks confirmed state UNION a
//   pending UniquenessIndex (mempool index at submission, earlier records of the same block in a block).
// - blockIndex on a block-level failure is the chain index the block must occupy (prefix.at(-1).index + 1). It is the
//   same as block.index whenever BAD_INDEX is not the failure.

import { canonicalize } from "./canonical.js";
import { deriveChainId, makeGenesis, computeBlockHash, meetsProofOfWork } from "./block.js";
import { MAX_RECORDS_PER_BLOCK, type ChainConfig, type Clock } from "./config.js";
import type { ChainCrypto, HashFn } from "./crypto.js";
import { ChainError, type ErrorCode } from "./errors.js";
import { deriveAttendeeId, validatePublicKey, verifyPayload } from "./identity.js";
import { nextDifficulty } from "./difficulty.js";
import type { Block, BlockHeader, ChainRecord } from "./schemas.js";

export interface RegistrationEntry {
  alias: string;
  publicKey: string;
  blockIndex: number;
  timestamp: number;
}

// Confirmed state: built from blocks that passed validation, in order.
export interface ChainState {
  registrations: Map<string, RegistrationEntry>;
  // Keys are attendanceKey(attendeeId, sessionId).
  attendance: Set<string>;
}

// Uniqueness-only view of records that are not yet confirmed. Never used for the registration lookup.
export interface UniquenessIndex {
  registrations: Set<string>;
  attendance: Set<string>;
}

// Mempool-side pending view (SPEC section 7, validateRecordAtSubmission).
export type MempoolIndex = UniquenessIndex;

// Per-block scope for validateRecordInBlock: confirmed state from earlier blocks, plus the block-local view of earlier
// records in the same block. validateBlock creates one scope per block and fills `pending` after each record passes.
export interface BlockScope {
  state: ChainState;
  pending: UniquenessIndex;
}

export type Result = { ok: true } | { ok: false; code: ErrorCode; blockIndex?: number };

export type KeyLookup = (attendeeId: string) => string | undefined;

const OK: Result = { ok: true };

function failure(code: ErrorCode, blockIndex?: number): Result {
  return blockIndex === undefined ? { ok: false, code } : { ok: false, code, blockIndex };
}

export function attendanceKey(attendeeId: string, sessionId: string): string {
  return `${attendeeId}|${sessionId}`;
}

export function emptyState(): ChainState {
  return { registrations: new Map(), attendance: new Set() };
}

export function emptyUniquenessIndex(): UniquenessIndex {
  return { registrations: new Set(), attendance: new Set() };
}

// Copies the state in O(size). Entries are copied so the clone can be mutated independently.
export function cloneState(state: ChainState): ChainState {
  const registrations = new Map<string, RegistrationEntry>();
  for (const [attendeeId, entry] of state.registrations) {
    registrations.set(attendeeId, { ...entry });
  }
  return { registrations, attendance: new Set(state.attendance) };
}

// Applies one validated block to the confirmed state. Throws INTERNAL on a duplicate, which means the block was not
// validated against this state: the validators must run first.
export function applyBlockToState(state: ChainState, block: Block): void {
  for (const record of block.records) {
    const payload = record.payload;
    if (payload.type === "register") {
      if (state.registrations.has(payload.attendeeId)) {
        throw new ChainError("INTERNAL", "applyBlockToState: duplicate registration; block was not validated");
      }
      state.registrations.set(payload.attendeeId, {
        alias: payload.alias,
        publicKey: payload.publicKey,
        blockIndex: block.index,
        timestamp: payload.timestamp,
      });
    } else {
      const key = attendanceKey(payload.attendeeId, payload.sessionId);
      if (state.attendance.has(key)) {
        throw new ChainError("INTERNAL", "applyBlockToState: duplicate attendance; block was not validated");
      }
      state.attendance.add(key);
    }
  }
}

// Replays blocks into a fresh state. Does NOT validate: call validateChain first. Use applyBlockToState for incremental use.
export function buildState(blocks: readonly Block[]): ChainState {
  const state = emptyState();
  for (const block of blocks) {
    applyBlockToState(state, block);
  }
  return state;
}

// Adds an accepted record to a pending view. Callers do this only after the record passed its validator.
export function addRecordToUniquenessIndex(index: UniquenessIndex, record: ChainRecord): void {
  const payload = record.payload;
  if (payload.type === "register") {
    index.registrations.add(payload.attendeeId);
  } else {
    index.attendance.add(attendanceKey(payload.attendeeId, payload.sessionId));
  }
}

// recordId = hash(canonicalize(signedRecord)) (SPEC section 10).
export function recordId(record: ChainRecord, hash: HashFn): string {
  return hash(canonicalize(record));
}

function confirmedKeyLookup(state: ChainState): KeyLookup {
  return (attendeeId) => state.registrations.get(attendeeId)?.publicKey;
}

// Fixed order, first failure wins (SPEC section 7).
// register: CHAIN_ID_MISMATCH, INVALID_KEY, ATTENDEE_ID_MISMATCH, INVALID_SIGNATURE (payload's own key).
// attend:   CHAIN_ID_MISMATCH, ATTENDEE_NOT_REGISTERED (keyLookup), INVALID_SIGNATURE (registered key).
export async function verifyRecordIntegrity(
  record: ChainRecord,
  keyLookup: KeyLookup,
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<Result> {
  const payload = record.payload;
  if (payload.chainId !== deriveChainId(config, crypto.hash)) {
    return failure("CHAIN_ID_MISMATCH");
  }

  if (payload.type === "register") {
    if (!(await validatePublicKey(payload.publicKey, crypto.identity))) {
      return failure("INVALID_KEY");
    }
    if ((await deriveAttendeeId(payload.publicKey, crypto.identity)) !== payload.attendeeId) {
      return failure("ATTENDEE_ID_MISMATCH");
    }
    const valid = await verifyPayload(payload, record.signature, payload.publicKey, crypto.identity);
    return valid ? OK : failure("INVALID_SIGNATURE");
  }

  const registeredKey = keyLookup(payload.attendeeId);
  if (registeredKey === undefined) {
    return failure("ATTENDEE_NOT_REGISTERED");
  }
  const valid = await verifyPayload(payload, record.signature, registeredKey, crypto.identity);
  return valid ? OK : failure("INVALID_SIGNATURE");
}

// Uniqueness rules against the given confirmed state and pending view. Shared by both record validators.
function checkUniqueness(record: ChainRecord, state: ChainState, pending: UniquenessIndex): Result {
  const payload = record.payload;
  if (payload.type === "register") {
    const taken = state.registrations.has(payload.attendeeId) || pending.registrations.has(payload.attendeeId);
    return taken ? failure("KEY_ALREADY_REGISTERED") : OK;
  }
  const key = attendanceKey(payload.attendeeId, payload.sessionId);
  const taken = state.attendance.has(key) || pending.attendance.has(key);
  return taken ? failure("DUPLICATE_ATTENDANCE") : OK;
}

// Mempool admission. Order (deterministic, first failure wins):
//   1. integrity (keyLookup over confirmed state only)
//   2. UNKNOWN_SESSION (attend only; catalog is an admission policy, RC5)
//   3. TIMESTAMP_OUT_OF_RANGE if |clock.now() - payload.timestamp| > maxRecordSkewMs
//   4. KEY_ALREADY_REGISTERED / DUPLICATE_ATTENDANCE against confirmed state UNION mempool index
// MEMPOOL_FULL is NOT checked here: the caller (node) checks its pending count before calling this function.
// The caller inserts the record into `mempool` (addRecordToUniquenessIndex) synchronously under the writer lock after a pass.
export async function validateRecordAtSubmission(
  record: ChainRecord,
  state: ChainState,
  mempool: MempoolIndex,
  catalog: ReadonlySet<string>,
  config: ChainConfig,
  clock: Clock,
  crypto: ChainCrypto,
): Promise<Result> {
  const integrity = await verifyRecordIntegrity(record, confirmedKeyLookup(state), config, crypto);
  if (!integrity.ok) {
    return integrity;
  }
  const payload = record.payload;
  if (payload.type === "attend" && !catalog.has(payload.sessionId)) {
    return failure("UNKNOWN_SESSION");
  }
  if (Math.abs(clock.now() - payload.timestamp) > config.maxRecordSkewMs) {
    return failure("TIMESTAMP_OUT_OF_RANGE");
  }
  return checkUniqueness(record, state, mempool);
}

// In-block validation. No clock, no catalog. Order (first failure wins):
//   1. integrity (keyLookup over scope.state only: a registration earlier in the SAME block does not satisfy it)
//   2. |block.timestamp - payload.timestamp| <= maxRecordAgeInBlockMs (symmetric), else TIMESTAMP_OUT_OF_RANGE
//   3. KEY_ALREADY_REGISTERED / DUPLICATE_ATTENDANCE against scope.state UNION scope.pending
export async function validateRecordInBlock(
  record: ChainRecord,
  block: Pick<BlockHeader, "index" | "timestamp">,
  scope: BlockScope,
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<Result> {
  const integrity = await verifyRecordIntegrity(record, confirmedKeyLookup(scope.state), config, crypto);
  if (!integrity.ok) {
    return integrity;
  }
  if (Math.abs(block.timestamp - record.payload.timestamp) > config.maxRecordAgeInBlockMs) {
    return failure("TIMESTAMP_OUT_OF_RANGE");
  }
  return checkUniqueness(record, scope.state, scope.pending);
}

// Block validation, steps 2 and 3 of SPEC section 7. Order (first failure wins):
//   BAD_INDEX, BAD_PREVIOUS_HASH, BAD_BLOCK_HASH, BAD_POW, BAD_DIFFICULTY (nextDifficulty(prefix)),
//   BAD_TIMESTAMP_ORDER, TOO_MANY_RECORDS, then each record in order via validateRecordInBlock.
// prefix: the blocks before this one, in chain order. Must be non-empty (genesis is validated by validateChain).
// It is read synchronously and never mutated. state: confirmed state for the prefix. Not mutated.
export async function validateBlock(
  block: Block,
  prefix: readonly Block[],
  state: ChainState,
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<Result> {
  const previous = prefix.at(-1);
  if (previous === undefined) {
    throw new ChainError("INTERNAL", "validateBlock needs a non-empty prefix; genesis is validated by validateChain");
  }
  const expectedIndex = previous.index + 1;
  const fail = (code: ErrorCode): Result => failure(code, expectedIndex);

  if (block.index !== expectedIndex) {
    return fail("BAD_INDEX");
  }
  if (block.previousHash !== previous.hash) {
    return fail("BAD_PREVIOUS_HASH");
  }
  const recomputed = computeBlockHash(block, crypto.hash);
  if (recomputed !== block.hash) {
    return fail("BAD_BLOCK_HASH");
  }
  if (!meetsProofOfWork(recomputed, block.difficulty)) {
    return fail("BAD_POW");
  }
  if (nextDifficulty(prefix, config) !== block.difficulty) {
    return fail("BAD_DIFFICULTY");
  }
  if (block.timestamp < previous.timestamp) {
    return fail("BAD_TIMESTAMP_ORDER");
  }
  if (block.records.length > MAX_RECORDS_PER_BLOCK) {
    return fail("TOO_MANY_RECORDS");
  }

  // Block-local scope: confirmed state is never written; earlier records of this block go into `pending` only.
  const scope: BlockScope = { state, pending: emptyUniquenessIndex() };
  for (const record of block.records) {
    const result = await validateRecordInBlock(record, block, scope, config, crypto);
    if (!result.ok) {
      return fail(result.code);
    }
    addRecordToUniquenessIndex(scope.pending, record);
  }
  return OK;
}

// Admission of a newly mined block: validateBlock, then block.timestamp <= clock.now() + maxBlockSkewMs.
// Never used on reload or in validateChain.
export async function validateBlockAdmission(
  block: Block,
  prefix: readonly Block[],
  state: ChainState,
  config: ChainConfig,
  clock: Clock,
  crypto: ChainCrypto,
): Promise<Result> {
  const result = await validateBlock(block, prefix, state, config, crypto);
  if (!result.ok) {
    return result;
  }
  if (block.timestamp > clock.now() + config.maxBlockSkewMs) {
    return failure("TIMESTAMP_OUT_OF_RANGE", block.index);
  }
  return OK;
}

// Historical validation of a whole chain (SPEC section 7). No clock and no catalog: the signature has exactly three
// parameters and the function reads neither wall-clock time nor sessions.json (tests A5, RC5).
// blocks[0] must equal the regenerated genesis (canonicalize equality), else GENESIS_MISMATCH at index 0 (also for an
// empty array). Each later block is validated with validateBlock against one incrementally maintained state and
// prefix; a block is applied only after it validates. Inputs are expected to be structurally parsed (schemas.ts);
// canonicalize throws ChainError(INVALID_SCHEMA) on values it cannot serialize.
export async function validateChain(
  blocks: readonly Block[],
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<Result> {
  const genesis = blocks[0];
  if (genesis === undefined || canonicalize(genesis) !== canonicalize(makeGenesis(config, crypto.hash))) {
    return failure("GENESIS_MISMATCH", 0);
  }

  const state = emptyState();
  const prefix: Block[] = [genesis];
  applyBlockToState(state, genesis);

  for (let position = 1; position < blocks.length; position += 1) {
    const block = blocks[position];
    if (block === undefined) {
      throw new ChainError("INTERNAL", "validateChain: block missing at a valid position");
    }
    const result = await validateBlock(block, prefix, state, config, crypto);
    if (!result.ok) {
      return result;
    }
    applyBlockToState(state, block);
    prefix.push(block);
  }
  return OK;
}
