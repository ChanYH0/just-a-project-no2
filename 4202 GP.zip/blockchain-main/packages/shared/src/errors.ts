// Error taxonomy (SPEC section 11). Codes are defined once here.

export const ERROR_CODES = [
  "INVALID_SCHEMA",
  "INVALID_KEY",
  "INVALID_SIGNATURE",
  "ATTENDEE_ID_MISMATCH",
  "CHAIN_ID_MISMATCH",
  "KEY_ALREADY_REGISTERED",
  "ATTENDEE_NOT_REGISTERED",
  "DUPLICATE_ATTENDANCE",
  "UNKNOWN_SESSION",
  "TIMESTAMP_OUT_OF_RANGE",
  "BAD_PREVIOUS_HASH",
  "BAD_BLOCK_HASH",
  "BAD_POW",
  "BAD_DIFFICULTY",
  "BAD_INDEX",
  "BAD_TIMESTAMP_ORDER",
  "GENESIS_MISMATCH",
  "TOO_MANY_RECORDS",
  "NOT_FOUND",
  "BODY_TOO_LARGE",
  "RATE_LIMITED",
  "MEMPOOL_FULL",
  "MINER_UNAVAILABLE",
  "CHAIN_FILE_CORRUPT",
  "CHAIN_STORE_MISMATCH",
  "INTERNAL",
] as const;

export type ErrorCode = (typeof ERROR_CODES)[number];

export class ChainError extends Error {
  readonly code: ErrorCode;

  constructor(code: ErrorCode, message: string) {
    super(message);
    this.name = "ChainError";
    this.code = code;
  }
}
