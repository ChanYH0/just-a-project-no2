// Tamper mutations for POST /demo/tamper-check (SPEC section 10). Node-only (exported from node.ts): they mine blocks
// with the sync HashFn the caller supplies. Pure: no clock, no I/O, inputs are never mutated.
//
// Every mutation must change something. A mutation that would be a no-op is rejected (ChainError INVALID_SCHEMA, mapped
// to 400 by the route) or, if the mutator itself is broken, fails with ChainError INTERNAL; it is never a result.

import { canonicalize } from "./canonical.js";
import { mineBlock, type BlockCandidate } from "./block.js";
import type { ChainConfig } from "./config.js";
import type { HashFn } from "./crypto.js";
import { nextDifficulty } from "./difficulty.js";
import { ChainError } from "./errors.js";
import { ChainRecord, HexSha256, type Block } from "./schemas.js";

export const MUTATIONS = [
  "edit-record",
  "edit-previous-hash",
  "rehash-after-edit",
  "lower-difficulty",
  "delete-record-and-remine",
] as const;
export type Mutation = (typeof MUTATIONS)[number];

// delete-record-and-remine re-mines blocks blockIndex..head; more than this many is refused.
export const MAX_REMINE_BLOCKS = 10;

// Replaces one record by a changed copy. Injectable so a test can supply a broken mutator (RC15).
export type RecordMutator = (record: ChainRecord) => ChainRecord;

export interface MutationOptions {
  recordMutator?: RecordMutator;
}

function tamperedValue(current: string): string {
  return current === "tampered" ? "tampered2" : "tampered";
}

// SPEC 10: switches on payload.type, never assumes a field exists.
export const defaultRecordMutator: RecordMutator = (record) => {
  const payload = record.payload;
  switch (payload.type) {
    case "register":
      return { payload: { ...payload, alias: tamperedValue(payload.alias) }, signature: record.signature };
    case "attend":
      return { payload: { ...payload, sessionId: tamperedValue(payload.sessionId) }, signature: record.signature };
  }
};

function canonicalOrInternal(value: unknown): string {
  try {
    return canonicalize(value);
  } catch {
    throw new ChainError("INTERNAL", "mutation produced a value that cannot be serialized");
  }
}

// Applies the mutator to the FIRST record of the block and leaves hash, nonce and every other field alone.
// Post-condition (INTERNAL if violated): the record changed and still passes the structural schema.
export function mutateFirstRecord(block: Block, mutator: RecordMutator = defaultRecordMutator): Block {
  const first = block.records[0];
  if (first === undefined) {
    throw new ChainError("INVALID_SCHEMA", "the block has no records");
  }
  const mutated = mutator(first);
  if (canonicalOrInternal(mutated) === canonicalOrInternal(first)) {
    throw new ChainError("INTERNAL", "mutation did not change the record");
  }
  if (!ChainRecord.safeParse(mutated).success) {
    throw new ChainError("INTERNAL", "mutated record no longer passes the structural schema");
  }
  return { ...block, records: [mutated, ...block.records.slice(1)] };
}

// Replaces the first hex character: "0" becomes "1", anything else becomes "0". Hash and nonce stay as they were.
export function editPreviousHash(block: Block): Block {
  const head = block.previousHash.slice(0, 1);
  const previousHash = `${head === "0" ? "1" : "0"}${block.previousHash.slice(1)}`;
  if (previousHash === block.previousHash || !HexSha256.safeParse(previousHash).success) {
    throw new ChainError("INTERNAL", "previousHash mutation did not produce a different valid hash");
  }
  return { ...block, previousHash };
}

function remine(candidate: BlockCandidate, hash: HashFn): Block {
  const block = mineBlock(candidate, hash);
  if (block === null) {
    throw new ChainError("INTERNAL", "mining returned no block without an abort callback");
  }
  return block;
}

function blockAt(blocks: readonly Block[], index: number): Block {
  const block = blocks[index];
  if (block === undefined) {
    throw new ChainError("INVALID_SCHEMA", "blockIndex is out of range");
  }
  return block;
}

function lastAttendancePosition(block: Block): number {
  for (let position = block.records.length - 1; position >= 0; position -= 1) {
    if (block.records[position]?.payload.type === "attend") {
      return position;
    }
  }
  return -1;
}

// Every precondition of every mutation, as ChainError(INVALID_SCHEMA) (the route maps it to 400). Cheap and synchronous,
// so the route can run it before it hands the job to the worker. The profile rule (delete only in demo/test) belongs to
// the route, which knows the profile.
export function assertMutationApplicable(
  blocks: readonly Block[],
  mutation: Mutation,
  blockIndex: number,
  config: ChainConfig,
): void {
  if (!Number.isSafeInteger(blockIndex) || blockIndex < 1 || blockIndex >= blocks.length) {
    throw new ChainError("INVALID_SCHEMA", "blockIndex must satisfy 1 <= blockIndex < chain length");
  }
  const block = blockAt(blocks, blockIndex);
  if (block.records.length === 0) {
    throw new ChainError("INVALID_SCHEMA", "the block has no records");
  }
  if (mutation === "lower-difficulty" && nextDifficulty(blocks.slice(0, blockIndex), config) <= config.minDifficulty) {
    throw new ChainError("INVALID_SCHEMA", "the required difficulty is already the minimum");
  }
  if (mutation === "delete-record-and-remine") {
    if (lastAttendancePosition(block) < 0) {
      throw new ChainError("INVALID_SCHEMA", "the block has no attendance record");
    }
    if (blocks.length - blockIndex > MAX_REMINE_BLOCKS) {
      throw new ChainError("INVALID_SCHEMA", `more than ${MAX_REMINE_BLOCKS} blocks would need re-mining`);
    }
  }
}

function replaceBlock(blocks: readonly Block[], index: number, block: Block): Block[] {
  return blocks.map((existing, position) => (position === index ? block : existing));
}

// Returns a NEW chain with the mutation applied (the input array and its blocks are not touched). Re-mined blocks use the
// difficulty that nextDifficulty requires for their position (except lower-difficulty, which uses required - 1 on purpose).
export function applyMutation(
  blocks: readonly Block[],
  mutation: Mutation,
  blockIndex: number,
  config: ChainConfig,
  hash: HashFn,
  options: MutationOptions = {},
): Block[] {
  assertMutationApplicable(blocks, mutation, blockIndex, config);
  const block = blockAt(blocks, blockIndex);
  const required = nextDifficulty(blocks.slice(0, blockIndex), config);

  switch (mutation) {
    case "edit-record":
      return replaceBlock(blocks, blockIndex, mutateFirstRecord(block, options.recordMutator));
    case "edit-previous-hash":
      return replaceBlock(blocks, blockIndex, editPreviousHash(block));
    case "rehash-after-edit": {
      const edited = mutateFirstRecord(block, options.recordMutator);
      const mined = remine(
        {
          index: edited.index,
          timestamp: edited.timestamp,
          previousHash: edited.previousHash,
          difficulty: required,
          records: edited.records,
        },
        hash,
      );
      return replaceBlock(blocks, blockIndex, mined);
    }
    case "lower-difficulty": {
      const mined = remine(
        {
          index: block.index,
          timestamp: block.timestamp,
          previousHash: block.previousHash,
          difficulty: required - 1,
          records: block.records,
        },
        hash,
      );
      return replaceBlock(blocks, blockIndex, mined);
    }
    case "delete-record-and-remine": {
      const result: Block[] = blocks.slice(0, blockIndex);
      for (let position = blockIndex; position < blocks.length; position += 1) {
        const original = blockAt(blocks, position);
        const previous = result[position - 1];
        if (previous === undefined) {
          throw new ChainError("INTERNAL", "re-mined chain has a hole");
        }
        let records = original.records;
        if (position === blockIndex) {
          const removed = lastAttendancePosition(original);
          records = original.records.filter((_, at) => at !== removed);
        }
        result.push(
          remine(
            {
              index: original.index,
              timestamp: original.timestamp,
              previousHash: previous.hash,
              difficulty: nextDifficulty(result, config),
              records,
            },
            hash,
          ),
        );
      }
      return result;
    }
  }
}
