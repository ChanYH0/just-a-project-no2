// Semantic identity helpers (SPEC sections 5.1, 6). Async, crypto supplied by argument.

import { canonicalize } from "./canonical.js";
import type { IdentityCrypto, PrivateKeyHandle } from "./crypto.js";
import { ChainError } from "./errors.js";
import { RSA_MODULUS_BITS, RSA_PUBLIC_EXPONENT } from "./config.js";
import { decodeBase64Strict } from "./schemas.js";

const encoder = new TextEncoder();

// Signed bytes: UTF-8 of canonicalize(payload).
function payloadBytes(payload: unknown): Uint8Array {
  return encoder.encode(canonicalize(payload));
}

// True only if the key is RSA-2048 with e=65537 and has exactly one canonical encoding.
// Any other input, including unparsable input, returns false.
export async function validatePublicKey(publicKey: string, identity: IdentityCrypto): Promise<boolean> {
  const info = await identity.inspectPublicKey(publicKey);
  return (
    info !== null &&
    info.modulusBits === RSA_MODULUS_BITS &&
    info.publicExponent === RSA_PUBLIC_EXPONENT &&
    info.canonicalSpki === publicKey
  );
}

// attendeeId = sha256Hex(SPKI DER bytes). Throws ChainError(INVALID_SCHEMA) if publicKey is not canonical base64.
export async function deriveAttendeeId(publicKey: string, identity: IdentityCrypto): Promise<string> {
  const der = decodeBase64Strict(publicKey);
  if (der === null) {
    throw new ChainError("INVALID_SCHEMA", "publicKey is not canonical base64");
  }
  return identity.sha256Hex(der);
}

export async function signPayload(
  payload: unknown,
  privateKey: PrivateKeyHandle,
  identity: IdentityCrypto,
): Promise<string> {
  return identity.sign(payloadBytes(payload), privateKey);
}

// Returns false for a bad signature or malformed key or signature. Throws only if payload is not canonicalizable.
export async function verifyPayload(
  payload: unknown,
  signature: string,
  publicKey: string,
  identity: IdentityCrypto,
): Promise<boolean> {
  return identity.verify(payloadBytes(payload), signature, publicKey);
}
