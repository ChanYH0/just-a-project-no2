// Structural validation only (SPEC section 5.1). Semantic checks live in identity.ts and chain.ts.
// Schemas reject non-conforming input and never transform it.

import { z } from "zod";
import {
  ALIAS_MAX_CODE_POINTS,
  MAX_RECORDS_PER_BLOCK,
  RSA_MODULUS_BITS,
  RSA_SPKI_DER_LENGTH,
} from "./config.js";

// RSA-2048 signature length in bytes.
const RSA_SIGNATURE_BYTES = RSA_MODULUS_BITS / 8;

const BASE64_STD_PATTERN = /^[A-Za-z0-9+/]+={0,2}$/;

// Strict canonical base64 decode. Returns null unless the input matches the
// standard alphabet, has length % 4 == 0 and re-encodes to exactly the same string.
export function decodeBase64Strict(input: string): Uint8Array | null {
  if (!BASE64_STD_PATTERN.test(input) || input.length % 4 !== 0) {
    return null;
  }
  const binary = atob(input);
  if (btoa(binary) !== input) {
    return null;
  }
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// Integers: Number.isSafeInteger and not -0. Never reuse one for the other.
function safeIntAtLeast(min: number, label: string) {
  return z.number().refine(
    (n) => Number.isSafeInteger(n) && !Object.is(n, -0) && n >= min,
    `${label} must be a safe integer >= ${min}, not -0`,
  );
}

export const HexSha256 = z.string().regex(/^[0-9a-f]{64}$/, "must be 64 lowercase hex characters");

export const Base64Std = z
  .string()
  .refine((s) => decodeBase64Strict(s) !== null, "must be canonical standard base64");

export const PublicKey = z
  .string()
  .refine(
    (s) => decodeBase64Strict(s)?.length === RSA_SPKI_DER_LENGTH,
    `must be canonical base64 of ${RSA_SPKI_DER_LENGTH} bytes`,
  );

export const Signature = z
  .string()
  .refine(
    (s) => decodeBase64Strict(s)?.length === RSA_SIGNATURE_BYTES,
    `must be canonical base64 of ${RSA_SIGNATURE_BYTES} bytes`,
  );

export const PositiveInt = safeIntAtLeast(1, "PositiveInt");
export const NonNegativeInt = safeIntAtLeast(0, "NonNegativeInt");

export const Timestamp = PositiveInt;

export const AttendeeId = HexSha256;

export const SessionId = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/, "must be 1-64 chars of [A-Za-z0-9_-]");

// 1-50 code points, NFC-normalized, no leading or trailing whitespace, and no
// control, format (bidi overrides, zero-width), unassigned, private-use, surrogate,
// line or paragraph separator characters. Rejected, never trimmed or normalized.
const ALIAS_FORBIDDEN_PATTERN = /[\p{C}\p{Zl}\p{Zp}]/u;

export const Alias = z
  .string()
  .refine((s) => {
    const codePoints = [...s].length;
    return (
      codePoints >= 1 &&
      codePoints <= ALIAS_MAX_CODE_POINTS &&
      s.normalize("NFC") === s &&
      s.trim() === s &&
      !ALIAS_FORBIDDEN_PATTERN.test(s)
    );
  }, `must be 1-${ALIAS_MAX_CODE_POINTS} NFC code points with no leading/trailing whitespace or control, format, separator, unassigned or private-use characters`);

export const RegistrationPayload = z
  .object({
    type: z.literal("register"),
    chainId: HexSha256,
    attendeeId: AttendeeId,
    alias: Alias,
    publicKey: PublicKey,
    timestamp: Timestamp,
  })
  .strict();

export const SignedRegistration = z
  .object({
    payload: RegistrationPayload,
    signature: Signature,
  })
  .strict();

export const AttendancePayload = z
  .object({
    type: z.literal("attend"),
    chainId: HexSha256,
    attendeeId: AttendeeId,
    sessionId: SessionId,
    timestamp: Timestamp,
  })
  .strict();

export const SignedAttendance = z
  .object({
    payload: AttendancePayload,
    signature: Signature,
  })
  .strict();

// Discriminated on payload.type.
export const ChainRecord = z.union([SignedRegistration, SignedAttendance]);

export const BlockHeader = z
  .object({
    index: NonNegativeInt,
    timestamp: Timestamp,
    previousHash: HexSha256,
    difficulty: PositiveInt,
    nonce: NonNegativeInt,
  })
  .strict();

export const Block = BlockHeader.extend({
  records: z.array(ChainRecord).max(MAX_RECORDS_PER_BLOCK),
  hash: HexSha256,
}).strict();

export type RegistrationPayload = z.infer<typeof RegistrationPayload>;
export type SignedRegistration = z.infer<typeof SignedRegistration>;
export type AttendancePayload = z.infer<typeof AttendancePayload>;
export type SignedAttendance = z.infer<typeof SignedAttendance>;
export type ChainRecord = z.infer<typeof ChainRecord>;
export type BlockHeader = z.infer<typeof BlockHeader>;
export type Block = z.infer<typeof Block>;
