// GET /chain/validate and the gated /demo/difficulty-simulation and /demo/tamper-check (SPEC sections 8, 9 and 10).

import { open } from "node:fs/promises";
import { z } from "zod";
import { ChainError, assertMutationApplicable } from "@conference-chain/shared";
import type { RouteRegistrar } from "./app.js";
import { parseWith } from "./request.js";
import { chainFilePath } from "./store.js";
import { tamperCacheKey, validateCacheKey } from "./validation-cache.js";
import {
  SimulationParams,
  TamperParams,
  type JobOutcome,
  type TamperOutcome,
  type ValidateSnapshotOutcome,
} from "./validation-protocol.js";

const EmptyQuery = z.object({}).strict();

type ValidateResponse = { ok: true } | { ok: false; code: string; blockIndex?: number };

const STORE_MISMATCH: ValidateResponse = { ok: false, code: "CHAIN_STORE_MISMATCH" };

// Bounded read of exactly `size` bytes from the start of the file. Returns null when the file is shorter than `size`
// (external truncation) or gone. Bytes beyond `size` (an append in flight) are never read.
async function readSnapshot(path: string, size: number): Promise<Uint8Array<ArrayBuffer> | null> {
  let handle;
  try {
    handle = await open(path, "r");
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return null;
    }
    throw new ChainError("INTERNAL", "chain file cannot be opened");
  }
  try {
    // One stat, compared with the committed size only to detect a file that is shorter than what memory holds.
    if ((await handle.stat()).size < size) {
      return null;
    }
    const buffer = new Uint8Array(size);
    let filled = 0;
    while (filled < size) {
      const { bytesRead } = await handle.read(buffer, filled, size - filled, filled);
      if (bytesRead === 0) {
        return null;
      }
      filled += bytesRead;
    }
    return buffer;
  } finally {
    await handle.close();
  }
}

function expectKind<K extends JobOutcome["kind"]>(outcome: JobOutcome, kind: K): Extract<JobOutcome, { kind: K }> {
  if (outcome.kind !== kind) {
    throw new ChainError("INTERNAL", "validation worker answered a different job kind");
  }
  return outcome as Extract<JobOutcome, { kind: K }>;
}

export const registerValidateRoutes: RouteRegistrar = (app, ctx) => {
  app.get("/chain/validate", { onRequest: ctx.heavyLimit }, async (request): Promise<ValidateResponse> => {
    parseWith(EmptyQuery, request.query, "query");
    const { ledger, validationCache: cache } = ctx;

    // The snapshot boundary is the COMMITTED size (memory), captured together with the committed head in one
    // synchronous step. A block that is mid-append is on disk beyond this bound but not in memory, so it is never read
    // and can never look like corruption.
    const committedSize = ledger.committedSize;
    const blockCount = ledger.blocks.length;
    const headHash = ledger.head.hash;

    const snapshot = await readSnapshot(chainFilePath(ctx.settings.dataDir), committedSize);
    if (snapshot === null) {
      return STORE_MISMATCH;
    }

    const key = validateCacheKey(ctx.chainId, ctx.settings.config, snapshot);
    let outcome: ValidateSnapshotOutcome;
    const cached = cache.get(key);
    if (cached !== undefined) {
      outcome = cached;
    } else {
      outcome = expectKind(
        await ctx.validationManager.run({ kind: "validate-snapshot", snapshot, config: ctx.settings.config }),
        "validate-snapshot",
      );
      // A head change while the worker ran already cleared the caches; do not store a result keyed to the old head.
      if (ledger.blocks.length === blockCount) {
        cache.set(key, outcome);
      }
    }

    if (!outcome.result.ok) {
      return outcome.result;
    }
    if (outcome.blockCount !== blockCount || outcome.headHash !== headHash) {
      return STORE_MISMATCH;
    }
    return { ok: true };
  });
};

// POST /demo/tamper-check (SPEC section 10): copies the live chain in memory, applies one mutation inside the validation
// worker and runs the real validateChain on the copy. The live chain, the file and the mempool are never touched. It has
// its own cache (tamperCache, keys under the "tamper" prefix); the simulation handler below cannot reach any cache.
export const registerTamperRoutes: RouteRegistrar = (app, ctx) => {
  if (!ctx.settings.enableDemoRoutes) {
    return;
  }
  app.post("/demo/tamper-check", { onRequest: ctx.heavyLimit }, async (request) => {
    const { mutation, blockIndex } = parseWith(TamperParams, request.body, "body");
    const { ledger, settings, tamperCache: cache } = ctx;
    if (mutation === "delete-record-and-remine" && settings.profile === "production") {
      throw new ChainError("INVALID_SCHEMA", "delete-record-and-remine is not available in the production profile");
    }

    // One synchronous step: the copy and the head it belongs to cannot diverge.
    const blocks = ledger.blocks.slice();
    const headHash = ledger.head.hash;
    assertMutationApplicable(blocks, mutation, blockIndex, settings.config);

    const key = tamperCacheKey(ctx.chainId, settings.config, headHash, mutation, blockIndex);
    let outcome: TamperOutcome;
    const cached = cache.get(key);
    if (cached !== undefined) {
      outcome = cached;
    } else {
      outcome = expectKind(
        await ctx.validationManager.run({ kind: "tamper", mutation, blockIndex, blocks, config: settings.config }),
        "tamper",
      );
      // A head change while the worker ran already cleared the cache; do not store a result keyed to the old head.
      if (ledger.head.hash === headHash) {
        cache.set(key, outcome);
      }
    }
    return { ...outcome.result, note: outcome.note };
  });
};

// Demo routes: registered only when ENABLE_DEMO_ROUTES is exactly 'true'. The simulation handler reaches the
// validation worker only: it has no access to the result caches, the miner, the ledger or the clock.
export const registerDemoRoutes: RouteRegistrar = (app, ctx) => {
  if (!ctx.settings.enableDemoRoutes) {
    return;
  }
  const manager = ctx.validationManager;
  const config = ctx.settings.config;
  app.post("/demo/difficulty-simulation", { onRequest: ctx.heavyLimit }, async (request) => {
    const body = parseWith(SimulationParams, request.body, "body");
    const outcome = expectKind(await manager.run({ kind: "simulate", ...body, config }), "simulate");
    return { valid: outcome.valid, blocks: outcome.blocks, adjustments: outcome.adjustments };
  });
};
