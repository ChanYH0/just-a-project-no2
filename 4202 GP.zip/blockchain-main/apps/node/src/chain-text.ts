// JSONL chain text parsing (SPEC section 9): one canonical block per line, newline terminated. Used by boot loading
// and by the validation worker so both reject exactly the same torn or unparsable inputs. Pure; never repairs.

import { Block, canonicalize } from "@conference-chain/shared";

export type ChainTextResult =
  | { ok: true; blocks: Block[]; lines: string[] }
  | { ok: false; message: string; position: number };

export function parseChainText(text: string): ChainTextResult {
  if (text.length === 0 || !text.endsWith("\n")) {
    const lastLine = text.length === 0 ? 0 : text.split("\n").length - 1;
    return { ok: false, message: "chain.jsonl is empty or its last line is torn", position: lastLine };
  }
  const lines = text.slice(0, -1).split("\n");
  const blocks: Block[] = [];
  for (const [position, line] of lines.entries()) {
    let json: unknown;
    try {
      json = JSON.parse(line);
    } catch {
      return { ok: false, message: "chain.jsonl contains an unparsable line", position };
    }
    const parsed = Block.safeParse(json);
    if (!parsed.success) {
      return { ok: false, message: "chain.jsonl contains a line that is not a block", position };
    }
    // Genesis has its own exact-byte comparison and GENESIS_MISMATCH error at boot.
    if (position > 0 && line !== canonicalize(parsed.data)) {
      return { ok: false, message: "chain.jsonl contains a noncanonical block line", position };
    }
    blocks.push(parsed.data);
  }
  return { ok: true, blocks, lines };
}
