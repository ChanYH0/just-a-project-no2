// Persistence (SPEC section 9): ChainStore, the process lock on DATA_DIR and boot-time chain loading.

import { mkdir, open, readFile, rename, unlink, type FileHandle } from "node:fs/promises";
import { join } from "node:path";
import {
  canonicalize,
  type Block,
  makeGenesis,
  validateChain,
  type ChainConfig,
  type ChainCrypto,
} from "@conference-chain/shared";
import { BootError } from "./boot-error.js";
import { parseChainText } from "./chain-text.js";

export const CHAIN_FILE_NAME = "chain.jsonl";
export const CHAIN_LOCK_NAME = "chain.lock";

// The only storage abstraction. Injectable so tests can inject faults at each call.
export interface ChainStore {
  size(): Promise<number>;
  append(line: string): Promise<void>;
  fsync(): Promise<void>;
  truncate(offset: number): Promise<void>;
}

export function chainFilePath(dataDir: string): string {
  return join(dataDir, CHAIN_FILE_NAME);
}

function hasErrnoCode(error: unknown, code: string): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === code;
}

// Real file implementation: append-mode handle, explicit fsync, ftruncate.
export class FileChainStore implements ChainStore {
  private constructor(private readonly handle: FileHandle) {}

  // The chain file must already exist (loadChainFile creates it with the genesis block).
  static async open(dataDir: string): Promise<FileChainStore> {
    return new FileChainStore(await open(chainFilePath(dataDir), "a"));
  }

  async size(): Promise<number> {
    return (await this.handle.stat()).size;
  }

  async append(line: string): Promise<void> {
    await this.handle.appendFile(line);
  }

  async fsync(): Promise<void> {
    await this.handle.sync();
  }

  async truncate(offset: number): Promise<void> {
    await this.handle.truncate(offset);
  }

  async close(): Promise<void> {
    await this.handle.close();
  }
}

export interface ProcessLock {
  release(): Promise<void>;
}

// Exclusive create (flag 'wx') of DATA_DIR/chain.lock holding the pid. A stale lock is never removed automatically:
// the operator removes it. Removed on clean shutdown.
export async function acquireLock(dataDir: string): Promise<ProcessLock> {
  await mkdir(dataDir, { recursive: true });
  const path = join(dataDir, CHAIN_LOCK_NAME);
  let handle: FileHandle;
  try {
    handle = await open(path, "wx");
  } catch (error) {
    if (hasErrnoCode(error, "EEXIST")) {
      throw new BootError(
        "INTERNAL",
        "chain.lock already exists: another node uses this DATA_DIR, or a stale lock must be removed by the operator",
      );
    }
    throw new BootError("INTERNAL", "cannot create chain.lock");
  }
  try {
    await handle.writeFile(`${process.pid}\n`);
    await handle.sync();
  } finally {
    await handle.close();
  }
  let released = false;
  return {
    async release() {
      if (released) {
        return;
      }
      released = true;
      try {
        await unlink(path);
      } catch (error) {
        if (!hasErrnoCode(error, "ENOENT")) {
          throw error;
        }
      }
    },
  };
}

async function writeGenesisFile(path: string, line: string): Promise<void> {
  const temp = `${path}.tmp`;
  const handle = await open(temp, "w");
  try {
    await handle.writeFile(line);
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(temp, path);
}

// Reads chain.jsonl and returns the validated blocks. Creates and persists the genesis block if the file is absent.
// Refuses (BootError carrying the code and block index) on a torn or unparsable line, a missing trailing newline,
// a genesis mismatch or any validateChain failure. Never repairs. No clock and no session catalog are involved.
export async function loadChainFile(dataDir: string, config: ChainConfig, crypto: ChainCrypto): Promise<Block[]> {
  await mkdir(dataDir, { recursive: true });
  const path = chainFilePath(dataDir);
  const genesisLine = canonicalize(makeGenesis(config, crypto.hash));

  let text: string;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (!hasErrnoCode(error, "ENOENT")) {
      throw new BootError("CHAIN_FILE_CORRUPT", "chain.jsonl cannot be read");
    }
    await writeGenesisFile(path, `${genesisLine}\n`);
    text = `${genesisLine}\n`;
  }

  const parsed = parseChainText(text);
  if (!parsed.ok) {
    throw new BootError("CHAIN_FILE_CORRUPT", parsed.message, parsed.position);
  }
  const { blocks, lines } = parsed;

  if (lines[0] !== genesisLine) {
    throw new BootError("GENESIS_MISMATCH", "first line of chain.jsonl differs from the regenerated genesis", 0);
  }

  const result = await validateChain(blocks, config, crypto);
  if (!result.ok) {
    throw new BootError(result.code, "chain.jsonl failed validation", result.blockIndex);
  }
  return blocks;
}
