// Messages between the main thread and mine-worker.ts (SPEC section 9). One job message in, one result message out.

import type { Block, BlockCandidate } from "@conference-chain/shared";

export interface MineJobMessage {
  jobId: number;
  candidate: BlockCandidate;
  // Optional for compatibility with single-worker callers; defaults to lane 0/1.
  nonceStart?: number;
  nonceStride?: number;
}

export interface MineResultMessage {
  jobId: number;
  block: Block;
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

export interface WorkerHandlers {
  onMessage(message: unknown): void;
  onError(error: Error): void;
  onExit(code: number): void;
}

// What the Miner needs from a mining worker. The real implementation wraps worker_threads; tests inject doubles.
export interface MineWorkerHandle {
  setHandlers(handlers: WorkerHandlers): void;
  postMessage(message: MineJobMessage): void;
  // Resolves once the worker thread is gone.
  terminate(): Promise<void>;
}

export type WorkerFactory = () => MineWorkerHandle;

// Injectable setTimeout abstraction (batch delay and backoff).
export interface Timers {
  setTimeout(callback: () => void, ms: number): unknown;
  clearTimeout(handle: unknown): void;
}

export const systemTimers: Timers = {
  setTimeout: (callback, ms) => setTimeout(callback, ms),
  clearTimeout: (handle) => {
    if (typeof handle === "object" && handle !== null) {
      clearTimeout(handle as NodeJS.Timeout);
    }
  },
};
