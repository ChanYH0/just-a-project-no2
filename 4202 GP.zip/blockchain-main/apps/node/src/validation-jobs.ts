// Pure job implementations run inside the validation worker (SPEC sections 8 and 9). No clock, no live node state:
// everything comes from the job message.

import {
  ChainError,
  GENESIS_TIMESTAMP,
  adjustmentAt,
  applyMutation,
  makeGenesis,
  mineBlock,
  nextDifficulty,
  validateChain,
  type Block,
  type ChainConfig,
  type ChainCrypto,
  type Mutation,
  type MutationOptions,
} from "@conference-chain/shared";
import { parseChainText } from "./chain-text.js";
import type {
  JobOutcome,
  SimulateOutcome,
  TamperOutcome,
  ValidateSnapshotOutcome,
  ValidationJob,
  ValidationVerdict,
} from "./validation-protocol.js";
import { nodeCrypto } from "./node-crypto.js";

async function verdictOf(blocks: readonly Block[], config: ChainConfig, crypto: ChainCrypto): Promise<ValidationVerdict> {
  try {
    const result = await validateChain(blocks, config, crypto);
    if (result.ok) {
      return { ok: true };
    }
    return result.blockIndex === undefined
      ? { ok: false, code: result.code }
      : { ok: false, code: result.code, blockIndex: result.blockIndex };
  } catch (error) {
    if (error instanceof ChainError) {
      return { ok: false, code: error.code };
    }
    throw error;
  }
}

// Parses the JSONL snapshot with the Block schema and runs validateChain. A torn or unparsable snapshot yields
// CHAIN_FILE_CORRUPT with the offending line, never a partial ok.
export async function validateSnapshot(
  snapshot: string | Uint8Array,
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<ValidateSnapshotOutcome> {
  let text: string;
  try {
    text = typeof snapshot === "string" ? snapshot : new TextDecoder("utf-8", { fatal: true }).decode(snapshot);
  } catch {
    return { kind: "validate-snapshot", result: { ok: false, code: "CHAIN_FILE_CORRUPT", blockIndex: 0 }, blockCount: 0, headHash: null };
  }
  const parsed = parseChainText(text);
  if (!parsed.ok) {
    return {
      kind: "validate-snapshot",
      result: { ok: false, code: "CHAIN_FILE_CORRUPT", blockIndex: parsed.position },
      blockCount: 0,
      headHash: null,
    };
  }
  const result = await verdictOf(parsed.blocks, config, crypto);
  return {
    kind: "validate-snapshot",
    result,
    blockCount: parsed.blocks.length,
    headHash: parsed.blocks.at(-1)?.hash ?? null,
  };
}

// SPEC section 8: a brand-new in-memory chain from the profile genesis, `count` empty blocks with synthetic timestamps
// GENESIS_TIMESTAMP + k * intervalMs. No clock is read; nothing outside this function's locals is touched.
export async function simulateDifficulty(
  count: number,
  intervalMs: number,
  config: ChainConfig,
  crypto: ChainCrypto,
): Promise<SimulateOutcome> {
  const chain: Block[] = [makeGenesis(config, crypto.hash)];
  const adjustments: SimulateOutcome["adjustments"] = [];
  for (let k = 1; k <= count; k += 1) {
    const previous = chain[k - 1];
    if (previous === undefined) {
      throw new ChainError("INTERNAL", "simulation chain has a hole");
    }
    const adjustment = adjustmentAt(chain, config);
    if (adjustment !== null) {
      adjustments.push({ atIndex: k, ...adjustment });
    }
    const block = mineBlock(
      {
        index: k,
        timestamp: GENESIS_TIMESTAMP + k * intervalMs,
        previousHash: previous.hash,
        difficulty: nextDifficulty(chain, config),
        records: [],
      },
      crypto.hash,
    );
    if (block === null) {
      throw new ChainError("INTERNAL", "simulation mining returned no block");
    }
    chain.push(block);
  }
  const verdict = await verdictOf(chain, config, crypto);
  return {
    kind: "simulate",
    valid: verdict.ok,
    blocks: chain.slice(1).map((block) => ({
      index: block.index,
      hash: block.hash,
      difficulty: block.difficulty,
      timestamp: block.timestamp,
    })),
    adjustments,
  };
}

const ANCHOR_NOTE =
  "A local hash chain plus proof of work is tamper-evident, not distributed consensus: whoever controls the data can " +
  "delete a record and re-mine every later block undetectably unless the head hash is anchored outside the node.";

const EDIT_NOTES: Readonly<Record<Exclude<Mutation, "delete-record-and-remine">, string>> = {
  "edit-record": "The first record of the block was edited and the block hash left alone",
  "edit-previous-hash": "The previousHash of the block was changed",
  "rehash-after-edit": "The first record of the block was edited and only that block was re-mined",
  "lower-difficulty": "The block was re-mined at a difficulty one below the required value",
};

// Fixed explanatory text per mutation; the verdict itself always comes from the real validateChain.
function tamperNote(mutation: Mutation, verdict: ValidationVerdict): string {
  if (mutation === "delete-record-and-remine") {
    return verdict.ok
      ? `The last attendance record of the block was deleted and the blocks were re-mined with fixed links; the real validator accepted the chain. ${ANCHOR_NOTE}`
      : `The last attendance record of the block was deleted and the blocks were re-mined; the real validator rejected the chain with ${verdict.code}.`;
  }
  return verdict.ok
    ? `${EDIT_NOTES[mutation]}; the real validator accepted the chain.`
    : `${EDIT_NOTES[mutation]}; the real validator rejected the chain with ${verdict.code}.`;
}

// SPEC section 10: applies the mutation to the copied chain and runs the real validateChain on the result.
export async function tamperCheck(
  job: Extract<ValidationJob, { kind: "tamper" }>,
  crypto: ChainCrypto,
  options: MutationOptions,
): Promise<TamperOutcome> {
  const mutated = applyMutation(job.blocks, job.mutation, job.blockIndex, job.config, crypto.hash, options);
  const result = await verdictOf(mutated, job.config, crypto);
  return { kind: "tamper", result, note: tamperNote(job.mutation, result) };
}

// Test seam: the real worker never passes hooks. A test double can inject a broken record mutator (RC15).
export type JobHooks = MutationOptions;

export async function runJob(job: ValidationJob, hooks: JobHooks = {}): Promise<JobOutcome> {
  switch (job.kind) {
    case "validate-snapshot":
      return validateSnapshot(job.snapshot, job.config, nodeCrypto);
    case "simulate":
      return simulateDifficulty(job.count, job.intervalMs, job.config, nodeCrypto);
    case "tamper":
      return tamperCheck(job, nodeCrypto, hooks);
  }
}
