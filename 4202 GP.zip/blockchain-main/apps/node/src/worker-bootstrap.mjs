// Worker entry shim: registers the tsx loader inside the worker thread, then loads the real TypeScript worker.
// `--import` in Worker execArgv is not applied by Node 22, and its native type stripping arrives only in later releases.
import { workerData } from "node:worker_threads";
import { register } from "tsx/esm/api";

register();
await import(workerData.entry);
