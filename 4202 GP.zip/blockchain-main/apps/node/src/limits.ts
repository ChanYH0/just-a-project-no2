// Node-local operational limits (SPEC sections 9 and 10). Defined once here; protocol constants stay in packages/shared.

export const BODY_LIMIT_BYTES = 16 * 1024;

// Per-IP fixed-window write limit: 30 requests per minute.
export const WRITE_RATE_LIMIT = 30;
export const WRITE_RATE_WINDOW_MS = 60_000;

export const BLOCKS_DEFAULT_LIMIT = 20;
export const BLOCKS_MAX_LIMIT = 100;
export const MEMPOOL_VIEW_MAX = 100;

// /chain/validate and /demo/*: 6 requests per minute per IP (shared bucket).
export const HEAVY_RATE_LIMIT = 6;
export const HEAVY_RATE_WINDOW_MS = 60_000;

// Validation worker jobs (validate-snapshot, simulate, later tamper): one at a time, terminated after 30 s.
export const VALIDATION_TIMEOUT_MS = 30_000;
// Jobs allowed to wait behind the running one; further requests are refused with RATE_LIMITED (no unbounded queue).
export const VALIDATION_QUEUE_MAX = 4;
// Result caches of the validation worker: bounded, oldest evicted.
export const VALIDATION_CACHE_MAX_ENTRIES = 64;

// POST /demo/difficulty-simulation body bounds.
export const SIMULATION_MAX_COUNT = 30;
export const SIMULATION_MAX_INTERVAL_MS = 120_000;

// Terminal (expired, rejected) record statuses kept for GET /records/:id.
export const TERMINAL_LRU_LIMIT = 10_000;

// Miner restart backoff after a worker crash or a persist error: 1 s, 2 s, ... max 30 s.
export const BACKOFF_INITIAL_MS = 1_000;
export const BACKOFF_MAX_MS = 30_000;
