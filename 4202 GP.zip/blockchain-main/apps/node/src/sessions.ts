// sessions.json loading (SPEC section 9): the admission catalog. It is NOT consensus (RC5).

import { readFile } from "node:fs/promises";
import { z } from "zod";
import { SessionId } from "@conference-chain/shared";
import { BootError } from "./boot-error.js";

export const SessionEntry = z.object({ id: SessionId, title: z.string().min(1).max(200) }).strict();
export type SessionEntry = z.infer<typeof SessionEntry>;

const SessionList = z.array(SessionEntry);

export function parseSessions(text: string): SessionEntry[] {
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new BootError("INVALID_SCHEMA", "SESSIONS_FILE is not valid JSON");
  }
  const parsed = SessionList.safeParse(json);
  if (!parsed.success) {
    throw new BootError("INVALID_SCHEMA", "SESSIONS_FILE does not match [{ id, title }]");
  }
  const seen = new Set<string>();
  for (const entry of parsed.data) {
    if (seen.has(entry.id)) {
      throw new BootError("INVALID_SCHEMA", "SESSIONS_FILE contains a duplicate session id");
    }
    seen.add(entry.id);
  }
  return parsed.data;
}

export async function loadSessions(path: string): Promise<SessionEntry[]> {
  let text: string;
  try {
    text = await readFile(path, "utf8");
  } catch {
    throw new BootError("INVALID_SCHEMA", "SESSIONS_FILE cannot be read");
  }
  return parseSessions(text);
}
