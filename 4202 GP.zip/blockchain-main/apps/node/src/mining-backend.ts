import type { WorkerFactory } from "./mine-protocol.js";
import type { NodeSettings } from "./env.js";
import { BootError } from "./boot-error.js";
import { createRealWorkerFactory } from "./worker-factory.js";
import { createWorkerPool } from "./worker-pool.js";
import { createMetalWorkerFactory, preflightMetal } from "./metal-worker-factory.js";
import { DEFAULT_METAL_BATCH_SIZE, DEFAULT_MINING_BACKEND, DEFAULT_MINING_WORKERS } from "./mining-config.js";

export async function configuredMiningFactory(settings: NodeSettings): Promise<WorkerFactory> {
  const workers = settings.miningWorkers ?? DEFAULT_MINING_WORKERS;
  if ((settings.miningBackend ?? DEFAULT_MINING_BACKEND) === "cpu") return createRealWorkerFactory(workers);
  if (process.platform !== "darwin") {
    throw new BootError("INVALID_SCHEMA", "the Metal backend requires macOS");
  }
  try {
    // Compile/load and dispatch a bounded real GPU job before touching the data directory.
    await preflightMetal();
  } catch {
    throw new BootError("INTERNAL", "Metal preflight failed; build and verify the native Metal helper");
  }
  return createWorkerPool(createMetalWorkerFactory({ batchSize: settings.metalBatchSize ?? DEFAULT_METAL_BATCH_SIZE }), workers);
}
