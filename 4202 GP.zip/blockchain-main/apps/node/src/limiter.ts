// Small in-house per-key fixed-window rate limiter with an injectable clock (no library, SPEC section 10).

import type { Clock } from "@conference-chain/shared";

interface Window {
  startedAt: number;
  count: number;
}

// Bound on tracked keys; expired windows are pruned when it is reached.
const MAX_TRACKED_KEYS = 10_000;

export class FixedWindowLimiter {
  private readonly windows = new Map<string, Window>();

  constructor(
    private readonly limit: number,
    private readonly windowMs: number,
    private readonly clock: Clock,
    private readonly maxKeys: number = MAX_TRACKED_KEYS,
  ) {}

  // Returns true if the request is allowed and counts it; false if the key exceeded the limit in the current window.
  take(key: string): boolean {
    const now = this.clock.now();
    const current = this.windows.get(key);
    if (current === undefined || now - current.startedAt >= this.windowMs || now < current.startedAt) {
      if (current === undefined && this.windows.size >= this.maxKeys) {
        this.prune(now);
        // Still full of live windows: fail closed instead of growing the map without bound.
        if (this.windows.size >= this.maxKeys) {
          return false;
        }
      }
      this.windows.set(key, { startedAt: now, count: 1 });
      return true;
    }
    if (current.count >= this.limit) {
      return false;
    }
    current.count += 1;
    return true;
  }

  private prune(now: number): void {
    for (const [key, window] of this.windows) {
      if (now - window.startedAt >= this.windowMs) {
        this.windows.delete(key);
      }
    }
  }
}
