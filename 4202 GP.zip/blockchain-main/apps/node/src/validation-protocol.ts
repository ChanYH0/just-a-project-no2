// Messages between the main thread and validation-worker.ts (SPEC section 9). One job message in, one result message
// out. The job union is the extension point: each job kind extends JobSchema and OutcomeSchema (and the worker dispatch).

import { z } from "zod";
import {
  Block,
  ERROR_CODES,
  HexSha256,
  MUTATIONS,
  NonNegativeInt,
  PositiveInt,
  type ChainConfig,
} from "@conference-chain/shared";
import { SIMULATION_MAX_COUNT, SIMULATION_MAX_INTERVAL_MS } from "./limits.js";
import type { WorkerHandlers } from "./mine-protocol.js";

const ConfigSchema: z.ZodType<ChainConfig> = z
  .object({
    conferenceId: z.string(),
    initialDifficulty: z.number(),
    minDifficulty: z.number(),
    maxDifficulty: z.number(),
    targetBlockTimeMs: z.number(),
    adjustmentInterval: z.number(),
    maxRecordSkewMs: z.number(),
    mempoolTtlMs: z.number(),
    maxRecordAgeInBlockMs: z.number(),
    maxBlockSkewMs: z.number(),
  })
  .strict();

// Shared by the HTTP body of POST /demo/difficulty-simulation and the worker job (one definition of the bounds).
export const SimulationParams = z
  .object({
    count: PositiveInt.pipe(z.number().max(SIMULATION_MAX_COUNT)),
    intervalMs: NonNegativeInt.pipe(z.number().max(SIMULATION_MAX_INTERVAL_MS)),
  })
  .strict();

// HTTP body of POST /demo/tamper-check; the worker job reuses the same field schemas.
export const TamperParams = z.object({ mutation: z.enum(MUTATIONS), blockIndex: NonNegativeInt }).strict();

const ValidateSnapshotJob = z
  .object({
    kind: z.literal("validate-snapshot"),
    // The exact bytes of chain.jsonl up to the snapshot size, or the same text.
    snapshot: z.union([z.string(), z.instanceof(Uint8Array)]),
    config: ConfigSchema,
  })
  .strict();

const SimulateJob = z
  .object({
    kind: z.literal("simulate"),
    count: SimulationParams.shape.count,
    intervalMs: SimulationParams.shape.intervalMs,
    config: ConfigSchema,
  })
  .strict();

// A copy of the live chain (taken in memory by the route) plus the mutation to apply to it inside the worker.
const TamperJob = z
  .object({
    kind: z.literal("tamper"),
    mutation: TamperParams.shape.mutation,
    blockIndex: TamperParams.shape.blockIndex,
    blocks: z.array(Block),
    config: ConfigSchema,
  })
  .strict();

export const JobSchema = z.discriminatedUnion("kind", [ValidateSnapshotJob, SimulateJob, TamperJob]);
export type ValidationJob = z.infer<typeof JobSchema>;

export const JobMessageSchema = z.object({ jobId: z.number().int(), job: JobSchema }).strict();
export interface ValidationJobMessage {
  jobId: number;
  job: ValidationJob;
}

const ResultSchema = z.union([
  z.object({ ok: z.literal(true) }).strict(),
  z
    .object({
      ok: z.literal(false),
      code: z.enum(ERROR_CODES),
      blockIndex: NonNegativeInt.optional(),
    })
    .strict(),
]);
export type ValidationVerdict = z.infer<typeof ResultSchema>;

const ValidateSnapshotOutcome = z
  .object({
    kind: z.literal("validate-snapshot"),
    result: ResultSchema,
    // Parsed block count and head hash of the snapshot (0 and null when it could not be parsed).
    blockCount: NonNegativeInt,
    headHash: HexSha256.nullable(),
  })
  .strict();

const SimulateOutcome = z
  .object({
    kind: z.literal("simulate"),
    valid: z.boolean(),
    blocks: z.array(
      z
        .object({ index: NonNegativeInt, hash: HexSha256, difficulty: PositiveInt, timestamp: PositiveInt })
        .strict(),
    ),
    adjustments: z.array(
      z
        .object({
          atIndex: PositiveInt,
          actualMs: z.number().int(),
          expectedMs: z.number().int(),
          from: PositiveInt,
          to: PositiveInt,
        })
        .strict(),
    ),
  })
  .strict();

const TamperOutcome = z
  .object({
    kind: z.literal("tamper"),
    result: ResultSchema,
    note: z.string().min(1),
  })
  .strict();

export const OutcomeSchema = z.discriminatedUnion("kind", [ValidateSnapshotOutcome, SimulateOutcome, TamperOutcome]);
export type JobOutcome = z.infer<typeof OutcomeSchema>;
export type ValidateSnapshotOutcome = z.infer<typeof ValidateSnapshotOutcome>;
export type SimulateOutcome = z.infer<typeof SimulateOutcome>;
export type TamperOutcome = z.infer<typeof TamperOutcome>;

export const ResultMessageSchema = z.union([
  z.object({ jobId: z.number().int(), outcome: OutcomeSchema }).strict(),
  // A job that threw inside the worker. Fixed text only: no stack trace crosses the boundary.
  z.object({ jobId: z.number().int(), error: z.string() }).strict(),
]);
export type ValidationResultMessage = z.infer<typeof ResultMessageSchema>;

// What the manager needs from a validation worker. The real implementation wraps worker_threads; tests inject doubles.
export interface ValidationWorkerHandle {
  setHandlers(handlers: WorkerHandlers): void;
  postMessage(message: ValidationJobMessage): void;
  // Resolves once the worker thread is gone.
  terminate(): Promise<void>;
}

export type ValidationWorkerFactory = () => ValidationWorkerHandle;
