// Validation result caches (SPEC section 9). In memory, bounded (oldest evicted), cleared whenever the head changes.
// Keys contain validity-relevant inputs only; a missing component is a cache miss by construction.

import { canonicalize, nodeHash, PROTOCOL_VERSION, MAX_RECORDS_PER_BLOCK, type ChainConfig } from "@conference-chain/shared";
import { VALIDATION_CACHE_MAX_ENTRIES } from "./limits.js";

export class BoundedCache<V> {
  private readonly entries = new Map<string, V>();

  constructor(private readonly maxEntries: number = VALIDATION_CACHE_MAX_ENTRIES) {}

  get size(): number {
    return this.entries.size;
  }

  get(key: string): V | undefined {
    return this.entries.get(key);
  }

  // Re-setting an existing key refreshes its position; the oldest entry is evicted beyond the bound.
  set(key: string, value: V): void {
    this.entries.delete(key);
    this.entries.set(key, value);
    while (this.entries.size > this.maxEntries) {
      const oldest = this.entries.keys().next();
      if (oldest.done === true) {
        break;
      }
      this.entries.delete(oldest.value);
    }
  }

  clear(): void {
    this.entries.clear();
  }
}

// sha256Hex(canonicalize(consensus params)): the same consensus fields as chainId (skew and mempool settings are not
// validity-relevant and are excluded).
export function configHash(config: ChainConfig): string {
  return nodeHash(
    canonicalize({
      protocol: PROTOCOL_VERSION,
      initialDifficulty: config.initialDifficulty,
      minDifficulty: config.minDifficulty,
      maxDifficulty: config.maxDifficulty,
      targetBlockTimeMs: config.targetBlockTimeMs,
      adjustmentInterval: config.adjustmentInterval,
      maxRecordAgeInBlockMs: config.maxRecordAgeInBlockMs,
      maxRecordsPerBlock: MAX_RECORDS_PER_BLOCK,
    }),
  );
}

// /chain/validate key: chainId + configHash + sha256(snapshot bytes). The prefix keeps the key spaces of different
// cached operations (the tamper-check) disjoint.
export function validateCacheKey(chainId: string, config: ChainConfig, snapshot: Uint8Array): string {
  return ["validate", chainId, configHash(config), nodeHash(snapshot)].join(":");
}

// /demo/tamper-check key: chainId + configHash + headHash + mutation + blockIndex, under its own prefix so it can never
// equal a /chain/validate key. A missing component is refused here (the route then simply does not cache).
export function tamperCacheKey(
  chainId: string,
  config: ChainConfig,
  headHash: string,
  mutation: string,
  blockIndex: number,
): string {
  if (chainId === "" || headHash === "" || mutation === "") {
    throw new Error("tamper cache key component is missing");
  }
  return ["tamper", chainId, configHash(config), headHash, mutation, String(blockIndex)].join(":");
}
