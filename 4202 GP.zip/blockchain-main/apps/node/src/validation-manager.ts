// Validation worker manager (SPEC section 9): runs validation, simulation (and later tamper) jobs one at a time, each in
// a fresh worker, with a timeout enforced by terminate(). The worker factory and the timeout are injectable.

import { ChainError } from "@conference-chain/shared";
import { systemTimers, type Timers } from "./mine-protocol.js";
import { VALIDATION_QUEUE_MAX, VALIDATION_TIMEOUT_MS } from "./limits.js";
import {
  ResultMessageSchema,
  type JobOutcome,
  type ValidationJob,
  type ValidationWorkerFactory,
} from "./validation-protocol.js";

export interface ValidationManagerOptions {
  factory: ValidationWorkerFactory;
  timeoutMs?: number;
  timers?: Timers;
  queueMax?: number;
}

export class ValidationWorkerManager {
  private readonly timeoutMs: number;
  private readonly timers: Timers;
  private tail: Promise<unknown> = Promise.resolve();
  private nextJobId = 1;
  private pending = 0;
  private closed = false;
  private abortActive: (() => void) | null = null;

  constructor(private readonly options: ValidationManagerOptions) {
    this.timeoutMs = options.timeoutMs ?? VALIDATION_TIMEOUT_MS;
    this.timers = options.timers ?? systemTimers;
  }

  // Jobs queue behind the running one: at most one worker exists at any time.
  run(job: ValidationJob): Promise<JobOutcome> {
    if (this.closed) {
      return Promise.reject(new ChainError("INTERNAL", "validation worker is shut down"));
    }
    // One running job plus at most queueMax waiting; the rest is refused so a burst cannot grow the queue without bound.
    if (this.pending > (this.options.queueMax ?? VALIDATION_QUEUE_MAX)) {
      return Promise.reject(new ChainError("RATE_LIMITED", "validation queue is full"));
    }
    this.pending += 1;
    const result = this.tail.then(() => this.execute(job));
    const settled = (): void => {
      this.pending -= 1;
    };
    this.tail = result.then(settled, settled);
    return result;
  }

  // Terminates the running worker (its job fails) and refuses new jobs.
  async shutdown(): Promise<void> {
    this.closed = true;
    this.abortActive?.();
    await this.tail;
  }

  private execute(job: ValidationJob): Promise<JobOutcome> {
    return new Promise<JobOutcome>((resolve, reject) => {
      if (this.closed) {
        reject(new ChainError("INTERNAL", "validation worker is shut down"));
        return;
      }
      const jobId = this.nextJobId;
      this.nextJobId += 1;
      let worker: ReturnType<ValidationWorkerFactory>;
      try {
        worker = this.options.factory();
      } catch {
        reject(new ChainError("INTERNAL", "validation worker could not be started"));
        return;
      }

      let settled = false;
      let timer: unknown = null;
      const finish = (settle: () => void): void => {
        if (settled) {
          return;
        }
        settled = true;
        if (timer !== null) {
          this.timers.clearTimeout(timer);
        }
        this.abortActive = null;
        // The worker is always gone before the caller sees the result.
        worker.terminate().then(settle, settle);
      };
      const fail = (message: string): void => finish(() => reject(new ChainError("INTERNAL", message)));

      this.abortActive = () => fail("validation job aborted");
      worker.setHandlers({
        onMessage: (raw) => {
          const parsed = ResultMessageSchema.safeParse(raw);
          if (!parsed.success) {
            fail("validation worker sent a malformed message");
            return;
          }
          if (parsed.data.jobId !== jobId) {
            return;
          }
          if ("error" in parsed.data) {
            fail("validation job failed");
            return;
          }
          const outcome = parsed.data.outcome;
          if (outcome.kind !== job.kind) {
            fail("validation worker answered a different job kind");
            return;
          }
          finish(() => resolve(outcome));
        },
        // Worker exceptions can contain payloads; log only the protocol code and job id.
        onError: () => {
          if (!settled) {
            console.error({ code: "INTERNAL", jobId });
          }
          fail("validation worker failed");
        },
        onExit: () => {
          fail("validation worker exited without a result");
        },
      });
      timer = this.timers.setTimeout(() => {
        timer = null;
        fail("validation job timed out");
      }, this.timeoutMs);
      try {
        worker.postMessage({ jobId, job });
      } catch {
        fail("validation worker rejected the job");
      }
    });
  }
}
