// Produces exact byte sections for a native SHA-256 nonce search. The helper
// hashes prefix + ASCII nonce + suffix, matching computeBlockHash's canonical JSON.

import { Block, canonicalize, ChainError, type BlockCandidate } from "@conference-chain/shared";

const NONCE_MARKER = '"nonce":0,"previousHash":';
const NONCE_KEY_LENGTH = '"nonce":'.length;
const NONCE_VALUE_LENGTH = "0".length;

export interface MetalTemplate {
  prefix: Buffer;
  suffix: Buffer;
}

export function makeMetalTemplate(candidate: BlockCandidate): MetalTemplate {
  const parsed = Block.omit({ hash: true, nonce: true }).safeParse(candidate);
  if (!parsed.success) {
    throw new ChainError("INVALID_SCHEMA", "Metal candidate failed block structural validation");
  }

  const serialized = canonicalize({ ...parsed.data, nonce: 0 });
  const marker = serialized.indexOf(NONCE_MARKER);
  if (marker < 0 || serialized.indexOf(NONCE_MARKER, marker + NONCE_MARKER.length) >= 0) {
    throw new ChainError("INTERNAL", "canonical candidate has no unique nonce position");
  }

  const prefixEnd = marker + NONCE_KEY_LENGTH;
  const suffixStart = marker + NONCE_KEY_LENGTH + NONCE_VALUE_LENGTH;
  return {
    prefix: Buffer.from(serialized.slice(0, prefixEnd), "utf8"),
    suffix: Buffer.from(serialized.slice(suffixStart), "utf8"),
  };
}
