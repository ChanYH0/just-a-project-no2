// OpenAPI 3.1 documentation for the HTTP interface (SPEC section 10).
// The request bodies start from the shared Zod schemas so documentation follows the protocol owner.

import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import {
  Alias,
  ALIAS_MAX_CODE_POINTS,
  AttendancePayload,
  Block,
  ChainRecord,
  CONFERENCE_ID_PATTERN,
  ERROR_CODES,
  MAX_RECORDS_PER_BLOCK,
  HexSha256,
  MINER_STATES,
  NonNegativeInt,
  PositiveInt,
  PROTOCOL_VERSION,
  PROFILE_NAMES,
  PublicKey,
  RSA_MODULUS_BITS,
  RSA_SPKI_DER_LENGTH,
  SessionId,
  Signature,
  SignedAttendance,
  SignedRegistration,
  Timestamp,
} from "@conference-chain/shared";
import { SIMULATION_MAX_COUNT, SIMULATION_MAX_INTERVAL_MS, BLOCKS_MAX_LIMIT } from "./limits.js";

const require = createRequire(import.meta.url);
const ASSETS = {
  "swagger-ui-bundle.js": "swagger-ui-dist/swagger-ui-bundle.js",
  "swagger-ui.css": "swagger-ui-dist/swagger-ui.css",
} as const;
type Asset = keyof typeof ASSETS;

type JsonObject = Record<string, unknown>;

function asObject(value: unknown): JsonObject {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new TypeError("OpenAPI schema is not an object");
  }
  return value as JsonObject;
}

function asRecord(value: unknown, label: string): JsonObject {
  const result = asObject(value);
  if (!Object.hasOwn(result, label)) {
    throw new TypeError(`OpenAPI schema has no ${label}`);
  }
  return asObject(result[label]);
}

function jsonSchema(schema: z.ZodType): JsonObject {
  const { $schema: _dialect, ...converted } = z.toJSONSchema(schema);
  return converted;
}

function safeInteger(schema: JsonObject, minimum: number, description: string): JsonObject {
  return {
    ...schema,
    type: "integer",
    minimum,
    maximum: Number.MAX_SAFE_INTEGER,
    description,
    "x-runtime-rejects-negative-zero": true,
  };
}

function decorateSignedRecord(schema: JsonObject): void {
  const properties = asRecord(schema, "properties");
  const payload = asRecord(properties["payload"], "properties");
  if (Object.hasOwn(payload, "alias")) payload["alias"] = { $ref: "#/components/schemas/Alias" };
  if (Object.hasOwn(payload, "publicKey")) payload["publicKey"] = { $ref: "#/components/schemas/PublicKey" };
  if (Object.hasOwn(payload, "sessionId")) payload["sessionId"] = { $ref: "#/components/schemas/SessionId" };
  payload["timestamp"] = { $ref: "#/components/schemas/Timestamp" };
  properties["signature"] = { $ref: "#/components/schemas/Signature" };
}

function decorateSchemas(): JsonObject {
  const publicKeyLength = 4 * Math.ceil(RSA_SPKI_DER_LENGTH / 3);
  const signatureBytes = RSA_MODULUS_BITS / 8;
  const signatureLength = 4 * Math.ceil(signatureBytes / 3);
  const schemas: JsonObject = {
    SignedRegistration: jsonSchema(SignedRegistration),
    SignedAttendance: jsonSchema(SignedAttendance),
    ChainRecord: jsonSchema(ChainRecord),
    AttendancePayload: jsonSchema(AttendancePayload),
    Block: jsonSchema(Block),
    Alias: {
      ...jsonSchema(Alias),
      description: `Pseudonymous display label: 1–${ALIAS_MAX_CODE_POINTS} Unicode code points, NFC, with no surrounding whitespace, controls, invisible format characters, line separators, unassigned code points, or private-use characters.`,
      "x-runtime-constraints": ["count Unicode code points, not UTF-16 code units", "NFC normalization must already be applied", "Unicode category C, Zl and Zp are rejected"],
    },
    PublicKey: {
      ...jsonSchema(PublicKey),
      contentEncoding: "base64",
      description: `Canonical standard base64 encoding of the ${RSA_SPKI_DER_LENGTH}-byte RSA-${RSA_MODULUS_BITS} SPKI DER public key. RSA parameters are checked semantically after structural validation.`,
      minLength: publicKeyLength,
      maxLength: publicKeyLength,
    },
    Signature: {
      ...jsonSchema(Signature),
      contentEncoding: "base64",
      description: `Canonical standard base64 encoding of a ${signatureBytes}-byte RSASSA-PKCS1-v1_5 SHA-256 signature.`,
      minLength: signatureLength,
      maxLength: signatureLength,
    },
    SessionId: { ...jsonSchema(SessionId), description: "1–64 ASCII letters, digits, underscore, or hyphen." },
    HexSha256: { ...jsonSchema(HexSha256), description: "64 lowercase hexadecimal SHA-256 characters." },
    Timestamp: safeInteger(jsonSchema(Timestamp), 1, "Positive safe integer milliseconds since Unix epoch; negative zero is rejected."),
    NonNegativeInt: safeInteger(jsonSchema(NonNegativeInt), 0, "Non-negative safe integer; negative zero is rejected."),
    PositiveInt: safeInteger(jsonSchema(PositiveInt), 1, "Positive safe integer; negative zero is rejected."),
    ErrorCode: { type: "string", enum: [...ERROR_CODES] },
    ErrorResponse: {
      type: "object",
      required: ["error"],
      additionalProperties: false,
      properties: {
        error: {
          type: "object",
          required: ["code", "message"],
          additionalProperties: false,
          properties: { code: { $ref: "#/components/schemas/ErrorCode" }, message: { type: "string" } },
        },
      },
    },
  };

  decorateSignedRecord(asObject(schemas.SignedRegistration));
  decorateSignedRecord(asObject(schemas.SignedAttendance));
  const chainRecord = asObject(schemas.ChainRecord);
  if (!Array.isArray(chainRecord["anyOf"])) throw new TypeError("ChainRecord schema has no variants");
  for (const variant of chainRecord["anyOf"]) decorateSignedRecord(asObject(variant));

  const block = asRecord(schemas.Block, "properties");
  block["index"] = { $ref: "#/components/schemas/NonNegativeInt" };
  block["nonce"] = { $ref: "#/components/schemas/NonNegativeInt" };
  block["timestamp"] = { $ref: "#/components/schemas/Timestamp" };
  block["previousHash"] = { $ref: "#/components/schemas/HexSha256" };
  block["hash"] = { $ref: "#/components/schemas/HexSha256" };
  block["difficulty"] = { $ref: "#/components/schemas/PositiveInt" };
  const verification: JsonObject = {
    type: "object",
    required: ["hashValid", "powValid"],
    additionalProperties: false,
    properties: { hashValid: { type: "boolean" }, powValid: { type: "boolean" } },
  };
  const recordArray = asRecord(block["records"], "items");
  if (!Array.isArray(recordArray["anyOf"])) throw new TypeError("Block records schema has no variants");
  for (const variant of recordArray["anyOf"]) decorateSignedRecord(asObject(variant));

  const blockView = structuredClone(asObject(schemas.Block));
  const viewRequired = blockView["required"];
  if (!Array.isArray(viewRequired)) throw new TypeError("Block view schema has no required fields");
  blockView["required"] = [...viewRequired, "verification"];
  asRecord(blockView, "properties")["verification"] = verification;
  schemas["BlockView"] = blockView;

  return schemas;
}

const schemas = decorateSchemas();
const ref = (name: string): JsonObject => ({ $ref: `#/components/schemas/${name}` });
const jsonResponse = (description: string, schema: JsonObject): JsonObject => ({
  description,
  content: { "application/json": { schema } },
});
const errorResponses = (...statuses: number[]): JsonObject => Object.fromEntries(
  statuses.map((status) => [String(status), jsonResponse("Request failed. See the error code for the reason.", ref("ErrorResponse"))]),
);
const queryOrPathParam = (name: string, schema: JsonObject, location: "path" | "query" = "path", required = true): JsonObject => ({
  name,
  in: location,
  required,
  schema,
});
const requestBody = (schema: JsonObject): JsonObject => ({
  required: true,
  content: { "application/json": { schema } },
});

const decimalCursor: JsonObject = {
  type: "string",
  pattern: "^(0|[1-9][0-9]*)$",
  maxLength: 16,
  description: "Decimal safe integer block index; the next page starts before this block.",
};
const nonNegativeIntString: JsonObject = {
  type: "string",
  pattern: "^(0|[1-9][0-9]*)$",
  maxLength: 16,
  description: "Decimal non-negative safe integer; negative zero and leading zeroes are rejected.",
};

function operation(
  tag: string,
  summary: string,
  responses: JsonObject,
  extra: JsonObject = {},
): JsonObject {
  return { tags: [tag], summary, responses, ...extra };
}

export function openApiDocument(enableDemoRoutes: boolean): JsonObject {
  const paths: JsonObject = {
    "/chain/info": { get: operation("System", "Read deployment identity", {
      ...errorResponses(400),
      "200": jsonResponse("Protocol and deployment identity.", { type: "object", required: ["chainId", "conferenceId", "profile", "protocol"], additionalProperties: false, properties: {
        chainId: ref("HexSha256"), conferenceId: { type: "string", pattern: CONFERENCE_ID_PATTERN.source }, profile: { type: "string", enum: [...PROFILE_NAMES] }, protocol: { type: "string", const: PROTOCOL_VERSION },
      } }),
    }) },
    "/health": { get: operation("System", "Read miner and chain health", {
      ...errorResponses(400),
      "200": jsonResponse("Node health; ok is false only when the miner is fatal.", { type: "object", required: ["ok", "miner", "headIndex", "profile"], additionalProperties: false, properties: {
        ok: { type: "boolean" }, miner: { type: "string", enum: [...MINER_STATES] }, headIndex: ref("NonNegativeInt"), profile: { type: "string", enum: ["production", "demo", "test"] },
      } }),
    }) },
    "/sessions": { get: operation("Queries", "List current check-in sessions", {
      "200": jsonResponse("Admission session catalog.", { type: "array", items: { type: "object", required: ["id", "title"], additionalProperties: false, properties: { id: ref("SessionId"), title: { type: "string" } } } }),
      ...errorResponses(400),
    }) },
    "/registrations": { post: operation("Records", "Submit a signed registration for mining", {
      "202": jsonResponse("Record accepted into the pending pool; this does not mean it is confirmed.", { type: "object", required: ["recordId"], additionalProperties: false, properties: { recordId: ref("HexSha256") } }),
      ...errorResponses(400, 409, 413, 429, 500, 503),
    }, { requestBody: requestBody(ref("SignedRegistration")), description: "A successful response is admission only. Poll the record endpoint until it is confirmed." }) },
    "/attendance": { post: operation("Records", "Submit a signed session attendance record for mining", {
      "202": jsonResponse("Record accepted into the pending pool; this does not mean it is confirmed.", { type: "object", required: ["recordId"], additionalProperties: false, properties: { recordId: ref("HexSha256") } }),
      ...errorResponses(400, 409, 413, 429, 500, 503),
    }, { requestBody: requestBody(ref("SignedAttendance")) }) },
    "/records/{recordId}": { get: operation("Records", "Read record status", {
      "200": jsonResponse("reserved is reported as pending.", { oneOf: [
        { type: "object", required: ["status"], additionalProperties: false, properties: { status: { const: "pending" } } },
        { type: "object", required: ["status", "blockIndex"], additionalProperties: false, properties: { status: { const: "confirmed" }, blockIndex: ref("NonNegativeInt") } },
        { type: "object", required: ["status"], additionalProperties: false, properties: { status: { const: "expired" } } },
        { type: "object", required: ["status", "code"], additionalProperties: false, properties: { status: { const: "rejected" }, code: ref("ErrorCode") } },
      ] }),
      ...errorResponses(400, 404),
    }, { parameters: [queryOrPathParam("recordId", ref("HexSha256"))] }) },
    "/mempool": { get: operation("Mining", "Read pending records in admission order", {
      "200": jsonResponse("At most the oldest 100 pending records.", { type: "array", maxItems: 100, items: ref("ChainRecord") }),
      ...errorResponses(400),
    }) },
    "/blocks": { get: operation("Chain", "List newest blocks first", {
      "200": jsonResponse("Block page and cursor to the next older page.", { type: "object", required: ["blocks", "nextCursor"], additionalProperties: false, properties: {
        blocks: { type: "array", items: ref("Block") }, nextCursor: { oneOf: [{ type: "string", pattern: "^(0|[1-9][0-9]*)$" }, { type: "null" }] },
      } }),
      ...errorResponses(400),
    }, { parameters: [
      queryOrPathParam("limit", { type: "integer", minimum: 1, maximum: BLOCKS_MAX_LIMIT, default: 20 }, "query", false),
      queryOrPathParam("cursor", decimalCursor, "query", false),
    ] }) },
    "/blocks/{index}": { get: operation("Chain", "Read block and node-computed verification flags", {
      "200": jsonResponse("Block fields and the node's hash and proof-of-work verification results.", ref("BlockView")),
      ...errorResponses(400, 404),
    }, { parameters: [queryOrPathParam("index", nonNegativeIntString)] }) },
    "/attendees/{attendeeId}": { get: operation("Queries", "Read registration profile", {
      "200": jsonResponse("Pseudonymous registration profile.", { type: "object", required: ["attendeeId", "alias", "registeredAt", "blockIndex"], additionalProperties: false, properties: { attendeeId: ref("HexSha256"), alias: ref("Alias"), registeredAt: ref("Timestamp"), blockIndex: ref("NonNegativeInt") } }),
      ...errorResponses(400, 404),
    }, { parameters: [queryOrPathParam("attendeeId", ref("HexSha256"))] }) },
    "/attendees/{attendeeId}/sessions": { get: operation("Queries", "Q1: list sessions attended by an attendee", {
      "200": jsonResponse("Attendance records grouped under an attendee.", { type: "object", required: ["attendeeId", "sessions"], additionalProperties: false, properties: { attendeeId: ref("HexSha256"), sessions: { type: "array", items: { type: "object", required: ["sessionId", "timestamp", "blockIndex"], additionalProperties: false, properties: { sessionId: ref("SessionId"), timestamp: ref("Timestamp"), blockIndex: ref("NonNegativeInt") } } } } }),
      ...errorResponses(400, 404),
    }, { parameters: [queryOrPathParam("attendeeId", ref("HexSha256"))] }) },
    "/sessions/{sessionId}/attendees": { get: operation("Queries", "Q2: list attendees for a session", {
      "200": jsonResponse("Pseudonymous attendees and their confirmed check-in records.", { type: "object", required: ["sessionId", "attendees"], additionalProperties: false, properties: { sessionId: ref("SessionId"), attendees: { type: "array", items: { type: "object", required: ["attendeeId", "alias", "timestamp", "blockIndex"], additionalProperties: false, properties: { attendeeId: ref("HexSha256"), alias: ref("Alias"), timestamp: ref("Timestamp"), blockIndex: ref("NonNegativeInt") } } } } }),
      ...errorResponses(400, 404),
    }, { parameters: [queryOrPathParam("sessionId", ref("SessionId"))] }) },
    "/chain/validate": { get: operation("Validation", "Validate a consistent snapshot of the stored chain", {
      "200": jsonResponse("Result. An ok response has no error fields.", { oneOf: [
        { type: "object", required: ["ok"], additionalProperties: false, properties: { ok: { const: true } } },
        { type: "object", required: ["ok", "code"], additionalProperties: false, properties: { ok: { const: false }, code: ref("ErrorCode"), blockIndex: ref("NonNegativeInt") } },
      ] }),
      ...errorResponses(429, 500),
    }, { description: "Validates the disk snapshot captured at request start. Demo routes are separate from this live-chain check." }) },
  };

  if (enableDemoRoutes) {
    paths["/demo/tamper-check"] = { post: operation("Demo", "Run a real validator against a mutated chain copy", {
      "200": jsonResponse("Validator result for the temporary chain copy; the live chain is unchanged.", { type: "object", required: ["ok", "note"], additionalProperties: false, properties: { ok: { type: "boolean" }, code: ref("ErrorCode"), blockIndex: ref("NonNegativeInt"), note: { type: "string", minLength: 1 } } }),
      ...errorResponses(400, 404, 429, 500),
    }, { requestBody: requestBody({ type: "object", required: ["mutation", "blockIndex"], additionalProperties: false, properties: { mutation: { type: "string", enum: ["edit-record", "edit-previous-hash", "rehash-after-edit", "lower-difficulty", "delete-record-and-remine"] }, blockIndex: ref("NonNegativeInt") } }) }) };
    paths["/demo/difficulty-simulation"] = { post: operation("Demo", "Simulate dynamic difficulty on an isolated in-memory chain", {
      "200": jsonResponse("Synthetic simulation. It does not mine live blocks or change the live chain.", { type: "object", required: ["valid", "blocks", "adjustments"], additionalProperties: false, properties: {
        valid: { type: "boolean" }, blocks: { type: "array", items: { type: "object", required: ["index", "hash", "difficulty", "timestamp"], additionalProperties: false, properties: { index: ref("NonNegativeInt"), hash: ref("HexSha256"), difficulty: ref("PositiveInt"), timestamp: ref("Timestamp") } } },
        adjustments: { type: "array", items: { type: "object", required: ["atIndex", "actualMs", "expectedMs", "from", "to"], additionalProperties: false, properties: { atIndex: ref("PositiveInt"), actualMs: ref("NonNegativeInt"), expectedMs: ref("PositiveInt"), from: ref("PositiveInt"), to: ref("PositiveInt") } } },
      } }),
      ...errorResponses(400, 429, 500),
    }, { requestBody: requestBody({ type: "object", required: ["count", "intervalMs"], additionalProperties: false, properties: {
      count: { ...ref("PositiveInt"), maximum: SIMULATION_MAX_COUNT }, intervalMs: { ...ref("NonNegativeInt"), maximum: SIMULATION_MAX_INTERVAL_MS },
    } }) }) };
  }

  return {
    openapi: "3.1.0",
    info: {
      title: "Conference Chain API",
      version: PROTOCOL_VERSION,
      description: "HTTP API for signed registration, attendance, proof-of-work blocks, public queries, and validation. Attendee IDs and aliases are pseudonymous and linkable. The explorer trusts node verification flags and is not a light client. Successful write responses mean admitted to the pending pool; poll the record until confirmed.",
    },
    // Relative URLs work from either /openapi.json on Node or /api/openapi.json behind the same-origin proxy.
    servers: [{ url: ".", description: "Current node origin (directly or through the same-origin /api proxy)." }],
    tags: [
      { name: "System", description: "Node identity and health." },
      { name: "Records", description: "Signed records and their pending/confirmed state." },
      { name: "Mining", description: "Pending records waiting for a proof-of-work worker." },
      { name: "Chain", description: "Mined blocks and disk-backed validation." },
      { name: "Queries", description: "Public pseudonymous registration and attendance queries." },
      { name: "Validation", description: "Validation results for the stored chain snapshot." },
      ...(enableDemoRoutes ? [{ name: "Demo", description: "Optional demo-only endpoints. The difficulty simulation is isolated from the live chain." }] : []),
    ],
    paths,
    components: { schemas },
  };
}

function docsHtml(): string {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Conference Chain API</title><link rel="stylesheet" href="./docs/swagger-ui.css"><script defer src="./docs/swagger-ui-bundle.js"></script><script defer src="./docs/init.js"></script></head>
<body><main id="swagger-ui" aria-label="Conference Chain API reference"></main></body></html>`;
}

const DOCS_CSP = [
  "default-src 'none'",
  "base-uri 'none'",
  "frame-ancestors 'none'",
  "form-action 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  "font-src 'self' data:",
  "connect-src 'self'",
].join("; ");

export interface ApiDocsOptions {
  enableDemoRoutes: boolean;
}

/** Register the OpenAPI JSON and same-origin Swagger UI assets. No network CDN is used. */
export function registerApiDocs(app: FastifyInstance, options: ApiDocsOptions): void {
  const document = openApiDocument(options.enableDemoRoutes);
  app.get("/openapi.json", async (_request, reply) => reply
    .header("cache-control", "no-cache")
    .header("x-content-type-options", "nosniff")
    .send(document));

  app.get("/docs", async (_request, reply) => reply
    .type("text/html; charset=utf-8")
    .header("content-security-policy", DOCS_CSP)
    .header("cache-control", "no-cache")
    .header("x-content-type-options", "nosniff")
    .header("referrer-policy", "no-referrer")
    .send(docsHtml()));
  // Relative Location preserves an optional reverse-proxy prefix such as /api.
  app.get("/docs/", async (_request, reply) => reply.redirect("../docs", 308));

  app.get("/docs/init.js", async (_request, reply) => reply
    .type("application/javascript; charset=utf-8")
    .header("cache-control", "no-cache")
    .header("x-content-type-options", "nosniff")
    .send(`"use strict";
window.addEventListener("DOMContentLoaded", function () {
  SwaggerUIBundle({ url: "./openapi.json", dom_id: "#swagger-ui", deepLinking: true, displayRequestDuration: true, validatorUrl: null });
});`));

  for (const [asset, packagePath] of Object.entries(ASSETS) as [Asset, string][]) {
    const path = require.resolve(packagePath);
    const route = asset === "swagger-ui-bundle.js" ? "/docs/swagger-ui-bundle.js" : "/docs/swagger-ui.css";
    app.get(route, async (_request, reply) => {
      const content = await readFile(path);
      return reply.type(asset.endsWith(".js") ? "application/javascript; charset=utf-8" : "text/css; charset=utf-8")
        .header("cache-control", "public, max-age=86400").header("x-content-type-options", "nosniff").send(content);
    });
  }
}
