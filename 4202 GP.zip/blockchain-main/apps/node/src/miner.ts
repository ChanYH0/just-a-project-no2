// Miner and record lifecycle (SPEC section 9). One class owns the mempool, the mining job, the persist step and the
// MinerState machine, because the lifecycle transitions interlock:
//
//   admit          none -> pending                         (step 1)
//   candidate      pending -> reserved | expired | rejected (steps 2, 7)
//   job result     classify, validate, persist             (steps 3, 4)
//   cancel/crash   reserved -> pending                     (step 5)
//   re-validation  reserved -> pending | rejected          (step 6)
//
// Every transition on the mempool is a synchronous call; async work (crypto, file I/O) happens between them.
// Admission and block append share one writer lock.

import {
  Block,
  MAX_RECORDS_PER_BLOCK,
  MEMPOOL_MAX_RECORDS,
  MINER_BATCH_DELAY_MS,
  ChainError,
  addRecordToUniquenessIndex,
  canonicalize,
  emptyUniquenessIndex,
  nextDifficulty,
  recordId,
  validateBlockAdmission,
  validateRecordAtSubmission,
  validateRecordInBlock,
  type BlockCandidate,
  type BlockScope,
  type ChainConfig,
  type ChainCrypto,
  type ChainRecord,
  type Clock,
  type ErrorCode,
  type MinerState,
} from "@conference-chain/shared";
import { BACKOFF_INITIAL_MS, BACKOFF_MAX_MS, TERMINAL_LRU_LIMIT } from "./limits.js";
import type { Ledger } from "./ledger.js";
import { Mempool } from "./mempool.js";
import { isRecord, type MineWorkerHandle, type Timers, type WorkerFactory } from "./mine-protocol.js";
import { Mutex } from "./mutex.js";
import type { ChainStore } from "./store.js";

// A persist rollback failure leaves the file in an unknown state relative to memory.
const FATAL_PERSIST_CODE: ErrorCode = "CHAIN_STORE_MISMATCH";

export interface MinerOptions {
  config: ChainConfig;
  crypto: ChainCrypto;
  clock: Clock;
  store: ChainStore;
  ledger: Ledger;
  // Admission catalog (sessions.json). Not consensus.
  catalog: ReadonlySet<string>;
  workerFactory: WorkerFactory;
  timers: Timers;
  mempoolMax?: number;
  terminalLimit?: number;
  // Called once when the miner becomes fatal (the process exits non-zero after logging the code).
  onFatal?: (code: ErrorCode) => void;
}

export type RecordStatus =
  | { status: "pending" }
  | { status: "confirmed"; blockIndex: number }
  | { status: "expired" }
  | { status: "rejected"; code: ErrorCode };

interface Job {
  jobId: number;
  parentHash: string;
  parentIndex: number;
  // ids of the records of the candidate, in order (the reserved snapshot)
  snapshotIds: string[];
  // the subset of snapshotIds that are mempool records reserved for this job
  reservedIds: string[];
  worker: MineWorkerHandle;
  // set when the worker was terminated by us or has delivered its result: later worker events are ignored
  detached: boolean;
  resultReceived: boolean;
  terminated: Promise<void> | null;
}

function sameIds(a: readonly string[], b: readonly string[]): boolean {
  return a.length === b.length && a.every((value, position) => value === b[position]);
}

export class Miner {
  readonly mempool: Mempool;
  readonly ledger: Ledger;
  // Last unexpected (non-protocol) failure, kept for diagnosis. Never exposed through HTTP.
  lastFailure: unknown = null;
  fatalCode: ErrorCode | null = null;

  private readonly writer = new Mutex();
  private readonly mempoolMax: number;
  private currentState: MinerState = "idle";
  private job: Job | null = null;
  private building: Promise<void> | null = null;
  private critical: Promise<void> | null = null;
  private batchTimer: unknown = null;
  private backoffTimer: unknown = null;
  private backoffMs = BACKOFF_INITIAL_MS;
  private nextJobId = 1;
  private closing = false;
  private appended = 0;
  private waiters: (() => void)[] = [];
  private readonly bootBlockCount: number;

  constructor(private readonly options: MinerOptions) {
    this.ledger = options.ledger;
    this.mempool = new Mempool(options.terminalLimit ?? TERMINAL_LRU_LIMIT, options.config.mempoolTtlMs);
    this.mempoolMax = options.mempoolMax ?? MEMPOOL_MAX_RECORDS;
    this.bootBlockCount = options.ledger.blocks.length;
  }

  get state(): MinerState {
    return this.currentState;
  }

  get currentJobId(): number | null {
    return this.job?.jobId ?? null;
  }

  // ---- step 1: admission -------------------------------------------------------------------------------------

  // Returns the recordId. Throws ChainError with the protocol code on rejection.
  async admit(record: ChainRecord): Promise<string> {
    this.requireWritable();
    this.mempool.sweep(this.options.clock.now());
    this.requireCapacity();

    // Async integrity + state rules run BEFORE the writer lock (SPEC section 7).
    const checked = await validateRecordAtSubmission(
      record,
      this.ledger.state,
      this.mempool.index,
      this.options.catalog,
      this.options.config,
      this.options.clock,
      this.options.crypto,
    );
    if (!checked.ok) {
      throw new ChainError(checked.code, `record rejected: ${checked.code}`);
    }

    return this.writer.run(async () => {
      // Synchronous section: the uniqueness rules are re-checked right before the insert, so two concurrent
      // identical submissions cannot both pass.
      this.requireWritable();
      const now = this.options.clock.now();
      this.mempool.sweep(now);
      this.requireCapacity();
      const violation = this.mempool.uniquenessViolation(record, this.ledger.state);
      if (violation !== null) {
        throw new ChainError(violation, `record rejected: ${violation}`);
      }
      const id = recordId(record, this.options.crypto.hash);
      this.mempool.admit(id, record, now);
      this.maybeSchedule();
      return id;
    });
  }

  private requireWritable(): void {
    if (this.currentState === "fatal" || this.closing) {
      throw new ChainError("MINER_UNAVAILABLE", "the miner is not available");
    }
  }

  private requireCapacity(): void {
    if (this.mempool.size >= this.mempoolMax) {
      throw new ChainError("MEMPOOL_FULL", "the mempool is full");
    }
  }

  // ---- queries -----------------------------------------------------------------------------------------------

  // `reserved` is reported as `pending`. Null for an unknown id.
  recordStatus(id: string): RecordStatus | null {
    this.mempool.sweep(this.options.clock.now());
    const blockIndex = this.ledger.confirmedBlockIndex(id);
    if (blockIndex !== undefined) {
      return { status: "confirmed", blockIndex };
    }
    if (this.mempool.getLive(id) !== undefined) {
      return { status: "pending" };
    }
    const terminal = this.mempool.getTerminal(id);
    if (terminal === undefined) {
      return null;
    }
    return terminal.status === "rejected" && terminal.code !== undefined
      ? { status: "rejected", code: terminal.code }
      : { status: "expired" };
  }

  mempoolRecords(max: number): ChainRecord[] {
    this.mempool.sweep(this.options.clock.now());
    return this.mempool
      .liveEntries()
      .slice(0, max)
      .map((entry) => entry.record);
  }

  // ---- scheduling --------------------------------------------------------------------------------------------

  private maybeSchedule(): void {
    if (
      this.closing ||
      this.currentState !== "idle" ||
      this.batchTimer !== null ||
      this.building !== null ||
      this.job !== null ||
      this.critical !== null ||
      this.mempool.pendingCount() === 0
    ) {
      return;
    }
    this.batchTimer = this.options.timers.setTimeout(() => {
      this.batchTimer = null;
      this.runBuild();
    }, MINER_BATCH_DELAY_MS);
  }

  private runBuild(): void {
    if (this.closing || this.currentState !== "idle" || this.building !== null || this.job !== null) {
      return;
    }
    const build = this.buildAndLaunch()
      .catch((error: unknown) => this.failUnexpected(error))
      .finally(() => {
        if (this.building === build) {
          this.building = null;
        }
        this.touch();
        this.maybeSchedule();
      });
    this.building = build;
  }

  // Steps 2 and 7: candidate build under the writer lock, then launch the worker.
  private async buildAndLaunch(): Promise<void> {
    await this.writer.run(async () => {
      if (this.closing || this.currentState !== "idle") {
        return;
      }
      const { config, crypto, clock } = this.options;
      this.mempool.sweep(clock.now());
      const head = this.ledger.head;
      const timestamp = Math.max(head.timestamp, clock.now());
      const index = head.index + 1;
      const jobId = this.nextJobId;
      const scope: BlockScope = { state: this.ledger.state, pending: emptyUniquenessIndex() };
      const records: ChainRecord[] = [];
      const ids: string[] = [];

      for (const entry of this.mempool.pendingEntries()) {
        if (records.length >= MAX_RECORDS_PER_BLOCK) {
          break;
        }
        // pendingEntries() is a snapshot. A prior async validation may have
        // allowed this entry to expire or be replaced before we reach it.
        if (this.mempool.getLive(entry.id) !== entry || entry.status !== "pending") {
          continue;
        }
        if (Math.abs(timestamp - entry.record.payload.timestamp) > config.maxRecordAgeInBlockMs) {
          // An honest record that waited too long: expired, not rejected.
          this.mempool.expire(entry.id);
          continue;
        }
        const result = await validateRecordInBlock(entry.record, { index, timestamp }, scope, config, crypto);

        // Validation is asynchronous, so a pending entry may have expired (or been
        // replaced by a new admission epoch with the same record id) while the
        // integrity check was running. Re-sweep and require the exact LiveEntry
        // captured before the await before applying the result. This keeps a stale
        // validation result from reserving or rejecting a different epoch, and
        // avoids turning an ordinary TTL expiry into a fatal miner failure.
        this.mempool.sweep(clock.now());
        const current = this.mempool.getLive(entry.id);
        if (current !== entry || current.status !== "pending") {
          continue;
        }
        if (!result.ok) {
          this.mempool.reject(entry.id, result.code);
          continue;
        }
        addRecordToUniquenessIndex(scope.pending, entry.record);
        this.mempool.reserve(entry.id, jobId);
        records.push(entry.record);
        ids.push(entry.id);
      }

      if (records.length === 0) {
        return;
      }
      if (this.closing || this.currentState !== "idle") {
        this.mempool.releaseJob(jobId);
        return;
      }
      this.nextJobId += 1;
      const candidate: BlockCandidate = {
        index,
        timestamp,
        previousHash: head.hash,
        difficulty: nextDifficulty(this.ledger.blocks, config),
        records,
      };
      this.launch(jobId, candidate, ids, ids);
    });
  }

  // Test hook (SPEC section 9): starts a job for a given candidate. Production code builds candidates from the mempool.
  // Pending mempool records that appear in the candidate are reserved for the job.
  startJob(candidate: BlockCandidate): number {
    if (
      this.currentState !== "idle" ||
      this.job !== null ||
      this.building !== null ||
      this.critical !== null ||
      this.closing
    ) {
      throw new ChainError("INTERNAL", "startJob requires an idle miner");
    }
    const jobId = this.nextJobId;
    this.nextJobId += 1;
    const snapshotIds = candidate.records.map((record) => recordId(record, this.options.crypto.hash));
    const reservedIds: string[] = [];
    for (const id of snapshotIds) {
      if (this.mempool.getLive(id)?.status === "pending") {
        this.mempool.reserve(id, jobId);
        reservedIds.push(id);
      }
    }
    this.launch(jobId, candidate, snapshotIds, reservedIds);
    return jobId;
  }

  private launch(jobId: number, candidate: BlockCandidate, snapshotIds: string[], reservedIds: string[]): void {
    let worker: MineWorkerHandle;
    try {
      worker = this.options.workerFactory();
    } catch {
      // The worker could not be started: same as a crash. No record is lost.
      this.mempool.releaseJob(jobId);
      this.enterBackoff("restarting");
      return;
    }
    const job: Job = {
      jobId,
      parentHash: candidate.previousHash,
      parentIndex: candidate.index - 1,
      snapshotIds,
      reservedIds,
      worker,
      detached: false,
      resultReceived: false,
      terminated: null,
    };
    this.job = job;
    this.setState("mining");
    worker.setHandlers({
      onMessage: (message) => {
        this.onMessage(message).catch((error: unknown) => this.failUnexpected(error));
      },
      onError: () => {
        this.onWorkerGone(job).catch((error: unknown) => this.failUnexpected(error));
      },
      onExit: () => {
        this.onWorkerGone(job).catch((error: unknown) => this.failUnexpected(error));
      },
    });
    try {
      worker.postMessage({ jobId, candidate });
    } catch {
      this.onWorkerGone(job).catch((error: unknown) => this.failUnexpected(error));
    }
  }

  // ---- step 3: job result ------------------------------------------------------------------------------------

  private async onMessage(raw: unknown): Promise<void> {
    const job = this.job;
    if (job === null || job.detached || job.resultReceived) {
      return;
    }
    if (!isRecord(raw) || typeof raw["jobId"] !== "number") {
      // Not a result at all: a broken worker.
      await this.onWorkerGone(job);
      return;
    }
    if (raw["jobId"] !== job.jobId) {
      // Stale result: discard, NO state change.
      return;
    }
    job.resultReceived = true;
    const parsed = Block.safeParse(raw["block"]);
    if (!parsed.success) {
      job.resultReceived = false;
      await this.onWorkerGone(job);
      return;
    }
    const block = parsed.data;
    // The worker has delivered; free it.
    this.terminateWorker(job);

    const head = this.ledger.head;
    const ids = block.records.map((record) => recordId(record, this.options.crypto.hash));
    if (block.previousHash !== head.hash || block.index !== head.index + 1 || !sameIds(ids, job.snapshotIds)) {
      // Stale parent or not the reserved snapshot: treated as a cancel; a new job is scheduled.
      await this.abandonJob(job);
      this.maybeSchedule();
      return;
    }

    const verdict = await validateBlockAdmission(
      block,
      this.ledger.blocks,
      this.ledger.state,
      this.options.config,
      this.options.clock,
      this.options.crypto,
    );
    if (this.job !== job || this.closing) {
      // Cancelled or shut down while validating.
      return;
    }
    if (!verdict.ok) {
      await this.runCritical(() => this.discardAndRecheck(job, block));
      this.maybeSchedule();
      return;
    }
    await this.persist(job, block);
  }

  // ---- step 6: admission or re-validation failure ------------------------------------------------------------

  private async discardAndRecheck(job: Job, block: Block): Promise<void> {
    await this.writer.run(async () => {
      const { config, crypto } = this.options;
      const scope: BlockScope = { state: this.ledger.state, pending: emptyUniquenessIndex() };
      for (const id of job.reservedIds) {
        const entry = this.mempool.getLive(id);
        if (entry === undefined || entry.status !== "reserved" || entry.jobId !== job.jobId) {
          continue;
        }
        const result = await validateRecordInBlock(entry.record, block, scope, config, crypto);
        if (result.ok) {
          addRecordToUniquenessIndex(scope.pending, entry.record);
          this.mempool.releaseOne(id);
        } else {
          this.mempool.reject(id, result.code);
        }
      }
      this.job = null;
      this.mempool.sweep(this.options.clock.now());
      this.setState("idle");
    });
  }

  // ---- step 4: persist (fail-closed, non-cancellable) --------------------------------------------------------

  private async persist(job: Job, block: Block): Promise<void> {
    this.setState("persisting");
    const result: { outcome: "ok" | "retry" | "fatal" } = { outcome: "ok" };
    await this.runCritical(async () => {
      await this.writer.run(async () => {
        const line = `${canonicalize(block)}\n`;
        let offset: number | undefined;
        try {
          offset = await this.options.store.size();
          await this.options.store.append(line);
          await this.options.store.fsync();
        } catch {
          // Nothing was written if size() failed; otherwise roll back to the recorded offset.
          result.outcome = offset === undefined ? "retry" : await this.rollback(offset);
          return;
        }
        // I5: a block is appended only for the current job whose parent equals the current head.
        const head = this.ledger.head;
        if (this.job !== job || block.previousHash !== head.hash || block.index !== head.index + 1) {
          throw new ChainError("INTERNAL", "persist reached with a job that is not current");
        }
        // One synchronous critical section: memory, index, mempool and job.
        this.ledger.append(block);
        this.appended += 1;
        this.mempool.confirm(job.reservedIds);
        this.job = null;
      });
    });

    if (result.outcome === "ok") {
      this.backoffMs = BACKOFF_INITIAL_MS;
      this.setState("idle");
      this.maybeSchedule();
    } else if (result.outcome === "retry") {
      this.job = null;
      this.mempool.releaseJob(job.jobId);
      this.mempool.sweep(this.options.clock.now());
      this.enterBackoff("error");
    } else {
      this.fail(FATAL_PERSIST_CODE);
    }
  }

  // ftruncate(offset), fsync, verify the size equals offset. Any failure means the file may be corrupt: fatal.
  private async rollback(offset: number): Promise<"retry" | "fatal"> {
    try {
      await this.options.store.truncate(offset);
      await this.options.store.fsync();
      return (await this.options.store.size()) === offset ? "retry" : "fatal";
    } catch {
      return "fatal";
    }
  }

  private runCritical(task: () => Promise<void>): Promise<void> {
    const promise: Promise<void> = task().finally(() => {
      if (this.critical === promise) {
        this.critical = null;
      }
      this.touch();
    });
    this.critical = promise;
    return promise;
  }

  // ---- step 5: cancel and worker crash -----------------------------------------------------------------------

  // Test-only. Outside `persisting` it cancels now; during `persisting` it is deferred until persisting ends.
  async cancelCurrentJob(): Promise<void> {
    if (this.critical !== null) {
      await this.critical;
      return;
    }
    const job = this.job;
    if (job === null) {
      return;
    }
    await this.abandonJob(job);
    this.maybeSchedule();
  }

  // reserved -> pending, job cleared, worker terminated. The state is updated before the termination is awaited.
  private async abandonJob(job: Job): Promise<void> {
    if (this.job !== job) {
      return;
    }
    this.job = null;
    this.mempool.releaseJob(job.jobId);
    this.mempool.sweep(this.options.clock.now());
    this.setState("idle");
    this.terminateWorker(job);
    await job.terminated;
  }

  private async onWorkerGone(job: Job): Promise<void> {
    if (this.job !== job || job.detached) {
      return;
    }
    this.job = null;
    this.mempool.releaseJob(job.jobId);
    this.mempool.sweep(this.options.clock.now());
    this.terminateWorker(job);
    this.enterBackoff("restarting");
    await job.terminated;
  }

  private terminateWorker(job: Job): void {
    if (job.terminated !== null) {
      return;
    }
    job.detached = true;
    job.terminated = job.worker.terminate().catch((error: unknown) => this.failUnexpected(error));
  }

  // restarting (worker crash) or error (persist failure), then idle after an exponential backoff (1 s ... 30 s).
  private enterBackoff(state: "restarting" | "error"): void {
    this.setState(state);
    if (this.closing) {
      return;
    }
    const delay = this.backoffMs;
    this.backoffMs = Math.min(this.backoffMs * 2, BACKOFF_MAX_MS);
    this.backoffTimer = this.options.timers.setTimeout(() => {
      this.backoffTimer = null;
      if (this.closing || this.currentState === "fatal") {
        return;
      }
      this.setState("idle");
      this.runBuild();
    }, delay);
  }

  // ---- fatal and shutdown ------------------------------------------------------------------------------------

  private fail(code: ErrorCode): void {
    if (this.currentState === "fatal") {
      return;
    }
    this.clearTimers();
    const job = this.job;
    this.job = null;
    if (job !== null) {
      this.mempool.releaseJob(job.jobId);
      this.terminateWorker(job);
    }
    this.fatalCode = code;
    this.setState("fatal");
    this.options.onFatal?.(code);
  }

  private failUnexpected(error: unknown): void {
    this.lastFailure = error;
    this.fail("INTERNAL");
  }

  private clearTimers(): void {
    if (this.batchTimer !== null) {
      this.options.timers.clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }
    if (this.backoffTimer !== null) {
      this.options.timers.clearTimeout(this.backoffTimer);
      this.backoffTimer = null;
    }
  }

  // Awaits `persisting`, any candidate build, then cancels a running job. No record is dropped.
  async shutdown(): Promise<void> {
    this.closing = true;
    this.clearTimers();
    for (;;) {
      if (this.critical !== null) {
        await this.critical;
      } else if (this.building !== null) {
        await this.building;
      } else if (this.job !== null) {
        await this.abandonJob(this.job);
      } else {
        break;
      }
    }
    this.clearTimers();
  }

  // ---- test support ------------------------------------------------------------------------------------------

  // Resolves when no build, job or persist step is in progress (timers may still be scheduled).
  async settled(): Promise<void> {
    while (
      this.building !== null ||
      this.job !== null ||
      this.critical !== null ||
      this.currentState === "persisting"
    ) {
      await new Promise<void>((resolve) => this.waiters.push(resolve));
    }
  }

  private setState(state: MinerState): void {
    this.currentState = state;
    this.touch();
  }

  private touch(): void {
    const waiters = this.waiters;
    this.waiters = [];
    for (const resolve of waiters) {
      resolve();
    }
  }

  // Test-only. Throws on the first violated invariant among I1, I2, I3 and I5 (I4 and I6 need the file: see node.ts).
  assertInvariants(): void {
    const counts = this.mempool.counts();
    const confirmedOnChain = this.ledger.confirmedIds();
    const seen = new Set<string>();
    for (const entry of this.mempool.liveEntries()) {
      if (seen.has(entry.id)) {
        throw new Error("I1: record id appears twice in the mempool");
      }
      seen.add(entry.id);
      if (this.mempool.getTerminal(entry.id) !== undefined) {
        throw new Error("I1: record is both live and terminal");
      }
      if (confirmedOnChain.has(entry.id)) {
        throw new Error("I2: record is both in the mempool and confirmed");
      }
      if (entry.status === "reserved" && (this.job === null || entry.jobId !== this.job.jobId)) {
        throw new Error("I1: reserved record does not belong to the current job");
      }
      if (entry.status === "pending" && entry.jobId !== null) {
        throw new Error("I1: pending record carries a job id");
      }
    }
    for (const id of this.mempool.terminalIds()) {
      if (confirmedOnChain.has(id)) {
        throw new Error("I1: record is both terminal and confirmed");
      }
    }
    const total =
      counts.pending + counts.reserved + counts.confirmed + counts.expired + counts.rejected + counts.retired;
    if (counts.admitted !== total) {
      throw new Error(`I3: admitted ${counts.admitted} != states ${total}`);
    }
    if (!this.mempool.indexMatchesLive()) {
      throw new Error("I1: mempool uniqueness index differs from the live records");
    }
    const blocks = this.ledger.blocks;
    for (let position = 1; position < blocks.length; position += 1) {
      const block = blocks[position];
      const previous = blocks[position - 1];
      if (block === undefined || previous === undefined) {
        throw new Error("I5: chain has a hole");
      }
      if (block.index !== previous.index + 1 || block.previousHash !== previous.hash) {
        throw new Error("I5: chain is not linked");
      }
    }
    if (blocks.length - this.bootBlockCount !== this.appended) {
      throw new Error("I5: a block entered memory outside the persist step");
    }
    if (this.currentState === "fatal" && this.job !== null) {
      throw new Error("fatal miner still holds a job");
    }
  }
}
