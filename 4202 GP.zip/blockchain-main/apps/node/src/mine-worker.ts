// Plain synchronous mining worker (SPEC section 9). Receives ONE message { jobId, candidate }, runs mineBlock to
// completion and posts { jobId, block }. Cancellation is done by the main thread through worker.terminate(), because a
// synchronous loop never reads its message queue.

import { parentPort } from "node:worker_threads";
import { mineBlock, nodeHash, type BlockCandidate } from "@conference-chain/shared";
import { isRecord, type MineResultMessage } from "./mine-protocol.js";

if (parentPort === null) {
  throw new Error("mine-worker must run inside a worker thread");
}
const port = parentPort;

port.once("message", (message: unknown) => {
  if (!isRecord(message) || typeof message["jobId"] !== "number" || !isRecord(message["candidate"])) {
    throw new Error("mine-worker: malformed job message");
  }
  const jobId = message["jobId"];
  // The main thread builds the candidate from validated data; the worker mines exactly what it receives.
  const candidate = message["candidate"] as unknown as BlockCandidate;
  const rawStart = message["nonceStart"];
  const rawStride = message["nonceStride"];
  const nonceStart = rawStart === undefined ? 0 : rawStart;
  const nonceStride = rawStride === undefined ? 1 : rawStride;
  if (
    typeof nonceStart !== "number" || !Number.isSafeInteger(nonceStart) ||
    typeof nonceStride !== "number" || !Number.isSafeInteger(nonceStride)
  ) {
    throw new Error("mine-worker: invalid nonce lane");
  }
  const block = mineBlock(candidate, nodeHash, undefined, { startNonce: nonceStart, stride: nonceStride });
  if (block === null) {
    throw new Error("mine-worker: mineBlock returned no block");
  }
  const result: MineResultMessage = { jobId, block };
  port.postMessage(result);
});
