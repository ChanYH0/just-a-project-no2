// Request parsing shared by the HTTP route modules (SPEC section 10).

import { ChainError } from "@conference-chain/shared";
import type { z } from "zod";

export function parseWith<T>(schema: z.ZodType<T>, value: unknown, what: string): T {
  const result = schema.safeParse(value);
  if (result.success) {
    return result.data;
  }
  // Only the field paths are reported; submitted values and unknown keys are never echoed.
  const paths = [...new Set(result.error.issues.map((issue) => issue.path.join(".") || "(root)"))].slice(0, 10);
  throw new ChainError("INVALID_SCHEMA", `invalid ${what}: ${paths.join(", ")}`);
}
