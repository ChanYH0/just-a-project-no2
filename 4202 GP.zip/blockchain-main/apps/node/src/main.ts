// Process entry point (SPEC section 9). Logs only error codes; exits non-zero on a boot error or a fatal miner.

import { ChainError, type Clock, type ErrorCode } from "@conference-chain/shared";
import { createNode, type Node } from "./app.js";
import { BootError } from "./boot-error.js";
import { parseEnv } from "./env.js";
import { loadSessions } from "./sessions.js";
import { DEFAULT_MINING_BACKEND, DEFAULT_MINING_WORKERS } from "./mining-config.js";

const systemClock: Clock = { now: () => Date.now() };

// Optional bind address; not in the SPEC env table (flagged in the handoff report). Default is loopback only.
const DEFAULT_HOST = "127.0.0.1";

function describe(error: unknown): string {
  if (error instanceof BootError) {
    return error.blockIndex === undefined ? error.code : `${error.code} blockIndex=${error.blockIndex}`;
  }
  if (error instanceof ChainError) {
    return error.code;
  }
  return "INTERNAL";
}

let node: Node | null = null;
let stopping = false;

async function stop(exitCode: number): Promise<void> {
  if (stopping) {
    return;
  }
  stopping = true;
  try {
    await node?.close();
  } catch (error) {
    console.error(`shutdown failed: ${describe(error)}`);
    exitCode = 1;
  }
  process.exit(exitCode);
}

async function main(): Promise<void> {
  const settings = parseEnv(process.env);
  const sessions = await loadSessions(settings.sessionsFile);
  node = await createNode({
    settings,
    sessions,
    clock: systemClock,
    onFatal: (code: ErrorCode) => {
      console.error(`fatal: ${code}`);
      void stop(1);
    },
  });
  process.on("SIGINT", () => void stop(0));
  process.on("SIGTERM", () => void stop(0));
  await node.app.listen({ port: settings.port, host: process.env["HOST"] ?? DEFAULT_HOST });
  console.log(`listening profile=${settings.profile} port=${settings.port} mining=${settings.miningBackend ?? DEFAULT_MINING_BACKEND} workers=${settings.miningWorkers ?? DEFAULT_MINING_WORKERS}`);
}

main().catch((error: unknown) => {
  console.error(`boot refused: ${describe(error)}`);
  process.exit(1);
});
