// A logical mining worker backed by independent worker_threads scanning disjoint nonce lanes.
import {
  Block,
  canonicalize,
  computeBlockHash,
  meetsProofOfWork,
  nodeHash,
  type BlockCandidate,
  type HashFn,
} from "@conference-chain/shared";
import { MINING_WORKERS_MAX } from "./mining-config.js";
import type {
  MineJobMessage,
  MineResultMessage,
  MineWorkerHandle,
  WorkerFactory,
  WorkerHandlers,
} from "./mine-protocol.js";

function validateWorkerCount(count: number): void {
  if (!Number.isSafeInteger(count) || count < 1 || count > MINING_WORKERS_MAX) {
    throw new RangeError(`mining worker count must be an integer between 1 and ${MINING_WORKERS_MAX}`);
  }
}

function isMessageRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function candidateMatches(block: Block, candidate: BlockCandidate, hash: HashFn): boolean {
  return (
    block.index === candidate.index &&
    block.timestamp === candidate.timestamp &&
    block.previousHash === candidate.previousHash &&
    block.difficulty === candidate.difficulty &&
    canonicalize(block.records) === canonicalize(candidate.records) &&
    computeBlockHash(block, hash) === block.hash &&
    meetsProofOfWork(block.hash, candidate.difficulty)
  );
}

class MiningWorkerPoolHandle implements MineWorkerHandle {
  private handlers: WorkerHandlers | null = null;
  private workers: MineWorkerHandle[] = [];
  private state: "new" | "starting" | "running" | "finishing" | "done" | "failed" | "cancelled" = "new";
  private termination: Promise<void> | null = null;
  private cancelRequested = false;
  private queuedMessages: { message: unknown; workerIndex: number }[] = [];

  constructor(
    private readonly workerFactory: WorkerFactory,
    private readonly workerCount: number,
    private readonly hash: HashFn,
  ) {}

  setHandlers(handlers: WorkerHandlers): void {
    if (this.state !== "new") {
      throw new Error("worker pool handlers must be set before posting a job");
    }
    this.handlers = handlers;
  }

  postMessage(message: MineJobMessage): void {
    if (this.state !== "new" || this.handlers === null) {
      throw new Error("worker pool accepts one job after handlers are installed");
    }
    this.state = "starting";
    const candidate = message.candidate;
    try {
      for (let workerIndex = 0; workerIndex < this.workerCount; workerIndex += 1) {
        const worker = this.workerFactory();
        this.workers.push(worker);
        worker.setHandlers({
          onMessage: (raw) => this.onMessage(raw, workerIndex, message, candidate),
          onError: (error) => this.onWorkerFailure(error),
          onExit: (code) => this.onWorkerExit(code),
        });
      }
    } catch (error) {
      this.onWorkerFailure(error instanceof Error ? error : new Error("mining worker could not be created"));
      return;
    }

    // A synchronous test double may reply from postMessage. Queue those replies
    // until every child has been given its own lane.
    for (let workerIndex = 0; workerIndex < this.workers.length; workerIndex += 1) {
      const worker = this.workers[workerIndex];
      if (worker === undefined) {
        this.onWorkerFailure(new Error("mining worker pool has a missing worker"));
        return;
      }
      try {
        worker.postMessage({
          ...message,
          nonceStart: workerIndex,
          nonceStride: this.workerCount,
        });
      } catch (error) {
        this.onWorkerFailure(error instanceof Error ? error : new Error("mining worker rejected its job"));
        return;
      }
    }
    if (this.state !== "starting") {
      return;
    }
    this.state = "running";
    const queued = this.queuedMessages;
    this.queuedMessages = [];
    for (const entry of queued) {
      this.onMessage(entry.message, entry.workerIndex, message, candidate);
    }
  }

  terminate(): Promise<void> {
    if (this.state === "done" || this.state === "failed" || this.state === "cancelled") {
      return this.termination ?? Promise.resolve();
    }
    this.cancelRequested = true;
    this.state = "cancelled";
    return this.terminateChildren();
  }

  private onMessage(raw: unknown, workerIndex: number, job: MineJobMessage, candidate: BlockCandidate): void {
    if (this.state === "starting") {
      this.queuedMessages.push({ message: raw, workerIndex });
      return;
    }
    if (this.state !== "running") {
      return;
    }
    if (
      !isMessageRecord(raw) || typeof raw["jobId"] !== "number" ||
      !Number.isSafeInteger(raw["jobId"]) || raw["jobId"] < 1
    ) {
      this.onWorkerFailure(new Error("mining worker returned a malformed message"));
      return;
    }
    // Results from a previous logical job remain stale and do not affect this pool.
    if (raw["jobId"] !== job.jobId) {
      return;
    }
    if (!("block" in raw)) {
      this.onWorkerFailure(new Error("mining worker omitted its block"));
      return;
    }
    const parsed = Block.safeParse(raw.block);
    if (!parsed.success) {
      this.onWorkerFailure(new Error("mining worker returned a malformed block"));
      return;
    }
    const block = parsed.data;
    if (
      !candidateMatches(block, candidate, this.hash) ||
      workerIndex >= this.workerCount ||
      block.nonce < workerIndex ||
      (block.nonce - workerIndex) % this.workerCount !== 0
    ) {
      this.onWorkerFailure(new Error("mining worker returned an invalid block or nonce lane"));
      return;
    }

    this.state = "finishing";
    this.terminateChildren().then(
      () => {
        if (this.cancelRequested || this.state !== "finishing") {
          return;
        }
        this.state = "done";
        const result: MineResultMessage = { jobId: job.jobId, block };
        this.handlers?.onMessage(result);
      },
      (error: unknown) => this.notifyFailure(error),
    );
  }

  private onWorkerFailure(error: Error): void {
    if (!["starting", "running"].includes(this.state)) {
      return;
    }
    this.state = "finishing";
    this.terminateChildren().then(
      () => this.notifyFailure(error),
      (terminationError: unknown) => this.notifyFailure(terminationError),
    );
  }

  private onWorkerExit(code: number): void {
    if (this.state === "starting" || this.state === "running") {
      this.onWorkerFailure(new Error(`mining worker exited with code ${code}`));
    }
  }

  private notifyFailure(error: unknown): void {
    if (this.cancelRequested || this.state === "failed" || this.state === "cancelled") {
      return;
    }
    this.state = "failed";
    const failure = error instanceof Error ? error : new Error("mining worker pool failed");
    this.handlers?.onError(failure);
  }

  private terminateChildren(): Promise<void> {
    if (this.termination !== null) {
      return this.termination;
    }
    const workers = this.workers;
    this.termination = (async () => {
      const results = await Promise.allSettled(workers.map((worker) => worker.terminate()));
      const rejected = results.find((result): result is PromiseRejectedResult => result.status === "rejected");
      if (rejected !== undefined) {
        throw rejected.reason;
      }
    })();
    return this.termination;
  }
}

// Each logical worker shares one candidate across `workerCount` children. Workers
// scan lane [i, i + workerCount, ...], then the first validated solution is emitted
// after every child thread has exited.
export function createWorkerPool(
  workerFactory: WorkerFactory,
  workerCount: number,
  hash: HashFn = nodeHash,
): WorkerFactory {
  validateWorkerCount(workerCount);
  return () => new MiningWorkerPoolHandle(workerFactory, workerCount, hash);
}
