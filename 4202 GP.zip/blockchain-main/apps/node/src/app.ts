// Node assembly and HTTP API (SPEC sections 9 and 10). createNode boots (process lock, chain file, store, ledger,
// miner) and builds the Fastify instance. Tests drive it through app.inject(); nothing here binds a port.

import { readFile, stat } from "node:fs/promises";
import Fastify, { type FastifyError, type FastifyInstance, type FastifyRequest } from "fastify";
import { z } from "zod";
import {
  AttendeeId,
  ChainError,
  HexSha256,
  NonNegativeInt,
  PROTOCOL_VERSION,
  PositiveInt,
  SessionId,
  SignedAttendance,
  SignedRegistration,
  canonicalize,
  computeBlockHash,
  deriveChainId,
  verifyBlockPow,
  type ChainCrypto,
  type Clock,
  type ErrorCode,
} from "@conference-chain/shared";
import type { NodeSettings } from "./env.js";
import {
  BLOCKS_DEFAULT_LIMIT,
  BLOCKS_MAX_LIMIT,
  BODY_LIMIT_BYTES,
  HEAVY_RATE_LIMIT,
  HEAVY_RATE_WINDOW_MS,
  MEMPOOL_VIEW_MAX,
  WRITE_RATE_LIMIT,
  WRITE_RATE_WINDOW_MS,
} from "./limits.js";
import { FixedWindowLimiter } from "./limiter.js";
import { Ledger } from "./ledger.js";
import { Miner } from "./miner.js";
import { systemTimers, type Timers, type WorkerFactory } from "./mine-protocol.js";
import type { SessionEntry } from "./sessions.js";
import { FileChainStore, acquireLock, chainFilePath, loadChainFile, type ChainStore } from "./store.js";
import { nodeCrypto } from "./node-crypto.js";
import { parseWith } from "./request.js";
import { BoundedCache } from "./validation-cache.js";
import { ValidationWorkerManager } from "./validation-manager.js";
import type { TamperOutcome, ValidateSnapshotOutcome, ValidationWorkerFactory } from "./validation-protocol.js";
import { registerDemoRoutes, registerTamperRoutes, registerValidateRoutes } from "./validation-routes.js";
import { createRealValidationWorkerFactory } from "./worker-factory.js";
import { configuredMiningFactory } from "./mining-backend.js";
import { registerApiDocs } from "./api-docs.js";

export { nodeCrypto };

// HTTP status mapping lives only here (SPEC section 10). Codes that never surface through the API map to 500.
const HTTP_STATUS: Readonly<Record<ErrorCode, number>> = {
  INVALID_SCHEMA: 400,
  INVALID_KEY: 400,
  INVALID_SIGNATURE: 400,
  ATTENDEE_ID_MISMATCH: 400,
  CHAIN_ID_MISMATCH: 400,
  TIMESTAMP_OUT_OF_RANGE: 400,
  ATTENDEE_NOT_REGISTERED: 400,
  UNKNOWN_SESSION: 400,
  NOT_FOUND: 404,
  KEY_ALREADY_REGISTERED: 409,
  DUPLICATE_ATTENDANCE: 409,
  BODY_TOO_LARGE: 413,
  RATE_LIMITED: 429,
  MEMPOOL_FULL: 503,
  MINER_UNAVAILABLE: 503,
  INTERNAL: 500,
  CHAIN_STORE_MISMATCH: 500,
  BAD_PREVIOUS_HASH: 500,
  BAD_BLOCK_HASH: 500,
  BAD_POW: 500,
  BAD_DIFFICULTY: 500,
  BAD_INDEX: 500,
  BAD_TIMESTAMP_ORDER: 500,
  GENESIS_MISMATCH: 500,
  TOO_MANY_RECORDS: 500,
  CHAIN_FILE_CORRUPT: 500,
};

export function httpStatusFor(code: ErrorCode): number {
  return HTTP_STATUS[code];
}

export interface CreateNodeOptions {
  settings: NodeSettings;
  sessions: readonly SessionEntry[];
  clock: Clock;
  // Wraps the real file store (fault injection in tests). The wrapper must delegate to the store it receives.
  wrapStore?: (real: ChainStore) => ChainStore;
  workerFactory?: WorkerFactory;
  timers?: Timers;
  mempoolMax?: number;
  terminalLimit?: number;
  onFatal?: (code: ErrorCode) => void;
  // Validation worker (validate / simulate jobs): injectable factory and timeout (default: real worker, 30 s).
  validationWorkerFactory?: ValidationWorkerFactory;
  validationTimeoutMs?: number;
  // Time source of the /chain/validate and /demo/* rate limiter only. It is deliberately NOT the live `clock`, so these
  // routes never read the live clock (SPEC section 8, RC10). Default: the system clock.
  heavyRateClock?: Clock;
}

// Everything a route registrar needs. Later tasks add routes by appending to ROUTE_REGISTRARS.
export interface NodeContext {
  settings: NodeSettings;
  chainId: string;
  clock: Clock;
  crypto: ChainCrypto;
  miner: Miner;
  ledger: Ledger;
  sessions: readonly SessionEntry[];
  catalog: ReadonlySet<string>;
  writeLimit: (request: FastifyRequest) => Promise<void>;
  // 6/min per IP, one bucket shared by /chain/validate and /demo/*.
  heavyLimit: (request: FastifyRequest) => Promise<void>;
  validationManager: ValidationWorkerManager;
  // Cache of /chain/validate results only. Never handed to the simulation handler.
  validationCache: BoundedCache<ValidateSnapshotOutcome>;
  // Cache of /demo/tamper-check results only (keys under their own prefix). Never handed to the simulation handler.
  tamperCache: BoundedCache<TamperOutcome>;
}

export type RouteRegistrar = (app: FastifyInstance, ctx: NodeContext) => void;

export interface Node {
  app: FastifyInstance;
  miner: Miner;
  ledger: Ledger;
  chainId: string;
  settings: NodeSettings;
  // Test-visible handles on the validation machinery.
  validationCache: BoundedCache<ValidateSnapshotOutcome>;
  tamperCache: BoundedCache<TamperOutcome>;
  validationManager: ValidationWorkerManager;
  close(): Promise<void>;
  // Test-only: I1-I6 (I4 and I6 compare the file on disk with the in-memory chain).
  assertInvariants(): Promise<void>;
}

// ---- request parsing ---------------------------------------------------------------------------------------

const DECIMAL = /^(0|[1-9][0-9]{0,15})$/;

function decimalInt(target: z.ZodType<number, number>) {
  return z
    .string()
    .regex(DECIMAL)
    .transform((text) => Number(text))
    .pipe(target);
}

const RecordIdParams = z.object({ recordId: HexSha256 }).strict();
const BlockIndexParams = z.object({ index: decimalInt(NonNegativeInt) }).strict();
const AttendeeParams = z.object({ attendeeId: AttendeeId }).strict();
const SessionParams = z.object({ sessionId: SessionId }).strict();
const BlocksQuery = z
  .object({
    limit: decimalInt(PositiveInt.pipe(z.number().max(BLOCKS_MAX_LIMIT))).optional(),
    cursor: decimalInt(NonNegativeInt).optional(),
  })
  .strict();
const EmptyQuery = z.object({}).strict();

// ---- routes ------------------------------------------------------------------------------------------------

const registerInfoRoutes: RouteRegistrar = (app, ctx) => {
  app.get("/chain/info", async (request) => {
    parseWith(EmptyQuery, request.query, "query");
    return {
      chainId: ctx.chainId,
      conferenceId: ctx.settings.config.conferenceId,
      profile: ctx.settings.profile,
      protocol: PROTOCOL_VERSION,
    };
  });

  app.get("/health", async (request) => {
    parseWith(EmptyQuery, request.query, "query");
    return {
      ok: ctx.miner.state !== "fatal",
      miner: ctx.miner.state,
      headIndex: ctx.ledger.head.index,
      profile: ctx.settings.profile,
    };
  });

  app.get("/sessions", async (request) => {
    parseWith(EmptyQuery, request.query, "query");
    return ctx.sessions.map((entry) => ({ id: entry.id, title: entry.title }));
  });
};

const registerWriteRoutes: RouteRegistrar = (app, ctx) => {
  app.post("/registrations", { onRequest: ctx.writeLimit }, async (request, reply) => {
    requireWritableMiner(ctx);
    const record = parseWith(SignedRegistration, request.body, "body");
    const recordId = await ctx.miner.admit(record);
    return reply.status(202).send({ recordId });
  });

  app.post("/attendance", { onRequest: ctx.writeLimit }, async (request, reply) => {
    requireWritableMiner(ctx);
    const record = parseWith(SignedAttendance, request.body, "body");
    const recordId = await ctx.miner.admit(record);
    return reply.status(202).send({ recordId });
  });
};

function requireWritableMiner(ctx: NodeContext): void {
  if (ctx.miner.state === "fatal") {
    throw new ChainError("MINER_UNAVAILABLE", "the miner is not available");
  }
}

const registerReadRoutes: RouteRegistrar = (app, ctx) => {
  app.get("/records/:recordId", async (request) => {
    const { recordId } = parseWith(RecordIdParams, request.params, "params");
    parseWith(EmptyQuery, request.query, "query");
    const status = ctx.miner.recordStatus(recordId);
    if (status === null) {
      throw new ChainError("NOT_FOUND", "unknown record");
    }
    return status;
  });

  app.get("/mempool", async (request) => {
    parseWith(EmptyQuery, request.query, "query");
    return ctx.miner.mempoolRecords(MEMPOOL_VIEW_MAX);
  });

  app.get("/blocks", async (request) => {
    const query = parseWith(BlocksQuery, request.query, "query");
    const limit = query.limit ?? BLOCKS_DEFAULT_LIMIT;
    const head = ctx.ledger.head.index;
    const start = query.cursor === undefined ? head : Math.min(query.cursor - 1, head);
    const blocks = [];
    for (let index = start; index >= 0 && blocks.length < limit; index -= 1) {
      const block = ctx.ledger.blocks[index];
      if (block === undefined) {
        throw new ChainError("INTERNAL", "ledger has a hole");
      }
      blocks.push(block);
    }
    const last = blocks.at(-1);
    return { blocks, nextCursor: last !== undefined && last.index > 0 ? String(last.index) : null };
  });

  app.get("/blocks/:index", async (request) => {
    const { index } = parseWith(BlockIndexParams, request.params, "params");
    parseWith(EmptyQuery, request.query, "query");
    const block = ctx.ledger.blocks[index];
    if (block === undefined) {
      throw new ChainError("NOT_FOUND", "unknown block");
    }
    return {
      ...block,
      verification: {
        hashValid: computeBlockHash(block, ctx.crypto.hash) === block.hash,
        powValid: verifyBlockPow(block, ctx.crypto.hash),
      },
    };
  });
};

const registerQueryRoutes: RouteRegistrar = (app, ctx) => {
  app.get("/attendees/:attendeeId", async (request) => {
    const { attendeeId } = parseWith(AttendeeParams, request.params, "params");
    parseWith(EmptyQuery, request.query, "query");
    const entry = ctx.ledger.state.registrations.get(attendeeId);
    if (entry === undefined) {
      throw new ChainError("NOT_FOUND", "attendee is not registered");
    }
    return { attendeeId, alias: entry.alias, registeredAt: entry.timestamp, blockIndex: entry.blockIndex };
  });

  // Q1
  app.get("/attendees/:attendeeId/sessions", async (request) => {
    const { attendeeId } = parseWith(AttendeeParams, request.params, "params");
    parseWith(EmptyQuery, request.query, "query");
    if (!ctx.ledger.state.registrations.has(attendeeId)) {
      throw new ChainError("NOT_FOUND", "attendee is not registered");
    }
    return { attendeeId, sessions: ctx.ledger.sessionsOfAttendee(attendeeId) };
  });

  // Q2: 404 only if the session is neither in the current catalog nor present in any attendance record on chain.
  app.get("/sessions/:sessionId/attendees", async (request) => {
    const { sessionId } = parseWith(SessionParams, request.params, "params");
    parseWith(EmptyQuery, request.query, "query");
    if (!ctx.catalog.has(sessionId) && !ctx.ledger.sessionOnChain(sessionId)) {
      throw new ChainError("NOT_FOUND", "unknown session");
    }
    const attendees = ctx.ledger.attendeesOfSession(sessionId).map((entry) => {
      const registration = ctx.ledger.state.registrations.get(entry.attendeeId);
      if (registration === undefined) {
        throw new ChainError("INTERNAL", "attendance without registration");
      }
      return {
        attendeeId: entry.attendeeId,
        alias: registration.alias,
        timestamp: entry.timestamp,
        blockIndex: entry.blockIndex,
      };
    });
    return { sessionId, attendees };
  });
};

// Extension point: later tasks append registrars (for example /chain/validate and the gated /demo/* routes).
const ROUTE_REGISTRARS: readonly RouteRegistrar[] = [
  registerInfoRoutes,
  registerWriteRoutes,
  registerReadRoutes,
  registerQueryRoutes,
  registerValidateRoutes,
  registerDemoRoutes,
  registerTamperRoutes,
];

// ---- error handling ----------------------------------------------------------------------------------------

function errorBody(code: ErrorCode, message: string): { error: { code: ErrorCode; message: string } } {
  return { error: { code, message } };
}

function installErrorHandling(app: FastifyInstance): void {
  app.setErrorHandler((error: FastifyError | ChainError, _request, reply) => {
    if (error instanceof ChainError) {
      return reply.status(HTTP_STATUS[error.code]).send(errorBody(error.code, error.message));
    }
    const statusCode = "statusCode" in error ? error.statusCode : undefined;
    if (statusCode === 413) {
      return reply.status(413).send(errorBody("BODY_TOO_LARGE", "request body is too large"));
    }
    if (statusCode !== undefined && statusCode >= 400 && statusCode < 500) {
      // Malformed JSON, empty body, unsupported content type and similar: structural failures.
      return reply.status(400).send(errorBody("INVALID_SCHEMA", "malformed request"));
    }
    // Unknown failure: no detail, no stack trace.
    return reply.status(500).send(errorBody("INTERNAL", "internal error"));
  });

  app.setNotFoundHandler((_request, reply) => reply.status(404).send(errorBody("NOT_FOUND", "route not found")));
}

// ---- boot --------------------------------------------------------------------------------------------------

export async function createNode(options: CreateNodeOptions): Promise<Node> {
  const { settings, clock } = options;
  const { config } = settings;
  const crypto = nodeCrypto;

  const workerFactory = options.workerFactory ?? await configuredMiningFactory(settings);

  const lock = await acquireLock(settings.dataDir);
  let realStore: FileChainStore | null = null;
  try {
    const blocks = await loadChainFile(settings.dataDir, config, crypto);
    realStore = await FileChainStore.open(settings.dataDir);
    const store = options.wrapStore === undefined ? realStore : options.wrapStore(realStore);
    // The lock is held and the miner is not running yet: the file size is exactly the bytes of the loaded blocks.
    const ledger = Ledger.fromBlocks(blocks, crypto.hash, (await stat(chainFilePath(settings.dataDir))).size);
    const catalog = new Set(options.sessions.map((entry) => entry.id));
    const miner = new Miner({
      config,
      crypto,
      clock,
      store,
      ledger,
      catalog,
      workerFactory,
      timers: options.timers ?? systemTimers,
      ...(options.mempoolMax === undefined ? {} : { mempoolMax: options.mempoolMax }),
      ...(options.terminalLimit === undefined ? {} : { terminalLimit: options.terminalLimit }),
      ...(options.onFatal === undefined ? {} : { onFatal: options.onFatal }),
    });

    const writeLimiter = new FixedWindowLimiter(options.settings.writeRateLimit ?? WRITE_RATE_LIMIT, WRITE_RATE_WINDOW_MS, clock);
    const heavyLimiter = new FixedWindowLimiter(
      options.settings.heavyRateLimit ?? HEAVY_RATE_LIMIT,
      HEAVY_RATE_WINDOW_MS,
      options.heavyRateClock ?? { now: () => Date.now() },
    );
    const validationCache = new BoundedCache<ValidateSnapshotOutcome>();
    const tamperCache = new BoundedCache<TamperOutcome>();
    ledger.onCommit(() => {
      validationCache.clear();
      tamperCache.clear();
    });
    const validationManager = new ValidationWorkerManager({
      factory: options.validationWorkerFactory ?? createRealValidationWorkerFactory(),
      ...(options.validationTimeoutMs === undefined ? {} : { timeoutMs: options.validationTimeoutMs }),
    });
    const ctx: NodeContext = {
      heavyLimit: async (request) => {
        if (!heavyLimiter.take(request.ip)) {
          throw new ChainError("RATE_LIMITED", "too many validation requests");
        }
      },
      validationManager,
      validationCache,
      tamperCache,
      settings,
      chainId: deriveChainId(config, crypto.hash),
      clock,
      crypto,
      miner,
      ledger,
      sessions: options.sessions,
      catalog,
      writeLimit: async (request) => {
        if (!writeLimiter.take(request.ip)) {
          throw new ChainError("RATE_LIMITED", "too many write requests");
        }
      },
    };

    const app = Fastify({ bodyLimit: BODY_LIMIT_BYTES, logger: false, trustProxy: options.settings.trustProxy ?? false });
    installErrorHandling(app);
    for (const register of ROUTE_REGISTRARS) {
      register(app, ctx);
    }
    registerApiDocs(app, { enableDemoRoutes: settings.enableDemoRoutes });
    await app.ready();

    const opened = realStore;
    let closed = false;
    return {
      app,
      miner,
      ledger,
      chainId: ctx.chainId,
      settings,
      validationCache,
      tamperCache,
      validationManager,
      async close() {
        if (closed) {
          return;
        }
        closed = true;
        await miner.shutdown();
        await validationManager.shutdown();
        await app.close();
        await opened.close();
        await lock.release();
      },
      async assertInvariants() {
        miner.assertInvariants();
        if (miner.state === "fatal") {
          return;
        }
        const onDisk = await readFile(chainFilePath(settings.dataDir), "utf8");
        const inMemory = ledger.blocks.map((block) => `${canonicalize(block)}\n`).join("");
        if (onDisk !== inMemory) {
          throw new Error("I4/I6: the chain file differs from the in-memory chain");
        }
      },
    };
  } catch (error) {
    if (realStore !== null) {
      await realStore.close();
    }
    await lock.release();
    throw error;
  }
}
