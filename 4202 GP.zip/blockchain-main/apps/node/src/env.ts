// Environment parsing and validation (SPEC section 9). Any invalid value refuses to start.

import {
  CONFERENCE_ID_PATTERN,
  PROFILE_NAMES,
  getProfile,
  type ChainConfig,
  type ProfileName,
} from "@conference-chain/shared";
import { BootError } from "./boot-error.js";
import { HEAVY_RATE_LIMIT, WRITE_RATE_LIMIT } from "./limits.js";
import {
  DEFAULT_METAL_BATCH_SIZE, DEFAULT_MINING_BACKEND, DEFAULT_MINING_WORKERS, METAL_BATCH_SIZE_MAX,
  MINING_BACKENDS, MINING_WORKERS_MAX, type MiningBackend,
} from "./mining-config.js";

export type RawEnv = Readonly<Record<string, string | undefined>>;

export interface NodeSettings {
  profile: ProfileName;
  config: ChainConfig;
  port: number;
  dataDir: string;
  sessionsFile: string;
  enableDemoRoutes: boolean;
  // Per-IP requests per minute; defaults are the SPEC section 10 values in limits.ts.
  writeRateLimit?: number;
  heavyRateLimit?: number;
  // Take the client address from X-Forwarded-For. Only safe when every request comes through a proxy that overwrites it.
  trustProxy?: boolean;
  miningBackend?: MiningBackend;
  miningWorkers?: number;
  metalBatchSize?: number;
}

const DEFAULTS = {
  profile: "production",
  port: "3000",
  dataDir: "./data",
  sessionsFile: "./sessions.json",
} as const;

function isProfileName(value: string): value is ProfileName {
  return (PROFILE_NAMES as readonly string[]).includes(value);
}

function parsePort(raw: string): number {
  if (!/^(0|[1-9][0-9]{0,4})$/.test(raw) || Number(raw) > 65535) {
    throw new BootError("INVALID_SCHEMA", "PORT must be an integer between 0 and 65535");
  }
  return Number(raw);
}

function parseBoolFlag(name: string, raw: string | undefined): boolean {
  if (raw === undefined || raw === "false") {
    return false;
  }
  if (raw === "true") {
    return true;
  }
  throw new BootError("INVALID_SCHEMA", `${name} must be exactly 'true' or 'false'`);
}

function parseRateLimit(name: string, raw: string | undefined, fallback: number): number {
  if (raw === undefined) {
    return fallback;
  }
  if (!/^[1-9][0-9]{0,5}$/.test(raw)) {
    throw new BootError("INVALID_SCHEMA", `${name} must be a positive integer up to 999999`);
  }
  return Number(raw);
}

function nonEmpty(name: string, raw: string): string {
  if (raw.length === 0) {
    throw new BootError("INVALID_SCHEMA", `${name} must not be empty`);
  }
  return raw;
}

function executionInteger(name: string, raw: string | undefined, defaultValue: number, max: number): number {
  if (raw === undefined) return defaultValue;
  if (!/^[1-9][0-9]*$/.test(raw) || !Number.isSafeInteger(Number(raw)) || Number(raw) > max) {
    throw new BootError("INVALID_SCHEMA", `${name} must be a positive integer up to ${max}`);
  }
  return Number(raw);
}

// Pure: reads only the given environment object. Throws BootError carrying the error code.
export function parseEnv(env: RawEnv): NodeSettings {
  const profile = env["PROFILE"] ?? DEFAULTS.profile;
  if (!isProfileName(profile)) {
    throw new BootError("INVALID_SCHEMA", "PROFILE must be production, demo or test");
  }

  const conferenceId = env["CONFERENCE_ID"];
  if (conferenceId === undefined) {
    throw new BootError("INVALID_SCHEMA", "CONFERENCE_ID is required");
  }
  if (!CONFERENCE_ID_PATTERN.test(conferenceId)) {
    throw new BootError("INVALID_SCHEMA", "CONFERENCE_ID must match /^[a-z0-9][a-z0-9-]{2,63}$/");
  }

  const enableDemoRoutes = parseBoolFlag("ENABLE_DEMO_ROUTES", env["ENABLE_DEMO_ROUTES"]);
  if (profile === "production" && enableDemoRoutes) {
    throw new BootError("INVALID_SCHEMA", "ENABLE_DEMO_ROUTES=true is refused when PROFILE=production");
  }
  const miningBackend = env["MINING_BACKEND"] ?? DEFAULT_MINING_BACKEND;
  if (!(MINING_BACKENDS as readonly string[]).includes(miningBackend)) {
    throw new BootError("INVALID_SCHEMA", "MINING_BACKEND must be cpu or metal");
  }

  return {
    profile,
    config: getProfile(profile, conferenceId),
    port: parsePort(env["PORT"] ?? DEFAULTS.port),
    dataDir: nonEmpty("DATA_DIR", env["DATA_DIR"] ?? DEFAULTS.dataDir),
    sessionsFile: nonEmpty("SESSIONS_FILE", env["SESSIONS_FILE"] ?? DEFAULTS.sessionsFile),
    enableDemoRoutes,
    writeRateLimit: parseRateLimit("WRITE_RATE_LIMIT", env["WRITE_RATE_LIMIT"], WRITE_RATE_LIMIT),
    trustProxy: parseBoolFlag("TRUST_PROXY", env["TRUST_PROXY"]),
    heavyRateLimit: parseRateLimit("HEAVY_RATE_LIMIT", env["HEAVY_RATE_LIMIT"], HEAVY_RATE_LIMIT),
    miningBackend: miningBackend as MiningBackend,
    miningWorkers: executionInteger("MINING_WORKERS", env["MINING_WORKERS"], DEFAULT_MINING_WORKERS, MINING_WORKERS_MAX),
    metalBatchSize: executionInteger("METAL_BATCH_SIZE", env["METAL_BATCH_SIZE"], DEFAULT_METAL_BATCH_SIZE, METAL_BATCH_SIZE_MAX),
  };
}
