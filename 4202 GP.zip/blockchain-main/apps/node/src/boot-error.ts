// Boot errors carry an ErrorCode (and the block index when known). Only the code and index are ever printed.

import { ChainError, type ErrorCode } from "@conference-chain/shared";

export class BootError extends ChainError {
  readonly blockIndex: number | undefined;

  constructor(code: ErrorCode, message: string, blockIndex?: number) {
    super(code, message);
    this.name = "BootError";
    this.blockIndex = blockIndex;
  }
}
