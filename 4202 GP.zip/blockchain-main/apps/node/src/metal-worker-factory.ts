// Adapter from Miner worker threads to the local, self-contained Apple Metal helper.
// It passes only the block-hash byte template and mining parameters. It never logs
// helper input, payload records, candidate bytes, or native stderr.

import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { fileURLToPath } from "node:url";
import {
  ChainError,
  computeBlockHash,
  meetsProofOfWork,
  nodeHash,
  type BlockCandidate,
} from "@conference-chain/shared";
import { Base64Std, Block } from "@conference-chain/shared";
import type { MineWorkerHandle, MineJobMessage, WorkerFactory, WorkerHandlers } from "./mine-protocol.js";
import { makeMetalTemplate } from "./metal-template.js";
import { DEFAULT_METAL_BATCH_SIZE, METAL_BATCH_SIZE_MAX } from "./mining-config.js";

const DEFAULT_EXECUTABLE = fileURLToPath(new URL("../native/build/metal-pow", import.meta.url));
const DEFAULT_KERNEL = fileURLToPath(new URL("../native/pow.metal", import.meta.url));
const MAX_NATIVE_REQUEST_BYTES = 2 * 1024 * 1024;
const MAX_NATIVE_OUTPUT_BYTES = 16 * 1024;
const TERMINATE_GRACE_MS = 2_000;

export interface MetalJobRequest {
  prefix: string;
  suffix: string;
  difficulty: number;
  startNonce: number;
  stride: number;
  batchSize: number;
  maxNonces?: number;
  capturePath?: string;
}

export interface MetalJobResult {
  nonce: number | null;
  attempts: number;
  elapsedMs: number;
  device: string;
  capturePath?: string;
}

export interface RunMetalJobOptions {
  executablePath?: string;
  kernelPath?: string;
  signal?: AbortSignal;
}

export interface MetalWorkerOptions extends Omit<RunMetalJobOptions, "signal"> {
  batchSize?: number;
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isSafeInteger(value: unknown, min: number, max = Number.MAX_SAFE_INTEGER): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && !Object.is(value, -0) && value >= min && value <= max;
}

function validateRequest(request: MetalJobRequest): void {
  if (typeof request.prefix !== "string" || typeof request.suffix !== "string") {
    throw new ChainError("INVALID_SCHEMA", "Metal request prefix and suffix must be base64 strings");
  }
  if (!Base64Std.safeParse(request.prefix).success || !Base64Std.safeParse(request.suffix).success) {
    throw new ChainError("INVALID_SCHEMA", "Metal request prefix and suffix must be canonical base64");
  }
  if (
    !isSafeInteger(request.difficulty, 1, 64) ||
    !isSafeInteger(request.startNonce, 0) ||
    !isSafeInteger(request.stride, 1) ||
    !isSafeInteger(request.batchSize, 1, METAL_BATCH_SIZE_MAX) ||
    (request.maxNonces !== undefined && !isSafeInteger(request.maxNonces, 1)) ||
    (request.capturePath !== undefined && (typeof request.capturePath !== "string" || request.capturePath.length === 0 || request.capturePath.length > 4_096))
  ) {
    throw new ChainError("INVALID_SCHEMA", "Metal request contains out-of-range mining parameters");
  }
}

function parseResult(raw: string): MetalJobResult {
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new ChainError("INTERNAL", "Metal helper returned malformed JSON");
  }
  if (!isPlainRecord(value)) {
    throw new ChainError("INTERNAL", "Metal helper returned an invalid result");
  }
  const allowed = new Set(["nonce", "attempts", "elapsedMs", "device", "capturePath"]);
  if (Object.keys(value).some((key) => !allowed.has(key))) {
    throw new ChainError("INTERNAL", "Metal helper returned an unexpected result field");
  }
  if (
    !(value.nonce === null || isSafeInteger(value.nonce, 0)) ||
    !isSafeInteger(value.attempts, 1) ||
    typeof value.elapsedMs !== "number" || !Number.isFinite(value.elapsedMs) || value.elapsedMs < 0 ||
    typeof value.device !== "string" || value.device.length === 0 || value.device.length > 512 ||
    (value.capturePath !== undefined && typeof value.capturePath !== "string")
  ) {
    throw new ChainError("INTERNAL", "Metal helper returned invalid result values");
  }
  return {
    nonce: value.nonce,
    attempts: value.attempts,
    elapsedMs: value.elapsedMs,
    device: value.device,
    ...(value.capturePath === undefined ? {} : { capturePath: value.capturePath }),
  };
}

/** Runs one native job. The helper is called with argv, never a shell command. */
export async function runMetalJob(request: MetalJobRequest, options: RunMetalJobOptions = {}): Promise<MetalJobResult> {
  validateRequest(request);
  if (options.signal?.aborted === true) {
    throw new ChainError("INTERNAL", "Metal job was cancelled");
  }

  const executablePath = options.executablePath ?? DEFAULT_EXECUTABLE;
  const kernelPath = options.kernelPath ?? DEFAULT_KERNEL;
  const jobJson = `${JSON.stringify(request)}\n`;
  if (Buffer.byteLength(jobJson, "utf8") > MAX_NATIVE_REQUEST_BYTES) {
    throw new ChainError("INVALID_SCHEMA", "Metal request exceeds the native message limit");
  }

  return new Promise<MetalJobResult>((resolve, reject) => {
    let child: ChildProcessWithoutNullStreams;
    try {
      child = spawn(executablePath, [kernelPath], {
        stdio: ["pipe", "pipe", "pipe"],
        env: {
          ...process.env,
          ...(request.capturePath === undefined ? {} : { MTL_CAPTURE_ENABLED: "1" }),
        },
      });
    } catch {
      reject(new ChainError("INTERNAL", "Metal helper could not be started"));
      return;
    }

    let settled = false;
    let childClosed = false;
    let terminateTimer: NodeJS.Timeout | undefined;
    let deferredFailure: string | null = null;
    let outputBytes = 0;
    const output: Buffer[] = [];
    const cleanup = (): void => {
      options.signal?.removeEventListener("abort", abort);
      if (terminateTimer !== undefined) clearTimeout(terminateTimer);
    };
    const fail = (message: string): void => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new ChainError("INTERNAL", message));
    };
    const terminateWithError = (message: string): void => {
      if (childClosed || deferredFailure !== null) return;
      deferredFailure = message;
      child.kill("SIGTERM");
      terminateTimer = setTimeout(() => {
        if (!childClosed) child.kill("SIGKILL");
      }, TERMINATE_GRACE_MS);
    };
    const abort = (): void => terminateWithError("Metal job was cancelled");

    child.stdout.on("data", (chunk: Buffer | string) => {
      if (settled) return;
      const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      outputBytes += buffer.length;
      if (outputBytes > MAX_NATIVE_OUTPUT_BYTES) {
        terminateWithError("Metal helper output exceeded its limit");
        return;
      }
      output.push(buffer);
    });
    // Native stderr may contain driver or shader diagnostics. It is deliberately discarded.
    child.stderr.on("data", () => undefined);
    child.once("error", () => {
      if (!options.signal?.aborted) fail("Metal helper could not be started");
    });
    child.once("close", (code) => {
      childClosed = true;
      cleanup();
      if (settled) return;
      if (deferredFailure !== null) {
        fail(deferredFailure);
        return;
      }
      if (code !== 0) {
        fail("Metal helper exited unsuccessfully");
        return;
      }
      try {
        const result = parseResult(Buffer.concat(output).toString("utf8"));
        if (result.capturePath !== request.capturePath) {
          throw new ChainError("INTERNAL", "Metal helper capture result does not match its request");
        }
        resolve(result);
        settled = true;
      } catch (error) {
        settled = true;
        reject(error instanceof ChainError ? error : new ChainError("INTERNAL", "Metal helper returned an invalid result"));
      }
    });
    options.signal?.addEventListener("abort", abort, { once: true });
    if (options.signal?.aborted === true) {
      abort();
      return;
    }
    child.stdin.on("error", () => {
      if (!options.signal?.aborted) terminateWithError("Metal helper rejected its request");
    });
    child.stdin.end(jobJson, "utf8");
  });
}

interface LogicalMetalJob {
  controller: AbortController;
  finished: Promise<void>;
}

class MetalWorkerHandle implements MineWorkerHandle {
  private handlers: WorkerHandlers | null = null;
  private job: LogicalMetalJob | null = null;
  private terminatePromise: Promise<void> | null = null;
  private terminated = false;

  constructor(private readonly options: MetalWorkerOptions) {}

  setHandlers(handlers: WorkerHandlers): void {
    this.handlers = handlers;
  }

  postMessage(message: MineJobMessage): void {
    if (this.handlers === null) {
      throw new ChainError("INTERNAL", "Metal worker handlers must be set before a job is posted");
    }
    if (this.terminated || this.job !== null) {
      this.handlers.onError(new Error("Metal worker is unavailable"));
      return;
    }

    const startNonce = message.nonceStart ?? 0;
    const stride = message.nonceStride ?? 1;
    const controller = new AbortController();
    const job: LogicalMetalJob = { controller, finished: Promise.resolve() };
    this.job = job;
    job.finished = this.run(message, startNonce, stride, controller.signal).finally(() => {
      if (this.job === job) this.job = null;
    });
    // The miner observes failures through onError/onExit; retain no unhandled rejection.
    void job.finished.catch(() => undefined);
  }

  private async run(message: MineJobMessage, startNonce: number, stride: number, signal: AbortSignal): Promise<void> {
    const handlers = this.handlers;
    if (handlers === null) return;
    try {
      const template = makeMetalTemplate(message.candidate);
      const result = await runMetalJob({
        prefix: template.prefix.toString("base64"),
        suffix: template.suffix.toString("base64"),
        difficulty: message.candidate.difficulty,
        startNonce,
        stride,
        batchSize: this.options.batchSize ?? DEFAULT_METAL_BATCH_SIZE,
      }, { ...this.options, signal });
      if (this.terminated || signal.aborted) return;
      if (result.capturePath !== undefined) {
        throw new ChainError("INTERNAL", "unrequested GPU capture was returned");
      }
      if (result.nonce === null) {
        throw new ChainError("INTERNAL", "Metal worker exhausted a mining lane");
      }
      if (result.nonce < startNonce || (result.nonce - startNonce) % stride !== 0) {
        throw new ChainError("BAD_POW", "Metal worker returned a nonce outside its assigned lane");
      }
      const block = {
        ...message.candidate,
        nonce: result.nonce,
        hash: computeBlockHash({ ...message.candidate, nonce: result.nonce }, nodeHash),
      };
      const parsed = Block.safeParse(block);
      if (!parsed.success || !meetsProofOfWork(parsed.data.hash, parsed.data.difficulty)) {
        throw new ChainError("BAD_POW", "Metal worker returned an invalid proof");
      }
      handlers.onMessage({ jobId: message.jobId, block: parsed.data });
      handlers.onExit(0);
    } catch {
      if (this.terminated || signal.aborted) return;
      handlers.onError(new Error("Metal worker failed"));
      handlers.onExit(1);
    }
  }

  terminate(): Promise<void> {
    if (this.terminatePromise !== null) return this.terminatePromise;
    this.terminated = true;
    const job = this.job;
    if (job === null) {
      this.terminatePromise = Promise.resolve();
      return this.terminatePromise;
    }
    job.controller.abort();
    this.terminatePromise = job.finished.catch(() => undefined);
    return this.terminatePromise;
  }
}

export function createMetalWorkerFactory(options: MetalWorkerOptions = {}): WorkerFactory {
  if (options.batchSize !== undefined && !isSafeInteger(options.batchSize, 1, METAL_BATCH_SIZE_MAX)) {
    throw new ChainError("INVALID_SCHEMA", `Metal batch size must be between 1 and ${METAL_BATCH_SIZE_MAX}`);
  }
  return () => new MetalWorkerHandle(options);
}

// Startup check compiles and executes the Metal kernel on the selected GPU. It
// independently compares the first returned nonce with Node's SHA-256, so an
// available device with a broken shader does not pass preflight.
export async function preflightMetal(options: RunMetalJobOptions = {}): Promise<MetalJobResult> {
  const prefixBytes = Buffer.from("metal-proof-of-work-preflight:", "utf8");
  const suffixBytes = Buffer.from(":sha256", "utf8");
  const prefix = prefixBytes.toString("base64");
  const suffix = suffixBytes.toString("base64");
  let expectedNonce = 0;
  while (expectedNonce < 1_000 && !nodeHash(Buffer.concat([
    prefixBytes,
    Buffer.from(String(expectedNonce), "ascii"),
    suffixBytes,
  ])).startsWith("0")) {
    expectedNonce += 1;
  }
  if (expectedNonce === 1_000) {
    throw new ChainError("INTERNAL", "Metal preflight could not prepare a deterministic proof");
  }
  const result = await runMetalJob({
    prefix, suffix, difficulty: 1, startNonce: 0, stride: 1,
    batchSize: METAL_BATCH_SIZE_MAX, maxNonces: expectedNonce + 1,
  }, options);
  if (result.nonce !== expectedNonce) {
    throw new ChainError("INTERNAL", "Metal GPU did not match the CPU SHA-256 preflight vector");
  }
  return result;
}
