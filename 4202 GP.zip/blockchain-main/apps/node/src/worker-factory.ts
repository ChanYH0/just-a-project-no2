// Real worker factories: start mine-worker.ts and validation-worker.ts in worker_threads (SPEC section 9).
// Shared sources use `.js` import specifiers for `.ts` files, so each worker starts through worker-bootstrap.mjs,
// which registers the tsx loader inside the worker thread.

import { Worker } from "node:worker_threads";
import { DEFAULT_MINING_WORKERS } from "./mining-config.js";
import type { MineWorkerHandle, WorkerFactory, WorkerHandlers } from "./mine-protocol.js";
import type { ValidationWorkerFactory, ValidationWorkerHandle } from "./validation-protocol.js";
import { createWorkerPool } from "./worker-pool.js";

interface RawHandle<Message> {
  setHandlers(handlers: WorkerHandlers): void;
  postMessage(message: Message): void;
  terminate(): Promise<void>;
}

const BOOTSTRAP_URL = new URL("./worker-bootstrap.mjs", import.meta.url);

function startWorker<Message>(workerUrl: URL): RawHandle<Message> {
  const worker = new Worker(BOOTSTRAP_URL, { workerData: { entry: workerUrl.href } });
  return {
    setHandlers(handlers) {
      worker.on("message", (message: unknown) => handlers.onMessage(message));
      worker.on("error", (error: Error) => handlers.onError(error));
      worker.on("exit", (code: number) => handlers.onExit(code));
    },
    postMessage(message) {
      worker.postMessage(message);
    },
    async terminate() {
      await worker.terminate();
    },
  };
}

export function createRealWorkerFactory(workerCount = DEFAULT_MINING_WORKERS): WorkerFactory {
  const workerUrl = new URL("./mine-worker.ts", import.meta.url);
  const singleWorkerFactory: WorkerFactory = (): MineWorkerHandle => startWorker(workerUrl);
  return workerCount === 1 ? singleWorkerFactory : createWorkerPool(singleWorkerFactory, workerCount);
}

export function createRealValidationWorkerFactory(): ValidationWorkerFactory {
  const workerUrl = new URL("./validation-worker.ts", import.meta.url);
  return (): ValidationWorkerHandle => startWorker(workerUrl);
}
