// In-memory confirmed chain: blocks, state index, record index and the Q1/Q2 query indexes (SPEC sections 7, 10).
// Only the miner's persist step appends (invariant I5); boot builds it from an already validated chain.

import {
  applyBlockToState,
  canonicalize,
  emptyState,
  recordId,
  type Block,
  type ChainState,
  type HashFn,
} from "@conference-chain/shared";

// Bytes the persist step writes for a block: canonicalize(block) + "\n" in UTF-8.
function lineBytes(block: Block): number {
  return Buffer.byteLength(`${canonicalize(block)}\n`, "utf8");
}

export interface AttendeeSession {
  sessionId: string;
  timestamp: number;
  blockIndex: number;
}

export interface SessionAttendee {
  attendeeId: string;
  timestamp: number;
  blockIndex: number;
}

export class Ledger {
  readonly blocks: Block[] = [];
  readonly state: ChainState = emptyState();
  // recordId -> index of the block that contains it
  private readonly confirmed = new Map<string, number>();
  private readonly byAttendee = new Map<string, AttendeeSession[]>();
  private readonly bySession = new Map<string, SessionAttendee[]>();

  // Bytes of chain.jsonl that belong to committed (in-memory) blocks. The /chain/validate read bound: bytes beyond it
  // are an append in flight (or an external edit) and are never part of a snapshot.
  private committedBytes = 0;
  private readonly commitListeners: (() => void)[] = [];

  constructor(private readonly hash: HashFn) {}

  // `bootFileSize` is the size of the file the blocks were loaded from (it need not be byte-canonical); when omitted
  // the canonical line sizes are summed.
  static fromBlocks(blocks: readonly Block[], hash: HashFn, bootFileSize?: number): Ledger {
    const ledger = new Ledger(hash);
    for (const block of blocks) {
      ledger.apply(block);
      ledger.committedBytes += lineBytes(block);
    }
    if (bootFileSize !== undefined) {
      ledger.committedBytes = bootFileSize;
    }
    return ledger;
  }

  get committedSize(): number {
    return this.committedBytes;
  }

  // Called after every committed append (after the in-memory update), for example to clear result caches.
  onCommit(listener: () => void): void {
    this.commitListeners.push(listener);
  }

  get head(): Block {
    const head = this.blocks.at(-1);
    if (head === undefined) {
      throw new Error("ledger has no genesis block");
    }
    return head;
  }

  // Synchronous: callers invoke it inside one critical section after the block is on disk.
  append(block: Block): void {
    this.apply(block);
    this.committedBytes += lineBytes(block);
    for (const listener of this.commitListeners) {
      listener();
    }
  }

  private apply(block: Block): void {
    applyBlockToState(this.state, block);
    this.blocks.push(block);
    for (const record of block.records) {
      this.confirmed.set(recordId(record, this.hash), block.index);
      const payload = record.payload;
      if (payload.type === "attend") {
        const sessions = this.byAttendee.get(payload.attendeeId) ?? [];
        sessions.push({ sessionId: payload.sessionId, timestamp: payload.timestamp, blockIndex: block.index });
        this.byAttendee.set(payload.attendeeId, sessions);
        const attendees = this.bySession.get(payload.sessionId) ?? [];
        attendees.push({ attendeeId: payload.attendeeId, timestamp: payload.timestamp, blockIndex: block.index });
        this.bySession.set(payload.sessionId, attendees);
      }
    }
  }

  confirmedBlockIndex(id: string): number | undefined {
    return this.confirmed.get(id);
  }

  confirmedIds(): ReadonlySet<string> {
    return new Set(this.confirmed.keys());
  }

  sessionsOfAttendee(attendeeId: string): readonly AttendeeSession[] {
    return this.byAttendee.get(attendeeId) ?? [];
  }

  attendeesOfSession(sessionId: string): readonly SessionAttendee[] {
    return this.bySession.get(sessionId) ?? [];
  }

  // True if any attendance record for the session is on chain.
  sessionOnChain(sessionId: string): boolean {
    return this.bySession.has(sessionId);
  }
}
