// Execution settings only: these do not change block contents or consensus rules.
export const MINING_BACKENDS = ["cpu", "metal"] as const;
export type MiningBackend = (typeof MINING_BACKENDS)[number];
export const DEFAULT_MINING_BACKEND: MiningBackend = "cpu";
export const DEFAULT_MINING_WORKERS = 1;
export const MINING_WORKERS_MAX = 32;
export const DEFAULT_METAL_BATCH_SIZE = 16_384;
export const METAL_BATCH_SIZE_MAX = 65_536;
