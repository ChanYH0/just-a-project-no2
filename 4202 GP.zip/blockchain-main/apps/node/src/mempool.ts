// Mempool record table (SPEC section 9, record lifecycle). Memory only. Every method is synchronous, so each
// transition is one atomic critical section. States: pending, reserved(jobId) (live, in `live`), confirmed (counted
// here, derived from the ledger for lookups), expired and rejected(code) (terminal, bounded LRU).

import {
  addRecordToUniquenessIndex,
  attendanceKey,
  emptyUniquenessIndex,
  type ChainRecord,
  type ChainState,
  type ErrorCode,
  type MempoolIndex,
} from "@conference-chain/shared";

export type LiveStatus = "pending" | "reserved";

export interface LiveEntry {
  id: string;
  record: ChainRecord;
  // TTL is counted from admission time.
  admittedAt: number;
  status: LiveStatus;
  jobId: number | null;
}

export interface TerminalEntry {
  status: "expired" | "rejected";
  code?: ErrorCode;
}

export interface MempoolCounts {
  pending: number;
  reserved: number;
  confirmed: number;
  expired: number;
  rejected: number;
  // epochs whose terminal status was dropped from the LRU (eviction, or superseded by a re-admission)
  retired: number;
  admitted: number;
}

export class Mempool {
  // Map insertion order is admission order (FIFO).
  private readonly live = new Map<string, LiveEntry>();
  private readonly terminal = new Map<string, TerminalEntry>();
  // Uniqueness index over live (pending + reserved) records; duplicates are rejected while mining.
  readonly index: MempoolIndex = emptyUniquenessIndex();
  private admitted = 0;
  private confirmedEpochs = 0;
  private retired = 0;

  constructor(
    private readonly terminalLimit: number,
    private readonly ttlMs: number,
  ) {}

  get size(): number {
    return this.live.size;
  }

  getLive(id: string): LiveEntry | undefined {
    return this.live.get(id);
  }

  getTerminal(id: string): TerminalEntry | undefined {
    return this.terminal.get(id);
  }

  liveEntries(): LiveEntry[] {
    return [...this.live.values()];
  }

  pendingEntries(): LiveEntry[] {
    return [...this.live.values()].filter((entry) => entry.status === "pending");
  }

  pendingCount(): number {
    let count = 0;
    for (const entry of this.live.values()) {
      if (entry.status === "pending") {
        count += 1;
      }
    }
    return count;
  }

  // Sync uniqueness re-check right before an insert (SPEC section 7). Mirrors the two uniqueness rules of the shared
  // validators, against confirmed state UNION the live index.
  uniquenessViolation(record: ChainRecord, state: ChainState): ErrorCode | null {
    const payload = record.payload;
    if (payload.type === "register") {
      const taken = state.registrations.has(payload.attendeeId) || this.index.registrations.has(payload.attendeeId);
      return taken ? "KEY_ALREADY_REGISTERED" : null;
    }
    const key = attendanceKey(payload.attendeeId, payload.sessionId);
    const taken = state.attendance.has(key) || this.index.attendance.has(key);
    return taken ? "DUPLICATE_ATTENDANCE" : null;
  }

  // none -> pending. A terminal entry of the same id (expired or rejected) is replaced: a new epoch of the same id.
  admit(id: string, record: ChainRecord, now: number): void {
    if (this.live.has(id)) {
      throw new Error("mempool: id is already live");
    }
    if (this.terminal.delete(id)) {
      this.retired += 1;
    }
    this.live.set(id, { id, record, admittedAt: now, status: "pending", jobId: null });
    addRecordToUniquenessIndex(this.index, record);
    this.admitted += 1;
  }

  // pending -> reserved(jobId)
  reserve(id: string, jobId: number): void {
    const entry = this.live.get(id);
    if (entry === undefined || entry.status !== "pending") {
      throw new Error("mempool: reserve needs a pending record");
    }
    entry.status = "reserved";
    entry.jobId = jobId;
  }

  // reserved(jobId) -> pending for every record of the job. Returns the ids released.
  releaseJob(jobId: number): string[] {
    const released: string[] = [];
    for (const entry of this.live.values()) {
      if (entry.status === "reserved" && entry.jobId === jobId) {
        entry.status = "pending";
        entry.jobId = null;
        released.push(entry.id);
      }
    }
    return released;
  }

  // reserved(jobId) -> pending for one record (step 6 re-check).
  releaseOne(id: string): void {
    const entry = this.live.get(id);
    if (entry === undefined || entry.status !== "reserved") {
      throw new Error("mempool: release needs a reserved record");
    }
    entry.status = "pending";
    entry.jobId = null;
  }

  // pending -> expired
  expire(id: string): void {
    this.toTerminal(id, { status: "expired" }, "pending");
  }

  // pending -> rejected(code) at candidate build, or reserved -> rejected(code) at step 6 re-validation
  reject(id: string, code: ErrorCode): void {
    this.toTerminal(id, { status: "rejected", code }, null);
  }

  // reserved -> confirmed: leaves the mempool; confirmed status is derived from the ledger.
  confirm(ids: readonly string[]): void {
    for (const id of ids) {
      const entry = this.live.get(id);
      if (entry === undefined || entry.status !== "reserved") {
        throw new Error("mempool: confirm needs reserved records");
      }
      this.removeLive(entry);
      this.confirmedEpochs += 1;
    }
  }

  // Only pending records expire; reserved records are never expired while their job runs.
  sweep(now: number): string[] {
    const expired: string[] = [];
    for (const entry of this.pendingEntries()) {
      if (now - entry.admittedAt > this.ttlMs) {
        this.expire(entry.id);
        expired.push(entry.id);
      }
    }
    return expired;
  }

  counts(): MempoolCounts {
    let expired = 0;
    let rejected = 0;
    for (const entry of this.terminal.values()) {
      if (entry.status === "expired") {
        expired += 1;
      } else {
        rejected += 1;
      }
    }
    const pending = this.pendingCount();
    return {
      pending,
      reserved: this.live.size - pending,
      confirmed: this.confirmedEpochs,
      expired,
      rejected,
      retired: this.retired,
      admitted: this.admitted,
    };
  }

  terminalIds(): string[] {
    return [...this.terminal.keys()];
  }

  // Index consistency for assertInvariants: the index must equal the one rebuilt from the live entries.
  indexMatchesLive(): boolean {
    const rebuilt = emptyUniquenessIndex();
    for (const entry of this.live.values()) {
      addRecordToUniquenessIndex(rebuilt, entry.record);
    }
    const same = (a: ReadonlySet<string>, b: ReadonlySet<string>): boolean =>
      a.size === b.size && [...a].every((value) => b.has(value));
    return same(rebuilt.registrations, this.index.registrations) && same(rebuilt.attendance, this.index.attendance);
  }

  private toTerminal(id: string, terminal: TerminalEntry, requiredStatus: LiveStatus | null): void {
    const entry = this.live.get(id);
    if (entry === undefined || (requiredStatus !== null && entry.status !== requiredStatus)) {
      throw new Error("mempool: terminal transition from an unexpected state");
    }
    this.removeLive(entry);
    this.terminal.set(id, terminal);
    while (this.terminal.size > this.terminalLimit) {
      const oldest = this.terminal.keys().next();
      if (oldest.done === true) {
        break;
      }
      this.terminal.delete(oldest.value);
      this.retired += 1;
    }
  }

  private removeLive(entry: LiveEntry): void {
    this.live.delete(entry.id);
    const payload = entry.record.payload;
    if (payload.type === "register") {
      this.index.registrations.delete(payload.attendeeId);
    } else {
      this.index.attendance.delete(attendanceKey(payload.attendeeId, payload.sessionId));
    }
  }
}
