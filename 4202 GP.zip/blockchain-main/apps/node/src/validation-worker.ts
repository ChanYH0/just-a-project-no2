// Validation worker (SPEC sections 8 and 9). Receives ONE message { jobId, job }, runs it to completion and posts
// { jobId, outcome } (or { jobId, error } with a fixed text if the job threw). Cancellation (timeout) is done by the
// main thread through worker.terminate().

import { parentPort } from "node:worker_threads";
import { runJob } from "./validation-jobs.js";
import { JobMessageSchema, type ValidationResultMessage } from "./validation-protocol.js";

if (parentPort === null) {
  throw new Error("validation-worker must run inside a worker thread");
}
const port = parentPort;

port.once("message", (raw: unknown) => {
  const message = JobMessageSchema.safeParse(raw);
  if (!message.success) {
    throw new Error("validation-worker: malformed job message");
  }
  const { jobId, job } = message.data;
  runJob(job).then(
    (outcome) => {
      const result: ValidationResultMessage = { jobId, outcome };
      port.postMessage(result);
    },
    () => {
      const result: ValidationResultMessage = { jobId, error: "validation job failed" };
      port.postMessage(result);
    },
  );
});
