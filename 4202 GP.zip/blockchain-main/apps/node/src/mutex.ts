// Async mutex: the single writer lock (SPEC section 9). Mempool admission and block append are serialized under it.

export class Mutex {
  private tail: Promise<void> = Promise.resolve();

  run<T>(task: () => Promise<T>): Promise<T> {
    const result = this.tail.then(task);
    // The tail must continue after a failed task; the failure itself is delivered through `result`.
    this.tail = result.then(
      () => undefined,
      () => undefined,
    );
    return result;
  }
}
