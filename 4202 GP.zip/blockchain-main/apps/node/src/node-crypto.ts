// The node's ChainCrypto bundle. Defined once; imported by the HTTP app and by the validation worker.

import { nodeHash, nodeIdentityCrypto, type ChainCrypto } from "@conference-chain/shared";

export const nodeCrypto: ChainCrypto = { identity: nodeIdentityCrypto, hash: nodeHash };
