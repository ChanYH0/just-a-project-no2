// Compile the optional Apple Metal proof-of-work helper without shell interpolation.
import { mkdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

if (process.platform !== "darwin" || process.arch !== "arm64") {
  process.stderr.write("build-metal: Apple Silicon macOS with Xcode tools is required\n");
  process.exit(1);
}

const nodeDir = new URL("../", import.meta.url);
const nativeDir = new URL("../native/", import.meta.url);
const outputDir = new URL("../native/build/", import.meta.url);
const source = fileURLToPath(new URL("metal-pow.swift", nativeDir));
const binary = fileURLToPath(new URL("build/metal-pow", nativeDir));
await mkdir(outputDir, { recursive: true });
const child = spawnSync("xcrun", ["swiftc", "-O", "-parse-as-library", "-framework", "Metal", "-framework", "Foundation", "-o", binary, source], {
  cwd: fileURLToPath(nodeDir),
  stdio: "inherit",
});
if (child.error !== undefined) {
  process.stderr.write("build-metal: xcrun could not be started\n");
  process.exit(1);
}
if (child.status !== 0) {
  process.stderr.write("build-metal: Swift or Metal compilation failed\n");
  process.exit(child.status ?? 1);
}
process.stdout.write(`${binary}\n`);
