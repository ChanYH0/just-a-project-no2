// Explicit, bounded profiler runs; no chain store, HTTP writes, or private keys are persisted.
import { Worker } from "node:worker_threads";
import { mkdtemp, mkdir, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { performance } from "node:perf_hooks";
import { z } from "zod";
import {
  MAX_RECORDS_PER_BLOCK, deriveAttendeeId, deriveChainId, getProfile,
  makeGenesis, nodeHash, nodeIdentityCrypto, signPayload, type BlockCandidate,
  type SignedRegistration,
} from "@conference-chain/shared";
import { makeMetalTemplate } from "../src/metal-template.js";
import { runMetalJob } from "../src/metal-worker-factory.js";
import { DEFAULT_METAL_BATCH_SIZE, MINING_WORKERS_MAX } from "../src/mining-config.js";

function integer(name: string, defaultValue: number, min: number, max: number): number {
  const raw = process.env[name];
  const value = raw === undefined ? defaultValue : Number(raw);
  if ((raw !== undefined && !/^(0|[1-9][0-9]*)$/.test(raw)) || !Number.isSafeInteger(value) || value < min || value > max) {
    throw new Error(`${name} must be an integer in ${min}..${max}`);
  }
  return value;
}
function counts(name: string, defaults: readonly number[]): number[] {
  const values = process.env[name]?.split(",").map(Number) ?? [...defaults];
  if (values.length === 0 || values.some((value) => !Number.isSafeInteger(value) || value < 1 || value > MINING_WORKERS_MAX)) {
    throw new Error(`${name} contains an invalid worker count`);
  }
  return [...new Set(values)];
}
const attempts = integer("PROFILE_ATTEMPTS", 65_536, 1, 1_000_000);
const recordCount = integer("PROFILE_RECORDS", 1, 0, MAX_RECORDS_PER_BLOCK);
const outputRoot = resolve(process.env["PROFILE_OUTPUT_ROOT"] ?? "../../evidence");
await mkdir(outputRoot, { recursive: true });
const output = await mkdtemp(join(outputRoot, "pow-profile-"));
const config = getProfile("demo", "profiler-demo");
const records: SignedRegistration[] = [];
for (let i = 0; i < recordCount; i += 1) {
  const key = await nodeIdentityCrypto.generateKeyPair();
  const payload: SignedRegistration["payload"] = {
    type: "register", chainId: deriveChainId(config, nodeHash),
    attendeeId: await deriveAttendeeId(key.publicKey, nodeIdentityCrypto),
    alias: `profiler-${i}`, publicKey: key.publicKey, timestamp: Date.now(),
  };
  records.push({ payload, signature: await signPayload(payload, key.privateKey, nodeIdentityCrypto) });
}
// Difficulty 64 forces the full bounded workload; these are diagnostic bytes, never a submitted candidate.
const candidate: BlockCandidate = {
  index: 1, timestamp: Date.now(), previousHash: makeGenesis(config, nodeHash).hash,
  difficulty: 64, records,
};
const readyMessage = z.object({ type: z.literal("ready") }).strict();
const doneMessage = z.object({ type: z.literal("done"), attempts: z.number().int().positive(), elapsedMs: z.number().nonnegative(), checksum: z.number().int().nonnegative() }).strict();
const timedMessage = doneMessage.extend({ type: z.literal("timed") });
const results: unknown[] = [];

for (const workerCount of counts("PROFILE_CPU_WORKERS", [1, 2, 4])) {
  const active: Worker[] = [];
  try {
    const setupStarted = performance.now();
    const ready: Promise<void>[] = [];
    const timed: Promise<z.infer<typeof timedMessage>>[] = [];
    const completed: Promise<z.infer<typeof doneMessage>>[] = [];
    for (let lane = 0; lane < workerCount; lane += 1) {
      const count = Math.floor(attempts / workerCount) + (lane < attempts % workerCount ? 1 : 0);
      if (count === 0) continue;
      const worker = new Worker(new URL("../src/worker-bootstrap.mjs", import.meta.url), { workerData: {
        entry: new URL("./profile-cpu-worker.ts", import.meta.url).href,
        candidate, start: lane, stride: workerCount, count,
        profilePath: join(output, `cpu-${workerCount}-lane-${lane}.cpuprofile`),
      } });
      active.push(worker);
      let readyResolve: () => void = () => undefined;
      let readyReject: (error: Error) => void = () => undefined;
      let timedResolve: (result: z.infer<typeof timedMessage>) => void = () => undefined;
      let timedReject: (error: Error) => void = () => undefined;
      ready.push(new Promise<void>((resolve, reject) => { readyResolve = resolve; readyReject = reject; }));
      timed.push(new Promise((resolve, reject) => { timedResolve = resolve; timedReject = reject; }));
      completed.push(new Promise((resolve, reject) => {
        let done = false;
        worker.on("message", (raw: unknown) => {
          if (readyMessage.safeParse(raw).success) { readyResolve(); return; }
          const measured = timedMessage.safeParse(raw);
          if (measured.success) { timedResolve(measured.data); return; }
          const parsed = doneMessage.safeParse(raw);
          if (!parsed.success) { const error = new Error("malformed profiler worker result"); readyReject(error); timedReject(error); reject(error); return; }
          done = true;
          resolve(parsed.data);
        });
        worker.on("error", (error) => { readyReject(error); timedReject(error); reject(error); });
        worker.on("exit", () => { if (!done) { const error = new Error("profiler worker exited early"); readyReject(error); timedReject(error); reject(error); } });
      }));
    }
    const allDone = Promise.all(completed);
    const allTimed = Promise.all(timed);
    // Install a rejection handler before waiting for readiness, including failed worker startup.
    void allDone.catch(() => undefined);
    void allTimed.catch(() => undefined);
    await Promise.all(ready);
    const setupMs = performance.now() - setupStarted;
    const started = performance.now();
    active.forEach((worker) => worker.postMessage("go"));
    await allTimed;
    const workMs = performance.now() - started;
    active.forEach((worker) => worker.postMessage("profile"));
    const lanes = await allDone;
    const wallMs = setupMs + workMs;
    results.push({ backend: "cpu", workers: workerCount, attempts: lanes.reduce((sum, item) => sum + item.attempts, 0), setupMs, workMs, wallMs, hashesPerSecond: attempts / wallMs * 1000, workHashesPerSecond: attempts / workMs * 1000, lanes });
  } finally {
    await Promise.all(active.map((worker) => worker.terminate()));
  }
}
const template = makeMetalTemplate(candidate);
for (const workerCount of counts("PROFILE_GPU_WORKERS", [1, 2])) {
  const started = performance.now();
  const gpuRequest = (lane: number) => {
    const count = Math.floor(attempts / workerCount) + (lane < attempts % workerCount ? 1 : 0);
    return { prefix: template.prefix.toString("base64"), suffix: template.suffix.toString("base64"),
      difficulty: candidate.difficulty, startNonce: lane, stride: workerCount,
      batchSize: DEFAULT_METAL_BATCH_SIZE, maxNonces: count };
  };
  const lanes = await Promise.all(Array.from({ length: workerCount }, async (_, lane) => {
    const request = gpuRequest(lane);
    return request.maxNonces === 0 ? null : runMetalJob(request);
  }));
  const wallMs = performance.now() - started;
  const captures = await Promise.all(Array.from({ length: workerCount }, async (_, lane) => {
    const request = gpuRequest(lane);
    return request.maxNonces === 0 ? null : runMetalJob({ ...request, capturePath: join(output, `metal-${workerCount}-lane-${lane}.gputrace`) });
  }));
  results.push({ backend: "metal", workers: workerCount, attempts, wallMs, hashesPerSecond: attempts / wallMs * 1000, lanes, captures });
}
await writeFile(join(output, "summary.json"), JSON.stringify({
  workload: { attempts, recordCount, prefixBytes: template.prefix.length, suffixBytes: template.suffix.length },
  note: "Timing passes are unprofiled; CPU traces and Metal captures come from separate passes. CPU includes production canonical serialization; Metal uses precomputed canonical prefix/suffix. Wall time includes worker/helper startup. No speed threshold is asserted.",
  results,
}, null, 2) + "\n");
process.stdout.write(JSON.stringify({ output, results }) + "\n");
