// Diagnostic hashing workload. This never appends a block or changes live node state.
import { parentPort, workerData } from "node:worker_threads";
import { Session } from "node:inspector/promises";
import { writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";
import { z } from "zod";
import { Block, NonNegativeInt, PositiveInt, computeBlockHash, nodeHash } from "@conference-chain/shared";

const Input = z.object({
  entry: z.string(), candidate: Block.omit({ hash: true, nonce: true }),
  start: NonNegativeInt, stride: PositiveInt, count: PositiveInt, profilePath: z.string().min(1),
}).strict();
const input = Input.parse(workerData);
if (parentPort === null) throw new Error("profiling workload needs a worker thread");
const port = parentPort;
port.postMessage({ type: "ready" });
await new Promise<void>((resolve) => port.once("message", () => resolve()));
function hashRange(): number {
  let checksum = 0;
  for (let i = 0; i < input.count; i += 1) {
    const nonce = input.start + i * input.stride;
    if (!Number.isSafeInteger(nonce)) throw new Error("profiling nonce range exhausted");
    const digest = computeBlockHash({ ...input.candidate, nonce }, nodeHash);
    checksum = (checksum ^ Number.parseInt(digest.slice(0, 8), 16)) >>> 0;
  }
  return checksum;
}
const started = performance.now();
const checksum = hashRange();
const elapsedMs = performance.now() - started;
port.postMessage({ type: "timed", attempts: input.count, elapsedMs, checksum });
// A barrier prevents a fast lane's profiler pass from competing with slower timed lanes.
await new Promise<void>((resolve) => port.once("message", () => resolve()));
const session = new Session();
session.connect();
await session.post("Profiler.enable");
await session.post("Profiler.start");
if (hashRange() !== checksum) throw new Error("profiling workload checksum changed");
const { profile } = await session.post("Profiler.stop");
session.disconnect();
await writeFile(input.profilePath, JSON.stringify(profile));
port.postMessage({ type: "done", attempts: input.count, elapsedMs, checksum });
