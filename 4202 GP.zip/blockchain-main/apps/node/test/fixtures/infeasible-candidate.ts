// A block candidate whose proof of work can never complete in test time (difficulty 64 = a full SHA-256 of zeros).
// Used only by tests, only through Miner.startJob.

import type { Block, BlockCandidate } from "@conference-chain/shared";

export const INFEASIBLE_DIFFICULTY = 64;

export function infeasibleCandidate(head: Block): BlockCandidate {
  return {
    index: head.index + 1,
    timestamp: head.timestamp,
    previousHash: head.hash,
    difficulty: INFEASIBLE_DIFFICULTY,
    records: [],
  };
}
