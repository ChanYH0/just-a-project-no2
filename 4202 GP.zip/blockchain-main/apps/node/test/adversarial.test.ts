// Adversarial scenarios A1-A9 (SPEC 14.3, THREAT_MODEL section 8) end to end through the HTTP surface and the shared
// validator. Cases already covered elsewhere are not repeated; the comments name where they live:
//   A1 concurrent duplicates ........ duplicates.test.ts (identical concurrent attendance)
//   A5 1-block chain / other profile  restart.test.ts
//   A7 rehash-after-edit ............ rc11-mutations.test.ts and packages/shared/test/rc3-*.test.ts
//   A9 timestamp order in shared .... packages/shared/test/rc7-timestamps.test.ts

import { readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import {
  canonicalize,
  computeBlockHash,
  makeGenesis,
  mineBlock,
  nodeHash,
  validateChain,
  type Block,
} from "@conference-chain/shared";
import { BootError } from "../src/boot-error.js";
import { nodeCrypto } from "../src/node-crypto.js";
import { TEST_CONFIG, attend, getKeys, makeDataDir, makeHarness, register, TestClock, type Harness, type TestKeys } from "./support.js";
import { CHAIN_LENGTH, LIVE_HEAD, buildLiveChain, errorCode, expectLiveUnchanged, snapshotLive, tamper } from "./tamper-support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let live: Harness[] = [];
const dirs: string[] = [];

beforeAll(async () => {
  keys = await getKeys(4);
});
afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

function key(index: number): TestKeys {
  const value = keys[index];
  if (value === undefined) {
    throw new Error("missing key");
  }
  return value;
}

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  const harness = await makeHarness({ enableDemoRoutes: true, ...options });
  live.push(harness);
  return harness;
}

async function freshDir(): Promise<string> {
  const dir = await makeDataDir();
  dirs.push(dir);
  return dir;
}

async function bootError(dataDir: string, clock: TestClock): Promise<BootError> {
  try {
    await boot({ dataDir, clock, keepDir: true });
  } catch (error) {
    expect(error).toBeInstanceOf(BootError);
    return error as BootError;
  }
  throw new Error("boot unexpectedly succeeded");
}

function chainLines(blocks: readonly Block[]): string {
  return blocks.map((block) => `${canonicalize(block)}\n`).join("");
}

function mined(index: number, timestamp: number, previousHash: string, difficulty: number): Block {
  const block = mineBlock({ index, timestamp, previousHash, difficulty, records: [] }, nodeHash);
  if (block === null) {
    throw new Error("mining failed");
  }
  return block;
}

function validateLive(harness: Harness, blocks: readonly Block[]): ReturnType<typeof validateChain> {
  return validateChain(blocks, harness.node.settings.config, nodeCrypto);
}

describe("A1: duplicate attendance", () => {
  async function registered(): Promise<Harness> {
    const harness = await boot();
    expect((await harness.post("/registrations", await register(key(0), harness.clock.now(), "alice", harness.node.chainId))).status).toBe(202);
    await harness.mineNow();
    return harness;
  }

  it("sequential identical submissions: exactly one 202, the rest 409 DUPLICATE_ATTENDANCE", async () => {
    const harness = await registered();
    const statuses: number[] = [];
    const codes: unknown[] = [];
    for (let i = 0; i < 4; i += 1) {
      const response = await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId));
      statuses.push(response.status);
      codes.push(errorCode(response.body));
    }
    expect(statuses).toEqual([202, 409, 409, 409]);
    expect(codes.slice(1)).toEqual(Array<unknown>(3).fill("DUPLICATE_ATTENDANCE"));
  });

  it("the same pair with a different timestamp or fresh signature is still a duplicate", async () => {
    const harness = await registered();
    expect((await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId))).status).toBe(202);
    harness.clock.advance(10);
    const again = await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId));
    expect(again.status).toBe(409);
    expect(errorCode(again.body)).toBe("DUPLICATE_ATTENDANCE");
  });

  it("concurrent identical submissions: exactly one 202 (see also duplicates.test.ts)", async () => {
    const harness = await registered();
    const body = await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId);
    const responses = await Promise.all(Array.from({ length: 8 }, () => harness.post("/attendance", body)));
    expect(responses.filter((r) => r.status === 202)).toHaveLength(1);
    for (const response of responses.filter((r) => r.status !== 202)) {
      expect(response.status).toBe(409);
      expect(errorCode(response.body)).toBe("DUPLICATE_ATTENDANCE");
    }
  });

  it("rejected after confirmation too, and the chain holds the pair once", async () => {
    const harness = await registered();
    expect((await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId))).status).toBe(202);
    await harness.mineNow();
    const late = await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId));
    expect(late.status).toBe(409);
    expect(errorCode(late.body)).toBe("DUPLICATE_ATTENDANCE");
    const attendances = harness.node.ledger.blocks.flatMap((block) => block.records).filter((r) => r.payload.type === "attend");
    expect(attendances).toHaveLength(1);
  });
});

describe("A2: altered signed payloads are rejected", () => {
  async function twoRegistered(): Promise<Harness> {
    const harness = await boot();
    for (const [index, alias] of [[0, "alice"], [1, "bob"]] as const) {
      expect((await harness.post("/registrations", await register(key(index), harness.clock.now(), alias, harness.node.chainId))).status).toBe(202);
    }
    await harness.mineNow();
    return harness;
  }

  async function expectRejected(harness: Harness, url: string, body: unknown, code: string): Promise<void> {
    const pendingBefore = (await harness.get("/mempool")).body;
    const response = await harness.post(url, body);
    expect(response.status).toBeGreaterThanOrEqual(400);
    expect(response.status).toBeLessThan(500);
    expect(errorCode(response.body)).toBe(code);
    expect((await harness.get("/mempool")).body).toEqual(pendingBefore);
  }

  it("attendance: sessionId or timestamp changed after signing -> INVALID_SIGNATURE", async () => {
    const harness = await twoRegistered();
    const signed = await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId);
    await expectRejected(harness, "/attendance", { ...signed, payload: { ...signed.payload, sessionId: "workshop" } }, "INVALID_SIGNATURE");
    await expectRejected(harness, "/attendance", { ...signed, payload: { ...signed.payload, timestamp: signed.payload.timestamp + 1 } }, "INVALID_SIGNATURE");
  });

  it("attendance: attendeeId swapped to another registered attendee -> INVALID_SIGNATURE; to an unregistered one -> ATTENDEE_NOT_REGISTERED", async () => {
    const harness = await twoRegistered();
    const signed = await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId);
    await expectRejected(harness, "/attendance", { ...signed, payload: { ...signed.payload, attendeeId: key(1).attendeeId } }, "INVALID_SIGNATURE");
    await expectRejected(harness, "/attendance", { ...signed, payload: { ...signed.payload, attendeeId: key(2).attendeeId } }, "ATTENDEE_NOT_REGISTERED");
  });

  it("registration: attendeeId changed -> ATTENDEE_ID_MISMATCH; alias or timestamp changed -> INVALID_SIGNATURE", async () => {
    const harness = await boot();
    const signed = await register(key(0), harness.clock.now(), "alice", harness.node.chainId);
    await expectRejected(harness, "/registrations", { ...signed, payload: { ...signed.payload, attendeeId: key(1).attendeeId } }, "ATTENDEE_ID_MISMATCH");
    await expectRejected(harness, "/registrations", { ...signed, payload: { ...signed.payload, alias: "alicf" } }, "INVALID_SIGNATURE");
    await expectRejected(harness, "/registrations", { ...signed, payload: { ...signed.payload, timestamp: signed.payload.timestamp + 1 } }, "INVALID_SIGNATURE");
  });

  it("a signature copied from another record never validates (bit flip in the signature)", async () => {
    const harness = await twoRegistered();
    const signed = await attend(key(0), "keynote", harness.clock.now(), harness.node.chainId);
    const flipped = `${signed.signature.slice(0, -2)}${signed.signature.endsWith("A") ? "B" : "A"}${signed.signature.slice(-1)}`;
    const response = await harness.post("/attendance", { ...signed, signature: flipped });
    expect(response.status).toBeGreaterThanOrEqual(400);
    expect(response.status).toBeLessThan(500);
  });

  it("a different chainId -> CHAIN_ID_MISMATCH (registration and attendance)", async () => {
    const harness = await twoRegistered();
    await expectRejected(harness, "/registrations", await register(key(2), harness.clock.now(), "carol", "f".repeat(64)), "CHAIN_ID_MISMATCH");
    await expectRejected(harness, "/attendance", await attend(key(0), "keynote", harness.clock.now(), "f".repeat(64)), "CHAIN_ID_MISMATCH");
  });
});

describe("A3: edited blocks are detected at the right index", () => {
  it("tamper-check edit-record -> BAD_BLOCK_HASH and edit-previous-hash -> BAD_PREVIOUS_HASH, for every block", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const before = await snapshotLive(harness);
    for (let index = 1; index <= LIVE_HEAD; index += 1) {
      expect((await tamper(harness, "edit-record", index)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: index });
      expect((await tamper(harness, "edit-previous-hash", index)).body).toMatchObject({ ok: false, code: "BAD_PREVIOUS_HASH", blockIndex: index });
    }
    await expectLiveUnchanged(harness, before);
  });

  it("an edited stored hash on a copy of the live chain -> BAD_BLOCK_HASH at that block (shared validateChain)", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const original = harness.node.ledger.blocks.slice();
    expect(await validateLive(harness, original)).toEqual({ ok: true });
    for (let index = 1; index < original.length; index += 1) {
      const copy = original.slice();
      const block = copy[index] as Block;
      copy[index] = { ...block, hash: `${block.hash.slice(0, -1)}${block.hash.endsWith("0") ? "1" : "0"}` };
      expect(await validateLive(harness, copy), `block ${index}`).toEqual({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: index });
    }
  });

  it("a byte edited on disk is reported by GET /chain/validate with code and index", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const path = join(harness.dataDir, "chain.jsonl");
    const text = await readFile(path, "utf8");
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    await writeFile(path, text.replace('"alias":"bob"', '"alias":"bac"'));
    harness.heavyRateClock.advance(60_001);
    expect((await harness.get("/chain/validate")).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 4 });
  });
});

describe("A4: difficulty and proof of work", () => {
  it("lower-difficulty over HTTP -> BAD_DIFFICULTY at the block", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (const index of [4, 5, 6]) {
      expect((await tamper(harness, "lower-difficulty", index)).body).toMatchObject({ ok: false, code: "BAD_DIFFICULTY", blockIndex: index });
    }
  });

  it("a block whose own hash is consistent but misses its difficulty target -> BAD_POW (shared validateChain)", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const blocks = harness.node.ledger.blocks.slice();
    const head = blocks[LIVE_HEAD] as Block;
    expect(head.difficulty).toBeGreaterThanOrEqual(2);
    let nonce = 0;
    let hash = "";
    for (;; nonce += 1) {
      hash = computeBlockHash({ ...head, nonce }, nodeHash);
      if (!hash.startsWith("0".repeat(head.difficulty))) {
        break;
      }
    }
    const weak = [...blocks.slice(0, LIVE_HEAD), { ...head, nonce, hash }];
    expect(await validateLive(harness, weak)).toEqual({ ok: false, code: "BAD_POW", blockIndex: LIVE_HEAD });
  });
});

describe("A5: a richer chain survives a restart a year later", () => {
  it("reloads identical blocks (including the difficulty rise) and validates", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    const first = await boot({ dataDir: dir, clock, keepDir: true });
    await buildLiveChain(first, keys);
    const blocks = JSON.stringify(first.node.ledger.blocks);
    const difficulties = first.node.ledger.blocks.map((block) => block.difficulty);
    expect(difficulties[LIVE_HEAD]).toBeGreaterThan(difficulties[1] as number);
    await first.stop();
    clock.advance(365 * 24 * 60 * 60 * 1000);
    const second = await boot({ dataDir: dir, clock, keepDir: true });
    expect(JSON.stringify(second.node.ledger.blocks)).toBe(blocks);
    expect(second.node.ledger.blocks).toHaveLength(CHAIN_LENGTH);
    expect((await second.get("/chain/validate")).body).toEqual({ ok: true });
    expect(await validateLive(second, second.node.ledger.blocks)).toEqual({ ok: true });
  });
});

describe("A6: a modified genesis is refused at load", () => {
  it("a genesis line with a changed timestamp -> GENESIS_MISMATCH at index 0 (other-profile genesis: restart.test.ts)", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    const first = await boot({ dataDir: dir, clock, keepDir: true });
    await buildLiveChain(first, keys.slice(0, 3));
    await first.stop();
    const path = join(dir, "chain.jsonl");
    const lines = (await readFile(path, "utf8")).split("\n");
    const genesis = JSON.parse(lines[0] ?? "") as Block;
    lines[0] = canonicalize({ ...genesis, timestamp: genesis.timestamp + 1 });
    await writeFile(path, lines.join("\n"));
    const error = await bootError(dir, clock);
    expect(error.code).toBe("GENESIS_MISMATCH");
    expect(error.blockIndex).toBe(0);
  });
});

describe("A7: delete-record-and-remine", () => {
  it("is accepted by the validator (ok:true) and says why that is not a safety proof", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const before = await snapshotLive(harness);
    for (const index of [2, 3, 5, 6]) {
      const response = await tamper(harness, "delete-record-and-remine", index);
      expect(response.body["ok"]).toBe(true);
      expect(String(response.body["note"]).length).toBeGreaterThan(0);
    }
    await expectLiveUnchanged(harness, before);
  });
});

describe("A8: timestamp bounds", () => {
  it("record admission accepts now +/- maxRecordSkewMs and rejects 1 ms beyond (TIMESTAMP_OUT_OF_RANGE)", async () => {
    const sessions = ["s1", "s2", "s3", "s4"].map((id) => ({ id, title: id }));
    const harness = await boot({ sessions });
    const skew = harness.node.settings.config.maxRecordSkewMs;
    const chainId = harness.node.chainId;
    expect((await harness.post("/registrations", await register(key(0), harness.clock.now(), "alice", chainId))).status).toBe(202);
    await harness.mineNow();
    const now = harness.clock.now();
    expect((await harness.post("/attendance", await attend(key(0), "s1", now + skew, chainId))).status).toBe(202);
    expect((await harness.post("/attendance", await attend(key(0), "s2", now - skew, chainId))).status).toBe(202);
    for (const [session, offset] of [["s3", skew + 1], ["s4", -skew - 1]] as const) {
      const response = await harness.post("/attendance", await attend(key(0), session, now + offset, chainId));
      expect(response.status, session).toBe(400);
      expect(errorCode(response.body)).toBe("TIMESTAMP_OUT_OF_RANGE");
    }
  });

  it("a far-future non-decreasing head block loads: there is no historical upper bound (documented behaviour)", async () => {
    const dir = await freshDir();
    const genesis = makeGenesis(TEST_CONFIG, nodeHash);
    const future = mined(1, Date.UTC(2100, 0, 1), genesis.hash, 1);
    await writeFile(join(dir, "chain.jsonl"), chainLines([genesis, future]));
    const harness = await boot({ dataDir: dir, keepDir: true });
    expect(harness.node.ledger.head.index).toBe(1);
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
  });
});

describe("A9: timestamp order", () => {
  it("a head block re-mined with an earlier timestamp -> BAD_TIMESTAMP_ORDER from /chain/validate and at boot (shared: rc7)", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    const genesis = makeGenesis(TEST_CONFIG, nodeHash);
    const one = mined(1, genesis.timestamp + 10, genesis.hash, 1);
    const good = [genesis, one];
    await writeFile(join(dir, "chain.jsonl"), chainLines(good));
    const harness = await boot({ dataDir: dir, clock, keepDir: true });
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    // The head replaced by a validly mined block that goes back in time. /chain/validate only reads the committed
    // prefix of the file (RC14), so the verdict comes from the shared validator on the same blocks and from boot.
    const bad = [genesis, one, mined(2, genesis.timestamp + 9, one.hash, 1)];
    expect(await validateLive(harness, bad)).toEqual({ ok: false, code: "BAD_TIMESTAMP_ORDER", blockIndex: 2 });
    await harness.stop();
    await writeFile(join(dir, "chain.jsonl"), chainLines(bad));
    const error = await bootError(dir, clock);
    expect(error.code).toBe("BAD_TIMESTAMP_ORDER");
    expect(error.blockIndex).toBe(2);
  });
});
