import { afterEach, expect, it } from "vitest";
import { MAX_RECORDS_PER_BLOCK, computeBlockHash, nodeHash, recordId, verifyBlockPow } from "@conference-chain/shared";
import { attend, getKeys, makeHarness, register, type Harness } from "./support.js";

let harness: Harness | null = null;
afterEach(async () => { await harness?.stop(); harness = null; });

it("the real worker mines a full FIFO batch and preserves the overflow for the next block", async () => {
  const [key] = await getKeys(1);
  if (key === undefined) throw new Error("missing key");
  const sessions = Array.from({ length: MAX_RECORDS_PER_BLOCK + 1 }, (_, index) => ({ id: `batch-${index}`, title: `Batch session ${index}` }));
  const h = await makeHarness({ realWorker: true, sessions });
  harness = h;
  expect((await h.post("/registrations", await register(key, h.clock.now()))).status).toBe(202);
  await h.mineNow();

  // Direct admission avoids the HTTP write-rate limit. This is a controlled worker
  // integration test with injected clock/timers, not a live throughput benchmark.
  const ids: string[] = [];
  for (const session of sessions) ids.push(await h.miner.admit(await attend(key, session.id, h.clock.now())));
  await h.mineNow();
  const first = h.node.ledger.head;
  expect(first.index).toBe(2);
  expect(first.records.map((record) => recordId(record, nodeHash))).toEqual(ids.slice(0, MAX_RECORDS_PER_BLOCK));
  expect(h.miner.recordStatus(ids[MAX_RECORDS_PER_BLOCK] ?? "")).toEqual({ status: "pending" });
  expect(h.miner.mempool.pendingCount()).toBe(1);
  expect(computeBlockHash(first, nodeHash)).toBe(first.hash);
  expect(verifyBlockPow(first, nodeHash)).toBe(true);
  await h.node.assertInvariants();

  await h.mineNow();
  const last = h.node.ledger.head;
  expect(last.index).toBe(3);
  expect(last.records.map((record) => recordId(record, nodeHash))).toEqual(ids.slice(MAX_RECORDS_PER_BLOCK));
  expect(last.previousHash).toBe(first.hash);
  expect(h.miner.mempool.size).toBe(0);
  for (const id of ids) expect(h.miner.recordStatus(id)?.status).toBe("confirmed");
  expect(verifyBlockPow(last, nodeHash)).toBe(true);
  await h.node.assertInvariants();
}, 30_000);
