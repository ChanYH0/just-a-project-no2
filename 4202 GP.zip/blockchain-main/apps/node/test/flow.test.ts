import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { CHAIN_ID, getKeys, makeHarness, register, attend, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});

afterEach(async () => {
  await h?.stop();
  h = null;
});

describe("end to end flow", () => {
  it("registers, attends, mines and answers queries", async () => {
    h = await makeHarness();
    const [alice, bob] = keys as [TestKeys, TestKeys, TestKeys];
    const info = await h.get("/chain/info");
    expect(info.status).toBe(200);
    expect(info.body["chainId"]).toBe(CHAIN_ID);

    const reg = await register(alice, h.clock.now(), "alice");
    const posted = await h.post("/registrations", reg);
    expect(posted.status).toBe(202);
    const recordId = posted.body["recordId"] as string;
    expect((await h.get(`/records/${recordId}`)).body).toEqual({ status: "pending" });
    expect((await h.get("/mempool")).body["value"]).toHaveLength(1);

    await h.mineNow();
    expect((await h.get(`/records/${recordId}`)).body).toEqual({ status: "confirmed", blockIndex: 1 });
    expect((await h.get("/mempool")).body["value"]).toEqual([]);

    await h.post("/registrations", await register(bob, h.clock.now(), "bob"));
    const att = await h.post("/attendance", await attend(alice, "keynote", h.clock.now()));
    expect(att.status).toBe(202);
    await h.mineNow();

    const sessions = await h.get(`/attendees/${alice.attendeeId}/sessions`);
    expect(sessions.status).toBe(200);
    expect(sessions.body["sessions"]).toHaveLength(1);
    const attendees = await h.get("/sessions/keynote/attendees");
    expect((attendees.body["attendees"] as unknown[]).length).toBe(1);
    expect((await h.get(`/attendees/${bob.attendeeId}`)).status).toBe(200);
    expect((await h.get("/sessions")).body["value"]).toHaveLength(3);

    const blocks = await h.get("/blocks?limit=2");
    expect((blocks.body["blocks"] as { index: number }[]).map((b) => b.index)).toEqual([2, 1]);
    expect(blocks.body["nextCursor"]).toBe("1");
    const next = await h.get("/blocks?limit=5&cursor=1");
    expect((next.body["blocks"] as { index: number }[]).map((b) => b.index)).toEqual([0]);
    expect(next.body["nextCursor"]).toBeNull();

    const block = await h.get("/blocks/1");
    expect(block.body["verification"]).toEqual({ hashValid: true, powValid: true });
    expect((await h.get("/health")).body["ok"]).toBe(true);
    await h.node.assertInvariants();
  });

  it("returns 404 for unknown resources and 400 for malformed parameters", async () => {
    h = await makeHarness();
    expect((await h.get("/blocks/99")).status).toBe(404);
    expect((await h.get(`/records/${"a".repeat(64)}`)).status).toBe(404);
    expect((await h.get("/sessions/nope/attendees")).status).toBe(404);
    expect((await h.get("/attendees/zz")).status).toBe(400);
    expect((await h.get("/blocks?limit=1000")).status).toBe(400);
    expect((await h.get("/nothing")).status).toBe(404);
  });
});
