// Shared test support: clock, manual timers, fake workers, faulty store, signing helpers, PRNG, node factory.

import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  deriveAttendeeId,
  deriveChainId,
  getProfile,
  mineBlock,
  nodeHash,
  nodeIdentityCrypto,
  signPayload,
  type AttendancePayload,
  type Block,
  type ChainConfig,
  type Clock,
  type PrivateKeyHandle,
  type RegistrationPayload,
  type SignedAttendance,
  type SignedRegistration,
} from "@conference-chain/shared";
import { createNode, type Node } from "../src/app.js";
import type { NodeSettings } from "../src/env.js";
import type { MineJobMessage, MineWorkerHandle, Timers, WorkerFactory, WorkerHandlers } from "../src/mine-protocol.js";
import type { SessionEntry } from "../src/sessions.js";
import type { ChainStore } from "../src/store.js";
import { runJob, type JobHooks } from "../src/validation-jobs.js";
import type { ValidationJob, ValidationWorkerFactory } from "../src/validation-protocol.js";

export const CONFERENCE_ID = "conf-test-2026";
export const TEST_CONFIG: ChainConfig = getProfile("test", CONFERENCE_ID);
export const CHAIN_ID = deriveChainId(TEST_CONFIG, nodeHash);
export const BASE_TIME = Date.UTC(2026, 0, 1);

export const SESSIONS: SessionEntry[] = [
  { id: "keynote", title: "Keynote" },
  { id: "workshop", title: "Workshop" },
  { id: "panel", title: "Panel" },
];

// ---- clock and timers ---------------------------------------------------------------------------------------

export class TestClock implements Clock {
  constructor(private time: number = BASE_TIME) {}
  now(): number {
    return this.time;
  }
  advance(ms: number): void {
    this.time += ms;
  }
  set(time: number): void {
    this.time = time;
  }
}

interface ScheduledTimer {
  handle: number;
  at: number;
  callback: () => void;
}

export class ManualTimers implements Timers {
  private virtualTime = 0;
  private nextHandle = 1;
  private timers: ScheduledTimer[] = [];
  readonly delays: number[] = [];

  setTimeout(callback: () => void, ms: number): unknown {
    const handle = this.nextHandle;
    this.nextHandle += 1;
    this.delays.push(ms);
    this.timers.push({ handle, at: this.virtualTime + ms, callback });
    return handle;
  }

  clearTimeout(handle: unknown): void {
    this.timers = this.timers.filter((timer) => timer.handle !== handle);
  }

  get pending(): number {
    return this.timers.length;
  }

  // Runs every timer that becomes due within `ms` of virtual time, in order, including ones scheduled meanwhile.
  advance(ms: number): void {
    const target = this.virtualTime + ms;
    for (;;) {
      const due = this.timers.filter((timer) => timer.at <= target).sort((a, b) => a.at - b.at || a.handle - b.handle)[0];
      if (due === undefined) {
        break;
      }
      this.timers = this.timers.filter((timer) => timer !== due);
      this.virtualTime = Math.max(this.virtualTime, due.at);
      due.callback();
    }
    this.virtualTime = target;
  }
}

// ---- fake workers -------------------------------------------------------------------------------------------

export class FakeWorker implements MineWorkerHandle {
  handlers: WorkerHandlers | null = null;
  jobs: MineJobMessage[] = [];
  terminated = false;

  constructor(private readonly owner: FakeWorkers) {}

  setHandlers(handlers: WorkerHandlers): void {
    this.handlers = handlers;
  }

  postMessage(message: MineJobMessage): void {
    this.jobs.push(message);
    if (this.owner.autoMine) {
      queueMicrotask(() => {
        if (!this.terminated) {
          this.deliver(message);
        }
      });
    }
  }

  mine(message: MineJobMessage): Block {
    const block = mineBlock(message.candidate, nodeHash);
    if (block === null) {
      throw new Error("mineBlock returned null");
    }
    return block;
  }

  deliver(message: MineJobMessage): void {
    this.handlers?.onMessage({ jobId: message.jobId, block: this.mine(message) });
  }

  emit(message: unknown): void {
    this.handlers?.onMessage(message);
  }

  crash(): void {
    this.handlers?.onError(new Error("worker crashed"));
    this.handlers?.onExit(1);
  }

  async terminate(): Promise<void> {
    this.terminated = true;
  }
}

export class FakeWorkers {
  autoMine = true;
  failCreate = false;
  readonly workers: FakeWorker[] = [];

  readonly factory: WorkerFactory = () => {
    if (this.failCreate) {
      throw new Error("cannot start worker");
    }
    const worker = new FakeWorker(this);
    this.workers.push(worker);
    return worker;
  };

  get last(): FakeWorker {
    const worker = this.workers.at(-1);
    if (worker === undefined) {
      throw new Error("no worker was started");
    }
    return worker;
  }
}

// ---- validation worker double -------------------------------------------------------------------------------

// Runs the real job code in-process (no thread) and counts the jobs it was given. `hold` makes the next jobs wait
// until released, to observe queueing and shutdown.
export class CountingValidationWorkers {
  readonly jobs: ValidationJob[] = [];
  created = 0;
  terminated = 0;
  // Test seam passed to every job (for example a broken record mutator, RC15).
  hooks: JobHooks = {};
  private gate: Promise<void> | null = null;

  readonly factory: ValidationWorkerFactory = () => {
    this.created += 1;
    let handlers: WorkerHandlers | null = null;
    let dead = false;
    return {
      setHandlers: (next) => {
        handlers = next;
      },
      postMessage: (message) => {
        this.jobs.push(message.job);
        void (async () => {
          if (this.gate !== null) {
            await this.gate;
          }
          // Like the real worker: a job that throws answers with a fixed error text, never a stack trace.
          let reply: unknown;
          try {
            reply = { jobId: message.jobId, outcome: await runJob(message.job, this.hooks) };
          } catch {
            reply = { jobId: message.jobId, error: "validation job failed" };
          }
          if (!dead) {
            handlers?.onMessage(reply);
          }
        })();
      },
      terminate: async () => {
        dead = true;
        this.terminated += 1;
      },
    };
  };

  hold(): () => void {
    let release: () => void = () => undefined;
    this.gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    return () => {
      release();
      this.gate = null;
    };
  }

  count(kind: ValidationJob["kind"]): number {
    return this.jobs.filter((job) => job.kind === kind).length;
  }
}

// ---- faulty store -------------------------------------------------------------------------------------------

export type StoreOp = "size" | "append" | "fsync" | "truncate";

export interface Fault {
  op: StoreOp;
  // 1-based call number of that op (counted from the moment the fault is armed)
  nth: number;
  mode: "throw" | "partial-then-throw" | "wrong-size";
}

export class FaultyStore implements ChainStore {
  private faults: Fault[] = [];
  private counts: Record<StoreOp, number> = { size: 0, append: 0, fsync: 0, truncate: 0 };
  readonly calls: StoreOp[] = [];

  constructor(private readonly real: ChainStore) {}

  arm(...faults: Fault[]): void {
    this.faults = faults;
    this.counts = { size: 0, append: 0, fsync: 0, truncate: 0 };
  }

  private hit(op: StoreOp): Fault | undefined {
    this.calls.push(op);
    this.counts[op] += 1;
    return this.faults.find((fault) => fault.op === op && fault.nth === this.counts[op]);
  }

  async size(): Promise<number> {
    const fault = this.hit("size");
    if (fault?.mode === "throw") {
      throw new Error("injected size failure");
    }
    const size = await this.real.size();
    return fault?.mode === "wrong-size" ? size + 1 : size;
  }

  private gate: Promise<void> | null = null;

  // Blocks the next appends until the returned function is called (to observe the `persisting` state).
  holdAppend(): () => void {
    let release: () => void = () => undefined;
    this.gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    return () => {
      release();
      this.gate = null;
    };
  }

  async append(line: string): Promise<void> {
    if (this.gate !== null) {
      await this.gate;
    }
    if (this.partialGate !== null) {
      await this.real.append(line.slice(0, Math.floor(line.length / 2)));
      this.partialWaiting = true;
      await this.partialGate;
      this.partialWaiting = false;
      await this.real.append(line.slice(Math.floor(line.length / 2)));
      return;
    }
    const fault = this.hit("append");
    if (fault?.mode === "throw") {
      throw new Error("injected append failure");
    }
    if (fault?.mode === "partial-then-throw") {
      await this.real.append(line.slice(0, Math.floor(line.length / 2)));
      throw new Error("injected partial append failure");
    }
    await this.real.append(line);
  }

  private fsyncGate: Promise<void> | null = null;
  // True while a fsync is parked on the gate set by holdFsync().
  fsyncWaiting = false;
  private partialGate: Promise<void> | null = null;
  partialWaiting = false;

  // The next fsync waits until the returned function is called: the block is on disk but not yet committed.
  holdFsync(): () => void {
    let release: () => void = () => undefined;
    this.fsyncGate = new Promise<void>((resolve) => {
      release = resolve;
    });
    return () => {
      release();
      this.fsyncGate = null;
    };
  }

  // The next append writes the first half of its line, then waits: a torn line is on disk mid-append.
  holdPartialAppend(): () => void {
    let release: () => void = () => undefined;
    this.partialGate = new Promise<void>((resolve) => {
      release = resolve;
    });
    return () => {
      release();
      this.partialGate = null;
    };
  }

  async fsync(): Promise<void> {
    if (this.fsyncGate !== null) {
      this.fsyncWaiting = true;
      await this.fsyncGate;
      this.fsyncWaiting = false;
    }
    if (this.hit("fsync")?.mode === "throw") {
      throw new Error("injected fsync failure");
    }
    await this.real.fsync();
  }

  async truncate(offset: number): Promise<void> {
    if (this.hit("truncate")?.mode === "throw") {
      throw new Error("injected truncate failure");
    }
    await this.real.truncate(offset);
  }
}

// ---- keys and records ---------------------------------------------------------------------------------------

export interface TestKeys {
  attendeeId: string;
  publicKey: string;
  privateKey: PrivateKeyHandle;
}

export async function makeKeys(): Promise<TestKeys> {
  const pair = await nodeIdentityCrypto.generateKeyPair();
  return {
    attendeeId: await deriveAttendeeId(pair.publicKey, nodeIdentityCrypto),
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
  };
}

// RSA generation is slow: a small shared pool of keys is enough because every node uses its own empty DATA_DIR.
const keyPool: TestKeys[] = [];
export async function getKeys(count: number): Promise<TestKeys[]> {
  while (keyPool.length < count) {
    keyPool.push(await makeKeys());
  }
  return keyPool.slice(0, count);
}

export async function register(
  keys: TestKeys,
  timestamp: number,
  alias = "alice",
  chainId: string = CHAIN_ID,
): Promise<SignedRegistration> {
  const payload: RegistrationPayload = {
    type: "register",
    chainId,
    attendeeId: keys.attendeeId,
    alias,
    publicKey: keys.publicKey,
    timestamp,
  };
  return { payload, signature: await signPayload(payload, keys.privateKey, nodeIdentityCrypto) };
}

export async function attend(
  keys: TestKeys,
  sessionId: string,
  timestamp: number,
  chainId: string = CHAIN_ID,
): Promise<SignedAttendance> {
  const payload: AttendancePayload = {
    type: "attend",
    chainId,
    attendeeId: keys.attendeeId,
    sessionId,
    timestamp,
  };
  return { payload, signature: await signPayload(payload, keys.privateKey, nodeIdentityCrypto) };
}

// Event-free polling for in-memory conditions that become true after a few microtask/macrotask turns. The only bound
// is a generous safety timeout that fails with a message; it never decides pass/fail by speed.
export async function until(predicate: () => boolean, what: string, safetyMs = 30_000): Promise<void> {
  const deadline = Date.now() + safetyMs;
  while (!predicate()) {
    if (Date.now() > deadline) {
      throw new Error(`timed out waiting for: ${what}`);
    }
    await new Promise<void>((resolve) => setImmediate(resolve));
  }
}

// ---- PRNG ---------------------------------------------------------------------------------------------------

export function seededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- node factory -------------------------------------------------------------------------------------------

export async function makeDataDir(): Promise<string> {
  return mkdtemp(join(tmpdir(), "chain-node-test-"));
}

export interface Harness {
  node: Node;
  app: Node["app"];
  miner: Node["miner"];
  clock: TestClock;
  timers: ManualTimers;
  workers: FakeWorkers;
  dataDir: string;
  store: FaultyStore | null;
  fatal: string[];
  // Time source of the /chain/validate and /demo/* rate limiter (separate from the live clock).
  heavyRateClock: TestClock;
  validationWorkers: CountingValidationWorkers;
  chainFile(): Promise<string>;
  // Runs the batch timer, waits for the job to finish (auto-mining fake worker).
  mineNow(): Promise<void>;
  post(url: string, body: unknown): Promise<{ status: number; body: Record<string, unknown> }>;
  get(url: string): Promise<{ status: number; body: Record<string, unknown> }>;
  stop(): Promise<void>;
}

export interface HarnessOptions {
  dataDir?: string;
  clock?: TestClock;
  timers?: ManualTimers;
  workers?: FakeWorkers;
  faulty?: boolean;
  realWorker?: boolean;
  mempoolMax?: number;
  terminalLimit?: number;
  sessions?: SessionEntry[];
  keepDir?: boolean;
  profile?: NodeSettings["profile"];
  enableDemoRoutes?: boolean;
  conferenceId?: string;
  heavyRateClock?: TestClock;
  validationWorkers?: CountingValidationWorkers;
  // Use the real validation worker thread (tsx) instead of the in-process counting double.
  realValidationWorker?: boolean;
  validationTimeoutMs?: number;
}

export async function makeHarness(options: HarnessOptions = {}): Promise<Harness> {
  const dataDir = options.dataDir ?? (await makeDataDir());
  const clock = options.clock ?? new TestClock();
  const timers = options.timers ?? new ManualTimers();
  const workers = options.workers ?? new FakeWorkers();
  const fatal: string[] = [];
  let store: FaultyStore | null = null;
  const profile = options.profile ?? "test";
  const heavyRateClock = options.heavyRateClock ?? new TestClock();
  const validationWorkers = options.validationWorkers ?? new CountingValidationWorkers();
  const settings: NodeSettings = {
    profile,
    config: getProfile(profile, options.conferenceId ?? CONFERENCE_ID),
    port: 0,
    dataDir,
    sessionsFile: "unused",
    enableDemoRoutes: options.enableDemoRoutes ?? false,
  };
  const node = await createNode({
    settings,
    sessions: options.sessions ?? SESSIONS,
    clock,
    timers,
    heavyRateClock,
    ...(options.realValidationWorker === true ? {} : { validationWorkerFactory: validationWorkers.factory }),
    ...(options.validationTimeoutMs === undefined ? {} : { validationTimeoutMs: options.validationTimeoutMs }),
    ...(options.realWorker === true ? {} : { workerFactory: workers.factory }),
    ...(options.faulty === true
      ? {
          wrapStore: (real: ChainStore) => {
            store = new FaultyStore(real);
            return store;
          },
        }
      : {}),
    ...(options.mempoolMax === undefined ? {} : { mempoolMax: options.mempoolMax }),
    ...(options.terminalLimit === undefined ? {} : { terminalLimit: options.terminalLimit }),
    onFatal: (code) => fatal.push(code),
  });

  const decode = (text: string): Record<string, unknown> => {
    const parsed: unknown = text === "" ? {} : JSON.parse(text);
    return typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : { value: parsed };
  };

  let stopped = false;
  return {
    node,
    app: node.app,
    miner: node.miner,
    clock,
    timers,
    workers,
    dataDir,
    heavyRateClock,
    validationWorkers,
    get store() {
      return store;
    },
    fatal,
    chainFile: () => readFile(join(dataDir, "chain.jsonl"), "utf8"),
    async mineNow() {
      timers.advance(1000);
      await node.miner.settled();
    },
    async post(url, body) {
      const response = await node.app.inject({ method: "POST", url, payload: JSON.stringify(body), headers: { "content-type": "application/json" } });
      return { status: response.statusCode, body: decode(response.body) };
    },
    async get(url) {
      const response = await node.app.inject({ method: "GET", url });
      return { status: response.statusCode, body: decode(response.body) };
    },
    async stop() {
      if (stopped) {
        return;
      }
      stopped = true;
      await node.close();
      if (options.keepDir !== true) {
        await rm(dataDir, { recursive: true, force: true });
      }
    },
  };
}
