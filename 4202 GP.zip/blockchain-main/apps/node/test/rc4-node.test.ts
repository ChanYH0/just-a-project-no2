import { rm } from "node:fs/promises";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { BootError } from "../src/boot-error.js";
import { getKeys, makeDataDir, makeHarness, register, TestClock, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let live: Harness[] = [];
const dirs: string[] = [];

beforeAll(async () => {
  keys = await getKeys(1);
});
afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

describe("RC4 (node): deployment identity", () => {
  it("rejects a registration signed for another conference with CHAIN_ID_MISMATCH", async () => {
    const [alice] = keys as [TestKeys];
    const y = await makeHarness({ conferenceId: "conf-other-2026" });
    live.push(y);
    const record = await register(alice, y.clock.now());
    const result = await y.post("/registrations", record);
    expect(result.status).toBe(400);
    expect((result.body["error"] as { code: string }).code).toBe("CHAIN_ID_MISMATCH");
  });

  it("refuses a chain.jsonl from conference X when booted as conference Y", async () => {
    const [alice] = keys as [TestKeys];
    const dataDir = await makeDataDir();
    dirs.push(dataDir);
    const clock = new TestClock();
    const x = await makeHarness({ dataDir, clock, keepDir: true });
    await x.post("/registrations", await register(alice, clock.now()));
    await x.mineNow();
    await x.stop();
    await expect(makeHarness({ dataDir, clock, keepDir: true, conferenceId: "conf-other-2026" })).rejects.toSatisfy(
      (error: unknown) => error instanceof BootError && error.code === "CHAIN_ID_MISMATCH" && error.blockIndex === 1,
    );
  });
});
