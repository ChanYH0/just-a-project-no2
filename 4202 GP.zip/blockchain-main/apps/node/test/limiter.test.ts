// Fixed-window limiter: per-key limit and the hard bound on tracked keys.

import { describe, expect, it } from "vitest";
import { FixedWindowLimiter } from "../src/limiter.js";

describe("FixedWindowLimiter", () => {
  it("allows up to the limit per key then refuses", () => {
    const limiter = new FixedWindowLimiter(2, 1000, { now: () => 0 });
    expect([limiter.take("a"), limiter.take("a"), limiter.take("a"), limiter.take("b")]).toEqual([true, true, false, true]);
  });

  it("fails closed when the key table is full of live windows", () => {
    const limiter = new FixedWindowLimiter(5, 1000, { now: () => 0 }, 2);
    expect([limiter.take("a"), limiter.take("b"), limiter.take("c")]).toEqual([true, true, false]);
  });

  it("frees room once windows expire", () => {
    let now = 0;
    const limiter = new FixedWindowLimiter(5, 1000, { now: () => now }, 1);
    expect(limiter.take("a")).toBe(true);
    now = 1000;
    expect(limiter.take("b")).toBe(true);
  });
});
