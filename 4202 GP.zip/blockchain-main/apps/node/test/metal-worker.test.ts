import { chmod, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { describe, expect, it } from "vitest";
import {
  Block,
  MAX_RECORDS_PER_BLOCK,
  canonicalize,
  computeBlockHash,
  mineBlock,
  nodeHash,
  type BlockCandidate,
} from "@conference-chain/shared/node";
import { getProfile, makeGenesis } from "@conference-chain/shared";
import { makeMetalTemplate } from "../src/metal-template.js";
import { createMetalWorkerFactory, preflightMetal, runMetalJob } from "../src/metal-worker-factory.js";
import { createWorkerPool } from "../src/worker-pool.js";
import { infeasibleCandidate } from "./fixtures/infeasible-candidate.js";
import type { WorkerFactory } from "../src/mine-protocol.js";

function sampleCandidate(): BlockCandidate {
  return {
    index: 1,
    timestamp: 1_800_000_000_000,
    previousHash: "0".repeat(64),
    difficulty: 1,
    records: [
      {
        payload: {
          type: "register",
          chainId: "a".repeat(64),
          attendeeId: "b".repeat(64),
          alias: 'GPU template 🧪, "nonce":0,"previousHash":\\',
          publicKey: Buffer.alloc(294).toString("base64"),
          timestamp: 1_800_000_000_000,
        },
        signature: Buffer.alloc(256).toString("base64"),
      },
    ],
  };
}

async function fakeExecutable(output: string): Promise<{ folder: string; path: string }> {
  const folder = await mkdtemp(join(tmpdir(), "metal-helper-test-"));
  const path = join(folder, "helper.mjs");
  await writeFile(path, `process.stdin.resume(); process.stdin.on("end", () => { ${output} });\n`, "utf8");
  await chmod(path, 0o700);
  return { folder, path };
}

describe("Metal PoW transport", () => {
  it.each([0, 9, 10, 99, 100, Number.MAX_SAFE_INTEGER])(
    "splits exact canonical UTF-8 bytes for nonce %s",
    (nonce) => {
      const candidate = sampleCandidate();
      const template = makeMetalTemplate(candidate);
      const reconstructed = Buffer.concat([template.prefix, Buffer.from(String(nonce), "ascii"), template.suffix]);
      expect(reconstructed).toEqual(Buffer.from(canonicalize({ ...candidate, nonce }), "utf8"));
    },
  );

  it("rejects malformed or oversized requests before spawning", async () => {
    await expect(runMetalJob({
      prefix: "%%", suffix: "YQ==", difficulty: 1, startNonce: 0, stride: 1, batchSize: 1,
    })).rejects.toMatchObject({ code: "INVALID_SCHEMA" });
    await expect(runMetalJob({
      prefix: "YQ==", suffix: "Yg==", difficulty: 1, startNonce: 0, stride: 1, batchSize: 65_537,
    })).rejects.toMatchObject({ code: "INVALID_SCHEMA" });
  });

  it("returns fixed errors without echoing native stderr or job input", async () => {
    const fake = await fakeExecutable('process.stderr.write("private payload sentinel"); process.exitCode = 7;');
    const privateMarker = "private-payload-input-marker";
    try {
      const request = {
        prefix: Buffer.from(privateMarker).toString("base64"), suffix: "Yg==",
        difficulty: 1, startNonce: 0, stride: 1, batchSize: 1,
      };
      const error = await runMetalJob(request, { executablePath: process.execPath, kernelPath: fake.path })
        .then(() => { throw new Error("expected native helper error"); }, (caught: unknown) => caught);
      expect(error).toMatchObject({ code: "INTERNAL" });
      expect(String(error)).not.toContain(privateMarker);
      expect(String(error)).not.toContain("private payload sentinel");
    } finally {
      await rm(fake.folder, { recursive: true, force: true });
    }
  });

  it.skipIf(process.platform === "win32")("terminates the helper and waits for close after stdin fails", async () => {
    const folder = await mkdtemp(join(tmpdir(), "metal-helper-stdin-error-"));
    const helperPath = join(folder, "helper.mjs");
    const terminationPath = join(folder, "terminated");
    await writeFile(helperPath, `import { closeSync, writeFileSync } from "node:fs";
process.on("SIGTERM", () => {
  writeFileSync(${JSON.stringify(terminationPath)}, "terminated");
  process.exit(0);
});
closeSync(0);
setTimeout(() => process.exit(0), 2_000);
`, "utf8");
    await chmod(helperPath, 0o700);
    try {
      const error = await runMetalJob({
        // Exceed the pipe buffer while the child explicitly closes its read fd.
        prefix: Buffer.alloc(1_400_000).toString("base64"), suffix: "Yg==",
        difficulty: 1, startNonce: 0, stride: 1, batchSize: 1,
      }, { executablePath: process.execPath, kernelPath: helperPath })
        .then(() => { throw new Error("expected stdin failure"); }, (caught: unknown) => caught);

      expect(error).toMatchObject({ code: "INTERNAL", message: "Metal helper rejected its request" });
      await expect(readFile(terminationPath, "utf8")).resolves.toBe("terminated");
    } finally {
      await rm(folder, { recursive: true, force: true });
    }
  });

  it("reconstructs and verifies a returned nonce before notifying Miner", async () => {
    const candidate = sampleCandidate();
    const block = mineBlock(candidate, nodeHash);
    if (block === null) throw new Error("missing CPU proof");
    const fake = await fakeExecutable(
      `process.stdout.write(${JSON.stringify(JSON.stringify({
        nonce: block.nonce, attempts: block.nonce + 1, elapsedMs: 1.25, device: "fake-test-device",
      }))});`,
    );
    try {
      const worker = createMetalWorkerFactory({ executablePath: process.execPath, kernelPath: fake.path })();
      const result = new Promise<unknown>((resolve, reject) => {
        worker.setHandlers({
          onMessage: resolve,
          onError: reject,
          onExit: (code) => { if (code !== 0) reject(new Error("helper exited unsuccessfully")); },
        });
      });
      worker.postMessage({ jobId: 17, candidate });
      const message = await result as { jobId: number; block: ReturnType<typeof mineBlock> };
      expect(message.jobId).toBe(17);
      expect(message.block).toEqual(block);
      expect(message.block?.hash).toBe(computeBlockHash(block, nodeHash));
      await worker.terminate();
    } finally {
      await rm(fake.folder, { recursive: true, force: true });
    }
  });

  it.skipIf(process.platform !== "darwin" || process.env["RUN_METAL_TESTS"] !== "true")(
    "runs the real Metal GPU preflight against an independently found CPU SHA-256 vector",
    async () => {
      const result = await preflightMetal();
      expect(result.nonce).not.toBeNull();
      expect(result.attempts).toBeGreaterThanOrEqual(result.nonce! + 1);
      expect(result.device.length).toBeGreaterThan(0);
    },
    30_000,
  );

  it.skipIf(process.platform !== "darwin" || process.env["RUN_METAL_TESTS"] !== "true")(
    "preserves the first PoW nonce for a full block with long Unicode aliases",
    async () => {
      const timestamp = 1_800_000_000_000;
      const candidate: BlockCandidate = {
        index: 1,
        timestamp,
        previousHash: "0".repeat(64),
        difficulty: 1,
        records: Array.from({ length: MAX_RECORDS_PER_BLOCK }, (_, index) => ({
          payload: {
            type: "register" as const,
            chainId: "a".repeat(64),
            attendeeId: index.toString(16).padStart(64, "0"),
            alias: "水🙂".repeat(25),
            publicKey: Buffer.alloc(294, index).toString("base64"),
            timestamp,
          },
          signature: Buffer.alloc(256, index).toString("base64"),
        })),
      };
      const template = makeMetalTemplate(candidate);
      let expectedNonce: number | null = null;
      for (let nonce = 0; nonce < 1_000; nonce += 1) {
        const hash = nodeHash(Buffer.concat([
          template.prefix,
          Buffer.from(String(nonce), "ascii"),
          template.suffix,
        ]));
        if (hash.startsWith("0")) {
          expectedNonce = nonce;
          break;
        }
      }
      if (expectedNonce === null) throw new Error("could not prepare a deterministic CPU nonce vector");
      const maxNonces = expectedNonce + 1;
      const result = await runMetalJob({
        prefix: template.prefix.toString("base64"),
        suffix: template.suffix.toString("base64"),
        difficulty: 1,
        startNonce: 0,
        stride: 1,
        batchSize: maxNonces,
        maxNonces,
      });
      expect(result.nonce).toBe(expectedNonce);
      expect(result.attempts).toBe(maxNonces);
      expect(result.device).toContain("Apple");
    },
    30_000,
  );

  it.skipIf(process.platform !== "darwin" || process.env["RUN_METAL_TESTS"] !== "true")(
    "mines and CPU-verifies a real two-worker GPU pool block",
    async () => {
      const candidate = sampleCandidate();
      candidate.difficulty = 2;
      const factory = createWorkerPool(createMetalWorkerFactory(), 2);
      const handle = factory();
      const block = await new Promise<NonNullable<ReturnType<typeof mineBlock>>>((resolve, reject) => {
        handle.setHandlers({
          onMessage: (message) => {
            if (typeof message !== "object" || message === null || !("block" in message)) {
              reject(new Error("GPU worker pool returned a malformed result"));
              return;
            }
            resolve(message.block as NonNullable<ReturnType<typeof mineBlock>>);
          },
          onError: reject,
          onExit: (code) => { if (code !== 0) reject(new Error(`GPU worker pool exited with ${code}`)); },
        });
        handle.postMessage({ jobId: 71, candidate });
      });
      expect(block.hash).toBe(computeBlockHash(block, nodeHash));
      expect(block.hash.startsWith("00")).toBe(true);
      await handle.terminate();
    },
    30_000,
  );

  it.skipIf(process.platform !== "darwin" || process.env["RUN_METAL_TESTS"] !== "true")(
    "terminates two infeasible GPU lanes without affecting an independent valid GPU job",
    async () => {
      await preflightMetal();
      const idle = makeGenesis(getProfile("test", "metal-worker-cancel"), nodeHash);
      const metalWorker = createMetalWorkerFactory({ batchSize: 16 });
      const started: (() => void)[] = [];
      const startPromises = Array.from({ length: 2 }, () => new Promise<void>((resolve) => { started.push(resolve); }));
      let made = 0;
      const observedFactory: WorkerFactory = () => {
        const child = metalWorker();
        return {
          setHandlers: (handlers) => child.setHandlers(handlers),
          postMessage: (message) => {
            child.postMessage(message);
            const resolve = started[made];
            made += 1;
            resolve?.();
          },
          terminate: () => child.terminate(),
        };
      };
      const stalled = createWorkerPool(observedFactory, 2)();
      let unexpectedResult = false;
      let unexpectedFailure = false;
      stalled.setHandlers({
        onMessage: () => { unexpectedResult = true; },
        onError: () => { unexpectedFailure = true; },
        onExit: () => undefined,
      });
      stalled.postMessage({ jobId: 72, candidate: infeasibleCandidate(idle) });
      await Promise.all(startPromises);

      const candidate = { ...sampleCandidate(), difficulty: 1 };
      const healthy = createWorkerPool(createMetalWorkerFactory(), 2)();
      try {
        const result = new Promise<unknown>((resolve, reject) => {
          healthy.setHandlers({
            onMessage: resolve,
            onError: reject,
            onExit: (code) => { if (code !== 0) reject(new Error(`GPU worker pool exited with ${code}`)); },
          });
          healthy.postMessage({ jobId: 73, candidate });
        });
        const raw = await result;
        if (typeof raw !== "object" || raw === null || !("block" in raw)) {
          throw new Error("GPU pool returned no mined block");
        }
        const block = Block.parse(raw.block);
        expect(block.hash).toBe(computeBlockHash(block, nodeHash));
        expect(block.hash.startsWith("0")).toBe(true);
        await stalled.terminate();
        expect(unexpectedResult).toBe(false);
        expect(unexpectedFailure).toBe(false);
      } finally {
        await Promise.allSettled([stalled.terminate(), healthy.terminate()]);
      }
    },
    30_000,
  );
});
