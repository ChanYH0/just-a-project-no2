// Validation worker manager: one job at a time, timeout enforced by terminate(), typed message protocol.

import { describe, expect, it, vi } from "vitest";
import { ChainError } from "@conference-chain/shared";
import type { WorkerHandlers } from "../src/mine-protocol.js";
import { ValidationWorkerManager } from "../src/validation-manager.js";
import type { ValidationJob, ValidationJobMessage, ValidationWorkerHandle } from "../src/validation-protocol.js";
import { CountingValidationWorkers, TEST_CONFIG } from "./support.js";

const SIMULATE: ValidationJob = { kind: "simulate", count: 2, intervalMs: 0, config: TEST_CONFIG };

class ManualWorker implements ValidationWorkerHandle {
  handlers: WorkerHandlers | null = null;
  posted: ValidationJobMessage[] = [];
  terminated = false;
  setHandlers(handlers: WorkerHandlers): void {
    this.handlers = handlers;
  }
  postMessage(message: ValidationJobMessage): void {
    this.posted.push(message);
  }
  async terminate(): Promise<void> {
    this.terminated = true;
  }
}

describe("ValidationWorkerManager", () => {
  it("logs only the error code and job id when a worker error contains sensitive content", async () => {
    const log = vi.spyOn(console, "error").mockImplementation(() => undefined);
    try {
      const worker = new ManualWorker();
      const manager = new ValidationWorkerManager({ factory: () => worker });
      const pending = manager.run(SIMULATE);
      const rejected = expect(pending).rejects.toMatchObject({ code: "INTERNAL" });
      await new Promise<void>((resolve) => setImmediate(resolve));
      worker.handlers?.onError(new Error("private payload and signature"));
      await rejected;
      expect(log.mock.calls).toEqual([[{ code: "INTERNAL", jobId: 1 }]]);
    } finally {
      log.mockRestore();
    }
  });
  it("runs a job through the injected factory and terminates the worker afterwards", async () => {
    const workers = new CountingValidationWorkers();
    const manager = new ValidationWorkerManager({ factory: workers.factory });
    const outcome = await manager.run(SIMULATE);
    expect(outcome.kind).toBe("simulate");
    expect(workers.created).toBe(1);
    expect(workers.terminated).toBe(1);
  });

  it("terminates a job that exceeds the (injected) timeout and fails with INTERNAL", async () => {
    const worker = new ManualWorker();
    const manager = new ValidationWorkerManager({ factory: () => worker, timeoutMs: 20 });
    await expect(manager.run(SIMULATE)).rejects.toMatchObject({ code: "INTERNAL" });
    expect(worker.terminated).toBe(true);
  });

  it("runs one job at a time: the second worker only starts after the first finished", async () => {
    const created: ManualWorker[] = [];
    const manager = new ValidationWorkerManager({
      factory: () => {
        const worker = new ManualWorker();
        created.push(worker);
        return worker;
      },
    });
    const first = manager.run(SIMULATE);
    const second = manager.run(SIMULATE);
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(created).toHaveLength(1);
    const reply = (worker: ManualWorker): void => {
      const posted = worker.posted[0];
      if (posted === undefined) {
        throw new Error("no job posted");
      }
      worker.handlers?.onMessage({
        jobId: posted.jobId,
        outcome: { kind: "simulate", valid: true, blocks: [], adjustments: [] },
      });
    };
    reply(created[0] as ManualWorker);
    await first;
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(created).toHaveLength(2);
    reply(created[1] as ManualWorker);
    await second;
  });

  it("rejects malformed or mismatching worker messages, worker errors and early exits", async () => {
    const cases: ((worker: ManualWorker) => void)[] = [
      (worker) => worker.handlers?.onMessage({ nonsense: true }),
      (worker) => worker.handlers?.onMessage({ jobId: 1, error: "boom" }),
      (worker) =>
        worker.handlers?.onMessage({
          jobId: 1,
          outcome: { kind: "validate-snapshot", result: { ok: true }, blockCount: 1, headHash: null },
        }),
      (worker) => worker.handlers?.onError(new Error("crash")),
      (worker) => worker.handlers?.onExit(1),
    ];
    for (const trigger of cases) {
      const worker = new ManualWorker();
      const manager = new ValidationWorkerManager({ factory: () => worker });
      const pending = manager.run(SIMULATE);
      await new Promise<void>((resolve) => setImmediate(resolve));
      trigger(worker);
      await expect(pending).rejects.toBeInstanceOf(ChainError);
      expect(worker.terminated).toBe(true);
    }
  });

  it("fails with INTERNAL when the worker cannot be started, and after shutdown", async () => {
    const broken = new ValidationWorkerManager({
      factory: () => {
        throw new Error("no worker");
      },
    });
    await expect(broken.run(SIMULATE)).rejects.toMatchObject({ code: "INTERNAL" });
    const manager = new ValidationWorkerManager({ factory: new CountingValidationWorkers().factory });
    await manager.shutdown();
    await expect(manager.run(SIMULATE)).rejects.toMatchObject({ code: "INTERNAL" });
  });

  it("shutdown terminates the running worker", async () => {
    const worker = new ManualWorker();
    const manager = new ValidationWorkerManager({ factory: () => worker });
    const pending = manager.run(SIMULATE);
    pending.catch(() => undefined);
    await new Promise<void>((resolve) => setImmediate(resolve));
    await manager.shutdown();
    expect(worker.terminated).toBe(true);
    await expect(pending).rejects.toMatchObject({ code: "INTERNAL" });
  });
});

describe("ValidationWorkerManager queue bound", () => {
  it("refuses jobs beyond the queue limit with RATE_LIMITED", async () => {
    const manager = new ValidationWorkerManager({ factory: () => new ManualWorker(), timeoutMs: 50, queueMax: 1 });
    const jobs = [manager.run(SIMULATE), manager.run(SIMULATE)];
    await expect(manager.run(SIMULATE)).rejects.toMatchObject({ code: "RATE_LIMITED" });
    await Promise.allSettled(jobs);
  });
});
