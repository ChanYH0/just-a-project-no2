import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { parseEnv } from "../src/env.js";
import { attend, getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  vi.restoreAllMocks();
  await h?.stop();
  h = null;
});

describe("RC1: no email/HMAC surface", () => {
  it("rejects an extra email field", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const record = await register(alice, h.clock.now());
    const result = await h.post("/registrations", { ...record, email: "a@example.com" });
    expect(result.status).toBe(400);
    expect((result.body["error"] as { code: string }).code).toBe("INVALID_SCHEMA");
  });

  it("rejects name, email and emailCommitment inside the payload", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const record = await register(alice, h.clock.now());
    for (const field of ["emailCommitment", "email", "name"]) {
      const result = await h.post("/registrations", { ...record, payload: { ...record.payload, [field]: "x" } });
      expect(result.status).toBe(400);
      expect((result.body["error"] as { code: string }).code).toBe("INVALID_SCHEMA");
    }
    const attendance = await attend(alice, "keynote", h.clock.now());
    const result = await h.post("/attendance", { ...attendance, payload: { ...attendance.payload, email: "x" } });
    expect((result.body["error"] as { code: string }).code).toBe("INVALID_SCHEMA");
  });

  it("has no /registrations/prepare route", async () => {
    h = await makeHarness();
    expect((await h.get("/registrations/prepare")).status).toBe(404);
  });

  it("boots without EMAIL_PEPPER and ignores it when set", () => {
    const base = { CONFERENCE_ID: "conf-test-2026", PROFILE: "test" };
    const without = parseEnv(base);
    const withPepper = parseEnv({ ...base, EMAIL_PEPPER: "secret" });
    expect(withPepper).toEqual(without);
  });

  it("accepts two different keys with the same alias", async () => {
    h = await makeHarness();
    const [alice, bob] = keys as [TestKeys, TestKeys];
    expect((await h.post("/registrations", await register(alice, h.clock.now(), "same"))).status).toBe(202);
    expect((await h.post("/registrations", await register(bob, h.clock.now(), "same"))).status).toBe(202);
    await h.mineNow();
    expect((await h.get(`/attendees/${alice.attendeeId}`)).status).toBe(200);
    expect((await h.get(`/attendees/${bob.attendeeId}`)).status).toBe(200);
  });

  it("test 12: chain, API responses and logs contain only schema fields and no secrets", async () => {
    const logged: string[] = [];
    for (const method of ["log", "info", "warn", "error", "debug"] as const) {
      vi.spyOn(console, method).mockImplementation((...args: unknown[]) => {
        logged.push(args.map(String).join(" "));
      });
    }
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const reg = await register(alice, h.clock.now(), "alice");
    await h.post("/registrations", reg);
    await h.mineNow();
    await h.post("/attendance", await attend(alice, "keynote", h.clock.now()));
    await h.mineNow();

    const allowedRecordKeys = new Set(["payload", "signature"]);
    const allowedPayloadKeys = new Set(["type", "chainId", "attendeeId", "alias", "publicKey", "sessionId", "timestamp"]);
    const allowedBlockKeys = new Set(["index", "timestamp", "previousHash", "difficulty", "nonce", "records", "hash"]);
    for (const line of (await h.chainFile()).trim().split("\n")) {
      const block = JSON.parse(line) as Record<string, unknown>;
      expect(Object.keys(block).every((key) => allowedBlockKeys.has(key))).toBe(true);
      for (const record of block["records"] as Record<string, unknown>[]) {
        expect(Object.keys(record).every((key) => allowedRecordKeys.has(key))).toBe(true);
        expect(Object.keys(record["payload"] as object).every((key) => allowedPayloadKeys.has(key))).toBe(true);
      }
    }
    const responses = [
      await h.get("/blocks"),
      await h.get("/mempool"),
      await h.get(`/attendees/${alice.attendeeId}`),
      await h.get("/sessions/keynote/attendees"),
      await h.get("/health"),
      await h.get("/chain/info"),
    ];
    for (const response of responses) {
      const text = JSON.stringify(response.body);
      expect(text).not.toMatch(/email|PRIVATE KEY/i);
    }
    expect(JSON.stringify(responses[2]?.body)).not.toContain(alice.publicKey);
    // No log line carries the private key, the signature or the public key.
    for (const line of logged) {
      expect(line).not.toContain(reg.signature);
      expect(line).not.toContain(alice.publicKey);
      expect(line).not.toContain("PRIVATE KEY");
    }
  });
});
