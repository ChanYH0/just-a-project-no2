import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { nextDifficulty, type BlockCandidate } from "@conference-chain/shared";
import { attend, getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

function code(body: Record<string, unknown>): unknown {
  return (body["error"] as { code?: string } | undefined)?.code;
}

describe("duplicates", () => {
  it("rejects a duplicate key across the mempool and the chain", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    expect((await h.post("/registrations", await register(alice, h.clock.now(), "one"))).status).toBe(202);
    const inMempool = await h.post("/registrations", await register(alice, h.clock.now(), "two"));
    expect(inMempool.status).toBe(409);
    expect(code(inMempool.body)).toBe("KEY_ALREADY_REGISTERED");
    await h.mineNow();
    const onChain = await h.post("/registrations", await register(alice, h.clock.now(), "three"));
    expect(onChain.status).toBe(409);
    expect(code(onChain.body)).toBe("KEY_ALREADY_REGISTERED");
  });

  it("never lets two registrations of one key share a block", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const first = await register(alice, h.clock.now(), "one");
    const second = await register(alice, h.clock.now(), "two");
    h.workers.autoMine = true;
    const head = h.node.ledger.head;
    const candidate: BlockCandidate = {
      index: 1,
      timestamp: h.clock.now(),
      previousHash: head.hash,
      difficulty: nextDifficulty(h.node.ledger.blocks, h.node.settings.config),
      records: [first, second],
    };
    h.miner.startJob(candidate);
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(0);
    expect((await h.chainFile()).trim().split("\n")).toHaveLength(1);
    await h.node.assertInvariants();
  });

  it("A1: concurrent identical attendance submissions accept exactly one", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    await h.post("/registrations", await register(alice, h.clock.now()));
    await h.mineNow();
    const record = await attend(alice, "keynote", h.clock.now());
    const results = await Promise.all(Array.from({ length: 5 }, () => h?.post("/attendance", record)));
    const statuses = results.map((result) => result?.status).sort();
    expect(statuses).toEqual([202, 409, 409, 409, 409]);
    expect(code(results.find((r) => r?.status === 409)?.body ?? {})).toBe("DUPLICATE_ATTENDANCE");
    await h.mineNow();
    const replay = await h.post("/attendance", record);
    expect(replay.status).toBe(409);
    await h.node.assertInvariants();
  });

  it("concurrent identical registrations accept exactly one", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const record = await register(alice, h.clock.now());
    const results = await Promise.all([h.post("/registrations", record), h.post("/registrations", record)]);
    expect(results.map((r) => r.status).sort()).toEqual([202, 409]);
    expect(h.miner.mempool.size).toBe(1);
  });
});
