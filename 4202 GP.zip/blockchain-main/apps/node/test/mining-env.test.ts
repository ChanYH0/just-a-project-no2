import { describe, expect, it } from "vitest";
import { parseEnv } from "../src/env.js";
import { MINING_WORKERS_MAX, METAL_BATCH_SIZE_MAX } from "../src/mining-config.js";

const base = { CONFERENCE_ID: "mining-execution-test", PROFILE: "test" };
describe("mining execution settings", () => {
  it("defaults to one CPU worker without changing chain identity", () => {
    const cpu = parseEnv(base);
    const metal = parseEnv({ ...base, MINING_BACKEND: "metal", MINING_WORKERS: "2" });
    expect(cpu).toMatchObject({ miningBackend: "cpu", miningWorkers: 1 });
    expect(metal.config).toEqual(cpu.config);
  });
  it.each([
    { MINING_BACKEND: "cuda" }, { MINING_WORKERS: "0" }, { MINING_WORKERS: "1.5" },
    { MINING_WORKERS: String(MINING_WORKERS_MAX + 1) }, { METAL_BATCH_SIZE: "0" },
    { METAL_BATCH_SIZE: String(METAL_BATCH_SIZE_MAX + 1) },
  ])("rejects invalid execution settings %j", (settings) => {
    expect(() => parseEnv({ ...base, ...settings })).toThrow();
  });
});
