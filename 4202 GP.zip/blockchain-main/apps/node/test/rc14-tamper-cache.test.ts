// RC14 (tamper-check bullets): the tamper cache key, its isolation from the validate cache and the simulation, bounds,
// head-change invalidation and stale results. The /chain/validate bullets live in rc14-cache-keys.test.ts.

import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { getProfile } from "@conference-chain/shared";
import { BoundedCache, tamperCacheKey } from "../src/validation-cache.js";
import { CONFERENCE_ID, TEST_CONFIG, attend, getKeys, makeHarness, register, until, type Harness, type TestKeys } from "./support.js";
import { TAMPER_URL, buildLiveChain, errorCode, tamper } from "./tamper-support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  h = await makeHarness({ enableDemoRoutes: true, ...options });
  await buildLiveChain(h, keys);
  return h;
}

describe("RC14: tamper-check cache hits and misses", () => {
  it("an identical (head, mutation, blockIndex) triple is a hit: the worker runs once", async () => {
    const harness = await boot();
    const first = await tamper(harness, "edit-record", 2);
    const second = await tamper(harness, "edit-record", 2);
    expect(second.body).toEqual(first.body);
    expect(harness.validationWorkers.count("tamper")).toBe(1);
    expect(harness.node.tamperCache.size).toBe(1);
  });

  it("the same head with a different mutation is a miss", async () => {
    const harness = await boot();
    await tamper(harness, "edit-record", 2);
    await tamper(harness, "rehash-after-edit", 2);
    expect(harness.validationWorkers.count("tamper")).toBe(2);
    expect(harness.node.tamperCache.size).toBe(2);
  });

  it("the same mutation with a different blockIndex is a miss", async () => {
    const harness = await boot();
    await tamper(harness, "edit-record", 2);
    await tamper(harness, "edit-record", 3);
    expect(harness.validationWorkers.count("tamper")).toBe(2);
  });

  it("a cached failure verdict and a cached ok:true (delete) verdict both come back identical", async () => {
    const harness = await boot();
    const del1 = await tamper(harness, "delete-record-and-remine", 2);
    const del2 = await tamper(harness, "delete-record-and-remine", 2);
    expect(del1.body["ok"]).toBe(true);
    expect(del2.body).toEqual(del1.body);
    expect(harness.validationWorkers.count("tamper")).toBe(1);
  });

  it("request validation errors never reach the worker or the cache", async () => {
    const harness = await boot();
    await tamper(harness, "edit-record", 0);
    await tamper(harness, "lower-difficulty", 1);
    await tamper(harness, "delete-record-and-remine", 1);
    expect(harness.validationWorkers.jobs).toHaveLength(0);
    expect(harness.node.tamperCache.size).toBe(0);
  });
});

describe("RC14: tamper-check cache key", () => {
  const head = "0".repeat(63) + "a";
  const base = tamperCacheKey("chain", TEST_CONFIG, head, "edit-record", 2);

  it("changes with chainId, configHash, headHash, mutation and blockIndex", () => {
    expect(tamperCacheKey("other", TEST_CONFIG, head, "edit-record", 2)).not.toBe(base);
    expect(tamperCacheKey("chain", getProfile("demo", CONFERENCE_ID), head, "edit-record", 2)).not.toBe(base);
    expect(tamperCacheKey("chain", TEST_CONFIG, "0".repeat(63) + "b", "edit-record", 2)).not.toBe(base);
    expect(tamperCacheKey("chain", TEST_CONFIG, head, "rehash-after-edit", 2)).not.toBe(base);
    expect(tamperCacheKey("chain", TEST_CONFIG, head, "edit-record", 3)).not.toBe(base);
    expect(tamperCacheKey("chain", TEST_CONFIG, head, "edit-record", 2)).toBe(base);
  });

  it("has its own prefix, never colliding with validate keys", () => {
    expect(base.startsWith("tamper:")).toBe(true);
  });

  it("the key does not make 1:23 and 12:3 style collisions (index vs hash boundary)", () => {
    expect(tamperCacheKey("chain", TEST_CONFIG, head, "edit-record", 12)).not.toBe(
      tamperCacheKey("chain", TEST_CONFIG, head, "edit-record", 1),
    );
  });
});

describe("RC14: separation from the validate cache and the simulation", () => {
  it("is a distinct cache instance; a tamper result never answers /chain/validate and vice versa", async () => {
    const harness = await boot();
    expect(harness.node.tamperCache).not.toBe(harness.node.validationCache);
    await tamper(harness, "edit-record", 2);
    expect(harness.node.validationCache.size).toBe(0);
    // /chain/validate runs its own job and verdict (the live chain is valid), unaffected by the tamper verdict.
    harness.heavyRateClock.advance(60_001);
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(1);
    expect(harness.node.validationCache.size).toBe(1);
    expect(harness.node.tamperCache.size).toBe(1);
    // and the other way around: the cached validate entry does not satisfy a tamper request for another mutation
    await tamper(harness, "edit-previous-hash", 2);
    expect(harness.validationWorkers.count("tamper")).toBe(2);
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(1);
  });

  it("the simulation never reads, writes or clears either cache", async () => {
    const harness = await boot();
    await tamper(harness, "edit-record", 2);
    const spies = [harness.node.tamperCache, harness.node.validationCache].flatMap((cache) => [
      vi.spyOn(cache, "get"),
      vi.spyOn(cache, "set"),
      vi.spyOn(cache, "clear"),
    ]);
    const sizes = [harness.node.tamperCache.size, harness.node.validationCache.size];
    const body = { count: 4, intervalMs: 10 };
    harness.heavyRateClock.advance(60_001);
    const first = await harness.post("/demo/difficulty-simulation", body);
    harness.heavyRateClock.advance(60_001);
    const second = await harness.post("/demo/difficulty-simulation", body);
    expect(first.status).toBe(200);
    expect(second.body).toEqual(first.body);
    expect(harness.validationWorkers.count("simulate")).toBe(2);
    for (const spy of spies) {
      expect(spy).not.toHaveBeenCalled();
    }
    expect([harness.node.tamperCache.size, harness.node.validationCache.size]).toEqual(sizes);
  });
});

describe("RC14: tamper cache invalidation and bounds", () => {
  it("a head change clears the tamper cache; the same request afterwards re-runs the worker", async () => {
    const harness = await boot();
    await tamper(harness, "edit-record", 2);
    expect(harness.node.tamperCache.size).toBe(1);
    const dave = keys[2] as TestKeys;
    expect((await harness.post("/attendance", await attend(dave, "keynote", harness.clock.now(), harness.node.chainId))).status).toBe(202);
    await harness.mineNow();
    expect(harness.node.tamperCache.size).toBe(0);
    const again = await tamper(harness, "edit-record", 2);
    expect(again.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH" });
    expect(harness.validationWorkers.count("tamper")).toBe(2);
  });

  it("a result computed for an older head is not stored when the head changed while the worker ran", async () => {
    const harness = await boot();
    const release = harness.validationWorkers.hold();
    harness.heavyRateClock.advance(60_001);
    const pending = harness.post(TAMPER_URL, { mutation: "edit-record", blockIndex: 2 });
    await until(() => harness.validationWorkers.count("tamper") === 1, "tamper job started");
    // Carol is registered but has not attended yet: her attendance moves the head while the job waits.
    const carol = keys[2] as TestKeys;
    expect((await harness.post("/attendance", await attend(carol, "keynote",harness.clock.now(), harness.node.chainId))).status).toBe(202);
    await harness.mineNow();
    expect(harness.node.ledger.head.index).toBe(7);
    release();
    const response = await pending;
    // The verdict still describes the head the request started on.
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
    expect(harness.node.tamperCache.size).toBe(0);
  });

  it("65 distinct keys leave 64 entries and the oldest is evicted (same bounded cache type and bound as the node's)", async () => {
    const harness = await boot();
    expect(harness.node.tamperCache).toBeInstanceOf(BoundedCache);
    const outcome = { kind: "tamper", result: { ok: true }, note: "n" } as const;
    for (let i = 0; i < 65; i += 1) {
      harness.node.tamperCache.set(`k${i}`, outcome);
    }
    expect(harness.node.tamperCache.size).toBe(64);
    expect(harness.node.tamperCache.get("k0")).toBeUndefined();
    expect(harness.node.tamperCache.get("k1")).toEqual(outcome);
    expect(harness.node.tamperCache.get("k64")).toEqual(outcome);
  });
});

describe("RC14: tamper job lifecycle", () => {
  it("two concurrent requests are queued: one worker job at a time, both answered", async () => {
    const harness = await boot();
    const release = harness.validationWorkers.hold();
    harness.heavyRateClock.advance(60_001);
    const first = harness.post(TAMPER_URL, { mutation: "edit-record", blockIndex: 2 });
    const second = harness.post(TAMPER_URL, { mutation: "rehash-after-edit", blockIndex: 3 });
    await until(() => harness.validationWorkers.jobs.length === 1, "first job started");
    // give the second request every chance to start early
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(harness.validationWorkers.jobs).toHaveLength(1);
    release();
    const [a, b] = await Promise.all([first, second]);
    expect(a.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
    expect(b.body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 3 });
    expect(harness.validationWorkers.count("tamper")).toBe(2);
  });

  it("a job exceeding the timeout is 500 INTERNAL, the worker is terminated and nothing is cached", async () => {
    h = await makeHarness({ enableDemoRoutes: true, validationTimeoutMs: 50 });
    const harness = h;
    await buildLiveChain(harness, keys);
    const release = harness.validationWorkers.hold();
    const response = await tamper(harness, "edit-record", 2);
    expect(response.status).toBe(500);
    expect(errorCode(response.body)).toBe("INTERNAL");
    expect(response.body["ok"]).toBeUndefined();
    expect(harness.validationWorkers.terminated).toBeGreaterThanOrEqual(1);
    expect(harness.node.tamperCache.size).toBe(0);
    release();
    // the node recovers: the next request gets a fresh worker and a real verdict
    const ok = await tamper(harness, "edit-record", 2);
    expect(ok.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH" });
  });
});

describe("RC14: register helper sanity", () => {
  it("the chain id helper used by the tamper tests matches the node", async () => {
    const harness = await boot();
    const bob = keys[1] as TestKeys;
    // bob is already registered by buildLiveChain: a second registration of the same key is a duplicate (409)
    const dup = await harness.post("/registrations", await register(bob, harness.clock.now(), "bob", harness.node.chainId));
    expect(dup.status).toBe(409);
  });
});
