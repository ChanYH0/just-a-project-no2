// RC11 (SPEC 14.2): record-type-aware tamper mutations through POST /demo/tamper-check. The pure mutation functions are
// covered in packages/shared/test/mutations.test.ts; here every RC11 bullet is checked over HTTP against the real validator.

import { rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { canonicalize, makeGenesis, mineBlock, nodeHash, type Block } from "@conference-chain/shared";
import { attend, getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";
import {
  CHAIN_LENGTH,
  LIVE_HEAD,
  TAMPER_URL,
  buildLiveChain,
  errorCode,
  expectLiveUnchanged,
  snapshotLive,
  tamper,
} from "./tamper-support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;
const cleanup: string[] = [];

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
  for (const dir of cleanup.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  h = await makeHarness({ enableDemoRoutes: true, ...options });
  return h;
}

// Calls the endpoint and asserts that nothing live changed.
async function checkedTamper(
  harness: Harness,
  mutation: string,
  blockIndex: unknown,
): Promise<{ status: number; body: Record<string, unknown> }> {
  const before = await snapshotLive(harness);
  const response = await tamper(harness, mutation, blockIndex);
  await expectLiveUnchanged(harness, before);
  return response;
}

describe("RC11: edit-record and rehash-after-edit are record-type aware", () => {
  it.each([
    ["registration only", 1],
    ["attendance only", 2],
    ["mixed block, attendance first (mutation applies to the first record by type)", 5],
  ])("%s (block %i): edit-record -> BAD_BLOCK_HASH, rehash-after-edit -> INVALID_SIGNATURE at that index", async (_name, index) => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const edit = await checkedTamper(harness, "edit-record", index);
    expect(edit.status).toBe(200);
    expect(edit.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: index });
    expect(typeof edit.body["note"]).toBe("string");
    const rehash = await checkedTamper(harness, "rehash-after-edit", index);
    expect(rehash.status).toBe(200);
    expect(rehash.body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: index });
  });

  it("holds for every block of the live chain, both record types, with no crash from a missing field", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (let index = 1; index <= LIVE_HEAD; index += 1) {
      expect((await checkedTamper(harness, "edit-record", index)).body).toMatchObject({
        ok: false,
        code: "BAD_BLOCK_HASH",
        blockIndex: index,
      });
      expect((await checkedTamper(harness, "rehash-after-edit", index)).body).toMatchObject({
        ok: false,
        code: "INVALID_SIGNATURE",
        blockIndex: index,
      });
    }
  });

  it("edit-previous-hash -> BAD_PREVIOUS_HASH and lower-difficulty -> BAD_DIFFICULTY at that index", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (let index = 1; index <= LIVE_HEAD; index += 1) {
      expect((await checkedTamper(harness, "edit-previous-hash", index)).body).toMatchObject({
        ok: false,
        code: "BAD_PREVIOUS_HASH",
        blockIndex: index,
      });
    }
    // Blocks 4..6 require difficulty 2 (equal timestamps raise it at the first boundary).
    for (const index of [4, 5, 6]) {
      expect((await checkedTamper(harness, "lower-difficulty", index)).body).toMatchObject({
        ok: false,
        code: "BAD_DIFFICULTY",
        blockIndex: index,
      });
    }
  });
});

describe("RC11: blockIndex and empty-block rules", () => {
  it("blockIndex 0, the chain length and beyond are 400 INVALID_SCHEMA for every mutation", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (const mutation of ["edit-record", "edit-previous-hash", "rehash-after-edit", "lower-difficulty", "delete-record-and-remine"]) {
      for (const index of [0, CHAIN_LENGTH, CHAIN_LENGTH + 1, 1_000_000]) {
        const response = await checkedTamper(harness, mutation, index);
        expect(response.status, `${mutation} ${index}`).toBe(400);
        expect(errorCode(response.body)).toBe("INVALID_SCHEMA");
      }
    }
    expect(harness.validationWorkers.jobs).toHaveLength(0);
  });

  it("a malformed body is 400 INVALID_SCHEMA: unknown mutation, wrong types, -0, extra fields, missing fields", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    const bodies: unknown[] = [
      { mutation: "nope", blockIndex: 1 },
      { mutation: "edit-record", blockIndex: "1" },
      { mutation: "edit-record", blockIndex: 1.5 },
      { mutation: "edit-record", blockIndex: -1 },
      { mutation: "edit-record", blockIndex: 1, extra: true },
      { mutation: "edit-record" },
      { blockIndex: 1 },
      {},
    ];
    for (const body of bodies) {
      harness.heavyRateClock.advance(60_001);
      const response = await harness.post(TAMPER_URL, body);
      expect(response.status, JSON.stringify(body)).toBe(400);
      expect(errorCode(response.body)).toBe("INVALID_SCHEMA");
    }
    // -0 cannot be written by JSON.stringify of a number, so send the raw text.
    harness.heavyRateClock.advance(60_001);
    const raw = await harness.node.app.inject({
      method: "POST",
      url: TAMPER_URL,
      payload: '{"mutation":"edit-record","blockIndex":-0}',
      headers: { "content-type": "application/json" },
    });
    expect(raw.statusCode).toBe(400);
    expect(harness.validationWorkers.jobs).toHaveLength(0);
  });

  it("a block with no records is 400 INVALID_SCHEMA for every mutation", async () => {
    // The live node never mines an empty block, so the chain file is prepared offline (an empty block is valid).
    const harness = await boot({ keepDir: true });
    const dir = harness.dataDir;
    cleanup.push(dir);
    await harness.stop();
    h = null;
    const genesis = makeGenesis(harness.node.settings.config, nodeHash);
    const empty = mineBlock(
      { index: 1, timestamp: genesis.timestamp + 1, previousHash: genesis.hash, difficulty: 1, records: [] },
      nodeHash,
    );
    if (empty === null) {
      throw new Error("mining failed");
    }
    const lines: Block[] = [genesis, empty];
    await writeFile(join(dir, "chain.jsonl"), lines.map((block) => `${canonicalize(block)}\n`).join(""));
    const again = await boot({ dataDir: dir });
    expect(again.node.ledger.head.index).toBe(1);
    for (const mutation of ["edit-record", "edit-previous-hash", "rehash-after-edit", "lower-difficulty", "delete-record-and-remine"]) {
      const response = await checkedTamper(again, mutation, 1);
      expect(response.status, mutation).toBe(400);
      expect(errorCode(response.body)).toBe("INVALID_SCHEMA");
    }
    expect(again.validationWorkers.jobs).toHaveLength(0);
  });
});

describe("RC11: delete-record-and-remine", () => {
  it("on a block with no attendance record -> 400; on a block with one -> ok:true with a non-empty note", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (const index of [1, 4]) {
      const refused = await checkedTamper(harness, "delete-record-and-remine", index);
      expect(refused.status).toBe(400);
      expect(errorCode(refused.body)).toBe("INVALID_SCHEMA");
    }
    for (const index of [2, 3, 5, 6]) {
      const accepted = await checkedTamper(harness, "delete-record-and-remine", index);
      expect(accepted.status, `block ${index}`).toBe(200);
      expect(accepted.body["ok"]).toBe(true);
      expect(accepted.body["code"]).toBeUndefined();
      const note = accepted.body["note"];
      expect(typeof note === "string" && note.length > 0).toBe(true);
      expect(String(note)).toMatch(/tamper-evident, not distributed consensus/);
    }
  });

  it("refuses when more than 10 blocks would need re-mining, accepts exactly 10", async () => {
    const sessionIds = Array.from({ length: 12 }, (_, i) => `s${i}`);
    const harness = await boot({ sessions: sessionIds.map((id) => ({ id, title: id })) });
    const [alice] = keys as [TestKeys];
    await harness.post("/registrations", await register(alice, harness.clock.now(), "alice", harness.node.chainId));
    await harness.mineNow();
    for (const id of sessionIds) {
      await harness.post("/attendance", await attend(alice, id, harness.clock.now(), harness.node.chainId));
      await harness.mineNow();
    }
    expect(harness.node.ledger.head.index).toBe(13);
    // blockIndex 3 -> blocks 3..13 = 11 blocks; blockIndex 4 -> 10 blocks.
    const tooMany = await checkedTamper(harness, "delete-record-and-remine", 3);
    expect(tooMany.status).toBe(400);
    expect(errorCode(tooMany.body)).toBe("INVALID_SCHEMA");
    const exact = await checkedTamper(harness, "delete-record-and-remine", 4);
    expect(exact.status).toBe(200);
    expect(exact.body["ok"]).toBe(true);
  });

  it("is refused with 400 in the production profile; the other mutations still run there", async () => {
    const harness = await boot({ profile: "production" });
    const [alice] = keys as [TestKeys];
    await harness.post("/registrations", await register(alice, harness.clock.now(), "alice", harness.node.chainId));
    await harness.mineNow();
    await harness.post("/attendance", await attend(alice, "keynote", harness.clock.now(), harness.node.chainId));
    await harness.mineNow();
    const refused = await checkedTamper(harness, "delete-record-and-remine", 2);
    expect(refused.status).toBe(400);
    expect(errorCode(refused.body)).toBe("INVALID_SCHEMA");
    expect(harness.validationWorkers.jobs).toHaveLength(0);
    const edit = await checkedTamper(harness, "edit-record", 2);
    expect(edit.body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
  });

  it("is allowed in the demo profile", async () => {
    const harness = await boot({ profile: "demo" });
    const [alice] = keys as [TestKeys];
    await harness.post("/registrations", await register(alice, harness.clock.now(), "alice", harness.node.chainId));
    await harness.mineNow();
    await harness.post("/attendance", await attend(alice, "keynote", harness.clock.now(), harness.node.chainId));
    await harness.mineNow();
    const accepted = await checkedTamper(harness, "delete-record-and-remine", 2);
    expect(accepted.body["ok"]).toBe(true);
  });
});

describe("RC11: the live chain is never touched", () => {
  it("chain bytes, head, blocks and mempool are identical before and after every mutation, including a pending record", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    // a record waiting in the mempool must survive too
    const [alice] = keys as [TestKeys];
    expect((await harness.post("/attendance", await attend(alice, "workshop", harness.clock.now() + 1, harness.node.chainId))).status).toBe(409);
    const pending = await harness.post("/registrations", await register(keys[2] as TestKeys, harness.clock.now(), "dup", harness.node.chainId));
    expect(pending.status).toBe(409);
    const before = await snapshotLive(harness);
    for (const [mutation, index] of [
      ["edit-record", 3],
      ["edit-previous-hash", 3],
      ["rehash-after-edit", 3],
      ["lower-difficulty", 5],
      ["delete-record-and-remine", 3],
    ] as const) {
      const response = await tamper(harness, mutation, index);
      expect(response.status).toBe(200);
      await expectLiveUnchanged(harness, before);
    }
    // the live chain is still valid and still mines after the calls
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
  });

  it("the route is absent (404) unless demo routes are enabled", async () => {
    const harness = await boot({ enableDemoRoutes: false });
    const response = await tamper(harness, "edit-record", 1);
    expect(response.status).toBe(404);
    expect(errorCode(response.body)).toBe("NOT_FOUND");
  });

  it("shares the 6/min /demo/* rate limit: the 7th call in a window is 429 RATE_LIMITED", async () => {
    const harness = await boot();
    await buildLiveChain(harness, keys);
    for (let i = 0; i < 6; i += 1) {
      expect((await harness.post(TAMPER_URL, { mutation: "edit-record", blockIndex: 1 })).status).toBe(200);
    }
    const limited = await harness.post(TAMPER_URL, { mutation: "edit-record", blockIndex: 1 });
    expect(limited.status).toBe(429);
    expect(errorCode(limited.body)).toBe("RATE_LIMITED");
  });

  it("runs in the real validation worker thread too (same results as the in-process double)", async () => {
    const harness = await boot({ realValidationWorker: true });
    await buildLiveChain(harness, keys);
    const before = await snapshotLive(harness);
    expect((await tamper(harness, "edit-record", 2)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
    expect((await tamper(harness, "rehash-after-edit", 5)).body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 5 });
    const deleted = await tamper(harness, "delete-record-and-remine", 2);
    expect(deleted.body["ok"]).toBe(true);
    await expectLiveUnchanged(harness, before);
  });
});
