// Shared helpers for the tamper-check tests (RC11, RC14, RC15, A1-A9): a live chain with known contents, a rate-limit
// friendly caller and a snapshot of everything the tamper-check must never change.

import { expect } from "vitest";
import { attend, register, type Harness, type TestKeys } from "./support.js";

export const TAMPER_URL = "/demo/tamper-check";

export type MutationName =
  | "edit-record"
  | "edit-previous-hash"
  | "rehash-after-edit"
  | "lower-difficulty"
  | "delete-record-and-remine";

// Block layout produced by buildLiveChain (test profile, all timestamps equal, so the required difficulty is 1 for
// blocks 1..3 and 2 from block 4):
//   1: [register alice]            2: [attend alice keynote]       3: [attend alice workshop]
//   4: [register bob]              5: [attend alice panel, register carol]   (mixed, attendance FIRST)
//   6: [attend bob keynote]
export const LIVE_HEAD = 6;
export const CHAIN_LENGTH = 7;

export async function buildLiveChain(h: Harness, keys: readonly TestKeys[]): Promise<void> {
  const [alice, bob, carol] = keys;
  if (alice === undefined || bob === undefined || carol === undefined) {
    throw new Error("buildLiveChain needs three keys");
  }
  const chainId = h.node.chainId;
  const now = (): number => h.clock.now();
  const steps: (() => Promise<unknown>)[] = [
    async () => h.post("/registrations", await register(alice, now(), "alice", chainId)),
    async () => h.post("/attendance", await attend(alice, "keynote", now(), chainId)),
    async () => h.post("/attendance", await attend(alice, "workshop", now(), chainId)),
    async () => h.post("/registrations", await register(bob, now(), "bob", chainId)),
    async () => h.post("/attendance", await attend(alice, "panel", now(), chainId)),
    async () => h.post("/registrations", await register(carol, now(), "carol", chainId)),
    async () => h.post("/attendance", await attend(bob, "keynote", now(), chainId)),
  ];
  // Steps 4 and 5 (indexes 4 and 5) share one block; every other step is its own block.
  for (let i = 0; i < steps.length; i += 1) {
    const step = steps[i];
    if (step === undefined) {
      throw new Error("missing step");
    }
    const response = (await step()) as { status: number };
    expect(response.status).toBe(202);
    if (i !== 4) {
      await h.mineNow();
    }
  }
  expect(h.node.ledger.head.index).toBe(LIVE_HEAD);
}

// The tamper-check shares the 6/min /demo/* rate limit; each call opens a new window on the separate limiter clock.
export async function tamper(
  h: Harness,
  mutation: MutationName | string,
  blockIndex: unknown,
): Promise<{ status: number; body: Record<string, unknown> }> {
  h.heavyRateClock.advance(60_001);
  return h.post(TAMPER_URL, { mutation, blockIndex });
}

export interface LiveSnapshot {
  file: string;
  headHash: string;
  headIndex: number;
  blocks: string;
  mempool: unknown;
}

export async function snapshotLive(h: Harness): Promise<LiveSnapshot> {
  return {
    file: await h.chainFile(),
    headHash: h.node.ledger.head.hash,
    headIndex: h.node.ledger.head.index,
    blocks: JSON.stringify(h.node.ledger.blocks),
    mempool: (await h.get("/mempool")).body,
  };
}

export async function expectLiveUnchanged(h: Harness, before: LiveSnapshot): Promise<void> {
  const after = await snapshotLive(h);
  expect(after.file).toBe(before.file);
  expect(after.headHash).toBe(before.headHash);
  expect(after.headIndex).toBe(before.headIndex);
  expect(after.blocks).toBe(before.blocks);
  expect(after.mempool).toEqual(before.mempool);
  await h.node.assertInvariants();
}

export function errorCode(body: Record<string, unknown>): unknown {
  const error = body["error"];
  return typeof error === "object" && error !== null && "code" in error ? error.code : undefined;
}
