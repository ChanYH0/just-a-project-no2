// RC14: cache keys (all bullets except the tamper-check ones, which arrive with the tamper-check task).
// Uses a counting validation-worker double (CountingValidationWorkers runs the real job code and counts jobs).

import { appendFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { getProfile } from "@conference-chain/shared";
import { BoundedCache, configHash, validateCacheKey } from "../src/validation-cache.js";
import {
  CONFERENCE_ID,
  TEST_CONFIG,
  attend,
  getKeys,
  makeHarness,
  register,
  until,
  type Harness,
  type TestKeys,
} from "./support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(2);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

function key(index: number): TestKeys {
  const value = keys[index];
  if (value === undefined) {
    throw new Error("missing key");
  }
  return value;
}

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  h = await makeHarness(options);
  return h;
}

async function registerAlice(harness: Harness): Promise<void> {
  expect((await harness.post("/registrations", await register(key(0), harness.clock.now(), "alice"))).status).toBe(202);
  await harness.mineNow();
}

describe("RC14: /chain/validate cache", () => {
  it("an identical snapshot is a hit: the worker runs once for two requests", async () => {
    const harness = await boot();
    await registerAlice(harness);
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(1);
    expect(harness.node.validationCache.size).toBe(1);
  });

  it("editing one byte of chain.jsonl misses the cache and reports the specific code", async () => {
    const harness = await boot();
    await registerAlice(harness);
    await harness.get("/chain/validate");
    const text = await harness.chainFile();
    await writeFile(join(harness.dataDir, "chain.jsonl"), text.replace('"alias":"alice"', '"alias":"alicf"'));
    const result = await harness.get("/chain/validate");
    expect(result.body["ok"]).toBe(false);
    expect(result.body["code"]).toBe("BAD_BLOCK_HASH");
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(2);
    // The failure itself is cached for the edited bytes; restoring the bytes hits the first entry again.
    await writeFile(join(harness.dataDir, "chain.jsonl"), text);
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(2);
  });

  it("a different configHash (different profile) gives a different cache key for the same bytes", () => {
    const bytes = new TextEncoder().encode("same bytes\n");
    const demo = getProfile("demo", CONFERENCE_ID);
    expect(configHash(demo)).not.toBe(configHash(TEST_CONFIG));
    expect(validateCacheKey("chain", demo, bytes)).not.toBe(validateCacheKey("chain", TEST_CONFIG, bytes));
    // chainId and bytes are key components too.
    expect(validateCacheKey("other", TEST_CONFIG, bytes)).not.toBe(validateCacheKey("chain", TEST_CONFIG, bytes));
    expect(validateCacheKey("chain", TEST_CONFIG, new TextEncoder().encode("same bytes!\n"))).not.toBe(
      validateCacheKey("chain", TEST_CONFIG, bytes),
    );
    // Non-consensus tunables are not part of configHash.
    expect(configHash({ ...TEST_CONFIG, maxBlockSkewMs: TEST_CONFIG.maxBlockSkewMs + 1 })).toBe(configHash(TEST_CONFIG));
    expect(configHash({ ...TEST_CONFIG, targetBlockTimeMs: TEST_CONFIG.targetBlockTimeMs + 1 })).not.toBe(
      configHash(TEST_CONFIG),
    );
  });

  it("bytes appended after the request-start stat do not affect the response", async () => {
    const harness = await boot();
    await registerAlice(harness);
    const release = harness.validationWorkers.hold();
    const pending = harness.get("/chain/validate");
    await until(() => harness.validationWorkers.jobs.length === 1, "validation job started");
    // The snapshot was already taken; garbage and a whole extra block line land on disk afterwards.
    await appendFile(join(harness.dataDir, "chain.jsonl"), '{"garbage":true}\n{"torn":');
    release();
    expect((await pending).body).toEqual({ ok: true });
    // Also when the extra bytes are there before the request starts (stat sees a longer file).
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(1);
  });

  it("a head change clears the caches; the same request afterwards re-runs the worker", async () => {
    const harness = await boot();
    await registerAlice(harness);
    await harness.get("/chain/validate");
    expect(harness.node.validationCache.size).toBe(1);
    expect((await harness.post("/registrations", await register(key(1), harness.clock.now(), "bob"))).status).toBe(202);
    await harness.mineNow();
    expect(harness.node.validationCache.size).toBe(0);
    expect((await harness.get("/chain/validate")).body).toEqual({ ok: true });
    expect(harness.validationWorkers.count("validate-snapshot")).toBe(2);
    expect(harness.node.validationCache.size).toBe(1);
  });

  it("a result computed for an older head is not stored when the head changed while the worker ran", async () => {
    const harness = await boot();
    await registerAlice(harness);
    const release = harness.validationWorkers.hold();
    const pending = harness.get("/chain/validate");
    await until(() => harness.validationWorkers.jobs.length === 1, "validation job started");
    expect((await harness.post("/attendance", await attend(key(0), "keynote", harness.clock.now()))).status).toBe(202);
    harness.timers.advance(1000);
    await harness.miner.settled();
    expect(harness.node.ledger.head.index).toBe(2);
    release();
    // The snapshot was taken at head 1 (committed size at request start): still consistent with that head.
    expect((await pending).status).toBe(200);
    expect(harness.node.validationCache.size).toBe(0);
  });
});

describe("RC14: the cache is bounded", () => {
  it("65 distinct keys leave 64 entries and the oldest is evicted", () => {
    const cache = new BoundedCache<number>();
    for (let i = 0; i < 65; i += 1) {
      cache.set(`key-${i}`, i);
    }
    expect(cache.size).toBe(64);
    expect(cache.get("key-0")).toBeUndefined();
    expect(cache.get("key-1")).toBe(1);
    expect(cache.get("key-64")).toBe(64);
  });

  it("re-setting a key refreshes it; clear empties the cache", () => {
    const cache = new BoundedCache<number>(2);
    cache.set("a", 1);
    cache.set("b", 2);
    cache.set("a", 3);
    cache.set("c", 4);
    expect(cache.get("b")).toBeUndefined();
    expect(cache.get("a")).toBe(3);
    cache.clear();
    expect(cache.size).toBe(0);
  });

  it("the node's validate cache uses the 64 entry bound", async () => {
    const harness = await boot();
    for (let i = 0; i < 65; i += 1) {
      harness.node.validationCache.set(`k${i}`, { kind: "validate-snapshot", result: { ok: true }, blockCount: 1, headHash: null });
    }
    expect(harness.node.validationCache.size).toBe(64);
  });
});

describe("RC14: the simulation is never cached", () => {
  it("two identical calls run the worker twice and never read or write the validation caches", async () => {
    const harness = await boot({ enableDemoRoutes: true });
    await registerAlice(harness);
    await harness.get("/chain/validate");
    const cache = harness.node.validationCache;
    const sizeBefore = cache.size;
    const spies = [vi.spyOn(cache, "get"), vi.spyOn(cache, "set"), vi.spyOn(cache, "clear")];
    const body = { count: 4, intervalMs: 10 };
    const first = await harness.post("/demo/difficulty-simulation", body);
    const second = await harness.post("/demo/difficulty-simulation", body);
    expect(first.status).toBe(200);
    expect(second.body).toEqual(first.body);
    expect(harness.validationWorkers.count("simulate")).toBe(2);
    for (const spy of spies) {
      expect(spy).not.toHaveBeenCalled();
    }
    expect(cache.size).toBe(sizeBefore);
  });
});
