import { describe, expect, it } from "vitest";
import {
  computeBlockHash,
  makeGenesis,
  meetsProofOfWork,
  mineBlock,
  nodeHash,
  verifyBlockPow,
  type Block,
  type BlockCandidate,
} from "@conference-chain/shared";
import { createRealWorkerFactory } from "../src/worker-factory.js";
import type { MineJobMessage, MineWorkerHandle, WorkerHandlers, WorkerFactory } from "../src/mine-protocol.js";
import { createWorkerPool } from "../src/worker-pool.js";
import { TEST_CONFIG } from "./support.js";
import { infeasibleCandidate } from "./fixtures/infeasible-candidate.js";

const genesis = makeGenesis(TEST_CONFIG, nodeHash);

function candidate(index: number, difficulty = 3): BlockCandidate {
  return {
    index,
    timestamp: genesis.timestamp + index,
    previousHash: genesis.hash,
    difficulty,
    records: [],
  };
}

function start(handle: MineWorkerHandle, message: MineJobMessage): Promise<Block> {
  return new Promise<Block>((resolve, reject) => {
    handle.setHandlers({
      onMessage(raw) {
        if (typeof raw === "object" && raw !== null && "block" in raw) {
          resolve(raw.block as Block);
        } else {
          reject(new Error("worker returned a malformed result"));
        }
      },
      onError(error) { reject(error); },
      onExit(code) { reject(new Error(`worker exited before the result (${code})`)); },
    });
    handle.postMessage(message);
  });
}

describe("real CPU mining worker pools", () => {
  it.each([1, 2, 4])("mines simultaneous independent jobs with %i non-overlapping lanes", async (workerCount) => {
    const poolFactory = createRealWorkerFactory(workerCount);
    const jobs = [candidate(1), candidate(2)];
    const handles = jobs.map(() => poolFactory());
    try {
      const results = await Promise.all(jobs.map((blockCandidate, index) => {
        const handle = handles[index];
        if (handle === undefined) throw new Error("missing worker handle");
        return start(handle, { jobId: index + 1, candidate: blockCandidate });
      }));

      for (const [index, block] of results.entries()) {
        const expected = jobs[index];
        expect(expected).toBeDefined();
        expect(block.index).toBe(expected?.index);
        expect(block.timestamp).toBe(expected?.timestamp);
        expect(block.previousHash).toBe(expected?.previousHash);
        expect(block.difficulty).toBe(expected?.difficulty);
        expect(block.records).toEqual(expected?.records);
        expect(block.hash).toBe(computeBlockHash(block, nodeHash));
        expect(meetsProofOfWork(block.hash, block.difficulty)).toBe(true);
        expect(verifyBlockPow(block, nodeHash)).toBe(true);
      }
    } finally {
      await Promise.all(handles.map((handle) => handle.terminate()));
    }
  });

  it("terminating one infeasible pooled job leaves an independent worker job valid", async () => {
    const poolFactory = createRealWorkerFactory(4);
    const cancelled = poolFactory();
    const independent = poolFactory();
    let cancelledMessages = 0;
    cancelled.setHandlers({
      onMessage: () => { cancelledMessages += 1; },
      onError: () => { cancelledMessages += 1; },
      onExit: () => undefined,
    });
    cancelled.postMessage({ jobId: 40, candidate: infeasibleCandidate(genesis) });

    try {
      const block = await start(independent, { jobId: 41, candidate: candidate(41, 1) });
      expect(verifyBlockPow(block, nodeHash)).toBe(true);
      await cancelled.terminate();
      expect(cancelledMessages).toBe(0);
    } finally {
      await Promise.all([cancelled.terminate(), independent.terminate()]);
    }
  });
});

class ControlledWorker implements MineWorkerHandle {
  handlers: WorkerHandlers | null = null;
  posted: MineJobMessage | null = null;
  exited = false;

  setHandlers(handlers: WorkerHandlers): void { this.handlers = handlers; }
  postMessage(message: MineJobMessage): void { this.posted = message; }
  async terminate(): Promise<void> { this.exited = true; }

  answer(message: unknown): void { this.handlers?.onMessage(message); }
}

class ImmediateWorker extends ControlledWorker {
  override postMessage(message: MineJobMessage): void {
    super.postMessage(message);
    const laneBlock = mineBlock(message.candidate, nodeHash, undefined, {
      startNonce: message.nonceStart ?? 0,
      stride: message.nonceStride ?? 1,
    });
    if (laneBlock === null) throw new Error("lane unexpectedly cancelled");
    this.answer({ jobId: message.jobId, block: laneBlock });
  }
}

describe("worker pool validates and reaps lanes", () => {
  it("posts every nonce lane before accepting a synchronous worker result", async () => {
    const children: ImmediateWorker[] = [];
    const factory: WorkerFactory = () => {
      const child = new ImmediateWorker();
      children.push(child);
      return child;
    };
    const pool = createWorkerPool(factory, 4)();
    let result: unknown;
    let resolveReply: (() => void) | null = null;
    const reply = new Promise<void>((resolve) => { resolveReply = resolve; });
    pool.setHandlers({
      onMessage: (message) => { result = message; resolveReply?.(); },
      onError: (error) => { throw error; },
      onExit: () => undefined,
    });
    pool.postMessage({ jobId: 69, candidate: candidate(6, 1) });
    await reply;
    expect(children).toHaveLength(4);
    expect(children.map((child) => child.posted?.nonceStart)).toEqual([0, 1, 2, 3]);
    expect(children.map((child) => child.posted?.nonceStride)).toEqual([4, 4, 4, 4]);
    expect(result).toMatchObject({ jobId: 69 });
    expect(children.every((child) => child.exited)).toBe(true);
    await pool.terminate();
  });

  it("ignores stale results and publishes a valid lane result after all children stop", async () => {
    const children: ControlledWorker[] = [];
    const baseFactory: WorkerFactory = () => {
      const child = new ControlledWorker();
      children.push(child);
      return child;
    };
    const pool = createWorkerPool(baseFactory, 2)();
    const job = candidate(7, 1);
    let result: unknown;
    let resolveReply: (() => void) | null = null;
    const reply = new Promise<void>((resolve) => { resolveReply = resolve; });
    let errors = 0;
    let terminationsSeenAtReply = -1;
    pool.setHandlers({
      onMessage: (message) => {
        result = message;
        terminationsSeenAtReply = children.filter((child) => child.exited).length;
        resolveReply?.();
      },
      onError: () => { errors += 1; },
      onExit: () => undefined,
    });
    pool.postMessage({ jobId: 70, candidate: job });
    expect(children).toHaveLength(2);
    expect(children.map((child) => child.posted?.nonceStart)).toEqual([0, 1]);
    expect(children.map((child) => child.posted?.nonceStride)).toEqual([2, 2]);

    children[1]?.answer({ jobId: 69, block: mineBlock(job, nodeHash, undefined, { startNonce: 1, stride: 2 }) });
    expect(result).toBeUndefined();
    expect(errors).toBe(0);
    expect(children.some((child) => child.exited)).toBe(false);

    const winner = mineBlock(job, nodeHash, undefined, { startNonce: 1, stride: 2 });
    children[1]?.answer({ jobId: 70, block: winner });
    await reply;
    await pool.terminate();
    expect(errors).toBe(0);
    expect(terminationsSeenAtReply).toBe(2);
    expect(result).toMatchObject({ jobId: 70, block: winner });
  });

  it.each(["missing-block", "malformed-block", "wrong-candidate", "wrong-lane", "bad-hash", "bad-pow"] as const)(
    "fails and reaps all workers on a same-job %s result, then the next job succeeds",
    async (kind) => {
      const children: ControlledWorker[] = [];
      const baseFactory: WorkerFactory = () => {
        const child = new ControlledWorker();
        children.push(child);
        return child;
      };
      const poolFactory = createWorkerPool(baseFactory, 2);
      const pool = poolFactory();
      const job = candidate(13, 1);
      let fail!: (error: Error) => void;
      const failed = new Promise<Error>((resolve) => { fail = resolve; });
      pool.setHandlers({
        onMessage: () => { throw new Error("invalid worker output must not be accepted"); },
        onError: fail,
        onExit: () => undefined,
      });
      pool.postMessage({ jobId: 80, candidate: job });
      const [first, second] = children;
      if (first === undefined || second === undefined) throw new Error("worker lanes were not created");

      const goodLaneOne = mineBlock(job, nodeHash, undefined, { startNonce: 1, stride: 2 });
      // A stale result is still ignored, so a later valid same-job result could win.
      second.answer({ jobId: 79, block: goodLaneOne });

      let invalid: unknown;
      if (kind === "missing-block") {
        invalid = { jobId: 80 };
      } else if (kind === "malformed-block") {
        invalid = { jobId: 80, block: { index: -1 } };
      } else if (kind === "wrong-candidate") {
        invalid = { jobId: 80, block: mineBlock(candidate(14, 1), nodeHash, undefined, { startNonce: 0, stride: 2 }) };
      } else if (kind === "wrong-lane") {
        invalid = { jobId: 80, block: goodLaneOne };
      } else if (kind === "bad-hash") {
        const valid = mineBlock(job, nodeHash, undefined, { startNonce: 0, stride: 2 });
        invalid = { jobId: 80, block: { ...valid, hash: "f".repeat(64) } };
      } else {
        let bad: Block | null = null;
        for (let nonce = 0; nonce < 200; nonce += 2) {
          const blockContent = { ...job, nonce };
          const hash = computeBlockHash(blockContent, nodeHash);
          if (!hash.startsWith("0")) {
            bad = { ...blockContent, hash };
            break;
          }
        }
        if (bad === null) throw new Error("could not construct a bad-PoW fixture");
        invalid = { jobId: 80, block: bad };
      }
      first.answer(invalid);

      await expect(failed).resolves.toBeInstanceOf(Error);
      expect(first.exited).toBe(true);
      expect(second.exited).toBe(true);

      // A new logical handle gets fresh children after the faulty job's cleanup.
      const next = poolFactory();
      let resolveNext: ((block: Block) => void) | null = null;
      const nextResult = new Promise<Block>((resolve) => { resolveNext = resolve; });
      next.setHandlers({
        onMessage: (raw) => {
          if (typeof raw === "object" && raw !== null && "block" in raw) resolveNext?.(raw.block as Block);
        },
        onError: (error) => { throw error; },
        onExit: () => undefined,
      });
      const nextCandidate = candidate(15, 1);
      next.postMessage({ jobId: 81, candidate: nextCandidate });
      const nextWorker = children[2];
      if (nextWorker === undefined) throw new Error("next logical job did not create workers");
      nextWorker.answer({
        jobId: 81,
        block: mineBlock(nextCandidate, nodeHash, undefined, { startNonce: 0, stride: 2 }),
      });
      const winningBlock = await nextResult;
      expect(verifyBlockPow(winningBlock, nodeHash)).toBe(true);
      await next.terminate();
    },
  );

  it("rejects pool sizes outside the configured worker limit", () => {
    expect(() => createWorkerPool(() => new ControlledWorker(), 0)).toThrow(/worker count/);
    expect(() => createWorkerPool(() => new ControlledWorker(), 33)).toThrow(/worker count/);
  });
});
