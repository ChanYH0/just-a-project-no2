// RC13b: re-admission of expired records (stale payload timestamp, same recordId / new epoch) and the accounting
// invariants through re-admission and terminal-LRU eviction.
//
// Counter semantics (Mempool.counts()):
//   admitted  one per ADMISSION EPOCH (a re-admission of the same recordId counts again; not distinct ids)
//   retired   epochs whose terminal status left the terminal LRU: evicted by the limit, or superseded by re-admission
//   expired / rejected   terminal entries currently retained (expired + rejected <= terminalLimit)
//   confirmed one per epoch that became a block record
// Identity at every step: admitted = pending + reserved + confirmed + expired + rejected + retired.

import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { attend, getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

const SKEW = 5000; // test profile maxRecordSkewMs
const TTL = 5000; // test profile mempoolTtlMs

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(8);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

function k(index: number): TestKeys {
  const key = keys[index];
  if (key === undefined) {
    throw new Error("missing key");
  }
  return key;
}

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  h = await makeHarness(options);
  return h;
}

function errorCode(body: Record<string, unknown>): unknown {
  return (body["error"] as { code?: string } | undefined)?.code;
}

async function status(harness: Harness, id: string): Promise<unknown> {
  await harness.get("/mempool"); // runs the lazy TTL sweep
  const response = await harness.get(`/records/${id}`);
  return response.status === 404 ? "unknown" : response.body;
}

async function counts(harness: Harness): Promise<ReturnType<Harness["miner"]["mempool"]["counts"]>> {
  await harness.get("/mempool");
  return harness.miner.mempool.counts();
}

describe("RC13b: re-admission of an expired record", () => {
  it("(a) a stale payload timestamp (beyond maxRecordSkewMs) is rejected with TIMESTAMP_OUT_OF_RANGE and the record stays expired", async () => {
    const harness = await boot();
    const stale = await register(k(0), harness.clock.now() + SKEW, "stale");
    const admitted = await harness.post("/registrations", stale);
    expect(admitted.status).toBe(202);
    const id = admitted.body["recordId"] as string;

    // Past the TTL AND past the skew window of the payload timestamp: now - ts = 5001 > SKEW.
    harness.clock.advance(SKEW + TTL + 1);
    expect(await status(harness, id)).toEqual({ status: "expired" });
    const before = await counts(harness);
    expect(before).toMatchObject({ admitted: 1, expired: 1, pending: 0, retired: 0 });

    const again = await harness.post("/registrations", stale);
    expect(again.status).toBe(400);
    expect(errorCode(again.body)).toBe("TIMESTAMP_OUT_OF_RANGE");
    expect(await status(harness, id)).toEqual({ status: "expired" });
    expect(await counts(harness)).toEqual(before); // nothing changed: no new epoch
    await harness.node.assertInvariants();

    // A newly signed record (fresh timestamp) for the same key is a different record and is admitted.
    const fresh = await register(k(0), harness.clock.now(), "stale");
    const accepted = await harness.post("/registrations", fresh);
    expect(accepted.status).toBe(202);
    expect(accepted.body["recordId"]).not.toBe(id);
    await harness.node.assertInvariants();
  });

  it("(b) re-admission within skew succeeds: same recordId, new epoch, status pending", async () => {
    const harness = await boot();
    const record = await register(k(0), harness.clock.now() + SKEW, "again");
    const first = await harness.post("/registrations", record);
    expect(first.status).toBe(202);
    const id = first.body["recordId"] as string;

    harness.clock.advance(TTL + 1); // expired, and now - ts = -(SKEW - TTL - 1): inside the skew window
    expect(await status(harness, id)).toEqual({ status: "expired" });
    expect(await counts(harness)).toMatchObject({ admitted: 1, expired: 1, retired: 0, pending: 0 });

    const second = await harness.post("/registrations", record);
    expect(second.status).toBe(202);
    expect(second.body["recordId"]).toBe(id);
    expect(await status(harness, id)).toEqual({ status: "pending" });
    // New epoch: admitted counts it again, the superseded terminal entry is retired.
    expect(await counts(harness)).toMatchObject({ admitted: 2, expired: 0, retired: 1, pending: 1 });
    await harness.node.assertInvariants();

    // The re-admitted record is minable and confirms normally.
    await harness.mineNow();
    expect(await status(harness, id)).toEqual({ status: "confirmed", blockIndex: 1 });
    expect(await counts(harness)).toMatchObject({ admitted: 2, confirmed: 1, retired: 1, pending: 0 });
    await harness.node.assertInvariants();
  });
});

describe("RC13b: accounting through re-admission and terminal LRU eviction", () => {
  function identity(c: Awaited<ReturnType<typeof counts>>): number {
    return c.pending + c.reserved + c.confirmed + c.expired + c.rejected + c.retired;
  }

  it("(c) admitted/expired/retired stay consistent at every step with terminalLimit 2", async () => {
    const harness = await boot({ terminalLimit: 2 });
    const mempool = harness.miner.mempool;
    const step = async (expected: Partial<ReturnType<typeof mempool.counts>>): Promise<void> => {
      const c = await counts(harness);
      expect(c).toMatchObject(expected);
      expect(identity(c)).toBe(c.admitted);
      expect(c.expired + c.rejected).toBeLessThanOrEqual(2);
      await harness.node.assertInvariants();
    };

    // Six records signed at now + SKEW: still inside the skew window after the TTL has passed.
    const base = harness.clock.now();
    const records = [];
    const ids: string[] = [];
    for (let i = 0; i < 6; i += 1) {
      const record = await register(k(i), base + SKEW, `u${i}`);
      records.push(record);
      const response = await harness.post("/registrations", record);
      expect(response.status).toBe(202);
      ids.push(response.body["recordId"] as string);
      await step({ admitted: i + 1, pending: i + 1, expired: 0, retired: 0 });
    }

    // All six expire in admission order; the LRU keeps the last two and retires the other four.
    harness.clock.advance(TTL + 1);
    await step({ admitted: 6, pending: 0, expired: 2, retired: 4 });
    expect(await status(harness, ids[0] ?? "")).toBe("unknown");
    expect(await status(harness, ids[3] ?? "")).toBe("unknown");
    expect(await status(harness, ids[4] ?? "")).toEqual({ status: "expired" });
    expect(await status(harness, ids[5] ?? "")).toEqual({ status: "expired" });

    // Re-admit a RETAINED expired id: its terminal entry is superseded (retired), a new epoch is admitted.
    const retained = await harness.post("/registrations", records[4]);
    expect(retained.status).toBe(202);
    expect(retained.body["recordId"]).toBe(ids[4]);
    await step({ admitted: 7, pending: 1, expired: 1, retired: 5 });

    // Re-admit an EVICTED id: nothing to supersede, so retired does not change; the new epoch is admitted.
    const evicted = await harness.post("/registrations", records[0]);
    expect(evicted.status).toBe(202);
    expect(evicted.body["recordId"]).toBe(ids[0]);
    await step({ admitted: 8, pending: 2, expired: 1, retired: 5 });

    // Both new epochs expire: the LRU now holds ids[4], ids[0] (ids[5] is evicted).
    harness.clock.advance(TTL + 1);
    await step({ admitted: 8, pending: 0, expired: 2, retired: 6 });
    expect(await status(harness, ids[5] ?? "")).toBe("unknown");
    expect(await status(harness, ids[4] ?? "")).toEqual({ status: "expired" });
    expect(await status(harness, ids[0] ?? "")).toEqual({ status: "expired" });

    // Confirm path: a fresh record is mined; it leaves the live set and is counted as confirmed.
    const confirmedId = (await harness.post("/registrations", await register(k(6), harness.clock.now(), "c"))).body[
      "recordId"
    ] as string;
    await step({ admitted: 9, pending: 1, expired: 2, retired: 6, confirmed: 0 });
    await harness.mineNow();
    expect(await status(harness, confirmedId)).toEqual({ status: "confirmed", blockIndex: 1 });
    await step({ admitted: 9, pending: 0, expired: 2, retired: 6, confirmed: 1 });

    // Reject path: the miner rejects a pending record at candidate build (timestamp outside the block window).
    const rejectRecord = await register(k(7), harness.clock.now(), "r");
    const rejectId = (await harness.post("/registrations", rejectRecord)).body["recordId"] as string;
    await step({ admitted: 10, pending: 1, expired: 2, retired: 6, confirmed: 1, rejected: 0 });
    harness.workers.autoMine = true;
    const head = harness.node.ledger.head;
    harness.miner.startJob({
      index: head.index + 1,
      timestamp: harness.clock.now() + 16_000,
      previousHash: head.hash,
      difficulty: 1,
      records: [rejectRecord],
    });
    await harness.miner.settled();
    expect(await status(harness, rejectId)).toEqual({ status: "rejected", code: "TIMESTAMP_OUT_OF_RANGE" });
    // The rejected entry joins the LRU (limit 2): the oldest expired entry (ids[4]) is evicted and retired.
    await step({ admitted: 10, pending: 0, expired: 1, rejected: 1, retired: 7, confirmed: 1 });

    // A rejected record re-admitted: same id, new epoch, the rejected entry is superseded.
    const resubmitted = await harness.post("/registrations", rejectRecord);
    expect(resubmitted.status).toBe(202);
    expect(resubmitted.body["recordId"]).toBe(rejectId);
    await step({ admitted: 11, pending: 1, expired: 1, rejected: 0, retired: 8, confirmed: 1 });

    // A further admission of another record type keeps counting epochs.
    expect((await harness.post("/attendance", await attend(k(6), "keynote", harness.clock.now()))).status).toBe(202);
    await step({ admitted: 12, pending: 2 });
  });
});
