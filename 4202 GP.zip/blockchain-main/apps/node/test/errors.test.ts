import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { ChainError } from "@conference-chain/shared";
import { CHAIN_ID, attend, getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

function expectErrorShape(body: Record<string, unknown>, code: string): void {
  expect(Object.keys(body)).toEqual(["error"]);
  const error = body["error"] as Record<string, unknown>;
  expect(error["code"]).toBe(code);
  expect(typeof error["message"]).toBe("string");
  expect(JSON.stringify(body)).not.toMatch(/\bat\s+\S+\s+\(|node_modules|stack/i);
}

describe("error responses", () => {
  it("returns the error shape without stack traces for invalid bodies", async () => {
    h = await makeHarness();
    const bad = await h.app.inject({
      method: "POST",
      url: "/registrations",
      payload: "{not json",
      headers: { "content-type": "application/json" },
    });
    expect(bad.statusCode).toBe(400);
    expectErrorShape(JSON.parse(bad.body) as Record<string, unknown>, "INVALID_SCHEMA");

    const empty = await h.post("/attendance", {});
    expect(empty.status).toBe(400);
    expectErrorShape(empty.body, "INVALID_SCHEMA");

    const wrongType = await h.app.inject({
      method: "POST",
      url: "/registrations",
      payload: "x",
      headers: { "content-type": "text/plain" },
    });
    expect(wrongType.statusCode).toBe(400);
    expectErrorShape(JSON.parse(wrongType.body) as Record<string, unknown>, "INVALID_SCHEMA");
  });

  it("maps semantic rejections to protocol codes", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    const now = h.clock.now();
    const wrongChain = await register(alice, now);
    const tampered = { ...wrongChain, payload: { ...wrongChain.payload, chainId: "b".repeat(64) } };
    expectErrorShape((await h.post("/registrations", tampered)).body, "CHAIN_ID_MISMATCH");

    const badSig = { ...wrongChain, payload: { ...wrongChain.payload, alias: "mallory" } };
    const badSigResult = await h.post("/registrations", badSig);
    expect(badSigResult.status).toBe(400);
    expectErrorShape(badSigResult.body, "INVALID_SIGNATURE");

    const old = await register(alice, now - 6_000);
    const oldResult = await h.post("/registrations", old);
    expect(oldResult.status).toBe(400);
    expectErrorShape(oldResult.body, "TIMESTAMP_OUT_OF_RANGE");

    const unregistered = await h.post("/attendance", await attend(alice, "keynote", now));
    expect(unregistered.status).toBe(400);
    expectErrorShape(unregistered.body, "ATTENDEE_NOT_REGISTERED");

    expect((await h.post("/registrations", await register(alice, now))).status).toBe(202);
    await h.mineNow();
    const unknownSession = await h.post("/attendance", await attend(alice, "no-such-session", now));
    expectErrorShape(unknownSession.body, "UNKNOWN_SESSION");
    const again = await h.post("/registrations", await register(alice, now));
    expect(again.status).toBe(409);
    expectErrorShape(again.body, "KEY_ALREADY_REGISTERED");
  });

  it("returns 413 for an oversize body", async () => {
    h = await makeHarness();
    const response = await h.app.inject({
      method: "POST",
      url: "/registrations",
      payload: JSON.stringify({ pad: "x".repeat(17 * 1024) }),
      headers: { "content-type": "application/json" },
    });
    expect(response.statusCode).toBe(413);
    expectErrorShape(JSON.parse(response.body) as Record<string, unknown>, "BODY_TOO_LARGE");
  });

  it("rate limits writes per client and recovers in the next window", async () => {
    h = await makeHarness();
    for (let i = 0; i < 30; i += 1) {
      expect((await h.post("/registrations", {})).status).toBe(400);
    }
    const limited = await h.post("/registrations", {});
    expect(limited.status).toBe(429);
    expectErrorShape(limited.body, "RATE_LIMITED");
    // Reads are not limited.
    expect((await h.get("/health")).status).toBe(200);
    h.clock.advance(60_000);
    expect((await h.post("/registrations", {})).status).toBe(400);
  });

  it("returns 503 MEMPOOL_FULL at the cap", async () => {
    h = await makeHarness({ mempoolMax: 1 });
    const [alice, bob] = keys as [TestKeys, TestKeys];
    expect((await h.post("/registrations", await register(alice, h.clock.now()))).status).toBe(202);
    const full = await h.post("/registrations", await register(bob, h.clock.now()));
    expect(full.status).toBe(503);
    expectErrorShape(full.body, "MEMPOOL_FULL");
  });

  it("hides unexpected failures behind INTERNAL 500", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    vi.spyOn(h.miner, "admit").mockRejectedValueOnce(new Error("secret internal detail"));
    const result = await h.post("/registrations", await register(alice, h.clock.now()));
    expect(result.status).toBe(500);
    expectErrorShape(result.body, "INTERNAL");
    expect(JSON.stringify(result.body)).not.toContain("secret internal detail");
  });

  it("maps a ChainError thrown by a handler to its status", async () => {
    h = await makeHarness();
    const [alice] = keys as [TestKeys];
    vi.spyOn(h.miner, "admit").mockRejectedValueOnce(new ChainError("MEMPOOL_FULL", "x"));
    expect((await h.post("/registrations", await register(alice, h.clock.now()))).status).toBe(503);
  });

  it("exposes only the chain id the client needs", async () => {
    h = await makeHarness();
    expect((await h.get("/chain/info")).body["chainId"]).toBe(CHAIN_ID);
  });
});
