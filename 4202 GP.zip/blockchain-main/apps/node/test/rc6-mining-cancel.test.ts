import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { getKeys, makeHarness, register, until, type Harness, type TestKeys } from "./support.js";
import { infeasibleCandidate } from "./fixtures/infeasible-candidate.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(2);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

const SRC = new URL("../src/", import.meta.url).pathname;

describe("RC6: mining cancellation", () => {
  it("keeps the event loop free while the real worker runs an infeasible job", async () => {
    h = await makeHarness({ realWorker: true });
    h.miner.startJob(infeasibleCandidate(h.node.ledger.head));
    const health = await h.get("/health");
    expect(health.status).toBe(200);
    expect(health.body["miner"]).toBe("mining");
    expect(h.miner.currentJobId).not.toBeNull();
  });

  it("cancels the real worker, clears the job and mines a difficulty-1 block afterwards", async () => {
    const [alice] = keys as [TestKeys];
    h = await makeHarness({ realWorker: true });
    h.miner.startJob(infeasibleCandidate(h.node.ledger.head));
    await h.miner.cancelCurrentJob();
    expect(h.miner.currentJobId).toBeNull();
    expect(h.miner.state).toBe("idle");
    expect((await h.get("/health")).body["miner"]).toBe("idle");

    await h.post("/registrations", await register(alice, h.clock.now()));
    await h.mineNow();
    expect(h.node.ledger.head.index).toBe(1);
    expect(h.node.ledger.head.difficulty).toBe(1);
    await h.node.assertInvariants();
  });

  it("ignores a result with a stale jobId", async () => {
    h = await makeHarness();
    h.workers.autoMine = false;
    const jobId = h.miner.startJob(infeasibleCandidate(h.node.ledger.head));
    const worker = h.workers.last;
    const easy = { ...infeasibleCandidate(h.node.ledger.head), difficulty: 1 };
    const stale = worker.mine({ jobId, candidate: easy });
    worker.emit({ jobId: jobId + 100, block: stale });
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(h.node.ledger.head.index).toBe(0);
    expect(h.miner.state).toBe("mining");
    expect(h.miner.currentJobId).toBe(jobId);
    expect(worker.terminated).toBe(false);
    await h.node.assertInvariants();
  });

  it("recovers from a worker crash through the injected timer without losing records", async () => {
    const [alice] = keys as [TestKeys];
    h = await makeHarness();
    h.workers.autoMine = false;
    const posted = await h.post("/registrations", await register(alice, h.clock.now()));
    const recordId = posted.body["recordId"] as string;
    h.timers.advance(1000);
    await until(() => h?.workers.workers.length === 1, "first worker started");
    const first = h.workers.last;
    first.crash();
    await until(() => h?.miner.state === "restarting", "restarting state");
    expect(first.terminated).toBe(true);
    expect((await h.get(`/records/${recordId}`)).body).toEqual({ status: "pending" });
    expect((await h.get("/mempool")).body["value"]).toHaveLength(1);
    await h.node.assertInvariants();

    h.workers.autoMine = true;
    h.timers.advance(1000);
    await until(() => h?.workers.workers.length === 2, "second worker started");
    await h.miner.settled();
    expect(h.miner.state).toBe("idle");
    expect((await h.get(`/records/${recordId}`)).body).toEqual({ status: "confirmed", blockIndex: 1 });
  });

  it("mines a block with the real worker under vitest", async () => {
    const [alice] = keys as [TestKeys];
    h = await makeHarness({ realWorker: true });
    const posted = await h.post("/registrations", await register(alice, h.clock.now()));
    await h.mineNow();
    expect((await h.get(`/records/${posted.body["recordId"] as string}`)).body["status"]).toBe("confirmed");
  });

  it("static: no src file imports fixtures", async () => {
    for (const name of await readdir(SRC)) {
      if (name.endsWith(".ts")) {
        expect(await readFile(join(SRC, name), "utf8"), name).not.toMatch(/fixtures/);
      }
    }
  });

  it("static: mine-worker.ts has no abort handler", async () => {
    expect(await readFile(join(SRC, "mine-worker.ts"), "utf8")).not.toMatch(/abort/i);
  });
});
