import { readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { Block, canonicalize, computeBlockHash, getProfile, makeGenesis, nodeHash } from "@conference-chain/shared";
import { BootError } from "../src/boot-error.js";
import { getKeys, makeDataDir, makeHarness, register, TestClock, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
const dirs: string[] = [];
let live: Harness[] = [];

beforeAll(async () => {
  keys = await getKeys(2);
});
afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

async function freshDir(): Promise<string> {
  const dir = await makeDataDir();
  dirs.push(dir);
  return dir;
}

async function boot(dataDir: string, clock: TestClock): Promise<Harness> {
  const harness = await makeHarness({ dataDir, clock, keepDir: true });
  live.push(harness);
  return harness;
}

async function mineOneBlockAndStop(dataDir: string, clock: TestClock): Promise<void> {
  const [alice] = keys as [TestKeys];
  const first = await boot(dataDir, clock);
  await first.post("/registrations", await register(alice, clock.now()));
  await first.mineNow();
  await first.stop();
}

async function bootError(dataDir: string, clock: TestClock): Promise<BootError> {
  try {
    await boot(dataDir, clock);
  } catch (error) {
    expect(error).toBeInstanceOf(BootError);
    return error as BootError;
  }
  throw new Error("boot unexpectedly succeeded");
}

describe("restart and boot refusal", () => {
  it("reloads the chain and starts with an empty mempool", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const second = await boot(dir, clock);
    expect(second.node.ledger.head.index).toBe(1);
    expect((await second.get("/mempool")).body["value"]).toEqual([]);
    expect((await second.get("/blocks/1")).status).toBe(200);
    await second.node.assertInvariants();
  });

  it("refuses a truncated chain file", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const text = await readFile(join(dir, "chain.jsonl"), "utf8");
    await writeFile(join(dir, "chain.jsonl"), text.slice(0, text.length - 20));
    expect((await bootError(dir, clock)).code).toBe("CHAIN_FILE_CORRUPT");
  });

  it.each(["whitespace", "key order"])("refuses noncanonical %s in a later block without rewriting it", async (format) => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const path = join(dir, "chain.jsonl");
    const lines = (await readFile(path, "utf8")).split("\n");
    const block: unknown = JSON.parse(lines[1] ?? "");
    if (typeof block !== "object" || block === null) throw new Error("expected block");
    lines[1] = format === "whitespace"
      ? ` ${canonicalize(block)}`
      : JSON.stringify(Object.fromEntries(Object.entries(block).reverse()));
    const changed = lines.join("\n");
    await writeFile(path, changed);
    const error = await bootError(dir, clock);
    expect(error.code).toBe("CHAIN_FILE_CORRUPT");
    expect(error.blockIndex).toBe(1);
    expect(await readFile(path, "utf8")).toBe(changed);
  });

  it("refuses a file with a missing trailing newline and an empty file", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const text = await readFile(join(dir, "chain.jsonl"), "utf8");
    await writeFile(join(dir, "chain.jsonl"), text.trimEnd());
    expect((await bootError(dir, clock)).code).toBe("CHAIN_FILE_CORRUPT");
    await writeFile(join(dir, "chain.jsonl"), "");
    expect((await bootError(dir, clock)).code).toBe("CHAIN_FILE_CORRUPT");
  });

  it("refuses an edited block and reports its index", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const lines = (await readFile(join(dir, "chain.jsonl"), "utf8")).split("\n");
    const block = JSON.parse(lines[1] ?? "") as { records: { payload: { alias: string } }[] };
    const record = block.records[0];
    if (record === undefined) {
      throw new Error("expected a record");
    }
    record.payload.alias = "mallory";
    lines[1] = canonicalize(block);
    await writeFile(join(dir, "chain.jsonl"), lines.join("\n"));
    const error = await bootError(dir, clock);
    expect(error.code).toBe("BAD_BLOCK_HASH");
    expect(error.blockIndex).toBe(1);
  });

  it("refuses another profile's genesis", async () => {
    const dir = await freshDir();
    const demoGenesis = makeGenesis(getProfile("demo", "conf-test-2026"), nodeHash);
    await writeFile(join(dir, "chain.jsonl"), `${canonicalize(demoGenesis)}\n`);
    expect((await bootError(dir, new TestClock())).code).toBe("GENESIS_MISMATCH");
  });

  it("reports BAD_POW and the block index for a rehashed block with oversized difficulty", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const path = join(dir, "chain.jsonl");
    const lines = (await readFile(path, "utf8")).split("\n");
    const block = Block.parse(JSON.parse(lines[1] ?? ""));
    block.difficulty = Number.MAX_SAFE_INTEGER;
    block.hash = computeBlockHash(block, nodeHash);
    lines[1] = canonicalize(block);
    await writeFile(path, lines.join("\n"));
    const error = await bootError(dir, clock);
    expect(error.code).toBe("BAD_POW");
    expect(error.blockIndex).toBe(1);
  });

  it("refuses a torn last line", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    const text = await readFile(join(dir, "chain.jsonl"), "utf8");
    await writeFile(join(dir, "chain.jsonl"), `${text}{"index":2,"time`);
    expect((await bootError(dir, clock)).code).toBe("CHAIN_FILE_CORRUPT");
  });

  it("refuses a second node on the same DATA_DIR and releases the lock on close", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    const first = await boot(dir, clock);
    await bootError(dir, clock);
    await first.stop();
    const again = await boot(dir, clock);
    expect(again.node.ledger.head.index).toBe(0);
  });

  it("releases the lock when boot fails", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await writeFile(join(dir, "chain.jsonl"), "garbage\n");
    await bootError(dir, clock);
    await rm(join(dir, "chain.jsonl"));
    const ok = await boot(dir, clock);
    expect(ok.node.ledger.head.index).toBe(0);
  });

  it("A5: a chain stays valid when the clock moves a year ahead", async () => {
    const dir = await freshDir();
    const clock = new TestClock();
    await mineOneBlockAndStop(dir, clock);
    clock.advance(365 * 24 * 3600 * 1000);
    const later = await boot(dir, clock);
    expect(later.node.ledger.head.index).toBe(1);
  });
});
