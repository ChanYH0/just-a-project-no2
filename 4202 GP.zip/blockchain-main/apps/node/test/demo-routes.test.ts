import { afterEach, describe, expect, it } from "vitest";
import { BootError } from "../src/boot-error.js";
import { parseEnv } from "../src/env.js";
import { makeHarness, type Harness } from "./support.js";

let h: Harness | null = null;
afterEach(async () => {
  await h?.stop();
  h = null;
});

const BASE = { CONFERENCE_ID: "conf-test-2026" };

describe("test 15: demo routes", () => {
  it("are absent unless ENABLE_DEMO_ROUTES=true", async () => {
    h = await makeHarness();
    expect((await h.get("/demo/tamper-check")).status).toBe(404);
    expect((await h.post("/demo/tamper-check", {})).status).toBe(404);
    expect((await h.post("/demo/difficulty-simulation", {})).status).toBe(404);
    // /chain/validate is not a demo route: it exists regardless of the flag (covered in validate-endpoint.test.ts).
    expect((await h.get("/chain/validate")).status).toBe(200);
  });

  it("default to off and parse strictly", () => {
    expect(parseEnv({ ...BASE, PROFILE: "test" }).enableDemoRoutes).toBe(false);
    expect(parseEnv({ ...BASE, PROFILE: "demo", ENABLE_DEMO_ROUTES: "true" }).enableDemoRoutes).toBe(true);
    expect(parseEnv({ ...BASE, PROFILE: "test", ENABLE_DEMO_ROUTES: "false" }).enableDemoRoutes).toBe(false);
    expect(() => parseEnv({ ...BASE, PROFILE: "test", ENABLE_DEMO_ROUTES: "1" })).toThrow(BootError);
  });

  it("boot refuses PROFILE=production with the flag, and the profile defaults to production", () => {
    expect(() => parseEnv({ ...BASE, PROFILE: "production", ENABLE_DEMO_ROUTES: "true" })).toThrow(BootError);
    expect(() => parseEnv({ ...BASE, ENABLE_DEMO_ROUTES: "true" })).toThrow(BootError);
    expect(parseEnv(BASE).profile).toBe("production");
  });
});

describe("rate limit env", () => {
  it("defaults to the SPEC values, accepts overrides and refuses bad values", () => {
    expect(parseEnv(BASE).heavyRateLimit).toBe(6);
    expect(parseEnv(BASE).writeRateLimit).toBe(30);
    expect(parseEnv({ ...BASE, HEAVY_RATE_LIMIT: "60" }).heavyRateLimit).toBe(60);
    expect(() => parseEnv({ ...BASE, HEAVY_RATE_LIMIT: "0" })).toThrow();
    expect(() => parseEnv({ ...BASE, WRITE_RATE_LIMIT: "abc" })).toThrow();
  });
});

describe("TRUST_PROXY env", () => {
  it("defaults to false, accepts true and refuses other values", () => {
    expect(parseEnv(BASE).trustProxy).toBe(false);
    expect(parseEnv({ ...BASE, TRUST_PROXY: "true" }).trustProxy).toBe(true);
    expect(() => parseEnv({ ...BASE, TRUST_PROXY: "1" })).toThrow();
  });
});
