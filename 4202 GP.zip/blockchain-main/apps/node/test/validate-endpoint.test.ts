// SPEC 14.1 test 10 (validate step), RC5 (validate parts) and the GET /chain/validate snapshot contract (section 10).

import { stat, truncate, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import {
  BASE_TIME,
  TestClock,
  attend,
  getKeys,
  makeDataDir,
  makeHarness,
  register,
  until,
  type FaultyStore,
  type Harness,
  type TestKeys,
} from "./support.js";
import { rm } from "node:fs/promises";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let live: Harness[] = [];
const dirs: string[] = [];

beforeAll(async () => {
  keys = await getKeys(3);
});

afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  const harness = await makeHarness(options);
  live.push(harness);
  return harness;
}

function key(index: number): TestKeys {
  const value = keys[index];
  if (value === undefined) {
    throw new Error("missing key");
  }
  return value;
}

function faultyStore(h: Harness): FaultyStore {
  if (h.store === null) {
    throw new Error("harness has no faulty store");
  }
  return h.store;
}

// register alice -> block 1; alice attends keynote -> block 2
async function flow(h: Harness): Promise<void> {
  expect((await h.post("/registrations", await register(key(0), h.clock.now(), "alice"))).status).toBe(202);
  await h.mineNow();
  expect((await h.post("/attendance", await attend(key(0), "keynote", h.clock.now()))).status).toBe(202);
  await h.mineNow();
}

describe("test 10: full flow ends with a successful validate", () => {
  it("GET /chain/validate is ok after register, attend and mining", async () => {
    const h = await boot();
    await flow(h);
    expect(h.node.ledger.head.index).toBe(2);
    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
    await h.node.assertInvariants();
  });

  it("the committed size tracks the file exactly and validation does not change it", async () => {
    const h = await boot();
    await flow(h);
    const size = (await stat(join(h.dataDir, "chain.jsonl"))).size;
    expect(h.node.ledger.committedSize).toBe(size);
    await h.get("/chain/validate");
    expect((await stat(join(h.dataDir, "chain.jsonl"))).size).toBe(size);
  });

  it("works with the real validation worker thread", async () => {
    const h = await boot({ realValidationWorker: true });
    await flow(h);
    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
  });

  it("rejects query parameters", async () => {
    const h = await boot();
    const result = await h.get("/chain/validate?x=1");
    expect(result.status).toBe(400);
  });
});

describe("RC5 (validate parts): the catalog is not consensus", () => {
  it("restarting with a different sessions list does not change the validate result", async () => {
    const dataDir = await makeDataDir();
    dirs.push(dataDir);
    const clock = new TestClock();
    const first = await boot({ dataDir, clock, keepDir: true });
    await flow(first);
    await first.stop();
    const second = await boot({ dataDir, clock, keepDir: true, sessions: [{ id: "other", title: "Other" }] });
    expect(second.node.ledger.head.index).toBe(2);
    expect(await second.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
  });
});

describe("edits to chain.jsonl behind the node's back", () => {
  it("a same-size byte edit inside a block is reported with the specific validation failure", async () => {
    const h = await boot();
    await flow(h);
    const path = join(h.dataDir, "chain.jsonl");
    const text = await h.chainFile();
    const edited = text.replace('"alias":"alice"', '"alias":"alicf"');
    expect(edited).not.toBe(text);
    expect(edited.length).toBe(text.length);
    await writeFile(path, edited);
    const result = await h.get("/chain/validate");
    expect(result.status).toBe(200);
    expect(result.body["ok"]).toBe(false);
    expect(result.body["code"]).toBe("BAD_BLOCK_HASH");
    expect(result.body["blockIndex"]).toBe(1);
  });

  it("truncating the file (whole last line, or mid-line) is CHAIN_STORE_MISMATCH", async () => {
    const h = await boot();
    await flow(h);
    const path = join(h.dataDir, "chain.jsonl");
    const text = await h.chainFile();
    const lastLineStart = text.slice(0, -1).lastIndexOf("\n") + 1;
    await truncate(path, lastLineStart);
    expect((await h.get("/chain/validate")).body).toEqual({ ok: false, code: "CHAIN_STORE_MISMATCH" });
    await truncate(path, lastLineStart + 10);
    expect((await h.get("/chain/validate")).body).toEqual({ ok: false, code: "CHAIN_STORE_MISMATCH" });
  });

  it("a removed chain file is CHAIN_STORE_MISMATCH", async () => {
    const h = await boot();
    await flow(h);
    await rm(join(h.dataDir, "chain.jsonl"));
    expect((await h.get("/chain/validate")).body).toEqual({ ok: false, code: "CHAIN_STORE_MISMATCH" });
  });

  it("a torn snapshot (final newline replaced) returns CHAIN_FILE_CORRUPT with the line, never a partial ok", async () => {
    const h = await boot();
    await flow(h);
    const text = await h.chainFile();
    await writeFile(join(h.dataDir, "chain.jsonl"), `${text.slice(0, -1)} `);
    const result = await h.get("/chain/validate");
    expect(result.body["ok"]).toBe(false);
    expect(result.body["code"]).toBe("CHAIN_FILE_CORRUPT");
    expect(result.body["blockIndex"]).toBe(2);
  });

  it("an unparsable middle line returns CHAIN_FILE_CORRUPT at that line", async () => {
    const h = await boot();
    await flow(h);
    const lines = (await h.chainFile()).split("\n");
    const middle = lines[1] ?? "";
    lines[1] = `${"x".repeat(middle.length - 1)}}`;
    await writeFile(join(h.dataDir, "chain.jsonl"), lines.join("\n"));
    const result = await h.get("/chain/validate");
    expect(result.body["code"]).toBe("CHAIN_FILE_CORRUPT");
    expect(result.body["blockIndex"]).toBe(1);
  });

  it("rejects a noncanonical middle line even when the snapshot size is unchanged", async () => {
    const h = await boot();
    await flow(h);
    const lines = (await h.chainFile()).split("\n");
    const block: unknown = JSON.parse(lines[1] ?? "");
    if (typeof block !== "object" || block === null) throw new Error("expected block");
    lines[1] = JSON.stringify(Object.fromEntries(Object.entries(block).reverse()));
    const changed = lines.join("\n");
    expect(Buffer.byteLength(changed)).toBe(Buffer.byteLength(await h.chainFile()));
    await writeFile(join(h.dataDir, "chain.jsonl"), changed);
    expect((await h.get("/chain/validate")).body).toEqual({
      ok: false, code: "CHAIN_FILE_CORRUPT", blockIndex: 1,
    });
  });

  it("a different but valid chain of the same byte size is CHAIN_STORE_MISMATCH (head differs)", async () => {
    const h = await boot();
    expect((await h.post("/registrations", await register(key(0), h.clock.now(), "alice"))).status).toBe(202);
    await h.mineNow();
    const original = await h.chainFile();
    let alternative: string | null = null;
    for (let offset = 1; offset <= 40 && alternative === null; offset += 1) {
      const other = await boot({ clock: new TestClock(BASE_TIME + offset) });
      await other.post("/registrations", await register(key(0), other.clock.now(), "alice"));
      await other.mineNow();
      const text = await other.chainFile();
      if (text.length === original.length && text !== original) {
        alternative = text;
      }
      await other.stop();
    }
    if (alternative === null) {
      throw new Error("could not build a same-size alternative chain");
    }
    await writeFile(join(h.dataDir, "chain.jsonl"), alternative);
    expect((await h.get("/chain/validate")).body).toEqual({ ok: false, code: "CHAIN_STORE_MISMATCH" });
  });

  it("bytes appended to the file beyond the committed size are not read and do not affect the result", async () => {
    const h = await boot();
    await flow(h);
    const path = join(h.dataDir, "chain.jsonl");
    await writeFile(path, `${await h.chainFile()}{"torn":`);
    expect((await h.get("/chain/validate")).body).toEqual({ ok: true });
  });
});

describe("a block that is mid-append is never reported as corruption (GPT review)", () => {
  it("append written, fsync pending, block not yet committed: ok:true; after commit: ok with the new head", async () => {
    const h = await boot({ faulty: true });
    const store = faultyStore(h);
    expect((await h.post("/registrations", await register(key(0), h.clock.now(), "alice"))).status).toBe(202);
    const release = store.holdFsync();
    h.timers.advance(1000);
    await until(() => store.fsyncWaiting, "fsync pending");

    // On disk: the new line is fully written. In memory: not committed.
    const onDisk = (await stat(join(h.dataDir, "chain.jsonl"))).size;
    expect(onDisk).toBeGreaterThan(h.node.ledger.committedSize);
    expect(h.node.ledger.head.index).toBe(0);

    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });

    release();
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(1);
    expect(h.node.ledger.committedSize).toBe((await stat(join(h.dataDir, "chain.jsonl"))).size);
    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
    await h.node.assertInvariants();
  });

  it("a half-written (torn) line on disk mid-append is not corruption either", async () => {
    const h = await boot({ faulty: true });
    const store = faultyStore(h);
    expect((await h.post("/registrations", await register(key(0), h.clock.now(), "alice"))).status).toBe(202);
    const release = store.holdPartialAppend();
    h.timers.advance(1000);
    await until(() => store.partialWaiting, "partial append");
    expect((await h.chainFile()).endsWith("\n")).toBe(false);

    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });

    release();
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(1);
    expect(await h.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
    await h.node.assertInvariants();
  });
});

describe("rate limit", () => {
  it("6 per minute per IP, one bucket shared by /chain/validate and /demo/*", async () => {
    const h = await boot({ enableDemoRoutes: true });
    for (let i = 0; i < 3; i += 1) {
      expect((await h.get("/chain/validate")).status).toBe(200);
    }
    for (let i = 0; i < 3; i += 1) {
      expect((await h.post("/demo/difficulty-simulation", { count: 1, intervalMs: 0 })).status).toBe(200);
    }
    const limited = await h.get("/chain/validate");
    expect(limited.status).toBe(429);
    expect((limited.body["error"] as { code: string }).code).toBe("RATE_LIMITED");
    expect((await h.post("/demo/difficulty-simulation", { count: 1, intervalMs: 0 })).status).toBe(429);
    h.heavyRateClock.advance(60_000);
    expect((await h.get("/chain/validate")).status).toBe(200);
  });
});
