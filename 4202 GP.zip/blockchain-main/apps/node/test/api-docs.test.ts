import Fastify from "fastify";
import { afterEach, describe, expect, it } from "vitest";
import { MAX_RECORDS_PER_BLOCK } from "@conference-chain/shared";
import { openApiDocument, registerApiDocs } from "../src/api-docs.js";

const apps: ReturnType<typeof Fastify>[] = [];
afterEach(async () => {
  await Promise.all(apps.splice(0).map((app) => app.close()));
});

function object(value: unknown): Record<string, unknown> {
  expect(value).toBeTypeOf("object");
  expect(value).not.toBeNull();
  expect(Array.isArray(value)).toBe(false);
  return value as Record<string, unknown>;
}

describe("OpenAPI documentation", () => {
  it("documents the real HTTP routes and shared record schemas in OpenAPI 3.1", () => {
    const document = openApiDocument(false);
    expect(document["openapi"]).toBe("3.1.0");
    const paths = object(document["paths"]);
    expect(Object.keys(paths)).toEqual(expect.arrayContaining([
      "/chain/info", "/health", "/sessions", "/registrations", "/attendance",
      "/records/{recordId}", "/mempool", "/blocks", "/blocks/{index}",
      "/attendees/{attendeeId}", "/attendees/{attendeeId}/sessions",
      "/sessions/{sessionId}/attendees", "/chain/validate",
    ]));
    expect(paths).not.toHaveProperty("/demo/tamper-check");
    expect(paths).not.toHaveProperty("/demo/difficulty-simulation");

    const schemas = object(object(document["components"])["schemas"]);
    expect(schemas["SignedRegistration"]).toMatchObject({ additionalProperties: false });
    expect(schemas["SignedAttendance"]).toMatchObject({ additionalProperties: false });
    expect(schemas["PublicKey"]).toMatchObject({ contentEncoding: "base64", minLength: 392, maxLength: 392 });
    expect(schemas["Signature"]).toMatchObject({ contentEncoding: "base64", minLength: 344, maxLength: 344 });
    expect(schemas["Alias"]).toMatchObject({ "x-runtime-constraints": expect.arrayContaining(["count Unicode code points, not UTF-16 code units"]) });
    expect(schemas["Block"]).toMatchObject({ properties: { records: { maxItems: MAX_RECORDS_PER_BLOCK }, difficulty: { $ref: "#/components/schemas/PositiveInt" } } });
  });

  it("includes optional demo endpoints only when the node registered them", () => {
    const paths = object(openApiDocument(true)["paths"]);
    expect(paths).toHaveProperty("/demo/tamper-check");
    expect(paths).toHaveProperty("/demo/difficulty-simulation");
  });

  it("serves the spec, documentation page and all UI assets locally with restrictive headers", async () => {
    const app = Fastify({ logger: false });
    apps.push(app);
    registerApiDocs(app, { enableDemoRoutes: false });
    await app.ready();

    const spec = await app.inject({ method: "GET", url: "/openapi.json" });
    expect(spec.statusCode).toBe(200);
    expect(spec.headers["content-type"]).toContain("application/json");
    expect(spec.json()).toMatchObject({ openapi: "3.1.0", paths: { "/chain/info": { get: {} } } });
    expect(spec.headers["x-content-type-options"]).toBe("nosniff");

    const page = await app.inject({ method: "GET", url: "/docs" });
    expect(page.statusCode).toBe(200);
    expect(page.headers["content-type"]).toContain("text/html");
    expect(page.headers["content-security-policy"]).toContain("script-src 'self'");
    expect(page.headers["content-security-policy"]).toContain("connect-src 'self'");
    expect(page.body).toContain('href="./docs/swagger-ui.css"');
    expect(page.body).toContain('src="./docs/swagger-ui-bundle.js"');
    expect(page.body).toContain('src="./docs/init.js"');
    expect(page.body).not.toMatch(/https?:\/\//);

    const trailingSlash = await app.inject({ method: "GET", url: "/docs/" });
    expect(trailingSlash.statusCode).toBe(308);
    expect(trailingSlash.headers["location"]).toBe("../docs");

    const init = await app.inject({ method: "GET", url: "/docs/init.js" });
    expect(init.statusCode).toBe(200);
    expect(init.body).toContain('url: "./openapi.json"');
    expect(init.body).not.toMatch(/https?:\/\//);
    for (const path of ["/docs/swagger-ui-bundle.js", "/docs/swagger-ui.css"]) {
      const asset = await app.inject({ method: "GET", url: path });
      expect(asset.statusCode).toBe(200);
      expect(asset.body.length).toBeGreaterThan(1000);
      expect(asset.headers["x-content-type-options"]).toBe("nosniff");
    }
  });
});
