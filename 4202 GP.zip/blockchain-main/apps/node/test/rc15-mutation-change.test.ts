// RC15 (HTTP part): a mutation that does not change the record is an INTERNAL error, never a silently passing check;
// lower-difficulty at the minimum difficulty is a client error. The pure-function part is in
// packages/shared/test/mutations.test.ts.

import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { getKeys, makeHarness, register, type Harness, type TestKeys } from "./support.js";
import { buildLiveChain, errorCode, expectLiveUnchanged, snapshotLive, tamper } from "./tamper-support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  h = await makeHarness({ enableDemoRoutes: true, ...options });
  await buildLiveChain(h, keys);
  return h;
}

describe("RC15: the mutation really changes the record", () => {
  it("alias becomes 'tampered' (registration) and the chain reports BAD_BLOCK_HASH / INVALID_SIGNATURE", async () => {
    const harness = await boot();
    expect((await tamper(harness, "edit-record", 1)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 1 });
    expect((await tamper(harness, "rehash-after-edit", 1)).body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 1 });
  });

  it("sessionId becomes 'tampered' (attendance); the catalog is not consulted by the validator", async () => {
    // 'tampered' is not in the session catalog; chain validation checks hash, signature and structure only.
    const harness = await boot();
    expect((await tamper(harness, "edit-record", 2)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
    expect((await tamper(harness, "rehash-after-edit", 2)).body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 2 });
  });

  it("a record whose alias is already 'tampered' is changed to 'tampered2' (never a silent no-op)", async () => {
    const harness = await makeHarness({ enableDemoRoutes: true });
    h = harness;
    const [alice] = keys as [TestKeys];
    expect((await harness.post("/registrations", await register(alice, harness.clock.now(), "tampered", harness.node.chainId))).status).toBe(202);
    await harness.mineNow();
    expect((await tamper(harness, "edit-record", 1)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 1 });
    expect((await tamper(harness, "rehash-after-edit", 1)).body).toMatchObject({ ok: false, code: "INVALID_SIGNATURE", blockIndex: 1 });
  });
});

describe("RC15: a broken mutator is a 500 INTERNAL", () => {
  it("edit-record and rehash-after-edit answer 500 INTERNAL with the error body shape, no ok field, nothing cached", async () => {
    const harness = await boot();
    harness.validationWorkers.hooks = { recordMutator: (record) => record };
    const before = await snapshotLive(harness);
    for (const mutation of ["edit-record", "rehash-after-edit"] as const) {
      const response = await tamper(harness, mutation, 2);
      expect(response.status, mutation).toBe(500);
      expect(errorCode(response.body)).toBe("INTERNAL");
      expect(response.body["ok"]).toBeUndefined();
      expect(Object.keys(response.body)).toEqual(["error"]);
      // no stack trace or internal message leaks through the public body
      expect(JSON.stringify(response.body)).not.toMatch(/at .*\(|\.ts|mutat/i);
    }
    expect(harness.node.tamperCache.size).toBe(0);
    await expectLiveUnchanged(harness, before);
  });

  it("does not affect mutations that do not use the record mutator", async () => {
    const harness = await boot();
    harness.validationWorkers.hooks = { recordMutator: (record) => record };
    expect((await tamper(harness, "edit-previous-hash", 2)).body).toMatchObject({ ok: false, code: "BAD_PREVIOUS_HASH", blockIndex: 2 });
    expect((await tamper(harness, "lower-difficulty", 4)).body).toMatchObject({ ok: false, code: "BAD_DIFFICULTY", blockIndex: 4 });
    expect((await tamper(harness, "delete-record-and-remine", 2)).body["ok"]).toBe(true);
  });

  it("recovers once the mutator is fixed: the earlier failure was not cached", async () => {
    const harness = await boot();
    harness.validationWorkers.hooks = { recordMutator: (record) => record };
    expect((await tamper(harness, "edit-record", 2)).status).toBe(500);
    harness.validationWorkers.hooks = {};
    expect((await tamper(harness, "edit-record", 2)).body).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: 2 });
  });
});

describe("RC15: lower-difficulty needs required > minDifficulty", () => {
  it("at required difficulty = min (block 1) it is 400 INVALID_SCHEMA and no worker job is started", async () => {
    const harness = await boot();
    for (const index of [1, 2, 3]) {
      const response = await tamper(harness, "lower-difficulty", index);
      expect(response.status, `block ${index}`).toBe(400);
      expect(errorCode(response.body)).toBe("INVALID_SCHEMA");
    }
    expect(harness.validationWorkers.jobs).toHaveLength(0);
  });

  it("above the minimum (blocks 4..6) it is a BAD_DIFFICULTY verdict at that index", async () => {
    const harness = await boot();
    for (const index of [4, 5, 6]) {
      expect((await tamper(harness, "lower-difficulty", index)).body).toMatchObject({
        ok: false,
        code: "BAD_DIFFICULTY",
        blockIndex: index,
      });
    }
  });
});
