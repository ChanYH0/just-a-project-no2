import { readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import type { ChainRecord } from "@conference-chain/shared";
import { nodeCrypto } from "../src/node-crypto.js";
import {
  BASE_TIME,
  SESSIONS,
  TestClock,
  attend,
  getKeys,
  makeDataDir,
  makeHarness,
  register,
  seededRandom,
  until,
  type Harness,
  type TestKeys,
} from "./support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let keys: TestKeys[] = [];
let live: Harness[] = [];
const dirs: string[] = [];

beforeAll(async () => {
  keys = await getKeys(6);
});
afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

async function boot(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  const harness = await makeHarness(options);
  live.push(harness);
  return harness;
}

async function freshDir(): Promise<string> {
  const dir = await makeDataDir();
  dirs.push(dir);
  return dir;
}

function k(index: number): TestKeys {
  const key = keys[index];
  if (key === undefined) {
    throw new Error("missing key");
  }
  return key;
}

function errorCode(body: Record<string, unknown>): unknown {
  return (body["error"] as { code?: string } | undefined)?.code;
}

async function admit(h: Harness, record: ChainRecord): Promise<string> {
  const result = await h.post(record.payload.type === "register" ? "/registrations" : "/attendance", record);
  expect(result.status).toBe(202);
  return result.body["recordId"] as string;
}

async function admitRegistrations(h: Harness, count: number, tsOffset = 0): Promise<string[]> {
  const ids: string[] = [];
  for (let i = 0; i < count; i += 1) {
    ids.push(await admit(h, await register(k(i), h.clock.now() + tsOffset, `user${i}`)));
  }
  return ids;
}

// Starts the production job path with a worker that does not answer by itself.
async function launchJob(h: Harness): Promise<void> {
  const before = h.workers.workers.length;
  h.workers.autoMine = false;
  h.timers.advance(1000);
  await until(() => h.workers.workers.length > before, "job launch");
}

async function status(h: Harness, id: string): Promise<unknown> {
  return (await h.get(`/records/${id}`)).body;
}

async function lines(h: Harness): Promise<string[]> {
  return (await h.chainFile()).trim().split("\n");
}

describe("RC13: lifecycle", () => {
  it("does not fatal when a pending entry expires and is re-admitted during async candidate validation", async () => {
    const h = await boot();
    const now = h.clock.now();
    const record = await register(k(0), now + 5000, "race");
    const id = await admit(h, record);

    let enteredResolve: (() => void) | undefined;
    const entered = new Promise<void>((resolve) => {
      enteredResolve = resolve;
    });
    let releaseGate: (() => void) | undefined;
    const gate = new Promise<void>((resolve) => {
      releaseGate = resolve;
    });
    let blockFirstVerification = true;
    const originalVerify = nodeCrypto.identity.verify.bind(nodeCrypto.identity);
    const verifySpy = vi.spyOn(nodeCrypto.identity, "verify").mockImplementation(async (...args) => {
      if (blockFirstVerification) {
        blockFirstVerification = false;
        enteredResolve?.();
        await gate;
      }
      return originalVerify(...args);
    });

    try {
      h.workers.autoMine = false;
      h.timers.advance(1000);
      await entered;

      // The read path sweeps the old epoch while candidate validation is paused.
      h.clock.advance(5001);
      expect(await status(h, id)).toEqual({ status: "expired" });

      // Re-admit the same signed record as a new epoch before the old validation returns.
      // The candidate build owns the writer lock until its awaited validation
      // resumes, so start the request first and release the validation gate
      // before awaiting its response.
      const readmission = h.post("/registrations", record);
      releaseGate?.();
      const readmitted = await readmission;
      expect(readmitted.status).toBe(202);
      expect(await status(h, id)).toEqual({ status: "pending" });

      await until(() => h.miner.state === "idle" && h.miner.currentJobId === null, "candidate build recovery");
      expect(h.fatal).toEqual([]);
      expect(await status(h, id)).toEqual({ status: "pending" });

      h.workers.autoMine = true;
      h.timers.advance(1000);
      await h.miner.settled();
      expect(await status(h, id)).toEqual({ status: "confirmed", blockIndex: 1 });
      await h.node.assertInvariants();
    } finally {
      verifySpy.mockRestore();
      releaseGate?.();
    }
  });

  it("admit 3 -> pending; job -> reserved; duplicate of a reserved record is rejected", async () => {
    const h = await boot();
    const ids = await admitRegistrations(h, 3);
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "pending" });
    }
    await launchJob(h);
    for (const id of ids) {
      expect(h.miner.mempool.getLive(id)?.status).toBe("reserved");
    }
    const duplicate = await h.post("/registrations", await register(k(0), h.clock.now(), "other"));
    expect(duplicate.status).toBe(409);
    expect(errorCode(duplicate.body)).toBe("KEY_ALREADY_REGISTERED");
    await h.node.assertInvariants();
  });

  it("worker crash mid-job returns all records to pending; the next job mines them", async () => {
    const h = await boot();
    const ids = await admitRegistrations(h, 3);
    await launchJob(h);
    const before = await h.chainFile();
    h.workers.last.crash();
    await until(() => h.miner.state === "restarting", "restarting");
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "pending" });
    }
    expect(await h.chainFile()).toBe(before);
    await h.node.assertInvariants();
    h.workers.autoMine = true;
    h.timers.advance(1000);
    await until(() => h.workers.workers.length === 2, "second worker");
    await h.miner.settled();
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "confirmed", blockIndex: 1 });
    }
    await h.node.assertInvariants();
  });

  it("cancelCurrentJob mid-job gives the same outcome as a crash", async () => {
    const h = await boot();
    const ids = await admitRegistrations(h, 3);
    await launchJob(h);
    const before = await h.chainFile();
    const worker = h.workers.last;
    await h.miner.cancelCurrentJob();
    expect(worker.terminated).toBe(true);
    expect(h.miner.currentJobId).toBeNull();
    expect(h.miner.state).toBe("idle");
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "pending" });
    }
    expect(await h.chainFile()).toBe(before);
    await h.node.assertInvariants();
    // The miner does not stall: a new job is scheduled.
    expect(h.timers.pending).toBe(1);
    h.workers.autoMine = true;
    h.timers.advance(1000);
    await until(() => h.workers.workers.length === 2, "second worker");
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(1);
  });

  it("a result with the right jobId but a stale parent is treated as a cancel and a new job is scheduled", async () => {
    const h = await boot();
    const ids = await admitRegistrations(h, 3);
    await launchJob(h);
    const worker = h.workers.last;
    const job = worker.jobs[0];
    if (job === undefined) {
      throw new Error("no job");
    }
    const stale = worker.mine({ jobId: job.jobId, candidate: { ...job.candidate, previousHash: "f".repeat(64) } });
    worker.emit({ jobId: job.jobId, block: stale });
    await until(() => h.miner.currentJobId === null, "job cleared");
    expect(h.node.ledger.head.index).toBe(0);
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "pending" });
    }
    expect(h.miner.state).toBe("idle");
    expect(h.timers.pending).toBe(1);
    await h.node.assertInvariants();
    h.workers.autoMine = true;
    h.timers.advance(1000);
    await until(() => h.workers.workers.length === 2, "new job");
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(1);
  });

  it("a result that is not the reserved snapshot (missing or extra record) is discarded", async () => {
    for (const variant of ["missing", "extra"] as const) {
      const h = await boot();
      const ids = await admitRegistrations(h, 3);
      await launchJob(h);
      const worker = h.workers.last;
      const job = worker.jobs[0];
      if (job === undefined) {
        throw new Error("no job");
      }
      const records =
        variant === "missing"
          ? job.candidate.records.slice(0, 2)
          : [...job.candidate.records, await register(k(3), h.clock.now())];
      const block = worker.mine({ jobId: job.jobId, candidate: { ...job.candidate, records } });
      worker.emit({ jobId: job.jobId, block });
      await until(() => h.miner.currentJobId === null, "job cleared");
      expect(h.node.ledger.head.index).toBe(0);
      for (const id of ids) {
        expect(await status(h, id)).toEqual({ status: "pending" });
      }
      expect(await status(h, ids[0] ?? "")).toEqual({ status: "pending" });
      await h.node.assertInvariants();
      await h.stop();
    }
  });

  it("re-validation failure: the invalid record is rejected(code), the valid ones return to pending", async () => {
    const h = await boot();
    const now = h.clock.now();
    // Block timestamp now + 16 000: record A (ts now) is 16 000 ms older than the block (limit 15 000), B is 11 000.
    const a = await register(k(0), now, "a");
    const b = await register(k(1), now + 5000, "b");
    const idA = await admit(h, a);
    const idB = await admit(h, b);
    h.workers.autoMine = true;
    const head = h.node.ledger.head;
    h.miner.startJob({
      index: 1,
      timestamp: now + 16_000,
      previousHash: head.hash,
      difficulty: 1,
      records: [a, b],
    });
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(0);
    expect(await status(h, idA)).toEqual({ status: "rejected", code: "TIMESTAMP_OUT_OF_RANGE" });
    expect(await status(h, idB)).toEqual({ status: "pending" });
    await h.node.assertInvariants();
    // The miner continues: the valid record is mined by the scheduled job.
    h.timers.advance(1000);
    await h.miner.settled();
    expect(await status(h, idB)).toEqual({ status: "confirmed", blockIndex: 1 });
    await h.node.assertInvariants();
  });

  it("a block that fails validateBlockAdmission (clock moved back) is discarded and the miner continues", async () => {
    const h = await boot();
    const ids = await admitRegistrations(h, 2);
    await launchJob(h);
    const worker = h.workers.last;
    const job = worker.jobs[0];
    if (job === undefined) {
      throw new Error("no job");
    }
    h.clock.set(job.candidate.timestamp - 2000);
    worker.deliver(job);
    await until(() => h.miner.currentJobId === null, "job cleared");
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(0);
    for (const id of ids) {
      expect(await status(h, id)).toEqual({ status: "pending" });
    }
    expect(h.miner.state).toBe("idle");
    expect(h.timers.pending).toBe(1);
    await h.node.assertInvariants();
    h.clock.set(job.candidate.timestamp);
    h.workers.autoMine = true;
    h.timers.advance(1000);
    await h.miner.settled();
    expect(h.node.ledger.head.index).toBe(1);
  });

  describe("persistence fault injection", () => {
    async function faultScenario(h: Harness): Promise<{ id: string; before: string }> {
      const id = (await admitRegistrations(h, 1))[0] ?? "";
      return { id, before: await h.chainFile() };
    }

    async function expectRetryAppendsOnce(h: Harness, id: string, before: string): Promise<void> {
      expect(h.miner.state).toBe("error");
      expect(h.node.ledger.head.index).toBe(0);
      expect(await h.chainFile()).toBe(before);
      expect(await status(h, id)).toEqual({ status: "pending" });
      expect((await h.get("/health")).body["miner"]).toBe("error");
      await h.node.assertInvariants();
      h.store?.arm();
      h.timers.advance(1000);
      await h.miner.settled();
      expect(h.miner.state).toBe("idle");
      expect(await lines(h)).toHaveLength(2);
      expect(h.node.ledger.head.index).toBe(1);
      expect(await status(h, id)).toEqual({ status: "confirmed", blockIndex: 1 });
      await h.node.assertInvariants();
    }

    it("append rejects before writing", async () => {
      const h = await boot({ faulty: true });
      const { id, before } = await faultScenario(h);
      h.store?.arm({ op: "append", nth: 1, mode: "throw" });
      await h.mineNow();
      // The offset was recorded, so the rollback runs (a no-op here): a failed append may have written bytes.
      await expectRetryAppendsOnce(h, id, before);
    });

    it("append writes, then fsync rejects: truncate to the offset", async () => {
      const h = await boot({ faulty: true });
      const { id, before } = await faultScenario(h);
      h.store?.arm({ op: "fsync", nth: 1, mode: "throw" });
      await h.mineNow();
      expect(h.store?.calls).toContain("truncate");
      await expectRetryAppendsOnce(h, id, before);
    });

    it("append writes half a line, then rejects: no torn line remains", async () => {
      const h = await boot({ faulty: true });
      const { id, before } = await faultScenario(h);
      h.store?.arm({ op: "append", nth: 1, mode: "partial-then-throw" });
      await h.mineNow();
      expect(h.store?.calls).toContain("truncate");
      const text = await h.chainFile();
      expect(text.endsWith("\n")).toBe(true);
      await expectRetryAppendsOnce(h, id, before);
    });

    it("size rejects: nothing was written, retry after backoff", async () => {
      const h = await boot({ faulty: true });
      const { id, before } = await faultScenario(h);
      h.store?.arm({ op: "size", nth: 1, mode: "throw" });
      await h.mineNow();
      await expectRetryAppendsOnce(h, id, before);
    });

    async function expectFatal(h: Harness): Promise<void> {
      expect(h.miner.state).toBe("fatal");
      expect(h.fatal).toEqual(["CHAIN_STORE_MISMATCH"]);
      const health = await h.get("/health");
      expect(health.body["miner"]).toBe("fatal");
      expect(health.body["ok"]).toBe(false);
      const refused = await h.post("/registrations", await register(k(2), h.clock.now()));
      expect(refused.status).toBe(503);
      expect(errorCode(refused.body)).toBe("MINER_UNAVAILABLE");
      const workers = h.workers.workers.length;
      h.timers.advance(120_000);
      await new Promise<void>((resolve) => setImmediate(resolve));
      expect(h.workers.workers.length).toBe(workers);
      expect(h.miner.state).toBe("fatal");
      h.miner.assertInvariants();
    }

    it("truncate rejects (rollback fails): fatal, 503, mining never restarts", async () => {
      const h = await boot({ faulty: true });
      await faultScenario(h);
      h.store?.arm({ op: "fsync", nth: 1, mode: "throw" }, { op: "truncate", nth: 1, mode: "throw" });
      await h.mineNow();
      await expectFatal(h);
    });

    it("post-rollback size differs: fatal", async () => {
      const h = await boot({ faulty: true });
      await faultScenario(h);
      h.store?.arm({ op: "fsync", nth: 1, mode: "throw" }, { op: "size", nth: 2, mode: "wrong-size" });
      await h.mineNow();
      await expectFatal(h);
    });

    it("cancelCurrentJob while persisting is deferred; the block is confirmed once", async () => {
      const h = await boot({ faulty: true });
      const { id } = await faultScenario(h);
      const release = h.store?.holdAppend() ?? (() => undefined);
      h.timers.advance(1000);
      await until(() => h.miner.state === "persisting", "persisting");
      let cancelled = false;
      const cancel = h.miner.cancelCurrentJob().then(() => {
        cancelled = true;
      });
      await new Promise<void>((resolve) => setImmediate(resolve));
      expect(cancelled).toBe(false);
      expect(h.miner.state).toBe("persisting");
      release();
      await cancel;
      await h.miner.settled();
      expect(await status(h, id)).toEqual({ status: "confirmed", blockIndex: 1 });
      expect(await lines(h)).toHaveLength(2);
      await h.node.assertInvariants();
    });

    it("shutdown while persisting awaits the persist step; the block survives a restart", async () => {
      const dataDir = await freshDir();
      const clock = new TestClock();
      const h = await boot({ faulty: true, dataDir, clock, keepDir: true });
      const { id } = await faultScenario(h);
      const release = h.store?.holdAppend() ?? (() => undefined);
      h.timers.advance(1000);
      await until(() => h.miner.state === "persisting", "persisting");
      let closed = false;
      const closing = h.stop().then(() => {
        closed = true;
      });
      await new Promise<void>((resolve) => setImmediate(resolve));
      expect(closed).toBe(false);
      release();
      await closing;
      const text = await readFile(join(dataDir, "chain.jsonl"), "utf8");
      expect(text.trim().split("\n")).toHaveLength(2);
      const again = await boot({ dataDir, clock, keepDir: true });
      expect(again.node.ledger.head.index).toBe(1);
      expect(await status(again, id)).toEqual({ status: "confirmed", blockIndex: 1 });
    });
  });

  describe("re-admission and the terminal LRU", () => {
    it("expired and rejected records return to pending with the same recordId; confirmed and reserved are duplicates", async () => {
      const h = await boot();
      const now = h.clock.now();
      // Expiry path: ts = now + 5000 so the record is still within skew after the TTL has passed.
      const expiring = await register(k(0), now + 5000, "e");
      const id = await admit(h, expiring);
      h.clock.advance(5001);
      expect(await status(h, id)).toEqual({ status: "expired" });
      const readmitted = await h.post("/registrations", expiring);
      expect(readmitted.status).toBe(202);
      expect(readmitted.body["recordId"]).toBe(id);
      expect(await status(h, id)).toEqual({ status: "pending" });
      await h.node.assertInvariants();

      // Reserved is a duplicate.
      await launchJob(h);
      expect(h.miner.mempool.getLive(id)?.status).toBe("reserved");
      expect((await h.post("/registrations", expiring)).status).toBe(409);
      const job = h.workers.last.jobs[0];
      if (job === undefined) {
        throw new Error("no job");
      }
      h.workers.last.deliver(job);
      await h.miner.settled();
      // Confirmed is a duplicate.
      expect(await status(h, id)).toEqual({ status: "confirmed", blockIndex: 1 });
      expect((await h.post("/registrations", expiring)).status).toBe(409);
      await h.node.assertInvariants();
    });

    it("a rejected record can be resubmitted and gets the same id", async () => {
      const h = await boot();
      const now = h.clock.now();
      const a = await register(k(0), now, "a");
      const id = await admit(h, a);
      h.workers.autoMine = true;
      const head = h.node.ledger.head;
      h.miner.startJob({ index: 1, timestamp: now + 16_000, previousHash: head.hash, difficulty: 1, records: [a] });
      await h.miner.settled();
      expect(await status(h, id)).toEqual({ status: "rejected", code: "TIMESTAMP_OUT_OF_RANGE" });
      const again = await h.post("/registrations", a);
      expect(again.status).toBe(202);
      expect(again.body["recordId"]).toBe(id);
      expect(await status(h, id)).toEqual({ status: "pending" });
      await h.node.assertInvariants();
    });

    it("the terminal LRU evicts the oldest entry (small injected limit)", async () => {
      const h = await boot({ terminalLimit: 2 });
      const now = h.clock.now();
      const ids: string[] = [];
      for (let i = 0; i < 3; i += 1) {
        ids.push(await admit(h, await register(k(i), now + 5000, `u${i}`)));
      }
      h.clock.advance(5001);
      expect((await h.get("/mempool")).body["value"]).toEqual([]);
      expect((await h.get(`/records/${ids[0]}`)).status).toBe(404);
      expect(await status(h, ids[1] ?? "")).toEqual({ status: "expired" });
      expect(await status(h, ids[2] ?? "")).toEqual({ status: "expired" });
      await h.node.assertInvariants();
    });

    it("a pending record past the TTL at candidate build becomes expired, not rejected", async () => {
      const h = await boot();
      const [id] = await admitRegistrations(h, 1);
      h.clock.advance(5001);
      h.timers.advance(1000);
      await h.miner.settled();
      expect(await status(h, id ?? "")).toEqual({ status: "expired" });
      expect(h.workers.workers).toHaveLength(0);
      await h.node.assertInvariants();
    });
  });

  describe("restart", () => {
    it("a block present in the file is not re-minted: resubmission is a duplicate (crash between fsync and memory)", async () => {
      const dataDir = await freshDir();
      const clock = new TestClock();
      const first = await boot({ dataDir, clock, keepDir: true });
      const record = await register(k(0), clock.now());
      const id = await admit(first, record);
      await first.mineNow();
      await first.stop();
      const second = await boot({ dataDir, clock, keepDir: true });
      expect(await status(second, id)).toEqual({ status: "confirmed", blockIndex: 1 });
      const again = await second.post("/registrations", record);
      expect(again.status).toBe(409);
      expect(errorCode(again.body)).toBe("KEY_ALREADY_REGISTERED");
      expect(second.node.ledger.blocks).toHaveLength(2);
    });

    it("the mempool is empty after a restart; a prior pending id is 404 and resubmission succeeds", async () => {
      const dataDir = await freshDir();
      const clock = new TestClock();
      const first = await boot({ dataDir, clock, keepDir: true });
      const record = await register(k(0), clock.now());
      const id = await admit(first, record);
      await first.stop();
      const second = await boot({ dataDir, clock, keepDir: true });
      expect((await second.get("/mempool")).body["value"]).toEqual([]);
      expect((await second.get(`/records/${id}`)).status).toBe(404);
      expect((await second.post("/registrations", record)).status).toBe(202);
      await second.node.assertInvariants();
    });
  });

  describe("TTL", () => {
    it("pending expires after mempoolTtlMs", async () => {
      const h = await boot();
      const [id] = await admitRegistrations(h, 1);
      h.clock.advance(4999);
      expect(await status(h, id ?? "")).toEqual({ status: "pending" });
      h.clock.advance(2);
      expect(await status(h, id ?? "")).toEqual({ status: "expired" });
      await h.node.assertInvariants();
    });

    it("a reserved record past its TTL is not expired during the job and is re-checked on return to pending", async () => {
      const h = await boot();
      const [id] = await admitRegistrations(h, 1);
      await launchJob(h);
      h.clock.advance(5001);
      expect(await status(h, id ?? "")).toEqual({ status: "pending" });
      expect(h.miner.mempool.getLive(id ?? "")?.status).toBe("reserved");
      await h.node.assertInvariants();
      h.workers.last.crash();
      await until(() => h.miner.state === "restarting", "restarting");
      expect(await status(h, id ?? "")).toEqual({ status: "expired" });
      await h.node.assertInvariants();
    });
  });

  describe("counting", () => {
    it("50 seeded admit/cancel/crash/mine steps keep I1-I6 and end every record in exactly one state", async () => {
      const h = await boot();
      const random = seededRandom(20260101);
      const admitted = new Set<string>();
      const sessionIds = SESSIONS.map((session) => session.id);
      const pick = (n: number): number => Math.floor(random() * n);

      const jobNow = async (): Promise<boolean> => {
        if (h.miner.currentJobId !== null) {
          return true;
        }
        h.workers.autoMine = false;
        h.timers.advance(1000);
        await until(
          () => h.miner.currentJobId !== null || (h.miner.state === "idle" && h.miner.mempool.pendingCount() === 0) || h.miner.state === "restarting",
          "job or quiet",
        );
        return h.miner.currentJobId !== null;
      };

      for (let step = 0; step < 50; step += 1) {
        const roll = random();
        if (roll < 0.5) {
          const key = k(pick(4));
          const record =
            random() < 0.4
              ? await register(key, h.clock.now(), `a${pick(5)}`)
              : await attend(key, sessionIds[pick(sessionIds.length)] ?? "keynote", h.clock.now());
          const result = await h.post(record.payload.type === "register" ? "/registrations" : "/attendance", record);
          if (result.status === 202) {
            admitted.add(result.body["recordId"] as string);
          } else {
            expect([400, 409]).toContain(result.status);
          }
        } else if (roll < 0.6) {
          if (await jobNow()) {
            await h.miner.cancelCurrentJob();
          }
        } else if (roll < 0.7) {
          if (await jobNow()) {
            h.workers.last.crash();
            await until(() => h.miner.state === "restarting", "restarting");
          }
        } else if (roll < 0.9) {
          if (h.miner.currentJobId !== null) {
            const worker = h.workers.last;
            const job = worker.jobs[0];
            if (job === undefined) {
              throw new Error("no job");
            }
            worker.deliver(job);
          } else {
            h.workers.autoMine = true;
            h.timers.advance(1000);
          }
          await h.miner.settled();
          h.workers.autoMine = false;
        } else {
          h.clock.advance(pick(2000));
          await h.get("/mempool");
        }
        h.clock.advance(pick(1200));
        await h.node.assertInvariants();
      }

      // Drain: mine everything that is still live, then let the rest expire.
      for (let round = 0; round < 10; round += 1) {
        if (h.miner.currentJobId !== null) {
          await h.miner.cancelCurrentJob();
        }
        h.workers.autoMine = true;
        h.timers.advance(30_000);
        await h.miner.settled();
        await h.node.assertInvariants();
      }
      h.clock.advance(10_000);
      await h.get("/mempool");
      await h.node.assertInvariants();

      const counts = h.miner.mempool.counts();
      expect(counts.pending + counts.reserved).toBe(0);
      expect(counts.admitted).toBe(
        counts.confirmed + counts.expired + counts.rejected + counts.retired,
      );
      for (const id of admitted) {
        const state = (await status(h, id)) as { status: string };
        expect(["confirmed", "expired", "rejected"]).toContain(state.status);
      }
      expect(BASE_TIME).toBeGreaterThan(0);
    });
  });
});
