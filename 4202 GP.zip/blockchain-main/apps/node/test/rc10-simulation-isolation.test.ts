// RC10: the difficulty simulation is isolated from the live node (SPEC section 8).

import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { GENESIS_TIMESTAMP, getProfile } from "@conference-chain/shared";
import { CONFERENCE_ID, attend, getKeys, makeHarness, register, until, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 120_000, hookTimeout: 120_000 });

const DEMO = getProfile("demo", CONFERENCE_ID);
const COUNT = 11; // demo profile: I = 5, boundaries at blocks 6 and 11

let keys: TestKeys[] = [];
let h: Harness | null = null;

beforeAll(async () => {
  keys = await getKeys(3);
});
afterEach(async () => {
  await h?.stop();
  h = null;
});

function key(index: number): TestKeys {
  const value = keys[index];
  if (value === undefined) {
    throw new Error("missing key");
  }
  return value;
}

interface Simulation {
  valid: boolean;
  blocks: { index: number; hash: string; difficulty: number; timestamp: number }[];
  adjustments: { atIndex: number; actualMs: number; expectedMs: number; from: number; to: number }[];
}

async function simulate(harness: Harness, count: number, intervalMs: number): Promise<Simulation> {
  const response = await harness.post("/demo/difficulty-simulation", { count, intervalMs });
  expect(response.status).toBe(200);
  return response.body as unknown as Simulation;
}

// Demo profile node with an injected live clock, one registered attendee and one mined block.
async function setup(options: Parameters<typeof makeHarness>[0] = {}): Promise<Harness> {
  const harness = await makeHarness({ profile: "demo", enableDemoRoutes: true, ...options });
  h = harness;
  expect(
    (await harness.post("/registrations", await register(key(0), harness.clock.now(), "alice", harness.node.chainId)))
      .status,
  ).toBe(202);
  await harness.mineNow();
  expect(harness.node.ledger.head.index).toBe(1);
  return harness;
}

interface LiveSnapshot {
  headIndex: number;
  headHash: string;
  mempool: unknown;
  chainBytes: string;
}

async function snapshot(harness: Harness): Promise<LiveSnapshot> {
  return {
    headIndex: harness.node.ledger.head.index,
    headHash: harness.node.ledger.head.hash,
    mempool: (await harness.get("/mempool")).body,
    chainBytes: await harness.chainFile(),
  };
}

describe("RC10: simulation isolation", () => {
  it("intervalMs 0 raises the difficulty, intervalMs 120000 lowers it; the live node is untouched", async () => {
    // Uses the REAL validation worker thread once, to cover the production path.
    const harness = await setup({ realValidationWorker: true });
    const clockSpy = vi.spyOn(harness.clock, "now");

    const before = await snapshot(harness);
    let callsBefore = clockSpy.mock.calls.length;
    const rising = await simulate(harness, COUNT, 0);
    expect(clockSpy.mock.calls.length).toBe(callsBefore); // the live clock is never read by a simulation
    expect(rising.valid).toBe(true);
    expect(rising.blocks).toHaveLength(COUNT);
    expect(rising.blocks.map((block) => block.index)).toEqual(Array.from({ length: COUNT }, (_, i) => i + 1));
    expect(rising.blocks.map((block) => block.difficulty)).toEqual([2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4]);
    expect(rising.blocks.map((block) => block.timestamp)).toEqual(Array(COUNT).fill(GENESIS_TIMESTAMP));
    expect(rising.adjustments).toEqual([
      { atIndex: 6, actualMs: 0, expectedMs: DEMO.targetBlockTimeMs * (DEMO.adjustmentInterval - 1), from: 2, to: 3 },
      { atIndex: 11, actualMs: 0, expectedMs: DEMO.targetBlockTimeMs * (DEMO.adjustmentInterval - 1), from: 3, to: 4 },
    ]);
    expect(await snapshot(harness)).toEqual(before);

    harness.heavyRateClock.advance(60_000);
    callsBefore = clockSpy.mock.calls.length;
    const falling = await simulate(harness, COUNT, 120_000);
    expect(clockSpy.mock.calls.length).toBe(callsBefore);
    expect(falling.valid).toBe(true);
    expect(falling.blocks.map((block) => block.difficulty)).toEqual([2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1]);
    expect(falling.blocks.map((block) => block.timestamp)).toEqual(
      Array.from({ length: COUNT }, (_, i) => GENESIS_TIMESTAMP + (i + 1) * 120_000),
    );
    const expectedMs = DEMO.targetBlockTimeMs * (DEMO.adjustmentInterval - 1);
    expect(falling.adjustments).toEqual([
      { atIndex: 6, actualMs: 4 * 120_000, expectedMs, from: 2, to: 1 },
      { atIndex: 11, actualMs: 4 * 120_000, expectedMs, from: 1, to: 1 },
    ]);
    expect(await snapshot(harness)).toEqual(before);
    await harness.node.assertInvariants();
  });

  it("a mid-range interval keeps the difficulty (equal to the expected window)", async () => {
    const harness = await setup();
    // actual = 4 * interval; expected = 12 000 -> interval 3000 keeps.
    const kept = await simulate(harness, 6, DEMO.targetBlockTimeMs);
    expect(kept.adjustments).toEqual([{ atIndex: 6, actualMs: 12_000, expectedMs: 12_000, from: 2, to: 2 }]);
    expect(kept.blocks.map((block) => block.difficulty)).toEqual([2, 2, 2, 2, 2, 2]);
  });

  it("ordinary flow works afterwards, with live timestamps nowhere near the synthetic ones", async () => {
    const harness = await setup();
    const clockSpy = vi.spyOn(harness.clock, "now");
    await simulate(harness, COUNT, 0);
    harness.heavyRateClock.advance(60_000);
    await simulate(harness, COUNT, 120_000);

    const chainId = harness.node.chainId;
    const previous = harness.node.ledger.head;
    const callsBeforeFlow = clockSpy.mock.calls.length;
    harness.clock.advance(1000);
    expect((await harness.post("/registrations", await register(key(1), harness.clock.now(), "bob", chainId))).status).toBe(
      202,
    );
    await harness.mineNow();
    expect((await harness.post("/attendance", await attend(key(1), "keynote", harness.clock.now(), chainId))).status).toBe(
      202,
    );
    await harness.mineNow();
    expect(clockSpy.mock.calls.length).toBeGreaterThan(callsBeforeFlow); // the live path does read the clock

    const head = harness.node.ledger.head;
    expect(head.index).toBe(previous.index + 2);
    let lower = previous.timestamp;
    for (const block of harness.node.ledger.blocks.slice(previous.index + 1)) {
      expect(block.timestamp).toBeGreaterThanOrEqual(lower);
      expect(block.timestamp).toBeLessThanOrEqual(harness.clock.now() + DEMO.maxBlockSkewMs);
      expect(Math.abs(block.timestamp - harness.clock.now())).toBeLessThan(10_000);
      expect(block.timestamp).toBeGreaterThan(GENESIS_TIMESTAMP + 1_000_000_000);
      lower = block.timestamp;
    }

    const q1 = await harness.get(`/attendees/${key(1).attendeeId}/sessions`);
    expect((q1.body["sessions"] as unknown[]).length).toBe(1);
    const q2 = await harness.get("/sessions/keynote/attendees");
    expect((q2.body["attendees"] as { attendeeId: string }[]).map((entry) => entry.attendeeId)).toEqual([
      key(1).attendeeId,
    ]);
    harness.heavyRateClock.advance(60_000);
    expect(await harness.get("/chain/validate")).toEqual({ status: 200, body: { ok: true } });
    await harness.node.assertInvariants();
  });

  it("a live registration submitted while a simulation is running is admitted and mined normally", async () => {
    const harness = await setup();
    const release = harness.validationWorkers.hold();
    const running = harness.post("/demo/difficulty-simulation", { count: 6, intervalMs: 0 });
    await until(() => harness.validationWorkers.count("simulate") === 1, "simulation started");

    const posted = await harness.post(
      "/registrations",
      await register(key(2), harness.clock.now(), "carol", harness.node.chainId),
    );
    expect(posted.status).toBe(202);
    await harness.mineNow(); // the simulation is still parked in the validation worker
    expect(await harness.get(`/records/${posted.body["recordId"] as string}`)).toEqual({
      status: 200,
      body: { status: "confirmed", blockIndex: 2 },
    });

    release();
    const result = await running;
    expect(result.status).toBe(200);
    expect(result.body["valid"]).toBe(true);
    expect(harness.node.ledger.head.index).toBe(2);
    await harness.node.assertInvariants();
  });

  it("the simulation never touches the writer lock, the miner state or the mempool while a record is pending", async () => {
    const harness = await setup();
    expect(
      (await harness.post("/registrations", await register(key(1), harness.clock.now(), "bob", harness.node.chainId))).status,
    ).toBe(202);
    const mempoolBefore = (await harness.get("/mempool")).body;
    expect(mempoolBefore["value"]).toHaveLength(1);
    await simulate(harness, 3, 0);
    expect((await harness.get("/mempool")).body).toEqual(mempoolBefore);
    expect(harness.miner.state).toBe("idle");
    await harness.mineNow();
    expect(harness.node.ledger.head.index).toBe(2);
  });

  it("the route is absent when ENABLE_DEMO_ROUTES is not 'true'", async () => {
    h = await makeHarness({ profile: "demo", enableDemoRoutes: false });
    const response = await h.post("/demo/difficulty-simulation", { count: 3, intervalMs: 0 });
    expect(response.status).toBe(404);
    expect(h.validationWorkers.jobs).toHaveLength(0);
  });

  it("no 'DemoClock' symbol exists in the code base (grep over src)", async () => {
    const srcDir = fileURLToPath(new URL("../src/", import.meta.url));
    const entries = await readdir(srcDir, { recursive: true, withFileTypes: true });
    const files = entries.filter((entry) => entry.isFile() && entry.name.endsWith(".ts"));
    expect(files.length).toBeGreaterThan(10);
    for (const file of files) {
      const text = await readFile(join(file.parentPath, file.name), "utf8");
      expect(text, file.name).not.toContain("DemoClock");
    }
  });
});
