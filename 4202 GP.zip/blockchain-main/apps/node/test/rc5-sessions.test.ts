import { rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { afterEach, beforeAll, describe, expect, expectTypeOf, it, vi } from "vitest";
import { validateChain } from "@conference-chain/shared";
import { BootError } from "../src/boot-error.js";
import { loadSessions } from "../src/sessions.js";
import { attend, getKeys, makeDataDir, makeHarness, register, TestClock, type Harness, type TestKeys } from "./support.js";

vi.setConfig({ testTimeout: 30_000, hookTimeout: 30_000 });

let keys: TestKeys[] = [];
let live: Harness[] = [];
const dirs: string[] = [];

beforeAll(async () => {
  keys = await getKeys(1);
});
afterEach(async () => {
  for (const harness of live) {
    await harness.stop();
  }
  live = [];
  for (const dir of dirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
});

async function dir(): Promise<string> {
  const path = await makeDataDir();
  dirs.push(path);
  return path;
}

describe("RC5: the session catalog is not consensus", () => {
  it("keeps a confirmed attendance after the session leaves the catalog", async () => {
    const [alice] = keys as [TestKeys];
    const dataDir = await dir();
    const clock = new TestClock();
    const first = await makeHarness({ dataDir, clock, keepDir: true, sessions: [{ id: "s1", title: "S1" }] });
    live.push(first);
    await first.post("/registrations", await register(alice, clock.now()));
    await first.mineNow();
    expect((await first.post("/attendance", await attend(alice, "s1", clock.now()))).status).toBe(202);
    await first.mineNow();
    await first.stop();

    const second = await makeHarness({ dataDir, clock, keepDir: true, sessions: [{ id: "s2", title: "S2" }] });
    live.push(second);
    const q2 = await second.get("/sessions/s1/attendees");
    expect(q2.status).toBe(200);
    expect(q2.body["attendees"]).toHaveLength(1);
    const again = await second.post("/attendance", await attend(alice, "s1", clock.now()));
    expect(again.status).toBe(400);
    expect((again.body["error"] as { code: string }).code).toBe("UNKNOWN_SESSION");
    const chain = await validateChain(
      second.node.ledger.blocks,
      second.node.settings.config,
      (await import("../src/app.js")).nodeCrypto,
    );
    expect(chain).toEqual({ ok: true });
  });

  it("answers 404 for a session in neither the catalog nor the chain", async () => {
    const h = await makeHarness();
    live.push(h);
    expect((await h.get("/sessions/ghost/attendees")).status).toBe(404);
    expect((await h.get("/sessions/keynote/attendees")).status).toBe(200);
  });

  it("validateChain has no catalog parameter", () => {
    expectTypeOf(validateChain).parameters.toHaveProperty("length");
    type Params = Parameters<typeof validateChain>;
    expectTypeOf<Params["length"]>().toEqualTypeOf<3>();
  });

  it("refuses to boot with a sessions file that does not parse", async () => {
    const path = join(await dir(), "sessions.json");
    await writeFile(path, "{ not json");
    await expect(loadSessions(path)).rejects.toBeInstanceOf(BootError);
    await writeFile(path, JSON.stringify([{ id: "a", title: "A" }, { id: "a", title: "B" }]));
    await expect(loadSessions(path)).rejects.toBeInstanceOf(BootError);
    await writeFile(path, JSON.stringify([{ id: "bad id!", title: "A" }]));
    await expect(loadSessions(path)).rejects.toBeInstanceOf(BootError);
    await expect(loadSessions(join(await dir(), "missing.json"))).rejects.toBeInstanceOf(BootError);
  });

  it("loads the shipped example", async () => {
    const sessions = await loadSessions(new URL("../sessions.example.json", import.meta.url).pathname);
    expect(sessions.length).toBeGreaterThan(0);
  });
});
