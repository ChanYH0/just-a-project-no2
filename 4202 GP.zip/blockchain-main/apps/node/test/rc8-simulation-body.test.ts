// RC8 (node part): integer schemas on POST /demo/difficulty-simulation, including -0 via JSON.parse("-0").

import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { makeHarness, type Harness } from "./support.js";

vi.setConfig({ testTimeout: 60_000, hookTimeout: 60_000 });

let h: Harness;

beforeAll(async () => {
  h = await makeHarness({ enableDemoRoutes: true });
});
afterAll(async () => {
  await h.stop();
});
afterEach(() => {
  // Each request gets a fresh rate-limit window (the limiter has its own clock).
  h.heavyRateClock.advance(60_000);
});

async function raw(body: string): Promise<{ status: number; code: string | null }> {
  const response = await h.app.inject({
    method: "POST",
    url: "/demo/difficulty-simulation",
    payload: body,
    headers: { "content-type": "application/json" },
  });
  const parsed: unknown = JSON.parse(response.body);
  const error = typeof parsed === "object" && parsed !== null && "error" in parsed ? parsed.error : null;
  const code =
    typeof error === "object" && error !== null && "code" in error && typeof error.code === "string" ? error.code : null;
  return { status: response.statusCode, code };
}

describe("RC8: simulation body validation", () => {
  it("accepts intervalMs 0 and the documented bounds", async () => {
    expect((await raw('{"count":1,"intervalMs":0}')).status).toBe(200);
    expect((await raw('{"count":30,"intervalMs":120000}')).status).toBe(200);
    expect((await raw('{"count":1,"intervalMs":120000}')).status).toBe(200);
  });

  it.each([
    ["intervalMs -0", '{"count":1,"intervalMs":-0}'],
    ["intervalMs -1", '{"count":1,"intervalMs":-1}'],
    ["intervalMs 120001", '{"count":1,"intervalMs":120001}'],
    ["count 0", '{"count":0,"intervalMs":0}'],
    ["count -0", '{"count":-0,"intervalMs":0}'],
    ["count 31", '{"count":31,"intervalMs":0}'],
    ["count -1", '{"count":-1,"intervalMs":0}'],
    ["non-integer count", '{"count":1.5,"intervalMs":0}'],
    ["non-integer intervalMs", '{"count":1,"intervalMs":0.5}'],
    ["string count", '{"count":"1","intervalMs":0}'],
    ["missing count", '{"intervalMs":0}'],
    ["missing intervalMs", '{"count":1}'],
    ["extra field", '{"count":1,"intervalMs":0,"extra":1}'],
    ["unsafe integer", '{"count":1,"intervalMs":9007199254740993}'],
    ["null body field", '{"count":null,"intervalMs":0}'],
  ])("rejects %s with INVALID_SCHEMA (400)", async (_name, body) => {
    expect(await raw(body)).toEqual({ status: 400, code: "INVALID_SCHEMA" });
  });

  it("rejects malformed JSON and an empty body as INVALID_SCHEMA", async () => {
    expect(await raw("{")).toEqual({ status: 400, code: "INVALID_SCHEMA" });
    const empty = await h.app.inject({
      method: "POST",
      url: "/demo/difficulty-simulation",
      headers: { "content-type": "application/json" },
    });
    expect(empty.statusCode).toBe(400);
  });
});
