#include <metal_stdlib>
using namespace metal;

constant uint SHA256_K[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u,
    0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
    0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
    0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
    0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu,
    0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u,
    0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
    0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
    0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
    0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u,
    0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u,
    0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
    0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
    0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
};

inline uint shaROTR(uint x, uint n) { return (x >> n) | (x << (32u - n)); }

inline void shaCompress(thread uint *state, thread const uchar *block) {
    thread uint words[64];
    for (uint i = 0; i < 16; ++i) {
        uint j = i * 4;
        words[i] = (uint(block[j]) << 24) | (uint(block[j + 1]) << 16) |
                   (uint(block[j + 2]) << 8) | uint(block[j + 3]);
    }
    for (uint i = 16; i < 64; ++i) {
        uint x = words[i - 15];
        uint y = words[i - 2];
        uint s0 = shaROTR(x, 7) ^ shaROTR(x, 18) ^ (x >> 3);
        uint s1 = shaROTR(y, 17) ^ shaROTR(y, 19) ^ (y >> 10);
        words[i] = words[i - 16] + s0 + words[i - 7] + s1;
    }

    uint a = state[0], b = state[1], c = state[2], d = state[3];
    uint e = state[4], f = state[5], g = state[6], h = state[7];
    for (uint i = 0; i < 64; ++i) {
        uint big1 = shaROTR(e, 6) ^ shaROTR(e, 11) ^ shaROTR(e, 25);
        uint choose = (e & f) ^ ((~e) & g);
        uint t1 = h + big1 + choose + SHA256_K[i] + words[i];
        uint big0 = shaROTR(a, 2) ^ shaROTR(a, 13) ^ shaROTR(a, 22);
        uint majority = (a & b) ^ (a & c) ^ (b & c);
        uint t2 = big0 + majority;
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
    state[4] += e; state[5] += f; state[6] += g; state[7] += h;
}

inline bool hasLeadingZeroHexDigits(thread const uint *digest, uint difficulty) {
    uint wholeWords = difficulty / 8u;
    uint remainingNibbles = difficulty % 8u;
    for (uint i = 0; i < wholeWords; ++i) {
        if (digest[i] != 0u) return false;
    }
    if (remainingNibbles == 0u) return true;
    uint word = digest[wholeWords];
    uint shift = 32u - remainingNibbles * 4u;
    return (word >> shift) == 0u;
}

kernel void mine_batch(
    device const uchar *prefix [[buffer(0)]],
    device const uchar *suffix [[buffer(1)]],
    device atomic_uint *firstMatch [[buffer(2)]],
    constant uint &prefixLength [[buffer(3)]],
    constant uint &suffixLength [[buffer(4)]],
    constant ulong &startNonce [[buffer(5)]],
    constant ulong &nonceStride [[buffer(6)]],
    constant uint &batchCount [[buffer(7)]],
    constant uint &difficulty [[buffer(8)]],
    uint gid [[thread_position_in_grid]]) {
    if (gid >= batchCount) return;
    ulong nonce = startNonce + ulong(gid) * nonceStride;

    thread uchar digits[16];
    uchar reversed[16];
    uint digitCount = 0;
    ulong remaining = nonce;
    do {
        reversed[digitCount++] = uchar(48u + uint(remaining % 10ul));
        remaining /= 10ul;
    } while (remaining != 0ul && digitCount < 16u);
    for (uint i = 0; i < digitCount; ++i) digits[i] = reversed[digitCount - 1u - i];

    uint messageLength = prefixLength + digitCount + suffixLength;
    ulong bitLength = ulong(messageLength) * 8ul;
    uint blockCount = (messageLength + 9u + 63u) / 64u;
    thread uint state[8] = {
        0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
        0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u
    };

    for (uint blockIndex = 0; blockIndex < blockCount; ++blockIndex) {
        thread uchar block[64];
        uint blockStart = blockIndex * 64u;
        for (uint i = 0; i < 64u; ++i) {
            uint position = blockStart + i;
            if (position < prefixLength) {
                block[i] = prefix[position];
            } else if (position < prefixLength + digitCount) {
                block[i] = digits[position - prefixLength];
            } else if (position < messageLength) {
                block[i] = suffix[position - prefixLength - digitCount];
            } else if (position == messageLength) {
                block[i] = 0x80u;
            } else {
                block[i] = 0u;
            }
        }
        if (blockIndex == blockCount - 1u) {
            for (uint i = 0; i < 8u; ++i) {
                block[56u + i] = uchar((bitLength >> (56u - i * 8u)) & 0xfful);
            }
        }
        shaCompress(state, block);
    }

    if (hasLeadingZeroHexDigits(state, difficulty)) {
        atomic_fetch_min_explicit(firstMatch, gid, memory_order_relaxed);
    }
}
