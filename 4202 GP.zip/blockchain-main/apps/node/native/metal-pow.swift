import Foundation
import Metal

private let maximumSafeInteger: UInt64 = 9_007_199_254_740_991
private let maximumMessageBytes = 1_048_576
private let maximumInputBytes = 3 * 1_048_576

private enum HelperError: Error {
    case invalidRequest
    case oversizedRequest
    case nonceRangeExhausted
    case gpuUnavailable
    case captureDisabled
    case captureUnsupported
    case gpuFailed
    case kernelFailed
}

private struct Request: Decodable {
    let prefix: String
    let suffix: String
    let difficulty: UInt32
    let startNonce: UInt64
    let stride: UInt64
    let batchSize: UInt32
    let maxNonces: UInt64?
    let capturePath: String?

    enum CodingKeys: String, CodingKey, CaseIterable {
        case prefix, suffix, difficulty, startNonce, stride, batchSize, maxNonces, capturePath
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let keys = Set(container.allKeys)
        let required: Set<CodingKeys> = [.prefix, .suffix, .difficulty, .startNonce, .stride, .batchSize]
        guard required.isSubset(of: keys), keys.isSubset(of: Set(CodingKeys.allCases)) else {
            throw HelperError.invalidRequest
        }
        prefix = try container.decode(String.self, forKey: .prefix)
        suffix = try container.decode(String.self, forKey: .suffix)
        difficulty = try container.decode(UInt32.self, forKey: .difficulty)
        startNonce = try container.decode(UInt64.self, forKey: .startNonce)
        stride = try container.decode(UInt64.self, forKey: .stride)
        batchSize = try container.decode(UInt32.self, forKey: .batchSize)
        maxNonces = try container.decodeIfPresent(UInt64.self, forKey: .maxNonces)
        capturePath = try container.decodeIfPresent(String.self, forKey: .capturePath)
    }
}

private struct Result: Encodable {
    let nonce: UInt64?
    let attempts: UInt64
    let elapsedMs: Double
    let device: String
    let capturePath: String?

    private enum CodingKeys: String, CodingKey {
        case nonce, attempts, elapsedMs, device, capturePath
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        if let nonce {
            try container.encode(nonce, forKey: .nonce)
        } else {
            try container.encodeNil(forKey: .nonce)
        }
        try container.encode(attempts, forKey: .attempts)
        try container.encode(elapsedMs, forKey: .elapsedMs)
        try container.encode(device, forKey: .device)
        try container.encodeIfPresent(capturePath, forKey: .capturePath)
    }
}

private func strictBase64(_ encoded: String) throws -> Data {
    guard let data = Data(base64Encoded: encoded), data.base64EncodedString() == encoded else {
        throw HelperError.invalidRequest
    }
    return data
}

private func readRequest() throws -> Request {
    let input = FileHandle.standardInput.readDataToEndOfFile()
    guard !input.isEmpty, input.count <= maximumInputBytes else {
        throw input.isEmpty ? HelperError.invalidRequest : HelperError.oversizedRequest
    }
    guard let object = try JSONSerialization.jsonObject(with: input) as? [String: Any] else {
        throw HelperError.invalidRequest
    }
    let allowedKeys = Set(Request.CodingKeys.allCases.map(\.rawValue))
    let requiredKeys: Set<String> = ["prefix", "suffix", "difficulty", "startNonce", "stride", "batchSize"]
    guard Set(object.keys).isSubset(of: allowedKeys), requiredKeys.isSubset(of: Set(object.keys)) else {
        throw HelperError.invalidRequest
    }
    let request = try JSONDecoder().decode(Request.self, from: input)
    guard request.difficulty >= 1, request.difficulty <= 64,
          request.startNonce <= maximumSafeInteger,
          request.stride >= 1, request.stride <= maximumSafeInteger,
          request.batchSize >= 1, request.batchSize <= 65_536,
          (request.maxNonces == nil || (request.maxNonces! >= 1 && request.maxNonces! <= maximumSafeInteger)) else {
        throw HelperError.invalidRequest
    }
    if let capturePath = request.capturePath {
        guard !capturePath.isEmpty, capturePath.hasSuffix(".gputrace") else {
            throw HelperError.invalidRequest
        }
        guard ProcessInfo.processInfo.environment["MTL_CAPTURE_ENABLED"] == "1" else {
            throw HelperError.captureDisabled
        }
    }
    return request
}

private func prepareCapture(
    _ path: String?,
    device: any MTLDevice,
    commandQueue: any MTLCommandQueue
) throws -> MTLCaptureManager? {
    guard let path else { return nil }
    let manager = MTLCaptureManager.shared()
    guard manager.supportsDestination(.gpuTraceDocument) else {
        throw HelperError.captureUnsupported
    }
    let descriptor = MTLCaptureDescriptor()
    descriptor.captureObject = commandQueue
    descriptor.destination = .gpuTraceDocument
    descriptor.outputURL = URL(fileURLWithPath: path)
    do {
        _ = try manager.startCapture(with: descriptor)
    } catch {
        throw HelperError.captureUnsupported
    }
    return manager
}

private func run(_ request: Request, kernelURL: URL) throws -> Result {
    guard let device = MTLCreateSystemDefaultDevice(), let queue = device.makeCommandQueue() else {
        throw HelperError.gpuUnavailable
    }

    let prefix = try strictBase64(request.prefix)
    let suffix = try strictBase64(request.suffix)
    guard prefix.count <= maximumMessageBytes,
          suffix.count <= maximumMessageBytes - prefix.count,
          prefix.count + suffix.count <= maximumMessageBytes - 16 else {
        throw HelperError.oversizedRequest
    }

    let source: String
    do {
        source = try String(contentsOf: kernelURL, encoding: .utf8)
    } catch {
        throw HelperError.kernelFailed
    }
    let library: MTLLibrary
    do {
        library = try device.makeLibrary(source: source, options: nil)
    } catch {
        throw HelperError.kernelFailed
    }
    guard let function = library.makeFunction(name: "mine_batch") else {
        throw HelperError.kernelFailed
    }
    let pipeline: MTLComputePipelineState
    do {
        pipeline = try device.makeComputePipelineState(function: function)
    } catch {
        throw HelperError.kernelFailed
    }

    let prefixBytes = prefix.isEmpty ? Data([0]) : prefix
    let suffixBytes = suffix.isEmpty ? Data([0]) : suffix
    guard let prefixBuffer = prefixBytes.withUnsafeBytes({
        device.makeBuffer(bytes: $0.baseAddress!, length: prefixBytes.count, options: .storageModeShared)
    }), let suffixBuffer = suffixBytes.withUnsafeBytes({
        device.makeBuffer(bytes: $0.baseAddress!, length: suffixBytes.count, options: .storageModeShared)
    }), let winnerBuffer = device.makeBuffer(length: MemoryLayout<UInt32>.stride, options: .storageModeShared) else {
        throw HelperError.gpuFailed
    }

    let manager = try prepareCapture(request.capturePath, device: device, commandQueue: queue)
    let start = ProcessInfo.processInfo.systemUptime
    var currentNonce = request.startNonce
    var attempts: UInt64 = 0
    var nonceLimit = request.maxNonces
    var foundNonce: UInt64?
    defer { manager?.stopCapture() }

    repeat {
        let remaining = nonceLimit ?? UInt64(request.batchSize)
        let available = (maximumSafeInteger - currentNonce) / request.stride + 1
        let count = UInt32(min(UInt64(request.batchSize), min(remaining, available)))
        guard count > 0 else {
            if nonceLimit != nil && nonceLimit! == 0 { break }
            throw HelperError.nonceRangeExhausted
        }
        winnerBuffer.contents().storeBytes(of: UInt32.max, as: UInt32.self)

        guard let commandBuffer = queue.makeCommandBuffer(),
              let encoder = commandBuffer.makeComputeCommandEncoder() else {
            throw HelperError.gpuFailed
        }
        encoder.setComputePipelineState(pipeline)
        encoder.setBuffer(prefixBuffer, offset: 0, index: 0)
        encoder.setBuffer(suffixBuffer, offset: 0, index: 1)
        encoder.setBuffer(winnerBuffer, offset: 0, index: 2)
        var prefixLength = UInt32(prefix.count)
        var suffixLength = UInt32(suffix.count)
        var startValue = currentNonce
        var strideValue = request.stride
        var batchCount = count
        var difficulty = request.difficulty
        encoder.setBytes(&prefixLength, length: MemoryLayout<UInt32>.stride, index: 3)
        encoder.setBytes(&suffixLength, length: MemoryLayout<UInt32>.stride, index: 4)
        encoder.setBytes(&startValue, length: MemoryLayout<UInt64>.stride, index: 5)
        encoder.setBytes(&strideValue, length: MemoryLayout<UInt64>.stride, index: 6)
        encoder.setBytes(&batchCount, length: MemoryLayout<UInt32>.stride, index: 7)
        encoder.setBytes(&difficulty, length: MemoryLayout<UInt32>.stride, index: 8)

        let width = min(max(pipeline.threadExecutionWidth, pipeline.threadExecutionWidth * 4),
                        pipeline.maxTotalThreadsPerThreadgroup)
        let groupSize = max(width, 1)
        let groupCount = (Int(count) + groupSize - 1) / groupSize
        encoder.dispatchThreadgroups(MTLSize(width: groupCount, height: 1, depth: 1),
                                     threadsPerThreadgroup: MTLSize(width: groupSize, height: 1, depth: 1))
        encoder.endEncoding()
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        guard commandBuffer.status == .completed else { throw HelperError.gpuFailed }

        let winningOffset = winnerBuffer.contents().load(as: UInt32.self)
        if winningOffset != UInt32.max {
            let offset = UInt64(winningOffset)
            guard offset <= (maximumSafeInteger - currentNonce) / request.stride else {
                throw HelperError.nonceRangeExhausted
            }
            foundNonce = currentNonce + offset * request.stride
            // Every launched thread hashes one nonce; report the full dispatched batch.
            attempts += UInt64(count)
            break
        }

        attempts += UInt64(count)
        if let limit = nonceLimit {
            nonceLimit = limit - UInt64(count)
            if nonceLimit == 0 { break }
        }
        if UInt64(count) == available {
            throw HelperError.nonceRangeExhausted
        }
        currentNonce += UInt64(count) * request.stride
    } while true

    return Result(nonce: foundNonce, attempts: attempts,
                  elapsedMs: (ProcessInfo.processInfo.systemUptime - start) * 1000,
                  device: device.name, capturePath: request.capturePath)
}

@main
private struct MetalPoW {
    static func main() {
        do {
            guard CommandLine.arguments.count == 2 else { throw HelperError.invalidRequest }
            let request = try readRequest()
            let result = try run(request, kernelURL: URL(fileURLWithPath: CommandLine.arguments[1]))
            let output = try JSONEncoder().encode(result)
            FileHandle.standardOutput.write(output)
            FileHandle.standardOutput.write(Data([0x0a]))
        } catch let error as HelperError {
            let message: String
            switch error {
            case .invalidRequest: message = "invalid request"
            case .oversizedRequest: message = "request exceeds native helper limits"
            case .nonceRangeExhausted: message = "nonce range exhausted"
            case .gpuUnavailable: message = "Metal GPU is unavailable"
            case .captureDisabled: message = "GPU capture requires MTL_CAPTURE_ENABLED=1"
            case .captureUnsupported: message = "Metal GPU trace capture is unavailable"
            case .gpuFailed: message = "Metal command execution failed"
            case .kernelFailed: message = "Metal kernel could not be loaded"
            }
            FileHandle.standardError.write(Data("metal-pow: \(message)\n".utf8))
            exit(1)
        } catch {
            FileHandle.standardError.write(Data("metal-pow: helper failed\n".utf8))
            exit(1)
        }
    }
}
