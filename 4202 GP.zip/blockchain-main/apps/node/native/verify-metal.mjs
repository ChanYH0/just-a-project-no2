// Independently compare Apple GPU SHA-256 PoW answers with Node's CPU SHA-256.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";

const nativeDir = new URL("./", import.meta.url);
const executable = fileURLToPath(new URL("./build/metal-pow", nativeDir));
const kernel = fileURLToPath(new URL("./pow.metal", nativeDir));

function digest(prefix, nonce, suffix) {
  return createHash("sha256").update(prefix).update(String(nonce), "ascii").update(suffix).digest("hex");
}

function invoke(request, env = process.env) {
  return spawnSync(executable, [kernel], {
    input: `${JSON.stringify(request)}\n`,
    encoding: "utf8",
    env,
    maxBuffer: 1024 * 1024,
  });
}

for (const boundary of [10, 100, 1000, 10_000, 100_000, 1_000_000]) {
  let prefix;
  let suffix;
  let salt;
  for (salt = 0; salt < 1024; salt += 1) {
    prefix = Buffer.from(`canonical-prefix boundary-${boundary} salt-${salt} 🚀 `, "utf8");
    suffix = Buffer.from(`: ends-at-${boundary} café 漢字 ${"🚀λ".repeat(100)}`, "utf8");
    if (!digest(prefix, boundary - 1, suffix).startsWith("0") && digest(prefix, boundary, suffix).startsWith("0")) break;
  }
  assert.ok(salt < 1024, `could not find a CPU vector for nonce boundary ${boundary}`);
  const testCase = { label: `decimal boundary ${boundary}`, startNonce: boundary - 1, stride: 1 };
  const difficulty = 1;
  const expected = { nonce: boundary, offset: 1 };
  const checkedCount = 2;
  const child = invoke({
    prefix: prefix.toString("base64"),
    suffix: suffix.toString("base64"),
    difficulty,
    startNonce: testCase.startNonce,
    stride: testCase.stride,
    batchSize: 2,
    maxNonces: checkedCount,
  });
  assert.equal(child.status, 0, `${testCase.label}: GPU helper failed: ${child.stderr.trim()}`);
  const response = JSON.parse(child.stdout);
  assert.equal(response.nonce, expected.nonce, `${testCase.label}: GPU nonce differed from CPU`);
  assert.equal(response.attempts, 2, `${testCase.label}: dispatched hash count differed`);
  assert.match(response.device, /Apple/i, `${testCase.label}: unexpected GPU device`);
  if (process.env.EXPECTED_GPU_DEVICE !== undefined) {
    assert.equal(response.device, process.env.EXPECTED_GPU_DEVICE);
  }
  assert.equal(response.capturePath, undefined);
  assert.equal(digest(prefix, response.nonce, suffix), digest(prefix, expected.nonce, suffix));
  process.stdout.write(`${testCase.label}: nonce=${response.nonce} dispatched=${response.attempts} GPU=${response.device} elapsed_ms=${response.elapsedMs.toFixed(3)}\n`);
}

const captureDisabledEnv = { ...process.env };
delete captureDisabledEnv.MTL_CAPTURE_ENABLED;
const deniedCapture = invoke({
  prefix: "cA==", suffix: "cw==", difficulty: 1,
  startNonce: 0, stride: 1, batchSize: 1, maxNonces: 1,
  capturePath: "/tmp/metal-pow-disabled-test.gputrace",
}, captureDisabledEnv);
assert.notEqual(deniedCapture.status, 0);
assert.match(deniedCapture.stderr, /GPU capture requires MTL_CAPTURE_ENABLED=1/);
assert.equal(deniedCapture.stdout, "");

const impossible = invoke({
  prefix: "cHJlZml4", suffix: "c3VmZml4", difficulty: 64,
  startNonce: 0, stride: 1, batchSize: 16, maxNonces: 16,
});
assert.equal(impossible.status, 0, impossible.stderr);
assert.deepEqual(JSON.parse(impossible.stdout), {
  nonce: null,
  attempts: 16,
  elapsedMs: JSON.parse(impossible.stdout).elapsedMs,
  device: JSON.parse(impossible.stdout).device,
});
process.stdout.write("difficulty-64 bounded search: no false PoW result\ncapture gate: failed closed with MTL_CAPTURE_ENABLED unset\n");

const bounded = invoke({
  prefix: "cA==", suffix: "cw==", difficulty: 64,
  startNonce: Number.MAX_SAFE_INTEGER, stride: 1, batchSize: 1, maxNonces: 2,
});
assert.notEqual(bounded.status, 0);
assert.match(bounded.stderr, /nonce range exhausted/);
assert.equal(bounded.stdout, "");

const malformed = invoke({
  prefix: "cA==", suffix: "cw==", difficulty: 1,
  startNonce: 0, stride: 1, batchSize: 1, maxNonces: 1,
  leakedPayload: "must not be echoed",
});
assert.notEqual(malformed.status, 0);
assert.match(malformed.stderr, /invalid request/);
assert.equal(malformed.stdout, "");
assert.ok(!malformed.stderr.includes("must not be echoed"));
process.stdout.write("safe nonce exhaustion: no overflow\nrequest parser: rejects unknown fields without echoing input\n");
