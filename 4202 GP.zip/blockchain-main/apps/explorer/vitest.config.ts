import { defineConfig } from "vitest/config";

// Pure logic and IndexedDB (fake-indexeddb) run in plain node; no DOM environment.
export default defineConfig({
  test: {
    environment: "node",
    include: ["test/**/*.test.ts"],
  },
});
