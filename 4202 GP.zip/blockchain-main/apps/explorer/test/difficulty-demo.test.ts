// Pure helpers for the isolated difficulty demo page: input bounds and chart geometry.

import { describe, expect, it } from "vitest";
import { layoutDifficulty, parseSimulationInput } from "../src/difficultyDemo";

describe("parseSimulationInput", () => {
  it("accepts the bounds exactly", () => {
    expect(parseSimulationInput("1", "0")).toEqual({ ok: true, value: { count: 1, intervalMs: 0 } });
    expect(parseSimulationInput("30", "120000")).toEqual({ ok: true, value: { count: 30, intervalMs: 120000 } });
  });

  it("rejects counts and intervals outside the range", () => {
    expect(parseSimulationInput("0", "0")).toMatchObject({ ok: false });
    expect(parseSimulationInput("31", "0")).toMatchObject({ ok: false });
    expect(parseSimulationInput("5", "-1")).toMatchObject({ ok: false });
    expect(parseSimulationInput("5", "120001")).toMatchObject({ ok: false });
  });

  it("rejects non-integers and scientific notation", () => {
    expect(parseSimulationInput("1.5", "0")).toMatchObject({ ok: false });
    expect(parseSimulationInput("1e1", "0")).toMatchObject({ ok: false });
    expect(parseSimulationInput("", "0")).toMatchObject({ ok: false });
    expect(parseSimulationInput("5", "abc")).toMatchObject({ ok: false });
  });
});

describe("layoutDifficulty", () => {
  it("returns no points for an empty series", () => {
    expect(layoutDifficulty([], 100, 50, 5)).toEqual({ points: [], polyline: "", minDifficulty: 0, maxDifficulty: 0 });
  });

  it("maps the lowest difficulty to the bottom and the highest to the top", () => {
    const geometry = layoutDifficulty(
      [
        { index: 0, difficulty: 1 },
        { index: 1, difficulty: 2 },
        { index: 2, difficulty: 3 },
      ],
      100,
      100,
      10,
    );
    expect(geometry.points.map((point) => point.x)).toEqual([10, 50, 90]);
    expect(geometry.points.map((point) => point.y)).toEqual([90, 50, 10]);
    expect(geometry.polyline).toBe("10.0,90.0 50.0,50.0 90.0,10.0");
    expect(geometry.minDifficulty).toBe(1);
    expect(geometry.maxDifficulty).toBe(3);
  });

  it("draws a flat series at mid height", () => {
    const geometry = layoutDifficulty(
      [
        { index: 0, difficulty: 4 },
        { index: 1, difficulty: 4 },
      ],
      100,
      60,
      10,
    );
    expect(geometry.points.map((point) => point.y)).toEqual([30, 30]);
  });
});
