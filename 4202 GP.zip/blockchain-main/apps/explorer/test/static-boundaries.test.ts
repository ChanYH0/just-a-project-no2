// Static checks over apps/explorer/src (SPEC sections 3, 13, 14.4 test 16).
// The explorer may import only the browser-safe shared entry; no node built-ins; no unsafe HTML sinks; no `any`.

import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const EXPLORER_ROOT = fileURLToPath(new URL("..", import.meta.url));
const SRC_DIR = join(EXPLORER_ROOT, "src");
const SOURCE_EXTENSIONS = [".ts", ".tsx"];

function listSourceFiles(dir: string): string[] {
  const files: string[] = [];
  for (const entry of readdirSync(dir)) {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) {
      files.push(...listSourceFiles(path));
    } else if (SOURCE_EXTENSIONS.some((extension) => path.endsWith(extension))) {
      files.push(path);
    }
  }
  return files;
}

const IMPORT_PATTERN = /(?:\bfrom\s+|\bimport\s+|\bimport\(\s*)["']([^"']+)["']/g;

function importSpecifiers(source: string): string[] {
  return [...source.matchAll(IMPORT_PATTERN)].map((match) => match[1] ?? "");
}

const files = listSourceFiles(SRC_DIR).map((path) => ({
  path,
  relative: path.slice(EXPLORER_ROOT.length),
  source: readFileSync(path, "utf8"),
}));

describe("explorer source boundaries", () => {
  it("finds the explorer source files", () => {
    expect(files.length).toBeGreaterThan(10);
  });

  it("imports from @conference-chain/shared only through the browser entry", () => {
    const offenders: string[] = [];
    for (const file of files) {
      for (const specifier of importSpecifiers(file.source)) {
        if (specifier.startsWith("@conference-chain/shared") && specifier !== "@conference-chain/shared/browser") {
          offenders.push(`${file.relative}: ${specifier}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it("does not import shared internals (node entry, block, chain, crypto-node) by any path", () => {
    const forbidden = /(crypto-node|\/block(\.js)?$|\/chain(\.js)?$|\/node(\.js)?$|packages\/shared|shared\/src)/;
    const offenders: string[] = [];
    for (const file of files) {
      for (const specifier of importSpecifiers(file.source)) {
        if (forbidden.test(specifier)) {
          offenders.push(`${file.relative}: ${specifier}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it("imports no node built-ins and no undeclared zod", () => {
    const offenders: string[] = [];
    for (const file of files) {
      for (const specifier of importSpecifiers(file.source)) {
        if (specifier.startsWith("node:") || specifier === "zod" || specifier === "crypto" || specifier === "fs") {
          offenders.push(`${file.relative}: ${specifier}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it("contains no dangerouslySetInnerHTML or other raw HTML sink", () => {
    const sinks = ["dangerouslySetInnerHTML", "innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval("];
    const offenders: string[] = [];
    for (const file of files) {
      for (const sink of sinks) {
        if (file.source.includes(sink)) {
          offenders.push(`${file.relative}: ${sink}`);
        }
      }
    }
    expect(offenders).toEqual([]);
  });

  it("uses no `any` type annotation or assertion", () => {
    const anyType = /:\s*any\b|<any>|\bas\s+any\b|\bany\[\]/;
    const offenders = files.filter((file) => anyType.test(file.source)).map((file) => file.relative);
    expect(offenders).toEqual([]);
  });

  it("index.html sets a strict Content-Security-Policy without unsafe directives", () => {
    const html = readFileSync(join(EXPLORER_ROOT, "index.html"), "utf8");
    expect(html).toContain('http-equiv="Content-Security-Policy"');
    expect(html).toContain("script-src 'self'");
    expect(html).toContain("default-src 'none'");
    expect(html).not.toContain("unsafe-inline");
    expect(html).not.toContain("unsafe-eval");
  });
});
