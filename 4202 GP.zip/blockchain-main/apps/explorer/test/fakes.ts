// Test doubles for the explorer api. Every method rejects unless a test overrides it,
// so an unexpected call fails the test instead of passing silently.

import { deriveChainId, getProfile, nodeHash } from "@conference-chain/shared/node";
import type { ExplorerApi } from "../src/api";

export const CONFERENCE_ID = "conf-test-2026";
export const CHAIN_ID = deriveChainId(getProfile("test", CONFERENCE_ID), nodeHash);
export const NOW = Date.UTC(2026, 0, 1);
export const RECORD_ID = "c".repeat(64);

export function fakeApi(overrides: Partial<ExplorerApi>): ExplorerApi {
  const unexpected = (name: string) => (): Promise<never> => Promise.reject(new Error(`unexpected api call: ${name}`));
  return {
    getChainInfo: unexpected("getChainInfo"),
    getHealth: unexpected("getHealth"),
    getBlocks: unexpected("getBlocks"),
    getBlock: unexpected("getBlock"),
    getMempool: unexpected("getMempool"),
    getSessions: unexpected("getSessions"),
    getAttendee: unexpected("getAttendee"),
    getAttendeeSessions: unexpected("getAttendeeSessions"),
    getSessionAttendees: unexpected("getSessionAttendees"),
    postRegistration: unexpected("postRegistration"),
    postAttendance: unexpected("postAttendance"),
    getRecord: unexpected("getRecord"),
    getChainValidate: unexpected("getChainValidate"),
    postTamperCheck: unexpected("postTamperCheck"),
    postDifficultySimulation: unexpected("postDifficultySimulation"),
    probeDemoRoutes: unexpected("probeDemoRoutes"),
    ...overrides,
  };
}

export function chainInfo(): Promise<{
  chainId: string;
  conferenceId: string;
  profile: string;
  protocol: string;
  demoRoutesEnabled: boolean;
}> {
  return Promise.resolve({
    chainId: CHAIN_ID,
    conferenceId: CONFERENCE_ID,
    profile: "test",
    protocol: "conference-chain/1",
    demoRoutesEnabled: false,
  });
}

export function must<T>(value: T | null | undefined, label: string): T {
  if (value === undefined || value === null) {
    throw new Error(`expected ${label} to be defined`);
  }
  return value;
}

export function bytesOf(base64: string): Uint8Array {
  return new Uint8Array(Buffer.from(base64, "base64"));
}
