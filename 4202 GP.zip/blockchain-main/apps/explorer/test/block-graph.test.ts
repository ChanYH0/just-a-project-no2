import { describe, expect, it } from "vitest";
import { blockLinks, findBlockPosition, sortAscending, type GraphBlock } from "../src/blockGraph";

const chain: GraphBlock[] = [
  { index: 0, hash: "aa", previousHash: "00" },
  { index: 1, hash: "bb", previousHash: "aa" },
  { index: 2, hash: "cc", previousHash: "bb" },
  { index: 3, hash: "dd", previousHash: "cc" },
];

describe("blockLinks", () => {
  it("links each block to its previousHash parent and marks genesis", () => {
    expect(blockLinks(chain, 0, 4)).toEqual([
      { child: 0, parent: undefined, state: "genesis" },
      { child: 1, parent: 0, state: "linked" },
      { child: 2, parent: 1, state: "linked" },
      { child: 3, parent: 2, state: "linked" },
    ]);
  });

  it("reports a tampered previousHash between adjacent blocks as a mismatch", () => {
    const broken = chain.map((block) => (block.index === 2 ? { ...block, previousHash: "zz" } : block));
    expect(blockLinks(broken, 2, 3)).toEqual([{ child: 2, parent: undefined, state: "mismatch" }]);
  });

  it("reports a parent that is not in the fetched list as outside view", () => {
    const tail = chain.slice(2);
    expect(blockLinks(tail, 0, 1)).toEqual([{ child: 0, parent: undefined, state: "outside" }]);
  });

  it("clamps the window to the list", () => {
    expect(blockLinks(chain, 3, 99)).toHaveLength(1);
    expect(blockLinks([], 0, 12)).toEqual([]);
  });
});

describe("sortAscending / findBlockPosition", () => {
  it("sorts oldest first without mutating the input", () => {
    const newestFirst = [...chain].reverse();
    expect(sortAscending(newestFirst).map((block) => block.index)).toEqual([0, 1, 2, 3]);
    expect(newestFirst[0]?.index).toBe(3);
  });

  it("finds by index, #index or hash prefix, case-insensitively", () => {
    expect(findBlockPosition(chain, "2")).toBe(2);
    expect(findBlockPosition(chain, "#3")).toBe(3);
    expect(findBlockPosition(chain, "BB")).toBe(1);
    expect(findBlockPosition(chain, "nope")).toBeUndefined();
    expect(findBlockPosition(chain, "  ")).toBeUndefined();
  });
});
