import { describe, expect, it } from "vitest";
import { LIVE_CHART_WINDOW, shapeDifficultySeries } from "../src/difficultySeries";

const block = (index: number, difficulty = 2, timestamp = index * 1000) => ({ index, difficulty, timestamp });

describe("shapeDifficultySeries", () => {
  it("handles an empty chain", () => {
    expect(shapeDifficultySeries([])).toEqual({ points: [], truncated: false });
  });

  it("handles genesis only", () => {
    expect(shapeDifficultySeries([block(0)])).toEqual({
      points: [{ index: 0, difficulty: 2, intervalMs: null, adjusted: false }],
      truncated: false,
    });
  });

  it("sorts newest-first input oldest-first and computes intervals", () => {
    const result = shapeDifficultySeries([block(2, 2, 5000), block(1, 2, 1500), block(0, 2, 0)]);
    expect(result.points.map((p) => p.index)).toEqual([0, 1, 2]);
    expect(result.points.map((p) => p.intervalMs)).toEqual([null, 1500, 3500]);
  });

  it("flags adjustment boundaries where difficulty changes", () => {
    const result = shapeDifficultySeries([block(0, 2), block(1, 2), block(2, 2), block(3, 3), block(4, 3), block(5, 2)]);
    expect(result.points.map((p) => p.adjusted)).toEqual([false, false, false, true, false, true]);
  });

  it("truncates to the most recent window", () => {
    const blocks = Array.from({ length: 120 }, (_, i) => block(i));
    const result = shapeDifficultySeries(blocks);
    expect(result.truncated).toBe(true);
    expect(result.points).toHaveLength(LIVE_CHART_WINDOW);
    expect(result.points[0]?.index).toBe(120 - LIVE_CHART_WINDOW);
    expect(result.points[0]?.intervalMs).toBeNull();
    expect(result.points.at(-1)?.index).toBe(119);
  });

  it("does not mark truncated at exactly the window size", () => {
    const blocks = Array.from({ length: 5 }, (_, i) => block(i));
    expect(shapeDifficultySeries(blocks, 5).truncated).toBe(false);
    expect(shapeDifficultySeries(blocks, 3).points.map((p) => p.index)).toEqual([2, 3, 4]);
  });

  it("does not mutate its input", () => {
    const blocks = [block(1), block(0)];
    shapeDifficultySeries(blocks);
    expect(blocks.map((b) => b.index)).toEqual([1, 0]);
  });
});
