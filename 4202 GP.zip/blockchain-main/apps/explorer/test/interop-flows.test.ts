// SPEC section 14.4, test 16: browser-signed payloads verify with the node adapter, node-signed payloads
// verify in the browser adapter, and the IndexedDB wallet survives a reload with a non-extractable key.
// nodeIdentityCrypto is imported here in the TEST only; the explorer source never imports the node entry.

import { IDBFactory } from "fake-indexeddb";
import { describe, expect, it } from "vitest";
import {
  AttendancePayload,
  browserIdentityCrypto,
  canonicalize,
  deriveAttendeeId,
  signPayload,
  validatePublicKey,
  verifyPayload,
  type SignedAttendance,
  type SignedRegistration,
} from "@conference-chain/shared/browser";
import { nodeIdentityCrypto } from "@conference-chain/shared/node";
import { checkIn, FlowError, pollRecord, registerIdentity, type FlowDeps } from "../src/flows";
import { createIndexedDbWalletStore } from "../src/wallet";
import { CHAIN_ID, NOW, RECORD_ID, chainInfo, bytesOf, fakeApi, must } from "./fakes";

const encoder = new TextEncoder();

// Writes a raw value into the wallet store, bypassing the validating store API (used to test load-side checks).
async function writeRawWalletValue(factory: IDBFactory, value: unknown): Promise<void> {
  const db = await new Promise<IDBDatabase>((resolve, reject) => {
    const request = factory.open("wallet", 1);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("raw open failed"));
  });
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction("keys", "readwrite");
      transaction.objectStore("keys").put(value, "current");
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(new Error("raw write failed"));
    });
  } finally {
    db.close();
  }
}

function depsFor(
  factory: IDBFactory,
  overrides: Partial<FlowDeps["api"]>,
): { deps: FlowDeps; registrations: SignedRegistration[]; attendances: SignedAttendance[] } {
  const registrations: SignedRegistration[] = [];
  const attendances: SignedAttendance[] = [];
  const api = fakeApi({
    getChainInfo: chainInfo,
    postRegistration: (signed) => {
      registrations.push(signed);
      return Promise.resolve({ recordId: RECORD_ID });
    },
    postAttendance: (signed) => {
      attendances.push(signed);
      return Promise.resolve({ recordId: RECORD_ID });
    },
    ...overrides,
  });
  return {
    deps: { api, identity: browserIdentityCrypto, wallet: createIndexedDbWalletStore(factory), now: () => NOW },
    registrations,
    attendances,
  };
}

describe("test 16: browser flows interoperate with the node identity adapter", () => {
  it("registration bytes are canonical(payload) and verify with nodeIdentityCrypto", async () => {
    const { deps, registrations } = depsFor(new IDBFactory(), {});

    const result = await registerIdentity(deps, { alias: "Pseudonym 01", replaceExisting: false });

    const signed = must(registrations[0], "registration");
    const { payload, signature } = signed;
    expect(payload.chainId).toBe(CHAIN_ID);
    expect(payload.timestamp).toBe(NOW);
    expect(result.recordId).toBe(RECORD_ID);
    expect(result.attendeeId).toBe(payload.attendeeId);

    const signedBytes = encoder.encode(canonicalize(payload));
    expect(await nodeIdentityCrypto.verify(signedBytes, signature, payload.publicKey)).toBe(true);
    expect(await verifyPayload(payload, signature, payload.publicKey, nodeIdentityCrypto)).toBe(true);
    expect(await validatePublicKey(payload.publicKey, nodeIdentityCrypto)).toBe(true);

    const digest = await nodeIdentityCrypto.sha256Hex(bytesOf(payload.publicKey));
    expect(payload.attendeeId).toBe(digest);
  });

  it("attendance bytes verify with the registered key under nodeIdentityCrypto", async () => {
    const factory = new IDBFactory();
    const { deps, attendances } = depsFor(factory, {});
    await registerIdentity(deps, { alias: "Pseudonym 02", replaceExisting: false });
    const wallet = must(await deps.wallet.load(), "wallet record");

    const result = await checkIn(deps, "keynote");

    expect(result.recordId).toBe(RECORD_ID);
    const signed = must(attendances[0], "attendance");
    expect(signed.payload.attendeeId).toBe(wallet.attendeeId);
    expect(signed.payload.sessionId).toBe("keynote");
    expect(AttendancePayload.safeParse(signed.payload).success).toBe(true);
    expect(await verifyPayload(signed.payload, signed.signature, wallet.publicKey, nodeIdentityCrypto)).toBe(true);
    // A different session must not verify with the same signature (replay protection).
    const replayed = { ...signed.payload, sessionId: "workshop" };
    expect(await verifyPayload(replayed, signed.signature, wallet.publicKey, nodeIdentityCrypto)).toBe(false);
  });

  it("node-signed payloads and node public keys verify in the browser adapter", async () => {
    const pair = await nodeIdentityCrypto.generateKeyPair();
    const attendeeId = await deriveAttendeeId(pair.publicKey, nodeIdentityCrypto);
    const payload = AttendancePayload.parse({
      type: "attend",
      chainId: CHAIN_ID,
      attendeeId,
      sessionId: "keynote",
      timestamp: NOW,
    });
    const signature = await signPayload(payload, pair.privateKey, nodeIdentityCrypto);

    expect(await verifyPayload(payload, signature, pair.publicKey, browserIdentityCrypto)).toBe(true);
    expect(await validatePublicKey(pair.publicKey, browserIdentityCrypto)).toBe(true);
    expect(await deriveAttendeeId(pair.publicKey, browserIdentityCrypto)).toBe(attendeeId);
  });

  it("the wallet survives a reload and the stored private key cannot be exported", async () => {
    const factory = new IDBFactory();
    const { deps } = depsFor(factory, {});
    await registerIdentity(deps, { alias: "Pseudonym 03", replaceExisting: false });
    const saved = must(await deps.wallet.load(), "wallet record");

    // A reload is a new store over the same database.
    const reopened = createIndexedDbWalletStore(factory);
    const loaded = must(await reopened.load(), "reloaded wallet record");

    expect(loaded.attendeeId).toBe(saved.attendeeId);
    expect(loaded.publicKey).toBe(saved.publicKey);
    expect(loaded.alias).toBe("Pseudonym 03");
    expect(loaded.privateKey.type).toBe("private");
    expect(loaded.privateKey.extractable).toBe(false);
    await expect(globalThis.crypto.subtle.exportKey("pkcs8", loaded.privateKey)).rejects.toThrow();

    // Use is still possible: the reloaded key signs bytes that the node adapter verifies.
    const message = encoder.encode("reload check");
    const signature = await browserIdentityCrypto.sign(message, loaded.privateKey);
    expect(await nodeIdentityCrypto.verify(message, signature, loaded.publicKey)).toBe(true);
  });
});

describe("flow guards", () => {
  it("refuses to replace an existing wallet unless the caller confirmed replacement", async () => {
    const factory = new IDBFactory();
    const first = depsFor(factory, {});
    await registerIdentity(first.deps, { alias: "First", replaceExisting: false });
    const before = must(await first.deps.wallet.load(), "wallet record");

    const second = depsFor(factory, {});
    await expect(registerIdentity(second.deps, { alias: "Second", replaceExisting: false })).rejects.toMatchObject({
      code: "WALLET_EXISTS",
    });
    expect(second.registrations).toHaveLength(0);
    const unchanged = must(await second.deps.wallet.load(), "wallet record");
    expect(unchanged.attendeeId).toBe(before.attendeeId);

    await registerIdentity(second.deps, { alias: "Second", replaceExisting: true });
    const replaced = must(await second.deps.wallet.load(), "wallet record");
    expect(replaced.attendeeId).not.toBe(before.attendeeId);
    expect(replaced.alias).toBe("Second");
  });

  it("rejects an invalid alias before any network call", async () => {
    const { deps, registrations } = depsFor(new IDBFactory(), {
      getChainInfo: () => Promise.reject(new Error("must not be called")),
    });
    // U+202E is a bidi override; Alias must reject it (SPEC section 5.1).
    await expect(registerIdentity(deps, { alias: "name\u202Egnp", replaceExisting: false })).rejects.toBeInstanceOf(
      FlowError,
    );
    await expect(registerIdentity(deps, { alias: "x".repeat(51), replaceExisting: false })).rejects.toMatchObject({
      code: "INVALID_INPUT",
    });
    expect(registrations).toHaveLength(0);
  });

  it("checkIn without a wallet fails with NO_WALLET", async () => {
    const { deps, attendances } = depsFor(new IDBFactory(), {});
    await expect(checkIn(deps, "keynote")).rejects.toMatchObject({ code: "NO_WALLET" });
    expect(attendances).toHaveLength(0);
  });

  it("save refuses a malformed record and leaves the stored record unchanged", async () => {
    const factory = new IDBFactory();
    const store = createIndexedDbWalletStore(factory);
    await registerIdentity(depsFor(factory, {}).deps, { alias: "Stored", replaceExisting: false });
    const stored = must(await store.load(), "wallet record");

    await expect(store.save({ ...stored, alias: "bad\u202Ealias" })).rejects.toThrow("wallet record is malformed");
    expect(await store.load()).toEqual(stored);
  });

  it("load fails loudly on a stored record that does not validate", async () => {
    const factory = new IDBFactory();
    const store = createIndexedDbWalletStore(factory);
    await store.load(); // creates the database and object store
    await writeRawWalletValue(factory, { attendeeId: "not-hex", publicKey: "AAAA", alias: "x" });

    await expect(store.load()).rejects.toThrow("wallet record is malformed");
  });
});

describe("pollRecord", () => {
  it("returns the first non-pending status and sleeps between attempts", async () => {
    const statuses = [{ status: "pending" as const }, { status: "pending" as const }, { status: "confirmed" as const, blockIndex: 4 }];
    const sleeps: number[] = [];
    const api = fakeApi({
      getRecord: () => Promise.resolve(must(statuses.shift(), "status")),
    });

    const result = await pollRecord(api, RECORD_ID, {
      attempts: 5,
      delayMs: 10,
      sleep: (ms) => {
        sleeps.push(ms);
        return Promise.resolve();
      },
    });

    expect(result).toEqual({ status: "confirmed", blockIndex: 4 });
    expect(sleeps).toEqual([10, 10]);
  });

  it("returns the last pending status when attempts run out", async () => {
    const api = fakeApi({ getRecord: () => Promise.resolve({ status: "pending" }) });
    const result = await pollRecord(api, RECORD_ID, { attempts: 2, delayMs: 0, sleep: () => Promise.resolve() });
    expect(result).toEqual({ status: "pending" });
  });
});
