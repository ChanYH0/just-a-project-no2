// Typed api wrapper: error body parsing, response shape checks, and client-side input checks.

import { makeGenesis, nodeHash } from "@conference-chain/shared/node";
import { getProfile } from "@conference-chain/shared/browser";
import { describe, expect, it } from "vitest";
import { ApiError, createApi, type FetchLike } from "../src/api";
import { CHAIN_ID, CONFERENCE_ID, RECORD_ID } from "./fakes";

function fetchReturning(status: number, body: string, calls: string[] = []): FetchLike {
  return (input) => {
    calls.push(input);
    return Promise.resolve(new Response(body, { status, headers: { "content-type": "application/json" } }));
  };
}

async function rejectionOf(promise: Promise<unknown>): Promise<unknown> {
  try {
    await promise;
  } catch (error) {
    return error;
  }
  throw new Error("expected the promise to reject");
}

describe("api wrapper", () => {
  it.each([
    ["session id", [{ id: "bad id", title: "Session" }], (api: ReturnType<typeof createApi>) => api.getSessions()],
    ["extra session field", [{ id: "s1", title: "Session", email: "unexpected" }], (api: ReturnType<typeof createApi>) => api.getSessions()],
    ["attendee id", { attendeeId: "x", sessions: [] }, (api: ReturnType<typeof createApi>) => api.getAttendeeSessions(CHAIN_ID)],
    ["query timestamp", { attendeeId: CHAIN_ID, sessions: [{ sessionId: "s1", timestamp: 0, blockIndex: 1 }] }, (api: ReturnType<typeof createApi>) => api.getAttendeeSessions(CHAIN_ID)],
    ["alias", { sessionId: "s1", attendees: [{ attendeeId: CHAIN_ID, alias: "a\u202eb", timestamp: 1, blockIndex: 1 }] }, (api: ReturnType<typeof createApi>) => api.getSessionAttendees("s1")],
    ["simulation hash", { valid: true, blocks: [{ index: 0, hash: "x", difficulty: 1, timestamp: 1 }], adjustments: [] }, (api: ReturnType<typeof createApi>) => api.postDifficultySimulation({ count: 1, intervalMs: 0 })],
    ["simulation difficulty", { valid: true, blocks: [{ index: 0, hash: CHAIN_ID, difficulty: 0, timestamp: 1 }], adjustments: [] }, (api: ReturnType<typeof createApi>) => api.postDifficultySimulation({ count: 1, intervalMs: 0 })],
    ["chain id", { chainId: "x", conferenceId: CONFERENCE_ID, profile: "test", protocol: "conference-chain/1" }, (api: ReturnType<typeof createApi>) => api.getChainInfo()],
    ["confirmed status", { status: "confirmed" }, (api: ReturnType<typeof createApi>) => api.getRecord(RECORD_ID)],
    ["pending error", { status: "pending", code: "BAD_POW" }, (api: ReturnType<typeof createApi>) => api.getRecord(RECORD_ID)],
    ["rejected code", { status: "rejected", code: "bogus" }, (api: ReturnType<typeof createApi>) => api.getRecord(RECORD_ID)],
    ["contradictory verdict", { ok: true, code: "BAD_POW" }, (api: ReturnType<typeof createApi>) => api.getChainValidate()],
    ["missing verdict code", { ok: false }, (api: ReturnType<typeof createApi>) => api.getChainValidate()],
    ["unsafe cursor", { blocks: [], nextCursor: "9007199254740992" }, (api: ReturnType<typeof createApi>) => api.getBlocks({ limit: 1 })],
    ["health profile", { ok: true, miner: "idle", headIndex: 0, profile: "bogus" }, (api: ReturnType<typeof createApi>) => api.getHealth()],
    ["miner state", { ok: true, miner: "bogus", headIndex: 0, profile: "demo" }, (api: ReturnType<typeof createApi>) => api.getHealth()],
    ["fatal health", { ok: true, miner: "fatal", headIndex: 0, profile: "demo" }, (api: ReturnType<typeof createApi>) => api.getHealth()],
    ["idle health", { ok: false, miner: "idle", headIndex: 0, profile: "demo" }, (api: ReturnType<typeof createApi>) => api.getHealth()],
  ] as const)("rejects malformed %s in a successful response", async (_label, body, call) => {
    const api = createApi(fetchReturning(200, JSON.stringify(body)));
    await expect(call(api)).rejects.toMatchObject({ code: "INVALID_RESPONSE" });
  });

  it("rejects an invalid record id returned after submission", async () => {
    const api = createApi(fetchReturning(200, JSON.stringify({ recordId: "x" })));
    // The parser must reject the response regardless of which signed payload was submitted.
    const { signedRegistration, makeKeys, BASE_TIME } = await import("../../../packages/shared/test/helpers");
    await expect(api.postRegistration(await signedRegistration(await makeKeys(), BASE_TIME)))
      .rejects.toMatchObject({ code: "INVALID_RESPONSE" });
  });

  it("calls same-origin /api paths and parses chain info", async () => {
    const calls: string[] = [];
    const body = JSON.stringify({
      chainId: CHAIN_ID,
      conferenceId: CONFERENCE_ID,
      profile: "test",
      protocol: "conference-chain/1",
    });
    const api = createApi(fetchReturning(200, body, calls));

    const info = await api.getChainInfo();

    expect(calls).toEqual(["/api/chain/info"]);
    expect(info).toEqual({
      chainId: CHAIN_ID,
      conferenceId: CONFERENCE_ID,
      profile: "test",
      protocol: "conference-chain/1",
      demoRoutesEnabled: false,
    });
  });

  it("parses the documented error body into code and message", async () => {
    const body = JSON.stringify({ error: { code: "DUPLICATE_ATTENDANCE", message: "already attended" } });
    const api = createApi(fetchReturning(409, body));

    const error = await rejectionOf(api.getRecord(RECORD_ID));
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 409, code: "DUPLICATE_ATTENDANCE", message: "already attended" });
  });

  it("maps a non-documented 404 body to HTTP_404 without echoing the body", async () => {
    const api = createApi(fetchReturning(404, "<html>secret-body</html>"));

    const error = await rejectionOf(api.getChainInfo());
    expect(error).toMatchObject({ status: 404, code: "HTTP_404" });
    expect(String(error)).not.toContain("secret-body");
  });

  it("reports a network failure as NETWORK_ERROR with status 0", async () => {
    const api = createApi(() => Promise.reject(new TypeError("fetch failed")));

    await expect(api.getHealth()).rejects.toMatchObject({ status: 0, code: "NETWORK_ERROR" });
  });

  it("rejects a 200 response whose shape does not match the contract", async () => {
    const api = createApi(fetchReturning(200, JSON.stringify({ chainId: 42 })));

    await expect(api.getChainInfo()).rejects.toMatchObject({ code: "INVALID_RESPONSE" });
  });

  it("validates a block view from the shared Block schema and keeps verification flags", async () => {
    const config = getProfile("test", CONFERENCE_ID);
    const genesis = makeGenesis(config, nodeHash);
    const body = JSON.stringify({ ...genesis, verification: { hashValid: true, powValid: true } });
    const api = createApi(fetchReturning(200, body));

    const block = await api.getBlock(0);
    expect(block.hash).toBe(genesis.hash);
    expect(block.verification).toEqual({ hashValid: true, powValid: true });
  });

  it("rejects a block response with an extra unknown field", async () => {
    const config = getProfile("test", CONFERENCE_ID);
    const genesis = makeGenesis(config, nodeHash);
    const body = JSON.stringify({ ...genesis, email: "x@example.com", verification: { hashValid: true, powValid: true } });
    const api = createApi(fetchReturning(200, body));

    await expect(api.getBlock(0)).rejects.toMatchObject({ code: "INVALID_RESPONSE" });
  });

  it("checks input before any request is made", async () => {
    const calls: string[] = [];
    const api = createApi(fetchReturning(200, "{}", calls));

    await expect(api.getBlock(-1)).rejects.toMatchObject({ code: "INVALID_INPUT" });
    await expect(api.getAttendee("not-hex")).rejects.toMatchObject({ code: "INVALID_INPUT" });
    await expect(api.getSessionAttendees("bad id!")).rejects.toMatchObject({ code: "INVALID_INPUT" });
    await expect(api.getRecord("zz")).rejects.toMatchObject({ code: "INVALID_INPUT" });
    expect(calls).toEqual([]);
  });

  it("accepts the block list as plain blocks without verification (SPEC GET /blocks)", async () => {
    const genesis = makeGenesis(getProfile("test", CONFERENCE_ID), nodeHash);
    const api = createApi(fetchReturning(200, JSON.stringify({ blocks: [genesis], nextCursor: null })));

    const page = await api.getBlocks({ limit: 20 });

    expect(page.blocks.map((block) => block.hash)).toEqual([genesis.hash]);
  });

  it("passes the blocks cursor through as a query parameter", async () => {
    const calls: string[] = [];
    const api = createApi(fetchReturning(200, JSON.stringify({ blocks: [], nextCursor: null }), calls));

    await api.getBlocks({ limit: 20, cursor: "7" });

    expect(calls).toEqual(["/api/blocks?limit=20&cursor=7"]);
  });

  it("probes demo routes: 404 means absent, any other status means present", async () => {
    const absent = createApi(fetchReturning(404, "{}"));
    const present = createApi(fetchReturning(400, JSON.stringify({ error: { code: "INVALID_SCHEMA", message: "bad" } })));

    await expect(absent.probeDemoRoutes()).resolves.toBe(false);
    await expect(present.probeDemoRoutes()).resolves.toBe(true);
  });

  it("shares the demo probe across concurrent callers and later navigation", async () => {
    const calls: string[] = [];
    const api = createApi(fetchReturning(400, "{}", calls));
    expect(await Promise.all([api.probeDemoRoutes(), api.probeDemoRoutes()])).toEqual([true, true]);
    await expect(api.probeDemoRoutes()).resolves.toBe(true);
    expect(calls).toEqual(["/api/demo/tamper-check"]);
  });

  it("retries demo discovery after a network failure", async () => {
    let attempts = 0;
    const api = createApi(() => {
      attempts += 1;
      return attempts === 1 ? Promise.reject(new TypeError("offline")) : Promise.resolve(new Response("{}", { status: 404 }));
    });
    await expect(api.probeDemoRoutes()).rejects.toMatchObject({ code: "NETWORK_ERROR" });
    await expect(api.probeDemoRoutes()).resolves.toBe(false);
    expect(attempts).toBe(2);
  });
});
