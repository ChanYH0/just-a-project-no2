// Light/dark preference. No stored value means "follow the system"; the toggle stores an explicit choice.
// The CSS keys off the data-theme attribute on <html>.

export type Theme = "light" | "dark";

const STORAGE_KEY = "explorer-theme";

function isTheme(value: unknown): value is Theme {
  return value === "light" || value === "dark";
}

function storedTheme(): Theme | null {
  try {
    const value = window.localStorage.getItem(STORAGE_KEY);
    return isTheme(value) ? value : null;
  } catch {
    // Storage can be blocked (private mode); the toggle still works for this page load.
    return null;
  }
}

export function systemTheme(): Theme {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function currentTheme(): Theme {
  const attribute = document.documentElement.dataset.theme;
  return isTheme(attribute) ? attribute : systemTheme();
}

export function applyStoredTheme(): void {
  const theme = storedTheme();
  if (theme !== null) document.documentElement.dataset.theme = theme;
}

export function setTheme(theme: Theme): void {
  document.documentElement.dataset.theme = theme;
  try {
    window.localStorage.setItem(STORAGE_KEY, theme);
  } catch {
    // Not persisted; see storedTheme.
  }
}
