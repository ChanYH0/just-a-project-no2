// UI session on top of the browser wallet. The wallet key is non-extractable and unrecoverable, so "log out" never
// deletes it: it only sets a local flag that hides identity-bound UI until the user signs in again.
// This is a UI gate, not access control: page scripts can still use the stored key (see the Register page notes).

import { useEffect } from "react";
import { IDENTITY_CHANGED_EVENT, notifyIdentityChanged } from "./identityEvents";
import { useAsync } from "./hooks";
import { defaultWallet } from "./services";
import type { WalletRecord } from "./wallet";

export const SIGNED_OUT_KEY = "chain-explorer:signed-out";

export type Role = "guest" | "attendee";

export interface Auth {
  loading: boolean;
  identity: WalletRecord | null; // the stored identity, even while logged out
  role: Role;
  signOut(): void;
  signIn(): void;
}

function readSignedOut(): boolean {
  return window.localStorage.getItem(SIGNED_OUT_KEY) === "1";
}

export function useAuth(): Auth {
  const wallet = useAsync(() => defaultWallet.load(), []);
  const { reload } = wallet;
  useEffect(() => {
    window.addEventListener(IDENTITY_CHANGED_EVENT, reload);
    return () => window.removeEventListener(IDENTITY_CHANGED_EVENT, reload);
  }, [reload]);

  const identity = wallet.state.status === "ready" ? wallet.state.value : null;
  return {
    loading: wallet.state.status === "loading",
    identity,
    role: identity !== null && !readSignedOut() ? "attendee" : "guest",
    signOut() {
      window.localStorage.setItem(SIGNED_OUT_KEY, "1");
      notifyIdentityChanged();
    },
    signIn() {
      window.localStorage.removeItem(SIGNED_OUT_KEY);
      notifyIdentityChanged();
    },
  };
}
