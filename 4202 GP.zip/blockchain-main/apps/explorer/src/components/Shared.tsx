import type { ChainRecord } from "@conference-chain/shared/browser";
import { ApiError, type RecordStatus } from "../api";
import { formatTime, shortId } from "../format";
import { Icon } from "./Icon";

// Plain-language sentences for known API error codes. The raw code stays visible as secondary text.
const ERROR_SENTENCES: ReadonlyMap<string, string> = new Map([
  ["RATE_LIMITED", "Too many requests; wait a minute and retry."],
  ["DUPLICATE_ATTENDANCE", "You already checked in to this session."],
  ["ATTENDEE_NOT_REGISTERED", "Your registration is not confirmed yet."],
  ["UNKNOWN_SESSION", "That session does not exist."],
  ["NETWORK_ERROR", "Node unreachable; try again."],
  ["MINER_UNAVAILABLE", "Node unreachable; try again."],
]);

export function describeRecordStatus(status: RecordStatus): string {
  const block = status.blockIndex !== undefined ? ` in block ${status.blockIndex}` : "";
  switch (status.status) {
    case "pending":
      return "waiting for confirmation";
    case "confirmed":
      return `confirmed${block}`;
    case "expired":
      return "not recorded (expired)";
    case "rejected":
      return "rejected by the node";
  }
}

// Raw status from the node, shown as secondary text next to the plain description.
export function rawRecordStatus(status: RecordStatus): string {
  return status.code !== undefined ? `${status.status} (${status.code})` : status.status;
}

export function RecordStatusText({ status }: { status: RecordStatus }) {
  return (
    <>
      {describeRecordStatus(status)} <small className="note">[{rawRecordStatus(status)}]</small>
    </>
  );
}

export interface ErrorView {
  message: string;
  // Raw code and HTTP status, shown as secondary text. Null when the message already carries them.
  detail: string | null;
}

export function describeError(error: unknown): ErrorView {
  if (error instanceof ApiError) {
    const sentence = ERROR_SENTENCES.get(error.code);
    if (sentence !== undefined) {
      return {
        message: sentence,
        detail: error.status === 0 ? error.code : `${error.code} (HTTP ${error.status})`,
      };
    }
    return {
      message: error.status === 0 ? `${error.code}: ${error.message}` : `${error.code} (HTTP ${error.status}): ${error.message}`,
      detail: null,
    };
  }
  if (error instanceof Error) {
    return { message: error.message, detail: null };
  }
  return { message: "Unexpected error", detail: null };
}

// Errors are shown as text: code and message only, never a stack trace.
export function ErrorBox({ error }: { error: unknown }) {
  const view = describeError(error);
  return (
    <div role="alert" className="error">
      <Icon name="alert" />
      <strong>Error: </strong>
      {view.message}
      {view.detail !== null && (
        <>
          {" "}
          <small className="note">({view.detail})</small>
        </>
      )}
    </div>
  );
}

export function isNotFound(error: unknown): boolean {
  return error instanceof ApiError && error.status === 404;
}

export function Loading() {
  return <p role="status">Loading...</p>;
}

export function RecordTable({ records }: { records: readonly ChainRecord[] }) {
  if (records.length === 0) {
    return <p>No records.</p>;
  }
  return (
    <div className="overflow-x-auto">
      <table>
        <thead>
          <tr>
            <th scope="col">Type</th>
            <th scope="col">Attendee</th>
            <th scope="col">Alias or session</th>
            <th scope="col">Timestamp</th>
            <th scope="col">Signature</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record, position) => {
            const payload = record.payload;
            const isRegistration = payload.type === "register";
            return (
              <tr key={`${position}-${record.signature.slice(0, 16)}`}>
                <td>{payload.type}</td>
                <td title={payload.attendeeId}>{shortId(payload.attendeeId)}</td>
                <td>{isRegistration ? payload.alias : payload.sessionId}</td>
                <td>{formatTime(payload.timestamp)}</td>
                <td title={record.signature}>{shortId(record.signature)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function TrustNote() {
  return (
    <p className="note">
      Verification flags come from the node. This page displays them and does not recompute them.
    </p>
  );
}
