import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Icon } from "./Icon";
import { currentTheme, setTheme, type Theme } from "../theme";

export function ThemeToggle() {
  const [theme, setCurrent] = useState<Theme>(currentTheme);
  const next: Theme = theme === "dark" ? "light" : "dark";
  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      aria-label={`Switch to ${next} theme`}
      onClick={() => {
        setTheme(next);
        setCurrent(next);
      }}
    >
      <Icon name={next === "dark" ? "moon" : "sun"} />
      {next === "dark" ? "Dark" : "Light"}
    </Button>
  );
}
