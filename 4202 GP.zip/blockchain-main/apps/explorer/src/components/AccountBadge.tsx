import { Link } from "react-router-dom";
import { useAuth } from "../auth";
import { Button } from "@/components/ui/button";
import { Icon } from "./Icon";
import { focusMain } from "./Layout";

const KEY_NOTE = "Your key stays in this browser. On a shared computer, clear site data to remove it.";

// Header account area: who is signed in plus hide, or a way to use an existing identity / create one.
export function AccountBadge() {
  const auth = useAuth();
  if (auth.loading) {
    return null;
  }
  if (auth.identity === null) {
    return (
      <Link className="account-badge" to="/register">
        <Icon name="user" />
        Create identity
      </Link>
    );
  }
  if (auth.role === "guest") {
    return (
      <Button
        type="button"
        variant="outline"
        title={KEY_NOTE}
        onClick={() => {
          auth.signIn();
          focusMain();
        }}
      >
        <Icon name="user" />
        Use identity {auth.identity.alias}
      </Button>
    );
  }
  return (
    <>
      <Link className="account-badge" to={`/attendees/${encodeURIComponent(auth.identity.attendeeId)}`}>
        <Icon name="user" />
        <span className="account-name">Signed in as {auth.identity.alias}</span>
      </Link>
      <Button
        type="button"
        variant="outline"
        title={KEY_NOTE}
        onClick={() => {
          auth.signOut();
          focusMain();
        }}
      >
        Hide identity
      </Button>
    </>
  );
}
