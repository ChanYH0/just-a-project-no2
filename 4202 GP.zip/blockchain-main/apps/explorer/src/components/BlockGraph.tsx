// Block graph: windowed SVG of blocks joined by previousHash arrows, with zoom, find and paging.
//
// PORTED FROM ChainKey (presentation only): the layout constants, node/edge SVG structure, zoom/find/paging
// controls and accessibility pattern come from chainkey-core/clients/explorer/src/ChainGraph.tsx, reused with
// the author's authorization for this course project. Adapted here: events became blocks, the SDK types and
// verification semantics were removed (checkpoint lanes are dropped), and all data comes from this project's API.
// This view shows hash references only; it does not verify the chain.

import { useId, useMemo, useRef, useState } from "react";
import { blockLinks, findBlockPosition, GRAPH_WINDOW_SIZE, sortAscending, type GraphLink } from "../blockGraph";
import { type Block } from "@conference-chain/shared/browser";
import { shortHash } from "../format";

const NODE_WIDTH = 210;
const NODE_HEIGHT = 118;
const GAP = 100;
const LEFT = 50;
const TOP = 135;
const PITCH = NODE_WIDTH + GAP;
const MIN_ZOOM = 0.2;
const MAX_ZOOM = 1.7;
const HEIGHT = 290;

interface Props {
  blocks: readonly Block[];
  onSelect: (index: number) => void;
}

function linkLabel(link: GraphLink, parentIndex: number | undefined): string {
  if (link.state === "genesis") {
    return "Genesis";
  }
  if (link.state === "mismatch") {
    return "Parent hash mismatch";
  }
  return parentIndex === undefined ? "Parent outside view" : `Parent #${parentIndex}`;
}

export function BlockGraph({ blocks, onSelect }: Props) {
  const sorted = useMemo(() => sortAscending(blocks), [blocks]);
  const [page, setPage] = useState(0);
  const [zoom, setZoom] = useState(0.85);
  const [search, setSearch] = useState("");
  const [message, setMessage] = useState("");
  const viewport = useRef<HTMLDivElement>(null);
  const arrow = useId().replaceAll(":", "");

  const maxPage = Math.max(0, Math.ceil(sorted.length / GRAPH_WINDOW_SIZE) - 1);
  const currentPage = Math.min(page, maxPage);
  const start = currentPage * GRAPH_WINDOW_SIZE;
  const visible = sorted.slice(start, start + GRAPH_WINDOW_SIZE);
  const links = useMemo(() => blockLinks(sorted, start, start + GRAPH_WINDOW_SIZE), [sorted, start]);

  const width = Math.max(660, LEFT * 2 + Math.max(1, visible.length) * PITCH);
  const nodeX = (offset: number) => LEFT + offset * PITCH;
  const centerY = TOP + NODE_HEIGHT / 2;

  function movePage(next: number) {
    setPage(Math.max(0, Math.min(next, maxPage)));
    viewport.current?.scrollTo({ left: 0, top: 0 });
  }

  function locate() {
    const position = findBlockPosition(sorted, search);
    if (position === undefined) {
      setMessage("No matching block. Enter a block index or a hash prefix.");
      return;
    }
    setMessage("");
    const target = Math.floor(position / GRAPH_WINDOW_SIZE);
    setPage(target);
    onSelect(sorted[position]?.index ?? 0);
  }

  return (
    <section className="block-graph" aria-label="Block graph">
      <div className="graph-controls">
        <form
          className="graph-find"
          onSubmit={(event) => {
            event.preventDefault();
            locate();
          }}
        >
          <input
            aria-label="Find block in graph"
            placeholder="Jump to index or hash..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
          <button type="submit">Find</button>
        </form>
        <div className="graph-zoom">
          <button
            type="button"
            aria-label="Zoom out"
            disabled={zoom <= MIN_ZOOM}
            onClick={() => setZoom((value) => Math.max(MIN_ZOOM, value - 0.15))}
          >
            -
          </button>
          <output aria-label="Graph zoom">{Math.round(zoom * 100)}%</output>
          <button
            type="button"
            aria-label="Zoom in"
            disabled={zoom >= MAX_ZOOM}
            onClick={() => setZoom((value) => Math.min(MAX_ZOOM, value + 0.15))}
          >
            +
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(Math.max(MIN_ZOOM, Math.min(1, (viewport.current?.clientWidth ?? width) / width)));
              viewport.current?.scrollTo(0, 0);
            }}
          >
            Fit
          </button>
        </div>
      </div>
      {message !== "" && (
        <p className="graph-message" role="alert">
          {message}
        </p>
      )}
      <div className="graph-legend">
        <span>
          <i className="legend-link" /> Matching previousHash reference
        </span>
        <span>
          <i className="legend-range" /> Missing or mismatched reference
        </span>
      </div>
      <div ref={viewport} className="graph-viewport" tabIndex={0} aria-label="Scrollable block graph">
        <svg
          width={width * zoom}
          height={HEIGHT * zoom}
          viewBox={`0 0 ${width} ${HEIGHT}`}
          role="group"
          aria-label="Blocks and previousHash links"
        >
          <defs>
            <marker id={arrow} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" />
            </marker>
          </defs>
          <text x={LEFT} y="34" className="graph-lane-title">
            BLOCK CHAIN
          </text>
          <text x={LEFT} y="57" className="graph-subtitle">
            Oldest first · arrows follow previousHash
          </text>
          {links.map((link) => {
            const offset = link.child - start;
            const x = nodeX(offset);
            if (link.state !== "linked" || link.parent === undefined) {
              return (
                <g key={link.child} className={`graph-reference ${link.state}`} data-link-state={link.state}>
                  <path d={`M ${x + 20} ${TOP - 40} V ${TOP - 6}`} markerEnd={`url(#${arrow})`} />
                  <text x={x} y={TOP - 50}>
                    {linkLabel(link, undefined)}
                  </text>
                </g>
              );
            }
            const parentOffset = link.parent - start;
            const adjacent = link.parent + 1 === link.child;
            const parentX = nodeX(parentOffset);
            const path = adjacent
              ? `M ${parentX + NODE_WIDTH} ${centerY} H ${x - 5}`
              : `M ${parentX + NODE_WIDTH / 2} ${TOP} V ${TOP - 30} H ${x + NODE_WIDTH / 2} V ${TOP - 5}`;
            return (
              <g key={link.child} className="graph-edge" data-link-state="linked">
                <path d={path} markerEnd={`url(#${arrow})`} />
                {adjacent && (
                  <text x={parentX + NODE_WIDTH + GAP / 2} y={centerY - 12} textAnchor="middle">
                    previousHash
                  </text>
                )}
              </g>
            );
          })}
          {visible.map((block, offset) => (
            <g
              key={block.index}
              role="button"
              tabIndex={0}
              aria-label={`Block ${block.index}`}
              className="graph-event"
              transform={`translate(${nodeX(offset)}, ${TOP})`}
              onClick={() => onSelect(block.index)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelect(block.index);
                }
              }}
            >
              <title>{`Block ${block.index}\n${block.hash}`}</title>
              <rect width={NODE_WIDTH} height={NODE_HEIGHT} rx="9" />
              <circle cx="18" cy="22" r="4" />
              <text x="30" y="26" className="graph-node-seq">
                #{block.index}
              </text>
              <text x="15" y="54" className="graph-node-type">
                {block.records.length} record{block.records.length === 1 ? "" : "s"}
              </text>
              <text x="15" y="77" className="graph-node-hash">
                {shortHash(block.hash)}
              </text>
              <text x="15" y="101" className="graph-node-meta">
                Difficulty {block.difficulty}
              </text>
            </g>
          ))}
          {visible.length === 0 && (
            <text x={LEFT} y={TOP + 50} className="graph-subtitle">
              No blocks
            </text>
          )}
        </svg>
      </div>
      <div className="graph-pagination">
        <span>
          {visible.length === 0
            ? "0 blocks"
            : `Blocks ${visible[0]?.index ?? 0} to ${visible.at(-1)?.index ?? 0} of ${sorted.length} loaded`}
        </span>
        <div>
          <button type="button" aria-label="Previous graph window" disabled={currentPage === 0} onClick={() => movePage(currentPage - 1)}>
            &lt;
          </button>
          <button type="button" aria-label="Next graph window" disabled={currentPage >= maxPage} onClick={() => movePage(currentPage + 1)}>
            &gt;
          </button>
        </div>
      </div>
      <p className="graph-footnote">
        Scroll to pan. Hash references do not establish authenticity; use Validate for the node&apos;s verification result.
      </p>
    </section>
  );
}
