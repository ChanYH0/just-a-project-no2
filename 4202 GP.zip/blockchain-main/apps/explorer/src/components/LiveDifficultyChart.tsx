import { type Block } from "@conference-chain/shared/browser";
import { layoutDifficulty } from "../difficultyDemo";
import { shapeDifficultySeries } from "../difficultySeries";

const WIDTH = 640;
const HEIGHT = 220;
const PADDING = 36;

// Real mined blocks from the live chain. Visually and textually distinct from the isolated simulation page.
export function LiveDifficultyChart({ blocks }: { blocks: readonly Block[] }) {
  const series = shapeDifficultySeries(blocks);
  const geometry = layoutDifficulty(series.points, WIDTH, HEIGHT, PADDING);
  const first = series.points[0];
  const last = series.points.at(-1);

  return (
    <section aria-labelledby="live-chart-heading" className="live-chart panel">
      <h2 id="live-chart-heading">Live chain (real mined blocks): difficulty</h2>
      <p className="note">
        Real blocks from this node, not the synthetic simulation on the Difficulty demo page.
        {series.truncated ? " Showing only the most recent blocks." : ""}
      </p>
      {first === undefined || last === undefined ? (
        <p>No blocks to chart.</p>
      ) : (
        <>
          <svg
            role="img"
            aria-labelledby="live-chart-title live-chart-desc"
            viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
            className="chart live"
          >
            <title id="live-chart-title">Live chain difficulty by block index</title>
            <desc id="live-chart-desc">
              {`Real mined blocks ${first.index} to ${last.index}. Difficulty ranges from ${geometry.minDifficulty} to ${geometry.maxDifficulty}. A table with the same data follows.`}
            </desc>
            <line className="axis" x1={PADDING} y1={HEIGHT - PADDING} x2={WIDTH - PADDING} y2={HEIGHT - PADDING} />
            <line className="axis" x1={PADDING} y1={PADDING} x2={PADDING} y2={HEIGHT - PADDING} />
            <polyline className="series" fill="none" points={geometry.polyline} />
            {geometry.points.map((point, position) => {
              const adjusted = series.points[position]?.adjusted === true;
              return (
                <circle
                  key={point.index}
                  className={adjusted ? "point adjusted" : "point"}
                  cx={point.x}
                  cy={point.y}
                  r={adjusted ? 5 : 3}
                />
              );
            })}
            <text className="axis-label" x={PADDING} y={PADDING - 12}>
              {`difficulty ${geometry.minDifficulty}-${geometry.maxDifficulty} (large dots: adjusted)`}
            </text>
            <text className="axis-label" x={PADDING} y={HEIGHT - 8}>
              {`block ${first.index}`}
            </text>
            <text className="axis-label" x={WIDTH - PADDING} y={HEIGHT - 8} textAnchor="end">
              {`block ${last.index}`}
            </text>
          </svg>
          <details>
            <summary>Live chain data table</summary>
            <div className="overflow-x-auto">
            <table>
              <caption>Live chain (real mined blocks)</caption>
              <thead>
                <tr>
                  <th scope="col">Block</th>
                  <th scope="col">Difficulty</th>
                  <th scope="col">Interval (ms)</th>
                  <th scope="col">Adjusted</th>
                </tr>
              </thead>
              <tbody>
                {series.points.map((point) => (
                  <tr key={point.index}>
                    <td>{point.index}</td>
                    <td>{point.difficulty}</td>
                    <td>{point.intervalMs ?? "-"}</td>
                    <td>{point.adjusted ? "yes" : "no"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </details>
        </>
      )}
    </section>
  );
}
