import { useState } from "react";
import { Button } from "@/components/ui/button";

// Copies a full id to the clipboard. Feedback is announced through a status region.
export function CopyButton({ value, label }: { value: string; label: string }) {
  const [feedback, setFeedback] = useState("");

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setFeedback("Copied");
    } catch {
      setFeedback("Copy failed");
    }
  }

  return (
    <>
      <Button type="button" variant="outline" aria-label={`Copy ${label}`} onClick={() => void copy()}>
        Copy
      </Button>{" "}
      <span role="status" className="note">
        {feedback}
      </span>
    </>
  );
}
