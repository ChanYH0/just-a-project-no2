// Shared page layout: every page is a Page (title and lead) holding Eyebrow groups and titled Panels.
// Styling lives in styles.css (.lead, .eyebrow, .panel, .form-row); markup stays semantic.

import { useEffect, useId, useRef, type FormEvent, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { Icon, type IconName } from "./Icon";

export const SITE_NAME = "Conference Chain Explorer";

// Moves focus to the main landmark (#main is tabIndex -1 in App). Used after header sign-in and sign-out.
export function focusMain(): void {
  document.getElementById("main")?.focus();
}

export function Page({
  title,
  lead,
  icon,
  children,
}: {
  title: string;
  lead?: string;
  icon?: IconName;
  children: ReactNode;
}) {
  const headingRef = useRef<HTMLHeadingElement>(null);
  const { pathname } = useLocation();
  const lastPathname = useRef<string | null>(null);

  useEffect(() => {
    document.title = `${title} – ${SITE_NAME}`;
  }, [title]);

  // Focus the heading when the route changes so screen reader and keyboard users land on the new page.
  // The first render only records the path; StrictMode's second effect run sees the same path and does nothing.
  useEffect(() => {
    if (lastPathname.current === null) {
      lastPathname.current = pathname;
      return;
    }
    if (lastPathname.current !== pathname) {
      lastPathname.current = pathname;
      headingRef.current?.focus();
    }
  }, [pathname]);

  return (
    <section>
      <h1 ref={headingRef} tabIndex={-1}>
        {icon !== undefined && <Icon name={icon} />}
        {title}
      </h1>
      {lead !== undefined && <p className="lead">{lead}</p>}
      {children}
    </section>
  );
}

// Small uppercase label that names a group of panels, so the page reads top to bottom.
export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="eyebrow">{children}</p>;
}

export function Panel({ title, icon, children }: { title: string; icon?: IconName; children: ReactNode }) {
  const headingId = useId();
  return (
    <section className="panel" aria-labelledby={headingId}>
      <h2 id={headingId}>
        {icon !== undefined && <Icon name={icon} />}
        {title}
      </h2>
      {children}
    </section>
  );
}

// Two panels side by side on wide screens, stacked on narrow ones.
export function PanelGrid({ children }: { children: ReactNode }) {
  return <div className="grid gap-5 md:grid-cols-2">{children}</div>;
}

// Labels, fields and the submit button on one wrapping row.
export function FormRow({
  onSubmit,
  describedBy,
  children,
}: {
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  describedBy?: string;
  children: ReactNode;
}) {
  return (
    <form className="form-row" onSubmit={onSubmit} aria-describedby={describedBy}>
      {children}
    </form>
  );
}
