// Runtime guards for untrusted JSON and form input. Callers narrow `unknown` with these; no `any`.

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function isString(value: unknown): value is string {
  return typeof value === "string";
}

export function isBoolean(value: unknown): value is boolean {
  return typeof value === "boolean";
}

// Safe integer >= 0, and never -0 (SPEC section 5.1, NonNegativeInt).
export function isNonNegativeInt(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0);
}

// Undefined is allowed; any other value must pass the guard. Returns null on a failed check.
export function optionalField<T>(value: unknown, guard: (candidate: unknown) => candidate is T): T | undefined | null {
  if (value === undefined) {
    return undefined;
  }
  return guard(value) ? value : null;
}
