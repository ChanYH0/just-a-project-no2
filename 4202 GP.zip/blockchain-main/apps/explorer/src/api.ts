// Typed fetch wrapper for the node HTTP API (SPEC section 10).
// Every response is checked against its contract before use; a mismatch is an error, never a partial value.
// Shared schemas (Block, ChainRecord, Alias, AttendeeId, SessionId) come from @conference-chain/shared/browser.

import {
  Alias,
  AttendeeId,
  Block,
  ChainRecord,
  CONFERENCE_ID_PATTERN,
  ERROR_CODES,
  HexSha256,
  MINER_STATES,
  NonNegativeInt,
  PROFILE_NAMES,
  PROTOCOL_VERSION,
  PositiveInt,
  SessionId,
  Timestamp,
  type ErrorCode,
  type SignedAttendance,
  type SignedRegistration,
} from "@conference-chain/shared/browser";
import { isBoolean, isNonNegativeInt, isRecord, isString, optionalField } from "./guards.js";

// The explorer always calls the same origin under this prefix (vite.config.ts proxies it to the node).
export const API_PREFIX = "/api";

// Demo bounds (SPEC section 10). The node enforces them; they are mirrored here only for form feedback.
export const DEMO_COUNT_RANGE = { min: 1, max: 30 } as const;
export const DEMO_INTERVAL_RANGE_MS = { min: 0, max: 120000 } as const;

export const TAMPER_MUTATIONS = [
  "edit-record",
  "edit-previous-hash",
  "rehash-after-edit",
  "lower-difficulty",
  "delete-record-and-remine",
] as const;
export type TamperMutation = (typeof TAMPER_MUTATIONS)[number];

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

export interface ChainInfo {
  chainId: string;
  conferenceId: string;
  profile: string;
  protocol: string;
  demoRoutesEnabled: boolean;
}

export interface BlockVerification {
  hashValid: boolean;
  powValid: boolean;
}

export type BlockView = Block & { verification: BlockVerification };

// GET /blocks returns plain blocks; only GET /blocks/:index adds the server-computed `verification` (SPEC section 9).
export interface BlockPage {
  blocks: Block[];
  nextCursor: string | null;
}

export interface Health {
  ok: boolean;
  miner: string;
  headIndex: number;
  profile: string;
}

export interface SessionInfo {
  id: string;
  title: string;
}

export type RecordState = "pending" | "confirmed" | "expired" | "rejected";

export interface RecordStatus {
  status: RecordState;
  blockIndex?: number;
  code?: string;
}

export interface AttendeeInfo {
  attendeeId: string;
  alias: string;
  registeredAt: number;
  blockIndex: number;
}

export interface AttendeeSession {
  sessionId: string;
  timestamp: number;
  blockIndex: number;
}

export interface AttendeeSessions {
  attendeeId: string;
  sessions: AttendeeSession[];
}

export interface SessionAttendee {
  attendeeId: string;
  alias: string;
  timestamp: number;
  blockIndex: number;
}

export interface SessionAttendees {
  sessionId: string;
  attendees: SessionAttendee[];
}

export interface ValidateResult {
  ok: boolean;
  code?: string;
  blockIndex?: number;
}

export interface TamperRequest {
  mutation: TamperMutation;
  blockIndex: number;
}

export interface SimulationRequest {
  count: number;
  intervalMs: number;
}

export interface SimulationBlock {
  index: number;
  hash: string;
  difficulty: number;
  timestamp: number;
}

export interface SimulationAdjustment {
  atIndex: number;
  actualMs: number;
  expectedMs: number;
  from: number;
  to: number;
}

export interface SimulationResult {
  valid: boolean;
  blocks: SimulationBlock[];
  adjustments: SimulationAdjustment[];
}

export interface ExplorerApi {
  getChainInfo(): Promise<ChainInfo>;
  getHealth(): Promise<Health>;
  getBlocks(options: { limit: number; cursor?: string }): Promise<BlockPage>;
  getBlock(index: number): Promise<BlockView>;
  getMempool(): Promise<ChainRecord[]>;
  getSessions(): Promise<SessionInfo[]>;
  getAttendee(attendeeId: string): Promise<AttendeeInfo>;
  getAttendeeSessions(attendeeId: string): Promise<AttendeeSessions>;
  getSessionAttendees(sessionId: string): Promise<SessionAttendees>;
  postRegistration(signed: SignedRegistration): Promise<{ recordId: string }>;
  postAttendance(signed: SignedAttendance): Promise<{ recordId: string }>;
  getRecord(recordId: string): Promise<RecordStatus>;
  getChainValidate(): Promise<ValidateResult>;
  // Returns the node's raw JSON result; the caller displays it as text.
  postTamperCheck(request: TamperRequest): Promise<Record<string, unknown>>;
  postDifficultySimulation(request: SimulationRequest): Promise<SimulationResult>;
  // True when the demo route exists (any status other than 404). Network failures are rethrown.
  probeDemoRoutes(): Promise<boolean>;
}

export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

type Parser<T> = (value: unknown) => T | null;

function strictObject(
  value: unknown,
  required: readonly string[],
  optional: readonly string[] = [],
): value is Record<string, unknown> {
  if (!isRecord(value)) {
    return false;
  }
  const allowed = new Set([...required, ...optional]);
  if (!required.every((key) => Object.hasOwn(value, key))) {
    return false;
  }
  return Object.keys(value).every((key) => allowed.has(key));
}

function matches<T>(schema: { safeParse(value: unknown): { success: boolean; data?: T } }, value: unknown): value is T {
  return schema.safeParse(value).success;
}

function isErrorCode(value: unknown): value is ErrorCode {
  return isString(value) && (ERROR_CODES as readonly string[]).includes(value);
}

function parseJson(text: string): { value: unknown } | null {
  try {
    const value: unknown = JSON.parse(text);
    return { value };
  } catch {
    return null;
  }
}

function errorFromResponse(status: number, text: string): ApiError {
  const parsed = parseJson(text);
  if (parsed !== null && isRecord(parsed.value)) {
    const error = parsed.value.error;
    if (isRecord(error) && isString(error.code) && isString(error.message)) {
      return new ApiError(status, error.code, error.message);
    }
  }
  // Not the documented error body (for example a framework 404 page). Keep the status; never echo the body.
  return new ApiError(status, `HTTP_${status}`, `Request failed with HTTP ${status}`);
}

async function request<T>(
  fetchFn: FetchLike,
  method: "GET" | "POST",
  path: string,
  parse: Parser<T>,
  body?: unknown,
): Promise<T> {
  const init: RequestInit = {
    method,
    credentials: "same-origin",
    cache: "no-store",
    headers: body === undefined ? {} : { "content-type": "application/json" },
  };
  if (body !== undefined) {
    init.body = JSON.stringify(body);
  }

  let response: Response;
  let text: string;
  try {
    response = await fetchFn(`${API_PREFIX}${path}`, init);
    text = await response.text();
  } catch {
    throw new ApiError(0, "NETWORK_ERROR", "The node could not be reached");
  }

  if (!response.ok) {
    throw errorFromResponse(response.status, text);
  }
  const parsed = parseJson(text);
  const value = parsed === null ? null : parse(parsed.value);
  if (value === null) {
    throw new ApiError(response.status, "INVALID_RESPONSE", `Unexpected response shape from ${path}`);
  }
  return value;
}

function requireValid(schemaMatches: boolean, label: string): void {
  if (!schemaMatches) {
    throw new ApiError(0, "INVALID_INPUT", `${label} is not valid`);
  }
}

function parseChainInfo(value: unknown): ChainInfo | null {
  if (!strictObject(value, ["chainId", "conferenceId", "profile", "protocol"], ["demoRoutesEnabled"])) {
    return null;
  }
  const { chainId, conferenceId, profile, protocol } = value;
  const demo = optionalField(value.demoRoutesEnabled, isBoolean);
  if (
    !matches(HexSha256, chainId) ||
    !isString(conferenceId) ||
    !CONFERENCE_ID_PATTERN.test(conferenceId) ||
    !isString(profile) ||
    !(PROFILE_NAMES as readonly string[]).includes(profile) ||
    protocol !== PROTOCOL_VERSION ||
    demo === null
  ) {
    return null;
  }
  return { chainId, conferenceId, profile, protocol, demoRoutesEnabled: demo === true };
}

function parseHealth(value: unknown): Health | null {
  if (!strictObject(value, ["ok", "miner", "headIndex", "profile"])) {
    return null;
  }
  const { ok, miner, headIndex, profile } = value;
  if (!isBoolean(ok) || !isString(miner) || !(MINER_STATES as readonly string[]).includes(miner) || !isNonNegativeInt(headIndex) ||
      !isString(profile) || !(PROFILE_NAMES as readonly string[]).includes(profile)) {
    return null;
  }
  if (ok !== (miner !== "fatal")) {
    return null;
  }
  return { ok, miner, headIndex, profile };
}

function parseBlockView(value: unknown): BlockView | null {
  if (!isRecord(value)) {
    return null;
  }
  const verification = value.verification;
  if (!strictObject(verification, ["hashValid", "powValid"]) || !isBoolean(verification.hashValid) || !isBoolean(verification.powValid)) {
    return null;
  }
  const { verification: _verification, ...blockFields } = value;
  const parsed = Block.safeParse(blockFields);
  if (!parsed.success) {
    return null;
  }
  return {
    ...parsed.data,
    verification: { hashValid: verification.hashValid, powValid: verification.powValid },
  };
}

function parseBlockPage(value: unknown): BlockPage | null {
  if (!strictObject(value, ["blocks", "nextCursor"]) || !Array.isArray(value.blocks)) {
    return null;
  }
  const blocks: Block[] = [];
  for (const item of value.blocks) {
    const parsed = Block.safeParse(item);
    if (!parsed.success) {
      return null;
    }
    blocks.push(parsed.data);
  }
  const cursor = value.nextCursor;
  if (cursor !== null && !(isString(cursor) && /^(0|[1-9][0-9]*)$/.test(cursor) && matches(NonNegativeInt, Number(cursor)))) {
    return null;
  }
  return { blocks, nextCursor: cursor };
}

function parseMempool(value: unknown): ChainRecord[] | null {
  const parsed = ChainRecord.array().safeParse(value);
  return parsed.success ? parsed.data : null;
}

function parseSessions(value: unknown): SessionInfo[] | null {
  if (!Array.isArray(value)) {
    return null;
  }
  const sessions: SessionInfo[] = [];
  for (const item of value) {
    if (!strictObject(item, ["id", "title"]) || !matches(SessionId, item.id) || !isString(item.title)) {
      return null;
    }
    sessions.push({ id: item.id, title: item.title });
  }
  return sessions;
}

function parseAttendee(value: unknown): AttendeeInfo | null {
  if (!strictObject(value, ["attendeeId", "alias", "registeredAt", "blockIndex"])) {
    return null;
  }
  const { attendeeId, alias, registeredAt, blockIndex } = value;
  if (
    !isString(attendeeId) ||
    !matches(AttendeeId, attendeeId) ||
    !isString(alias) ||
    !matches(Alias, alias) ||
    !matches(Timestamp, registeredAt) ||
    !isNonNegativeInt(blockIndex)
  ) {
    return null;
  }
  return { attendeeId, alias, registeredAt, blockIndex };
}

function parseAttendeeSessions(value: unknown): AttendeeSessions | null {
  if (
    !strictObject(value, ["attendeeId", "sessions"]) ||
    !matches(AttendeeId, value.attendeeId) ||
    !Array.isArray(value.sessions)
  ) {
    return null;
  }
  const sessions: AttendeeSession[] = [];
  for (const item of value.sessions) {
    if (
      !strictObject(item, ["sessionId", "timestamp", "blockIndex"]) ||
      !matches(SessionId, item.sessionId) ||
      !matches(Timestamp, item.timestamp) ||
      !isNonNegativeInt(item.blockIndex)
    ) {
      return null;
    }
    sessions.push({ sessionId: item.sessionId, timestamp: item.timestamp, blockIndex: item.blockIndex });
  }
  return { attendeeId: value.attendeeId, sessions };
}

function parseSessionAttendees(value: unknown): SessionAttendees | null {
  if (
    !strictObject(value, ["sessionId", "attendees"]) ||
    !matches(SessionId, value.sessionId) ||
    !Array.isArray(value.attendees)
  ) {
    return null;
  }
  const attendees: SessionAttendee[] = [];
  for (const item of value.attendees) {
    if (
      !strictObject(item, ["attendeeId", "alias", "timestamp", "blockIndex"]) ||
      !matches(AttendeeId, item.attendeeId) ||
      !matches(Alias, item.alias) ||
      !matches(Timestamp, item.timestamp) ||
      !isNonNegativeInt(item.blockIndex)
    ) {
      return null;
    }
    attendees.push({
      attendeeId: item.attendeeId,
      alias: item.alias,
      timestamp: item.timestamp,
      blockIndex: item.blockIndex,
    });
  }
  return { sessionId: value.sessionId, attendees };
}

function parseRecordId(value: unknown): { recordId: string } | null {
  if (!strictObject(value, ["recordId"]) || !matches(HexSha256, value.recordId)) {
    return null;
  }
  return { recordId: value.recordId };
}

function isRecordState(value: unknown): value is RecordState {
  return value === "pending" || value === "confirmed" || value === "expired" || value === "rejected";
}

function parseRecordStatus(value: unknown): RecordStatus | null {
  if (!strictObject(value, ["status"], ["blockIndex", "code"]) || !isRecordState(value.status)) {
    return null;
  }
  const blockIndex = optionalField(value.blockIndex, isNonNegativeInt);
  const code = optionalField(value.code, isErrorCode);
  if (blockIndex === null || code === null) {
    return null;
  }
  if (value.status === "confirmed" ? blockIndex === undefined || code !== undefined
      : value.status === "rejected" ? code === undefined || blockIndex !== undefined
      : blockIndex !== undefined || code !== undefined) {
    return null;
  }
  return { status: value.status, blockIndex, code };
}

function parseValidateResult(value: unknown): ValidateResult | null {
  if (!strictObject(value, ["ok"], ["code", "blockIndex"]) || !isBoolean(value.ok)) {
    return null;
  }
  const code = optionalField(value.code, isErrorCode);
  const blockIndex = optionalField(value.blockIndex, isNonNegativeInt);
  if (code === null || blockIndex === null) {
    return null;
  }
  if (value.ok ? code !== undefined || blockIndex !== undefined : code === undefined) {
    return null;
  }
  return { ok: value.ok, code, blockIndex };
}

function parseRawObject(value: unknown): Record<string, unknown> | null {
  return isRecord(value) ? value : null;
}

function parseSimulation(value: unknown): SimulationResult | null {
  if (
    !strictObject(value, ["valid", "blocks", "adjustments"]) ||
    !isBoolean(value.valid) ||
    !Array.isArray(value.blocks) ||
    !Array.isArray(value.adjustments)
  ) {
    return null;
  }
  const blocks: SimulationBlock[] = [];
  for (const item of value.blocks) {
    if (
      !strictObject(item, ["index", "hash", "difficulty", "timestamp"]) ||
      !matches(NonNegativeInt, item.index) ||
      !matches(HexSha256, item.hash) ||
      !matches(PositiveInt, item.difficulty) ||
      !matches(Timestamp, item.timestamp)
    ) {
      return null;
    }
    blocks.push({ index: item.index, hash: item.hash, difficulty: item.difficulty, timestamp: item.timestamp });
  }
  const adjustments: SimulationAdjustment[] = [];
  for (const item of value.adjustments) {
    if (
      !strictObject(item, ["atIndex", "actualMs", "expectedMs", "from", "to"]) ||
      !matches(PositiveInt, item.atIndex) ||
      !matches(NonNegativeInt, item.actualMs) ||
      !matches(PositiveInt, item.expectedMs) ||
      !matches(PositiveInt, item.from) ||
      !matches(PositiveInt, item.to)
    ) {
      return null;
    }
    adjustments.push({
      atIndex: item.atIndex,
      actualMs: item.actualMs,
      expectedMs: item.expectedMs,
      from: item.from,
      to: item.to,
    });
  }
  return { valid: value.valid, blocks, adjustments };
}

export function createApi(fetchFn: FetchLike = (input, init) => globalThis.fetch(input, init)): ExplorerApi {
  const get = <T>(path: string, parse: Parser<T>): Promise<T> => request(fetchFn, "GET", path, parse);
  const post = <T>(path: string, parse: Parser<T>, body: unknown): Promise<T> =>
    request(fetchFn, "POST", path, parse, body);
  // Availability is fixed for a running node. Share the probe across navigation and
  // concurrent page loads so discovering demos spends at most one heavy request.
  // A network failure is not an availability result and may be retried.
  let demoProbe: Promise<boolean> | null = null;

  return {
    getChainInfo: () => get("/chain/info", parseChainInfo),
    getHealth: () => get("/health", parseHealth),

    getBlocks({ limit, cursor }) {
      const params = new URLSearchParams({ limit: String(limit) });
      if (cursor !== undefined) {
        params.set("cursor", cursor);
      }
      return get(`/blocks?${params.toString()}`, parseBlockPage);
    },

    async getBlock(index) {
      requireValid(isNonNegativeInt(index), "block index");
      return get(`/blocks/${index}`, parseBlockView);
    },

    getMempool: () => get("/mempool", parseMempool),
    getSessions: () => get("/sessions", parseSessions),

    async getAttendee(attendeeId) {
      requireValid(matches(AttendeeId, attendeeId), "attendee id");
      return get(`/attendees/${encodeURIComponent(attendeeId)}`, parseAttendee);
    },

    async getAttendeeSessions(attendeeId) {
      requireValid(matches(AttendeeId, attendeeId), "attendee id");
      return get(`/attendees/${encodeURIComponent(attendeeId)}/sessions`, parseAttendeeSessions);
    },

    async getSessionAttendees(sessionId) {
      requireValid(matches(SessionId, sessionId), "session id");
      return get(`/sessions/${encodeURIComponent(sessionId)}/attendees`, parseSessionAttendees);
    },

    postRegistration: (signed) => post("/registrations", parseRecordId, signed),
    postAttendance: (signed) => post("/attendance", parseRecordId, signed),

    async getRecord(recordId) {
      requireValid(matches(HexSha256, recordId), "record id");
      return get(`/records/${recordId}`, parseRecordStatus);
    },

    getChainValidate: () => get("/chain/validate", parseValidateResult),

    postTamperCheck: (request) => post("/demo/tamper-check", parseRawObject, request),
    postDifficultySimulation: (simulation) => post("/demo/difficulty-simulation", parseSimulation, simulation),

    probeDemoRoutes() {
      if (demoProbe === null) {
        demoProbe = post("/demo/tamper-check", parseRawObject, {}).then(
          () => true,
          (error: unknown) => {
            if (error instanceof ApiError && error.code === "NETWORK_ERROR") {
              demoProbe = null;
              throw error;
            }
            // Any HTTP status other than 404 means the route exists (the empty body is rejected by the node).
            return !(error instanceof ApiError && error.status === 404);
          },
        );
      }
      return demoProbe;
    },
  };
}
