// Browser singletons used by the pages. Tests never import this module.

import { createApi, type ExplorerApi } from "./api";
import { createIndexedDbWalletStore, type WalletStore } from "./wallet";

export const defaultApi: ExplorerApi = createApi();
export const defaultWallet: WalletStore = createIndexedDbWalletStore(indexedDB);
