// Register and check-in flows (SPEC sections 5.2, 5.3, 12). Dependencies are arguments so the flows
// run in node tests with a fake api, the browser identity adapter, and an injected wallet store.

import {
  Alias,
  AttendancePayload,
  RegistrationPayload,
  SessionId,
  deriveAttendeeId,
  signPayload,
  type IdentityCrypto,
} from "@conference-chain/shared/browser";
import type { ExplorerApi, RecordStatus } from "./api";
import { isCryptoKey, type WalletStore } from "./wallet";

export type FlowErrorCode = "WALLET_EXISTS" | "NO_WALLET" | "INVALID_INPUT" | "INVALID_OPTIONS";

export class FlowError extends Error {
  readonly code: FlowErrorCode;

  constructor(code: FlowErrorCode, message: string) {
    super(message);
    this.name = "FlowError";
    this.code = code;
  }
}

export interface FlowDeps {
  api: ExplorerApi;
  identity: IdentityCrypto;
  wallet: WalletStore;
  now: () => number;
}

export interface RegisterInput {
  alias: string;
  // Must be true when a wallet already exists; the UI asks the user to confirm first.
  replaceExisting: boolean;
}

export interface RegisterResult {
  recordId: string;
  attendeeId: string;
}

export async function registerIdentity(deps: FlowDeps, input: RegisterInput): Promise<RegisterResult> {
  const existing = await deps.wallet.load();
  if (existing !== null && !input.replaceExisting) {
    throw new FlowError("WALLET_EXISTS", "a wallet identity already exists and was not confirmed for replacement");
  }
  if (!Alias.safeParse(input.alias).success) {
    throw new FlowError("INVALID_INPUT", "alias is not valid");
  }

  const info = await deps.api.getChainInfo();
  const pair = await deps.identity.generateKeyPair();
  if (!isCryptoKey(pair.privateKey)) {
    throw new FlowError("INVALID_INPUT", "identity adapter did not return a WebCrypto private key");
  }
  const attendeeId = await deriveAttendeeId(pair.publicKey, deps.identity);

  const payload = RegistrationPayload.safeParse({
    type: "register",
    chainId: info.chainId,
    attendeeId,
    alias: input.alias,
    publicKey: pair.publicKey,
    timestamp: deps.now(),
  });
  if (!payload.success) {
    throw new FlowError("INVALID_INPUT", "registration payload failed structural validation");
  }

  const signature = await signPayload(payload.data, pair.privateKey, deps.identity);
  const { recordId } = await deps.api.postRegistration({ payload: payload.data, signature });

  // Replace the wallet only after the node accepted the registration (202).
  await deps.wallet.save({
    attendeeId,
    publicKey: pair.publicKey,
    privateKey: pair.privateKey,
    alias: input.alias,
  });
  return { recordId, attendeeId };
}

export interface CheckInResult {
  recordId: string;
}

export async function checkIn(deps: FlowDeps, sessionId: string): Promise<CheckInResult> {
  const wallet = await deps.wallet.load();
  if (wallet === null) {
    throw new FlowError("NO_WALLET", "no identity in this browser; register first");
  }
  if (!SessionId.safeParse(sessionId).success) {
    throw new FlowError("INVALID_INPUT", "session id is not valid");
  }

  const info = await deps.api.getChainInfo();
  const payload = AttendancePayload.safeParse({
    type: "attend",
    chainId: info.chainId,
    attendeeId: wallet.attendeeId,
    sessionId,
    timestamp: deps.now(),
  });
  if (!payload.success) {
    throw new FlowError("INVALID_INPUT", "attendance payload failed structural validation");
  }

  const signature = await signPayload(payload.data, wallet.privateKey, deps.identity);
  const { recordId } = await deps.api.postAttendance({ payload: payload.data, signature });
  return { recordId };
}

export interface PollOptions {
  attempts: number;
  delayMs: number;
  sleep: (ms: number) => Promise<void>;
}

// Polls until the record leaves `pending` or the attempts run out; returns the last status seen.
export async function pollRecord(api: ExplorerApi, recordId: string, options: PollOptions): Promise<RecordStatus> {
  if (!Number.isSafeInteger(options.attempts) || options.attempts < 1) {
    throw new FlowError("INVALID_OPTIONS", "attempts must be a positive integer");
  }
  let last: RecordStatus | null = null;
  for (let attempt = 0; attempt < options.attempts; attempt += 1) {
    last = await api.getRecord(recordId);
    if (last.status !== "pending") {
      return last;
    }
    await options.sleep(options.delayMs);
  }
  if (last === null) {
    throw new FlowError("INVALID_OPTIONS", "no poll attempt was made");
  }
  return last;
}
