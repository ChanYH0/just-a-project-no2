// The browser wallet is the "login": registering stores the identity, and the header badge must refresh right away.
export const IDENTITY_CHANGED_EVENT = "identity-changed";

export function notifyIdentityChanged(): void {
  window.dispatchEvent(new Event(IDENTITY_CHANGED_EVENT));
}
