// Pure data shaping for the live-chain difficulty chart (real mined blocks only).
// Input is whatever the blocks API returned (any order); output is oldest-first and bounded.

export const LIVE_CHART_WINDOW = 50;

export interface SeriesBlock {
  index: number;
  timestamp: number;
  difficulty: number;
}

export interface SeriesPoint {
  index: number;
  difficulty: number;
  // Milliseconds since the previous block in the window; null for the first block shown.
  intervalMs: number | null;
  // Difficulty differs from the previous block in the window (an adjustment boundary).
  adjusted: boolean;
}

export interface DifficultySeries {
  points: SeriesPoint[];
  // True when older blocks were dropped to fit the window.
  truncated: boolean;
}

export function shapeDifficultySeries(
  blocks: readonly SeriesBlock[],
  window: number = LIVE_CHART_WINDOW,
): DifficultySeries {
  const size = Math.max(1, Math.floor(window));
  const sorted = [...blocks].sort((a, b) => a.index - b.index);
  const truncated = sorted.length > size;
  const shown = truncated ? sorted.slice(sorted.length - size) : sorted;
  const points = shown.map((block, position): SeriesPoint => {
    const previous = position === 0 ? undefined : shown[position - 1];
    return {
      index: block.index,
      difficulty: block.difficulty,
      intervalMs: previous === undefined ? null : block.timestamp - previous.timestamp,
      adjusted: previous !== undefined && previous.difficulty !== block.difficulty,
    };
  });
  return { points, truncated };
}
