// Display helpers. Output is always rendered as React text, never as HTML.

export function shortHash(hash: string): string {
  return `${hash.slice(0, 12)}...`;
}

export function shortId(id: string): string {
  return `${id.slice(0, 12)}...`;
}

export function formatTime(ms: number): string {
  return new Date(ms).toISOString().replace("T", " ").replace("Z", " UTC");
}
