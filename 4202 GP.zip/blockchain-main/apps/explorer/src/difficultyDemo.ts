// Pure helpers for the isolated difficulty simulation page: input parsing and chart geometry.
// Nothing here touches the live chain; the result comes from POST /demo/difficulty-simulation.

import { DEMO_COUNT_RANGE, DEMO_INTERVAL_RANGE_MS, type SimulationRequest } from "./api";

export type DemoInputResult = { ok: true; value: SimulationRequest } | { ok: false; message: string };

const INTEGER_PATTERN = /^[0-9]+$/;

function parseBoundedInteger(raw: string, label: string, range: { min: number; max: number }): number | string {
  const trimmed = raw.trim();
  if (!INTEGER_PATTERN.test(trimmed)) {
    return `${label} must be a whole number`;
  }
  const value = Number(trimmed);
  if (!Number.isSafeInteger(value) || value < range.min || value > range.max) {
    return `${label} must be between ${range.min} and ${range.max}`;
  }
  return value;
}

export function parseSimulationInput(rawCount: string, rawIntervalMs: string): DemoInputResult {
  const count = parseBoundedInteger(rawCount, "count", DEMO_COUNT_RANGE);
  if (typeof count === "string") {
    return { ok: false, message: count };
  }
  const intervalMs = parseBoundedInteger(rawIntervalMs, "intervalMs", DEMO_INTERVAL_RANGE_MS);
  if (typeof intervalMs === "string") {
    return { ok: false, message: intervalMs };
  }
  return { ok: true, value: { count, intervalMs } };
}

export interface ChartPoint {
  index: number;
  difficulty: number;
  x: number;
  y: number;
}

export interface ChartGeometry {
  points: ChartPoint[];
  polyline: string;
  minDifficulty: number;
  maxDifficulty: number;
}

// Maps blocks onto a width x height box with padding. Empty input yields no points.
// Y is inverted so higher difficulty is drawn higher. A flat series is drawn at mid height.
export function layoutDifficulty(
  blocks: readonly { index: number; difficulty: number }[],
  width: number,
  height: number,
  padding: number,
): ChartGeometry {
  if (blocks.length === 0) {
    return { points: [], polyline: "", minDifficulty: 0, maxDifficulty: 0 };
  }
  const indices = blocks.map((block) => block.index);
  const difficulties = blocks.map((block) => block.difficulty);
  const minIndex = Math.min(...indices);
  const maxIndex = Math.max(...indices);
  const minDifficulty = Math.min(...difficulties);
  const maxDifficulty = Math.max(...difficulties);

  const innerWidth = width - 2 * padding;
  const innerHeight = height - 2 * padding;
  const scaleX = (index: number): number =>
    maxIndex === minIndex ? width / 2 : padding + ((index - minIndex) / (maxIndex - minIndex)) * innerWidth;
  const scaleY = (difficulty: number): number =>
    maxDifficulty === minDifficulty
      ? height / 2
      : padding + (1 - (difficulty - minDifficulty) / (maxDifficulty - minDifficulty)) * innerHeight;

  const points = blocks.map((block) => ({
    index: block.index,
    difficulty: block.difficulty,
    x: scaleX(block.index),
    y: scaleY(block.difficulty),
  }));
  const polyline = points.map((point) => `${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ");
  return { points, polyline, minDifficulty, maxDifficulty };
}
