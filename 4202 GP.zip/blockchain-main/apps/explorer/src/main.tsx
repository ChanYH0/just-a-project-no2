import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { App } from "./App";
import "./styles.css";
import "./blockGraph.css";
import { applyStoredTheme } from "./theme";

applyStoredTheme();

const container = document.getElementById("root");
if (container === null) {
  throw new Error("root element is missing from index.html");
}

createRoot(container).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
