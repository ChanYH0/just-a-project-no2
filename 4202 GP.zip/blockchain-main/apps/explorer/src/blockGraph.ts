// Pure model for the block graph: which parent each block links to, from previousHash alone.
// Presentation-only: this does not verify anything; the node's flags and /chain/validate remain authoritative.
// The link-state idea (linked / outside view / genesis) follows ChainKey's graph model (see BlockGraph.tsx header).

export const GRAPH_WINDOW_SIZE = 12;

export interface GraphBlock {
  index: number;
  hash: string;
  previousHash: string;
}

export type LinkState = "linked" | "genesis" | "outside" | "mismatch";

export interface GraphLink {
  // Position of the child inside the sorted block list.
  child: number;
  // Position of the matching parent, present only when state is "linked".
  parent: number | undefined;
  state: LinkState;
}

// Oldest first, so the genesis block is leftmost. The API returns newest first.
export function sortAscending<T extends { index: number }>(blocks: readonly T[]): T[] {
  return [...blocks].sort((a, b) => a.index - b.index);
}

// Links for the half-open window [start, end) over an oldest-first list.
export function blockLinks(blocks: readonly GraphBlock[], start: number, end: number): GraphLink[] {
  const byHash = new Map<string, number>();
  blocks.forEach((block, position) => byHash.set(block.hash, position));

  const links: GraphLink[] = [];
  for (let child = Math.max(0, start); child < Math.min(end, blocks.length); child += 1) {
    const block = blocks[child];
    if (block === undefined) {
      continue;
    }
    if (block.index === 0) {
      links.push({ child, parent: undefined, state: "genesis" });
      continue;
    }
    const parent = byHash.get(block.previousHash);
    if (parent === undefined) {
      const before = blocks[child - 1];
      const adjacentMismatch = before !== undefined && before.index === block.index - 1;
      links.push({ child, parent: undefined, state: adjacentMismatch ? "mismatch" : "outside" });
    } else {
      links.push({ child, parent, state: "linked" });
    }
  }
  return links;
}

export function findBlockPosition(blocks: readonly GraphBlock[], query: string): number | undefined {
  const text = query.trim().replace(/^#/, "").toLowerCase();
  if (text === "") {
    return undefined;
  }
  const byIndex = /^\d+$/.test(text) ? blocks.findIndex((block) => block.index === Number(text)) : -1;
  const position = byIndex >= 0 ? byIndex : blocks.findIndex((block) => block.hash.toLowerCase().startsWith(text));
  return position >= 0 ? position : undefined;
}
