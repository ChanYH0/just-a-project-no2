import { useState, type FormEvent } from "react";
import { DEMO_COUNT_RANGE, DEMO_INTERVAL_RANGE_MS, type SimulationResult } from "../api";
import { defaultApi } from "../services";
import { layoutDifficulty, parseSimulationInput } from "../difficultyDemo";
import { ErrorBox, isNotFound } from "../components/Shared";
import { FormRow, Page, Panel } from "../components/Layout";
import { shortHash } from "../format";
import { Button } from "@/components/ui/button";

const CHART_WIDTH = 640;
const CHART_HEIGHT = 260;
const CHART_PADDING = 36;

export function DifficultyDemoPage() {
  const [count, setCount] = useState("10");
  const [intervalMs, setIntervalMs] = useState("0");
  const [inputError, setInputError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<unknown>(null);
  const [result, setResult] = useState<SimulationResult | null>(null);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) {
      return;
    }
    const parsed = parseSimulationInput(count, intervalMs);
    if (!parsed.ok) {
      setInputError(parsed.message);
      return;
    }
    setInputError(null);
    setBusy(true);
    setFailure(null);
    setResult(null);
    try {
      setResult(await defaultApi.postDifficultySimulation(parsed.value));
    } catch (error) {
      setFailure(error);
    } finally {
      setBusy(false);
    }
  }

  const inputInvalid = inputError !== null;

  return (
    <Page title="Difficulty demo" icon="activity" lead="Simulate how difficulty reacts to fast and slow blocks.">
      <p className="warning">
        <strong>Simulation (isolated chain) — synthetic timestamps, not measured.</strong> This runs on a separate
        in-memory chain. It never reads or changes the live chain shown on the Chain page.
      </p>

      <FormRow onSubmit={onSubmit}>
        <label htmlFor="count-input">
          Blocks ({DEMO_COUNT_RANGE.min} to {DEMO_COUNT_RANGE.max})
        </label>{" "}
        <input
          id="count-input"
          type="number"
          min={DEMO_COUNT_RANGE.min}
          max={DEMO_COUNT_RANGE.max}
          step={1}
          value={count}
          onChange={(event) => setCount(event.target.value)}
          aria-invalid={inputInvalid}
          aria-describedby={inputInvalid ? "demo-input-error" : undefined}
        />{" "}
        <label htmlFor="interval-input">
          Synthetic interval ms ({DEMO_INTERVAL_RANGE_MS.min} to {DEMO_INTERVAL_RANGE_MS.max})
        </label>{" "}
        <input
          id="interval-input"
          type="number"
          min={DEMO_INTERVAL_RANGE_MS.min}
          max={DEMO_INTERVAL_RANGE_MS.max}
          step={1}
          value={intervalMs}
          onChange={(event) => setIntervalMs(event.target.value)}
          aria-invalid={inputInvalid}
          aria-describedby={inputInvalid ? "demo-input-error" : undefined}
        />{" "}
        <Button type="submit" disabled={busy}>
          {busy ? "Simulating..." : "Run simulation"}
        </Button>
      </FormRow>
      <p className="note">
        0 ms gives equal timestamps, so difficulty rises. A large interval gives slow blocks, so difficulty falls.
      </p>
      {inputError !== null && (
        <p id="demo-input-error" role="alert">
          {inputError}
        </p>
      )}
      {failure !== null &&
        (isNotFound(failure) ? (
          <p role="alert">Demo routes are not enabled on this node (HTTP 404).</p>
        ) : (
          <ErrorBox error={failure} />
        ))}
      {result !== null && <SimulationView result={result} />}
    </Page>
  );
}

function SimulationView({ result }: { result: SimulationResult }) {
  const geometry = layoutDifficulty(result.blocks, CHART_WIDTH, CHART_HEIGHT, CHART_PADDING);
  return (
    <Panel title="Simulation (isolated chain) — synthetic timestamps, not measured">
      <p>Node validation of the isolated chain: {result.valid ? "valid" : "invalid"}</p>

      <svg
        role="img"
        aria-label="Difficulty per block in the isolated simulation"
        viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}
        width="100%"
        className="chart"
      >
        <line
          x1={CHART_PADDING}
          y1={CHART_HEIGHT - CHART_PADDING}
          x2={CHART_WIDTH - CHART_PADDING}
          y2={CHART_HEIGHT - CHART_PADDING}
          className="axis"
        />
        <polyline points={geometry.polyline} className="series" fill="none" />
        {geometry.points.map((point) => (
          <circle key={point.index} cx={point.x} cy={point.y} r={3} className="point">
            <title>{`block ${point.index}: difficulty ${point.difficulty}`}</title>
          </circle>
        ))}
        {result.adjustments.map((adjustment) => {
          const point = geometry.points.find((candidate) => candidate.index === adjustment.atIndex);
          if (point === undefined) {
            return null;
          }
          return (
            <text key={`adj-${adjustment.atIndex}`} x={point.x + 6} y={point.y - 8} className="annotation">
              {`${adjustment.from} to ${adjustment.to}`}
            </text>
          );
        })}
        <text x={CHART_PADDING} y={CHART_PADDING - 12} className="axis-label">
          {`difficulty ${geometry.minDifficulty} to ${geometry.maxDifficulty}`}
        </text>
      </svg>

      {/* The heading and its table share one scroll wrapper; the e2e test reads the table as the heading's sibling. */}
      <div className="overflow-x-auto">
        <h3>Blocks</h3>
        <table>
          <thead>
            <tr>
              <th scope="col">Index</th>
              <th scope="col">Hash</th>
              <th scope="col">Difficulty</th>
              <th scope="col">Synthetic timestamp (ms)</th>
            </tr>
          </thead>
          <tbody>
            {result.blocks.map((block) => (
              <tr key={block.index}>
                <td>{block.index}</td>
                <td title={block.hash}>{shortHash(block.hash)}</td>
                <td>{block.difficulty}</td>
                <td>{block.timestamp}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="overflow-x-auto">
        <h3>Adjustments</h3>
        {result.adjustments.length === 0 ? (
          <p>No adjustment boundary was reached.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th scope="col">At block</th>
                <th scope="col">Actual ms</th>
                <th scope="col">Expected ms</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
              </tr>
            </thead>
            <tbody>
              {result.adjustments.map((adjustment) => (
                <tr key={adjustment.atIndex}>
                  <td>{adjustment.atIndex}</td>
                  <td>{adjustment.actualMs}</td>
                  <td>{adjustment.expectedMs}</td>
                  <td>{adjustment.from}</td>
                  <td>{adjustment.to}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </Panel>
  );
}
