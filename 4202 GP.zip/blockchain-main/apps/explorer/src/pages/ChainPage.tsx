import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { type Block } from "@conference-chain/shared/browser";
import { type BlockPage } from "../api";
import { formatTime, shortHash } from "../format";
import { useAsync } from "../hooks";
import { defaultApi } from "../services";
import { BlockGraph } from "../components/BlockGraph";
import { LiveDifficultyChart } from "../components/LiveDifficultyChart";
import { LIVE_CHART_WINDOW } from "../difficultySeries";
import { ErrorBox, Loading, RecordTable } from "../components/Shared";
import { Eyebrow, Page, Panel, PanelGrid } from "../components/Layout";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/Icon";

const PAGE_SIZE = 20;

export function ChainPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const cursor = params.get("cursor") ?? undefined;

  const mempool = useAsync(() => defaultApi.getMempool(), []);
  const blocks = useAsync<BlockPage>(
    () => defaultApi.getBlocks(cursor === undefined ? { limit: PAGE_SIZE } : { limit: PAGE_SIZE, cursor }),
    [cursor],
  );

  const chartBlocks = useAsync<BlockPage>(() => defaultApi.getBlocks({ limit: LIVE_CHART_WINDOW }), []);

  const head = chartBlocks.state.status === "ready" ? chartBlocks.state.value.blocks[0] : undefined;
  const pending = mempool.state.status === "ready" ? mempool.state.value.length : undefined;

  return (
    <Page title="Chain" icon="box" lead="Live state of this node: newest blocks, pending records and difficulty.">
      <Eyebrow>Overview</Eyebrow>
      <dl className="stats" aria-label="Chain summary">
        <div>
          <dt>
            <Icon name="box" />
            Head block
          </dt>
          <dd>{head === undefined ? "-" : `#${head.index}`}</dd>
        </div>
        <div>
          <dt>
            <Icon name="activity" />
            Difficulty
          </dt>
          <dd>{head === undefined ? "-" : head.difficulty}</dd>
        </div>
        <div>
          <dt>
            <Icon name="clock" />
            Last block
          </dt>
          <dd className="text-sm">{head === undefined ? "-" : formatTime(head.timestamp)}</dd>
        </div>
        <div>
          <dt>
            <Icon name="list" />
            Pending records
          </dt>
          <dd>{pending === undefined ? "-" : pending}</dd>
        </div>
      </dl>

      <Eyebrow>Blocks</Eyebrow>
      {chartBlocks.state.status === "ready" && (
        <Panel title="Block graph">
          <BlockGraph blocks={chartBlocks.state.value.blocks} onSelect={(index) => navigate(`/blocks/${index}`)} />
        </Panel>
      )}
      {chartBlocks.state.status === "error" && <ErrorBox error={chartBlocks.state.error} />}

      <Panel title="Latest blocks">
        {blocks.state.status === "loading" && <Loading />}
        {blocks.state.status === "error" && <ErrorBox error={blocks.state.error} />}
        {blocks.state.status === "ready" && <BlockTable blocks={blocks.state.value.blocks} />}
        <p className="mt-1 flex items-center gap-4">
          {cursor !== undefined && <Link to="/">Back to latest</Link>}
          {blocks.state.status === "ready" && blocks.state.value.nextCursor !== null && (
            <Link to={`/?cursor=${encodeURIComponent(blocks.state.value.nextCursor)}`}>Older blocks</Link>
          )}
        </p>
      </Panel>

      <Eyebrow>Pending and difficulty</Eyebrow>
      <PanelGrid>
        <Panel title="Mempool (pending records)">
          {mempool.state.status === "loading" && <Loading />}
          {mempool.state.status === "error" && <ErrorBox error={mempool.state.error} />}
          {mempool.state.status === "ready" && (
            <div className="overflow-x-auto">
              <RecordTable records={mempool.state.value} />
            </div>
          )}
          <p className="mt-1">
            <Button type="button" variant="outline" onClick={mempool.reload}>
              <Icon name="refresh" />
              Refresh mempool
            </Button>
          </p>
        </Panel>
        {chartBlocks.state.status === "ready" && <LiveDifficultyChart blocks={chartBlocks.state.value.blocks} />}
      </PanelGrid>
    </Page>
  );
}

function BlockTable({ blocks }: { blocks: readonly Block[] }) {
  if (blocks.length === 0) {
    return <p>No blocks.</p>;
  }
  return (
    <div className="overflow-x-auto">
    <table>
      <thead>
        <tr>
          <th scope="col">Index</th>
          <th scope="col">Hash</th>
          <th scope="col">Records</th>
          <th scope="col">Difficulty</th>
          <th scope="col">Time</th>
        </tr>
      </thead>
      <tbody>
        {blocks.map((block) => (
          <tr key={block.index}>
            <td>
              <Link to={`/blocks/${block.index}`}>{block.index}</Link>
            </td>
            <td title={block.hash}>{shortHash(block.hash)}</td>
            <td>{block.records.length}</td>
            <td>{block.difficulty}</td>
            <td>{formatTime(block.timestamp)}</td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  );
}
