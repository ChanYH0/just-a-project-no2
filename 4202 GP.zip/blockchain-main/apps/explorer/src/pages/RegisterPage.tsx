import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { Alias, ALIAS_MAX_CODE_POINTS, browserIdentityCrypto } from "@conference-chain/shared/browser";
import { defaultApi, defaultWallet } from "../services";
import { pollRecord, registerIdentity, type RegisterResult } from "../flows";
import type { RecordStatus } from "../api";
import { useAsync } from "../hooks";
import { useAuth } from "../auth";
import { ErrorBox, Loading, RecordStatusText } from "../components/Shared";
import { CopyButton } from "../components/CopyButton";
import { Page, Panel, focusMain } from "../components/Layout";
import { shortId } from "../format";
import type { WalletRecord } from "../wallet";
import { Button } from "@/components/ui/button";

const POLL_ATTEMPTS = 30;
const POLL_DELAY_MS = 2000;

interface Outcome {
  attendeeId: string;
  recordId: string;
  status: RecordStatus | null;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function RegisterPage() {
  const wallet = useAsync(() => defaultWallet.load(), []);
  const auth = useAuth();
  const [alias, setAlias] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<unknown>(null);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const replaceTitleRef = useRef<HTMLHeadingElement>(null);
  const restoreSubmitFocus = useRef(false);

  const aliasValid = Alias.safeParse(alias).success;
  const aliasLength = [...alias].length;
  const existing: WalletRecord | null = wallet.state.status === "ready" ? wallet.state.value : null;
  // An identity already exists and this browser is signed out: offer sign-in and rename the submit.
  const offerSignIn = existing !== null && auth.role === "guest";
  // Pending and confirmed outcomes hide the form. Expired or rejected ones allow a new submission.
  const canSubmit =
    outcome === null || (outcome.status !== null && (outcome.status.status === "expired" || outcome.status.status === "rejected"));

  // Focus the dialog heading when the replace confirmation opens; return focus to the submit button on Cancel.
  useEffect(() => {
    if (confirming) {
      replaceTitleRef.current?.focus();
      return;
    }
    if (restoreSubmitFocus.current) {
      restoreSubmitFocus.current = false;
      formRef.current?.querySelector<HTMLButtonElement>('button[type="submit"]')?.focus();
    }
  }, [confirming]);

  // Polls the record until it leaves pending or the attempts run out. Used after submit and by "Check status again".
  async function pollRegistration(attendeeId: string, recordId: string): Promise<void> {
    setBusy(true);
    setFailure(null);
    try {
      const status = await pollRecord(defaultApi, recordId, {
        attempts: POLL_ATTEMPTS,
        delayMs: POLL_DELAY_MS,
        sleep: delay,
      });
      setOutcome({ attendeeId, recordId, status });
    } catch (error) {
      setFailure(error);
    } finally {
      setBusy(false);
    }
  }

  async function submit(replaceExisting: boolean) {
    setBusy(true);
    setFailure(null);
    setOutcome(null);
    setConfirming(false);
    let registered: RegisterResult;
    try {
      registered = await registerIdentity(
        { api: defaultApi, identity: browserIdentityCrypto, wallet: defaultWallet, now: () => Date.now() },
        { alias, replaceExisting },
      );
    } catch (error) {
      setFailure(error);
      setBusy(false);
      return;
    }
    // The identity is stored only after the node accepted the registration, so this is the sign-in point.
    wallet.reload();
    auth.signIn();
    setOutcome({ attendeeId: registered.attendeeId, recordId: registered.recordId, status: null });
    await pollRegistration(registered.attendeeId, registered.recordId);
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!aliasValid || busy) {
      return;
    }
    if (existing !== null) {
      setConfirming(true);
      return;
    }
    void submit(false);
  }

  function cancelReplace() {
    restoreSubmitFocus.current = true;
    setConfirming(false);
  }

  return (
    <Page title="Register" icon="userPlus" lead="Create a browser-held identity and register a pseudonymous alias on the chain.">
      {wallet.state.status === "loading" && <Loading />}
      {wallet.state.status === "error" && <ErrorBox error={wallet.state.error} />}

      {existing !== null && offerSignIn && (
        <p>
          <Button
            type="button"
            onClick={() => {
              auth.signIn();
              focusMain();
            }}
          >
            Sign in as {existing.alias}
          </Button>
        </p>
      )}

      {existing !== null && (
        <p>
          This browser already holds an identity: alias <strong>{existing.alias}</strong>, attendee{" "}
          <span className="mono" title={existing.attendeeId}>
            {shortId(existing.attendeeId)}
          </span>
          .
        </p>
      )}

      <div role="note" className="warning">
        <p>
          <strong>Do not use your real name</strong> or any identifying detail as the alias. The alias and attendee id
          will be public on the chain permanently, and in the explorer.
        </p>
      </div>

      {canSubmit && (
        <form ref={formRef} onSubmit={onSubmit}>
          <label htmlFor="alias-input">Alias (pseudonym, 1 to {ALIAS_MAX_CODE_POINTS} characters)</label>
          <br />
          <input
            id="alias-input"
            value={alias}
            onChange={(event) => setAlias(event.target.value)}
            maxLength={ALIAS_MAX_CODE_POINTS}
            autoComplete="username"
            aria-invalid={alias.length > 0 && !aliasValid}
            aria-describedby="alias-help"
            disabled={busy}
          />
          <p id="alias-help" className="note">
            {aliasValid
              ? "Alias accepted."
              : `Use 1 to ${ALIAS_MAX_CODE_POINTS} characters. No leading or trailing spaces, and no invisible or control characters.`}{" "}
            <span>
              {aliasLength}/{ALIAS_MAX_CODE_POINTS}
            </span>
          </p>

          {confirming && existing !== null && (
            <div role="alertdialog" aria-labelledby="replace-title" aria-describedby="replace-body" className="warning">
              <h2 id="replace-title" tabIndex={-1} ref={replaceTitleRef}>
                Replace identity?
              </h2>
              <p id="replace-body">
                The current identity in this browser, alias <strong>{existing.alias}</strong> (attendee{" "}
                <span className="mono">{shortId(existing.attendeeId)}</span>), will be lost. It cannot be recovered,
                and this browser will no longer be able to check in as it.
              </p>
              <Button
                type="button"
                className="replace-confirm"
                onClick={() => void submit(true)}
                disabled={busy}
              >
                Replace identity and register
              </Button>{" "}
              <Button type="button" variant="outline" onClick={cancelReplace}>
                Cancel
              </Button>
            </div>
          )}

          {!confirming && (
            <Button type="submit" disabled={!aliasValid || busy}>
              {busy
                ? "Registering..."
                : offerSignIn
                  ? "Create a new identity instead"
                  : "Create identity and register"}
            </Button>
          )}
        </form>
      )}

      {failure !== null && <ErrorBox error={failure} />}

      {outcome !== null && (
        <>
          <div role="status">
            {outcome.status === null && busy && <p>Waiting for confirmation...</p>}
            {outcome.status !== null && (
              <p>
                Record status: <RecordStatusText status={outcome.status} />
              </p>
            )}
            {outcome.status?.status === "pending" && (
              <p>Registration submitted. Wait for confirmation before checking in.</p>
            )}
            {outcome.status?.status === "confirmed" && (
              <p>
                This browser is now signed in with this identity. <Link to="/check-in">Sign attendance</Link> or{" "}
                <Link to={`/attendees/${encodeURIComponent(outcome.attendeeId)}`}>view my profile</Link>.
              </p>
            )}
          </div>
          <p>
            Attendee <span className="mono">{outcome.attendeeId}</span>{" "}
            <CopyButton value={outcome.attendeeId} label="attendee id" />
          </p>
          <p>
            Record <span className="mono">{outcome.recordId}</span>{" "}
            <CopyButton value={outcome.recordId} label="record id" />
          </p>
          {!busy && outcome.status?.status !== "confirmed" && (
            <p>
              <Button
                type="button"
                variant="outline"
                onClick={() => void pollRegistration(outcome.attendeeId, outcome.recordId)}
              >
                Check status again
              </Button>
            </p>
          )}
        </>
      )}

      <Panel title="About this identity">
        <ul>
          <li>The private key is generated in this browser and stored in IndexedDB.</li>
          <li>
            The key is non-extractable: this page cannot export it. Non-extractable does not stop page scripts from using
            it. Any script running in this page (for example through an XSS bug) can still sign with the key.
          </li>
          <li>
            There is no key download and no key recovery. If this browser&apos;s site data is cleared, the identity is
            lost.
          </li>
        </ul>
        <p className="note">Your key stays in this browser. On a shared computer, clear site data to remove it.</p>
      </Panel>
    </Page>
  );
}
