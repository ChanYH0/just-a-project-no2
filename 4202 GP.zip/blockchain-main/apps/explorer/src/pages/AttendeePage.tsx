import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AttendeeId } from "@conference-chain/shared/browser";
import { formatTime } from "../format";
import { useAsync } from "../hooks";
import { defaultApi, defaultWallet } from "../services";
import { ErrorBox, Loading, isNotFound } from "../components/Shared";
import { FormRow, Page, Panel } from "../components/Layout";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/Icon";

export function AttendeePage() {
  const { attendeeId } = useParams();
  const navigate = useNavigate();
  const [input, setInput] = useState(attendeeId ?? "");
  const wallet = useAsync(() => defaultWallet.load(), []);
  const ownId = wallet.state.status === "ready" ? (wallet.state.value?.attendeeId ?? null) : null;
  const [inputError, setInputError] = useState<string | null>(null);

  // Signed-in browser: open the lookup on its own id unless a route id is already shown.
  useEffect(() => {
    if (ownId !== null && attendeeId === undefined) {
      setInput((current) => (current === "" ? ownId : current));
    }
  }, [ownId, attendeeId]);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // Attendee ids are lowercase hex; normalise before validating so pasted uppercase ids still work.
    const candidate = input.trim().toLowerCase();
    if (!AttendeeId.safeParse(candidate).success) {
      setInputError("An attendee id is 64 lowercase hex characters.");
      return;
    }
    setInputError(null);
    navigate(`/attendees/${encodeURIComponent(candidate)}`);
  }

  const lookupForm = (
    <FormRow onSubmit={onSubmit} describedBy="attendee-help">
      <label htmlFor="attendee-input">Attendee id</label>{" "}
      <input
        id="attendee-input"
        value={input}
        onChange={(event) => setInput(event.target.value)}
        autoComplete="off"
        spellCheck={false}
        aria-invalid={inputError !== null}
        aria-describedby={inputError !== null ? "attendee-error attendee-help" : "attendee-help"}
      />{" "}
      <Button type="submit">
        <Icon name="search" />
        Look up
      </Button>
      {ownId !== null && (
        <>
          {" "}
          <Button type="button" variant="outline" onClick={() => setInput(ownId)}>
            Use my id
          </Button>
        </>
      )}
      <p id="attendee-help" className="note">
        Lookups are public and show only pseudonymous data. Aliases are self-chosen labels and are not verified.
      </p>
      {inputError !== null && (
        <p id="attendee-error" role="alert">
          {inputError}
        </p>
      )}
    </FormRow>
  );

  return (
    <Page title="Attendee" icon="user" lead="Look up a pseudonymous attendee by id.">
      {lookupForm}
      {attendeeId !== undefined && <AttendeeDetails attendeeId={attendeeId} />}
    </Page>
  );
}

function AttendeeDetails({ attendeeId }: { attendeeId: string }) {
  const details = useAsync(async () => {
    const [registration, sessions] = await Promise.all([
      defaultApi.getAttendee(attendeeId),
      defaultApi.getAttendeeSessions(attendeeId),
    ]);
    return { registration, sessions };
  }, [attendeeId]);

  if (details.state.status === "loading") {
    return <Loading />;
  }
  if (details.state.status === "error") {
    if (isNotFound(details.state.error)) {
      return <p role="alert">This attendee id is not registered on the chain.</p>;
    }
    return <ErrorBox error={details.state.error} />;
  }

  const { registration, sessions } = details.state.value;
  return (
    <>
      <Panel title="Registration">
      <div className="overflow-x-auto">
      <table>
        <tbody>
          <tr>
            <th scope="row">Attendee id</th>
            <td className="mono">{registration.attendeeId}</td>
          </tr>
          <tr>
            <th scope="row">Alias</th>
            <td>{registration.alias}</td>
          </tr>
          <tr>
            <th scope="row">Registered at</th>
            <td>{formatTime(registration.registeredAt)}</td>
          </tr>
          <tr>
            <th scope="row">Block</th>
            <td>
              <Link to={`/blocks/${registration.blockIndex}`}>{registration.blockIndex}</Link>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
      </Panel>

      <Panel title="Sessions attended">
      {sessions.sessions.length === 0 ? (
        <p>No attendance records.</p>
      ) : (
        <div className="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th scope="col">Session</th>
              <th scope="col">Timestamp</th>
              <th scope="col">Block</th>
            </tr>
          </thead>
          <tbody>
            {sessions.sessions.map((item) => (
              <tr key={`${item.sessionId}-${item.blockIndex}-${item.timestamp}`}>
                <td>
                  <Link to={`/sessions/${encodeURIComponent(item.sessionId)}`}>{item.sessionId}</Link>
                </td>
                <td>{formatTime(item.timestamp)}</td>
                <td>
                  <Link to={`/blocks/${item.blockIndex}`}>{item.blockIndex}</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      )}
      </Panel>
    </>
  );
}
