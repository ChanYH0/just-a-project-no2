import { useState, type FormEvent } from "react";
import { defaultApi } from "../services";
import { TAMPER_MUTATIONS, type TamperMutation, type ValidateResult } from "../api";
import { useAsync } from "../hooks";
import { ErrorBox, Loading } from "../components/Shared";
import { FormRow, Page, Panel } from "../components/Layout";
import { Button } from "@/components/ui/button";

export function ValidatePage() {
  const demo = useAsync<boolean>(async () => {
    const info = await defaultApi.getChainInfo();
    if (info.demoRoutesEnabled) {
      return true;
    }
    return defaultApi.probeDemoRoutes();
  }, []);

  return (
    <Page title="Validate" icon="shieldCheck" lead="Ask the node to re-check the whole chain.">
      <LiveValidation />
      {demo.state.status === "loading" && <Loading />}
      {demo.state.status === "error" && <ErrorBox error={demo.state.error} />}
      {demo.state.status === "ready" && demo.state.value && <TamperPanel />}
    </Page>
  );
}

function LiveValidation() {
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<unknown>(null);
  const [result, setResult] = useState<ValidateResult | null>(null);

  async function run() {
    setBusy(true);
    setFailure(null);
    try {
      setResult(await defaultApi.getChainValidate());
    } catch (error) {
      setResult(null);
      setFailure(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Panel title="Validate the live chain">
      <p>
        The node re-validates its stored chain file with the shared validator and reports the first failure, if any.
      </p>
      <Button type="button" variant="outline" onClick={() => void run()} disabled={busy}>
        {busy ? "Validating..." : "Run validation"}
      </Button>
      {failure !== null && <ErrorBox error={failure} />}
      {result !== null && (
        <p role="status">
          {result.ok
            ? "Chain is valid."
            : `Chain is invalid: ${result.code ?? "unknown code"}${
                result.blockIndex !== undefined ? ` at block ${result.blockIndex}` : ""
              }.`}
        </p>
      )}
    </Panel>
  );
}

function TamperPanel() {
  const [mutation, setMutation] = useState<TamperMutation>(TAMPER_MUTATIONS[0]);
  const [blockIndex, setBlockIndex] = useState("1");
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<unknown>(null);
  const [raw, setRaw] = useState<Record<string, unknown> | null>(null);

  const parsedIndex = /^[1-9][0-9]*$/.test(blockIndex) ? Number(blockIndex) : null;

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (parsedIndex === null || !Number.isSafeInteger(parsedIndex) || busy) {
      return;
    }
    setBusy(true);
    setFailure(null);
    setRaw(null);
    try {
      setRaw(await defaultApi.postTamperCheck({ mutation, blockIndex: parsedIndex }));
    } catch (error) {
      setFailure(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Panel title="Demo: tamper check">
      <p className="note">
        Demo routes are enabled on this node. The copy of the chain is tampered in memory and checked by the real
        validator. The live chain is not changed. The result below is the node&apos;s raw output.
      </p>
      <FormRow onSubmit={onSubmit}>
        <label htmlFor="mutation-select">Mutation</label>{" "}
        <select
          id="mutation-select"
          value={mutation}
          onChange={(event) => {
            const next = TAMPER_MUTATIONS.find((name) => name === event.target.value);
            if (next !== undefined) {
              setMutation(next);
            }
          }}
        >
          {TAMPER_MUTATIONS.map((name) => (
            <option key={name} value={name}>
              {name}
            </option>
          ))}
        </select>{" "}
        <label htmlFor="tamper-block">Block index (1 or more)</label>{" "}
        <input
          id="tamper-block"
          type="number"
          min={1}
          step={1}
          value={blockIndex}
          onChange={(event) => setBlockIndex(event.target.value)}
          aria-invalid={parsedIndex === null}
        />{" "}
        <Button type="submit" disabled={parsedIndex === null || busy}>
          {busy ? "Running..." : "Run tamper check"}
        </Button>
      </FormRow>
      {failure !== null && <ErrorBox error={failure} />}
      {raw !== null && (
        <pre aria-label="Raw tamper-check result">{JSON.stringify(raw, null, 2)}</pre>
      )}
    </Panel>
  );
}
