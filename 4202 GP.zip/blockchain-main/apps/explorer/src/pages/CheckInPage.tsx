import { useEffect, useState, type FormEvent } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { browserIdentityCrypto } from "@conference-chain/shared/browser";
import type { RecordStatus } from "../api";
import { checkIn, pollRecord } from "../flows";
import { useAsync } from "../hooks";
import { useAuth } from "../auth";
import { defaultApi, defaultWallet } from "../services";
import { ErrorBox, Loading, RecordStatusText, isNotFound } from "../components/Shared";
import { CopyButton } from "../components/CopyButton";
import { FormRow, Page, Panel } from "../components/Layout";
import { shortId } from "../format";
import { Button } from "@/components/ui/button";

const POLL_ATTEMPTS = 30;
const POLL_DELAY_MS = 2000;

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function CheckInPage() {
  const sessions = useAsync(() => defaultApi.getSessions(), []);
  const wallet = useAsync(() => defaultWallet.load(), []);
  const auth = useAuth();
  const [params] = useSearchParams();
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<unknown>(null);
  const [result, setResult] = useState<{ recordId: string; status: RecordStatus | null } | null>(null);
  const [elapsed, setElapsed] = useState(0);

  const ownId = wallet.state.status === "ready" && wallet.state.value !== null ? wallet.state.value.attendeeId : null;
  // Is this browser's identity confirmed on the chain? A 404 means it is not recorded yet.
  const registration = useAsync<boolean | null>(
    () =>
      ownId === null
        ? Promise.resolve(null)
        : defaultApi.getAttendee(ownId).then(
            () => true,
            (error: unknown) => {
              if (isNotFound(error)) {
                return false;
              }
              throw error;
            },
          ),
    [ownId],
  );
  const notConfirmed = registration.state.status === "ready" && registration.state.value === false;

  const polling = busy && result !== null && result.status === null;
  // Elapsed seconds while the record is polled. Restarts for each submission.
  useEffect(() => {
    if (!polling) {
      return;
    }
    const started = Date.now();
    setElapsed(0);
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [polling]);

  // Pre-fill: ?session=<id> if it is in the catalog, else the only session when there is exactly one.
  const catalog = sessions.state.status === "ready" ? sessions.state.value : [];
  const requested = params.get("session");
  const preset =
    requested !== null && catalog.some((item) => item.id === requested)
      ? requested
      : catalog.length === 1
        ? (catalog[0]?.id ?? "")
        : "";
  const sessionId = picked ?? preset;

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (sessionId === "" || busy || notConfirmed) {
      return;
    }
    setBusy(true);
    setFailure(null);
    setResult(null);
    try {
      const submitted = await checkIn(
        { api: defaultApi, identity: browserIdentityCrypto, wallet: defaultWallet, now: () => Date.now() },
        sessionId,
      );
      setResult({ recordId: submitted.recordId, status: null });
      const status = await pollRecord(defaultApi, submitted.recordId, {
        attempts: POLL_ATTEMPTS,
        delayMs: POLL_DELAY_MS,
        sleep: delay,
      });
      setResult({ recordId: submitted.recordId, status });
    } catch (error) {
      // Drop the waiting state so a failed poll never shows a stale "waiting" line.
      setResult(null);
      setFailure(error);
    } finally {
      setBusy(false);
    }
  }

  if (auth.loading || wallet.state.status === "loading" || sessions.state.status === "loading") {
    return (
      <Page title="Check in">
        <Loading />
      </Page>
    );
  }
  if (wallet.state.status === "error") {
    return (
      <Page title="Check in">
        <ErrorBox error={wallet.state.error} />
      </Page>
    );
  }
  if (wallet.state.value === null || auth.role === "guest") {
    return (
      <Page title="Check in">
        <p>
          {wallet.state.value === null ? (
            <>
              This browser has no identity yet. <Link to="/register">Register first</Link>.
            </>
          ) : (
            <>You are logged out. Use the identity button in the header to check in.</>
          )}
        </p>
      </Page>
    );
  }
  if (sessions.state.status === "error") {
    return (
      <Page title="Check in">
        <ErrorBox error={sessions.state.error} />
      </Page>
    );
  }

  const identity = wallet.state.value;
  const profilePath = `/attendees/${encodeURIComponent(identity.attendeeId)}`;
  return (
    <Page title="Check in" icon="checkCircle" lead="Sign a record that you attended a session.">
      <Panel title="Sign attendance">
        <p>
          Signing as <strong>{identity.alias}</strong> (attendee <span className="mono">{shortId(identity.attendeeId)}</span>{" "}
          <CopyButton value={identity.attendeeId} label="attendee id" />).
        </p>
        {notConfirmed && (
          <div role="note" className="warning">
            <p>
              Your registration is not confirmed yet. <Link to={profilePath}>Check your profile</Link>.
            </p>
          </div>
        )}
        {registration.state.status === "error" && <ErrorBox error={registration.state.error} />}
        <FormRow onSubmit={onSubmit}>
          <label htmlFor="session-select">Session</label>{" "}
          <select
            id="session-select"
            value={sessionId}
            onChange={(event) => setPicked(event.target.value)}
            disabled={busy}
          >
            <option value="">Choose a session</option>
            {sessions.state.value.map((session) => (
              <option key={session.id} value={session.id}>
                {session.title} ({session.id})
              </option>
            ))}
          </select>{" "}
          <Button type="submit" disabled={sessionId === "" || busy || notConfirmed}>
            {busy ? (result !== null ? "Waiting for block..." : "Submitting...") : "Sign and submit attendance"}
          </Button>
        </FormRow>

        {failure !== null && <ErrorBox error={failure} />}
        {result !== null && (
          <div role="status">
            <p>
              Record <span className="mono">{result.recordId}</span>{" "}
              <CopyButton value={result.recordId} label="record id" />:{" "}
              {result.status === null ? (
                <>waiting for confirmation... ({elapsed} s)</>
              ) : (
                <RecordStatusText status={result.status} />
              )}
            </p>
            {result.status?.status === "pending" && (
              <p>
                Still pending; it may confirm later. <Link to={profilePath}>Check your profile.</Link>
              </p>
            )}
            {result.status?.status === "expired" && <p>Not recorded. Submit again.</p>}
          </div>
        )}
      </Panel>
    </Page>
  );
}
