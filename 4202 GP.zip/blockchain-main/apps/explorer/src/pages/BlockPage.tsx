import { Link, useParams } from "react-router-dom";
import { formatTime } from "../format";
import { useAsync } from "../hooks";
import { defaultApi } from "../services";
import { ErrorBox, Loading, RecordTable, TrustNote, isNotFound } from "../components/Shared";
import { Page, Panel } from "../components/Layout";

// Decimal block index: no sign, no leading zeros, safe integer (SPEC section 5.1 NonNegativeInt).
export function parseBlockIndex(raw: string | undefined): number | null {
  if (raw === undefined || !/^(0|[1-9][0-9]*)$/.test(raw)) {
    return null;
  }
  const value = Number(raw);
  return Number.isSafeInteger(value) ? value : null;
}

export function BlockPage() {
  const { index: rawIndex } = useParams();
  const index = parseBlockIndex(rawIndex);

  const block = useAsync(async () => {
    if (index === null) {
      throw new Error("block index must be a non-negative integer");
    }
    return defaultApi.getBlock(index);
  }, [rawIndex]);
  const health = useAsync(() => defaultApi.getHealth(), []);

  if (block.state.status === "loading") {
    return (
      <Page title={`Block ${rawIndex ?? ""}`}>
        <Loading />
      </Page>
    );
  }
  if (block.state.status === "error") {
    return (
      <Page title={`Block ${rawIndex ?? ""}`}>
        {isNotFound(block.state.error) ? (
          <p role="alert">Block {rawIndex} does not exist.</p>
        ) : (
          <ErrorBox error={block.state.error} />
        )}
      </Page>
    );
  }

  const view = block.state.value;
  const headIndex = health.state.status === "ready" ? health.state.value.headIndex : null;
  return (
    <Page title={`Block ${view.index}`}>
      <nav aria-label="Block navigation">
        {view.index > 0 && <Link to={`/blocks/${view.index - 1}`}>Previous block</Link>}
        {headIndex !== null && view.index < headIndex && (
          <>
            {view.index > 0 && " | "}
            <Link to={`/blocks/${view.index + 1}`}>Next block</Link>
          </>
        )}
      </nav>

      <Panel title="Block details">
      <div className="overflow-x-auto">
      <table>
        <tbody>
          <tr>
            <th scope="row">Hash</th>
            <td className="mono">{view.hash}</td>
          </tr>
          <tr>
            <th scope="row">Previous hash</th>
            <td className="mono">{view.previousHash}</td>
          </tr>
          <tr>
            <th scope="row">Timestamp</th>
            <td>{formatTime(view.timestamp)}</td>
          </tr>
          <tr>
            <th scope="row">Difficulty</th>
            <td>{view.difficulty}</td>
          </tr>
          <tr>
            <th scope="row">Nonce</th>
            <td>{view.nonce}</td>
          </tr>
          <tr>
            <th scope="row">Hash valid (node)</th>
            <td>{view.verification.hashValid ? "yes" : "no"}</td>
          </tr>
          <tr>
            <th scope="row">Proof of work valid (node)</th>
            <td>{view.verification.powValid ? "yes" : "no"}</td>
          </tr>
        </tbody>
      </table>
      </div>
      <TrustNote />
      </Panel>

      <Panel title={`Records (${view.records.length})`}>
        <RecordTable records={view.records} />
      </Panel>
    </Page>
  );
}
