import { useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { SessionId } from "@conference-chain/shared/browser";
import { formatTime, shortId } from "../format";
import { useAsync } from "../hooks";
import { defaultApi } from "../services";
import { ErrorBox, Loading } from "../components/Shared";
import { FormRow, Page, Panel } from "../components/Layout";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/Icon";

export function SessionPage() {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const [input, setInput] = useState(sessionId ?? "");
  const [inputError, setInputError] = useState<string | null>(null);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const candidate = input.trim();
    if (!SessionId.safeParse(candidate).success) {
      setInputError("A session id is 1 to 64 characters of letters, digits, underscore or hyphen.");
      return;
    }
    setInputError(null);
    navigate(`/sessions/${encodeURIComponent(candidate)}`);
  }

  return (
    <Page title="Session" icon="calendar" lead="See who attended a session.">
      <FormRow onSubmit={onSubmit}>
        <label htmlFor="session-input">Session id</label>{" "}
        <input
          id="session-input"
          value={input}
          onChange={(event) => setInput(event.target.value)}
          autoComplete="off"
          spellCheck={false}
          aria-invalid={inputError !== null}
          aria-describedby={inputError !== null ? "session-error session-help" : "session-help"}
        />{" "}
        <Button type="submit">
          <Icon name="search" />
          Look up
        </Button>
        <p id="session-help" className="note">
          Aliases are self-chosen labels and are not verified.
        </p>
        {inputError !== null && (
          <p id="session-error" role="alert">
            {inputError}
          </p>
        )}
      </FormRow>
      {sessionId !== undefined && <SessionDetails sessionId={sessionId} />}
    </Page>
  );
}

function SessionDetails({ sessionId }: { sessionId: string }) {
  const attendees = useAsync(() => defaultApi.getSessionAttendees(sessionId), [sessionId]);

  if (attendees.state.status === "loading") {
    return <Loading />;
  }
  if (attendees.state.status === "error") {
    return <ErrorBox error={attendees.state.error} />;
  }

  const list = attendees.state.value.attendees;
  return (
    <Panel title={`Attendees of ${attendees.state.value.sessionId}`}>
      {list.length === 0 ? (
        <p>No attendance records for this session.</p>
      ) : (
        <div className="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th scope="col">Alias</th>
              <th scope="col">Attendee</th>
              <th scope="col">Timestamp</th>
              <th scope="col">Block</th>
            </tr>
          </thead>
          <tbody>
            {list.map((item) => (
              <tr key={`${item.attendeeId}-${item.blockIndex}`}>
                <td>{item.alias}</td>
                <td>
                  <Link to={`/attendees/${encodeURIComponent(item.attendeeId)}`} title={item.attendeeId}>
                    {shortId(item.attendeeId)}
                  </Link>
                </td>
                <td>{formatTime(item.timestamp)}</td>
                <td>
                  <Link to={`/blocks/${item.blockIndex}`}>{item.blockIndex}</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      )}
    </Panel>
  );
}
