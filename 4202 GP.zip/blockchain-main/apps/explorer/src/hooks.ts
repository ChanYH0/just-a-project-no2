import { useCallback, useEffect, useState } from "react";

export type AsyncState<T> =
  | { status: "loading" }
  | { status: "ready"; value: T }
  | { status: "error"; error: unknown };

export interface AsyncResult<T> {
  state: AsyncState<T>;
  reload: () => void;
}

// Runs `load` when the dependencies change or reload() is called. Stale results are ignored.
export function useAsync<T>(load: () => Promise<T>, deps: readonly unknown[]): AsyncResult<T> {
  const [state, setState] = useState<AsyncState<T>>({ status: "loading" });
  const [generation, setGeneration] = useState(0);

  useEffect(() => {
    let active = true;
    setState({ status: "loading" });
    load().then(
      (value) => {
        if (active) {
          setState({ status: "ready", value });
        }
      },
      (error: unknown) => {
        if (active) {
          setState({ status: "error", error });
        }
      },
    );
    return () => {
      active = false;
    };
    // The caller controls the dependency list; `load` is intentionally not a dependency.
  }, [...deps, generation]);

  const reload = useCallback(() => setGeneration((value) => value + 1), []);
  return { state, reload };
}
