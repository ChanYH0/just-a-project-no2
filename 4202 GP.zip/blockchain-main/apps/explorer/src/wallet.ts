// Browser wallet: one non-extractable RSA private key plus its public identity, stored in IndexedDB.
// The store is injected (WalletStore) so flows run in node tests with fake-indexeddb.
// A stored record that fails validation is an error, never silently ignored.

import { Alias, AttendeeId, PublicKey } from "@conference-chain/shared/browser";
import { isRecord } from "./guards";

export const WALLET_DB_NAME = "wallet";
export const WALLET_DB_VERSION = 1;
export const WALLET_STORE_NAME = "keys";
export const WALLET_RECORD_KEY = "current";

export interface WalletRecord {
  attendeeId: string;
  publicKey: string;
  privateKey: CryptoKey;
  alias: string;
}

export interface WalletStore {
  load(): Promise<WalletRecord | null>;
  save(record: WalletRecord): Promise<void>;
}

export function isCryptoKey(value: unknown): value is CryptoKey {
  return typeof CryptoKey !== "undefined" && value instanceof CryptoKey;
}

function parseWalletRecord(value: unknown): WalletRecord {
  if (!isRecord(value)) {
    throw new Error("wallet record is malformed");
  }
  const { attendeeId, publicKey, privateKey, alias } = value;
  if (
    typeof attendeeId !== "string" ||
    !AttendeeId.safeParse(attendeeId).success ||
    typeof publicKey !== "string" ||
    !PublicKey.safeParse(publicKey).success ||
    typeof alias !== "string" ||
    !Alias.safeParse(alias).success ||
    !isCryptoKey(privateKey) ||
    privateKey.type !== "private"
  ) {
    throw new Error("wallet record is malformed");
  }
  return { attendeeId, publicKey, privateKey, alias };
}

function openWalletDb(factory: IDBFactory): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = factory.open(WALLET_DB_NAME, WALLET_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(WALLET_STORE_NAME)) {
        db.createObjectStore(WALLET_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("wallet database could not be opened"));
    request.onblocked = () => reject(new Error("wallet database is blocked by another connection"));
  });
}

function readCurrent(db: IDBDatabase): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const request = db.transaction(WALLET_STORE_NAME, "readonly").objectStore(WALLET_STORE_NAME).get(WALLET_RECORD_KEY);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("wallet read failed"));
  });
}

// Resolves only after the transaction commits, so a resolved save is durable.
function writeCurrent(db: IDBDatabase, record: WalletRecord): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(WALLET_STORE_NAME, "readwrite");
    transaction.objectStore(WALLET_STORE_NAME).put(record, WALLET_RECORD_KEY);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(new Error("wallet write failed"));
    transaction.onabort = () => reject(new Error("wallet write aborted"));
  });
}

// Opens a connection per operation and closes it afterwards, so re-opening after a reload is simply a new store.
export function createIndexedDbWalletStore(factory: IDBFactory): WalletStore {
  return {
    async load() {
      const db = await openWalletDb(factory);
      try {
        const raw = await readCurrent(db);
        return raw === undefined ? null : parseWalletRecord(raw);
      } finally {
        db.close();
      }
    },

    async save(record) {
      const validated = parseWalletRecord(record);
      const db = await openWalletDb(factory);
      try {
        await writeCurrent(db, validated);
      } finally {
        db.close();
      }
    },
  };
}
