import { Link, NavLink, Route, Routes } from "react-router-dom";
import { BlockPage } from "./pages/BlockPage";
import { AttendeePage } from "./pages/AttendeePage";
import { ChainPage } from "./pages/ChainPage";
import { CheckInPage } from "./pages/CheckInPage";
import { DifficultyDemoPage } from "./pages/DifficultyDemoPage";
import { RegisterPage } from "./pages/RegisterPage";
import { SessionPage } from "./pages/SessionPage";
import { ValidatePage } from "./pages/ValidatePage";
import { Icon } from "./components/Icon";
import { useAuth } from "./auth";
import { AccountBadge } from "./components/AccountBadge";
import { ThemeToggle } from "./components/ThemeToggle";
import { Page, SITE_NAME } from "./components/Layout";
import { useAsync } from "./hooks";
import { defaultApi } from "./services";

function NotFound() {
  return (
    <Page title="Page not found">
      <p role="alert">Page not found.</p>
      <p>
        <Link to="/">Back to Chain</Link>
      </p>
    </Page>
  );
}

export function App() {
  const auth = useAuth();
  const signedIn = auth.role === "attendee";
  // The demo nav item is shown only when the node exposes the demo routes.
  const demo = useAsync(() => defaultApi.probeDemoRoutes(), []);
  const demoEnabled = demo.state.status === "ready" && demo.state.value;
  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="site-header">
        <div className="site-header-inner">
        <p className="brand">
          <Icon name="link" />
          {SITE_NAME}
        </p>
        <nav aria-label="Main">
          <ul className="nav-list">
            <li>
              <NavLink to="/" end>
                <Icon name="box" />
                Chain
              </NavLink>
            </li>
            {!signedIn && (
            <li>
              <NavLink to="/register">
                <Icon name="userPlus" />
                Register
              </NavLink>
            </li>
            )}
            {signedIn && (
            <li>
              <NavLink to="/check-in">
                <Icon name="checkCircle" />
                Check in
              </NavLink>
            </li>
            )}
            <li>
              <NavLink to="/attendees">
                <Icon name="user" />
                Attendee
              </NavLink>
            </li>
            <li>
              <NavLink to="/sessions">
                <Icon name="calendar" />
                Session
              </NavLink>
            </li>
            <li>
              <NavLink to="/validate">
                <Icon name="shieldCheck" />
                Validate
              </NavLink>
            </li>
            {demoEnabled && (
            <li>
              <NavLink to="/difficulty-demo">
                <Icon name="activity" />
                Difficulty demo
              </NavLink>
            </li>
            )}
          </ul>
        </nav>
        <div className="header-actions">
          <AccountBadge />
          <ThemeToggle />
        </div>
        </div>
      </header>

      <main id="main" tabIndex={-1}>
        <Routes>
          <Route path="/" element={<ChainPage />} />
          <Route path="/blocks/:index" element={<BlockPage />} />
          <Route path="/attendees" element={<AttendeePage />} />
          <Route path="/attendees/:attendeeId" element={<AttendeePage />} />
          <Route path="/sessions" element={<SessionPage />} />
          <Route path="/sessions/:sessionId" element={<SessionPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/check-in" element={<CheckInPage />} />
          <Route path="/validate" element={<ValidatePage />} />
          <Route path="/difficulty-demo" element={<DifficultyDemoPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer className="site-footer">
        <p>
          The explorer is a thin client. It trusts the node&apos;s verification flags (hash and proof of work) and does
          not verify the chain itself.
        </p>
        <p><a href="/api/docs">Interactive API reference</a></p>
      </footer>
    </>
  );
}
