import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// Dev server and API proxy (SPEC section 3). The explorer always calls `/api/...`;
// the proxy strips the prefix and forwards to the node. The node origin may be
// overridden with NODE_API_ORIGIN, which is read only here at config time.
const EXPLORER_PORT = 5173;
const DEFAULT_NODE_API_ORIGIN = "http://localhost:3000";
const API_PREFIX = "/api";

const nodeOrigin = process.env.NODE_API_ORIGIN ?? DEFAULT_NODE_API_ORIGIN;

const apiProxy = {
  [API_PREFIX]: {
    target: nodeOrigin,
    changeOrigin: false,
    rewrite: (path: string) => path.slice(API_PREFIX.length),
  },
};

// Dev server only (apply: "serve"): Vite HMR injects inline <style> and the React refresh preamble,
// which the strict CSP in index.html blocks. Remove that meta tag while serving; `vite build` and
// `vite preview` keep it, and the static-boundaries test pins the policy in index.html itself.
const cspMetaTag = /<meta\s+http-equiv="Content-Security-Policy"[^>]*>/s;
const devCspRelaxation = {
  name: "explorer-dev-without-csp",
  apply: "serve" as const,
  transformIndexHtml: (html: string) => html.replace(cspMetaTag, ""),
};

export default defineConfig({
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  plugins: [react(), tailwindcss(), devCspRelaxation],
  server: {
    port: EXPLORER_PORT,
    strictPort: true,
    proxy: apiProxy,
  },
  preview: {
    proxy: apiProxy,
  },
});
