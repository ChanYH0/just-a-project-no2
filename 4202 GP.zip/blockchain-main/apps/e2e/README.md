# @conference-chain/e2e

Playwright tests 17-20 cover `docs/SPEC.md` section 14.4 (register, check in, tamper demo, difficulty demo). Test 21 covers wallet reload, hide/restore, and duplicate attendance. Test 22 submits signed records through the real HTTP API, checks FIFO order and proof of work, and crosses a live difficulty boundary without synthetic timestamps or demo routes. Test 23 loads the self-hosted OpenAPI reference through the explorer proxy and makes a health request.

The demo tests can wait out the node's heavy-request rate limit (6 per IP per 60 s). Install Chromium with the workspace's pinned Playwright version using the command below.

## What it starts

`playwright.config.ts` starts two servers on fixed ports (see `e2e-env.ts`):

- node on `127.0.0.1:3100` via `scripts/start-node.mjs`: `PROFILE=demo`, `ENABLE_DEMO_ROUTES=true`,
  `CONFERENCE_ID=conf-e2e-2026`, `SESSIONS_FILE=apps/node/sessions.example.json`, and a fresh temp `DATA_DIR`
  (created by the launcher and removed on exit; Playwright starts `webServer` entries before `globalSetup`, so a
  globalSetup could not provide it in time).
- explorer (vite) on `127.0.0.1:5273` with `NODE_API_ORIGIN` pointing at the node. `--port` on the CLI overrides the
  config's `5173`; `strictPort` stays on.

## Run

```bash
pnpm install
pnpm --filter @conference-chain/e2e exec playwright install chromium
pnpm --filter @conference-chain/e2e test
```

Tests run serially (one worker) on one shared chain. No `data-testid` attributes were added to the explorer.

## Recorded browser validation (2026-11-08)

Tests 17-23 passed **7/7** in each of these configurations:

- **Metal2:** native macOS node with `MINING_BACKEND=metal` and two mining workers; Playwright starts Vite locally. This node is not in Docker because the Linux container runtime cannot use the Mac's Metal device.
- **CPU4:** isolated, built Linux Compose stack with four CPU mining workers, demo routes enabled, and a fresh data volume. Playwright targets the explorer at `127.0.0.1:18082` through its `/api` proxy.

To rerun Metal2, build the helper, then let Playwright start the native node and Vite:

```bash
pnpm --filter @conference-chain/node build:metal
MINING_BACKEND=metal MINING_WORKERS=2 HEAVY_RATE_LIMIT=60 \
  pnpm --filter @conference-chain/e2e test
```

For CPU4, start a dedicated Compose stack with `CHAIN_PROFILE=demo`, `CHAIN_ENABLE_DEMO_ROUTES=true`, `CHAIN_MINING_WORKERS=4`, and `EXPLORER_PORT=18082` in `chain.env`, then run:

```bash
E2E_EXTERNAL_URL=http://127.0.0.1:18082 \
  pnpm --filter @conference-chain/e2e test
```

The Metal run's screenshots and mining JSON are in [`evidence/gpu-integration-2026-11-08`](../../evidence/gpu-integration-2026-11-08/); the CPU run's are in [`evidence/cpu-integration-2026-11-08`](../../evidence/cpu-integration-2026-11-08/). These artifacts demonstrate the browser and real-mining paths under those configurations. They are not profiler measurements; see [Metal mining and profiler traces](../../docs/METAL_MINING.md) and [mining performance](../../docs/MINING_PERFORMANCE.md) for the separate trace evidence.

The 2026-11-03 run covered tests 17-20 only (4 passed) and is historical.

To test a separately started stack through its same-origin `/api` proxy:

```bash
E2E_EXTERNAL_URL=http://127.0.0.1:18080 pnpm --filter @conference-chain/e2e test
```

This mode starts no servers. Use an isolated demo deployment with demo routes enabled and a fresh data volume: tests write registrations and attendance to its chain. The external stack must use the checked-in example session catalog. Test 21 saves a browser screenshot in its ignored `test-results` output directory.

The mining-only test also works with demo routes disabled:

```bash
E2E_EXTERNAL_URL=http://127.0.0.1:18081 \
  pnpm --filter @conference-chain/e2e exec playwright test tests/22-mining.spec.ts
```

It writes a block-detail screenshot and `mining-evidence.json` under its `test-results` directory, including actual nonces, hashes, timestamps, difficulty adjustments, and sampled record/health states. Sampled states can miss a short mining job; the cancellation unit/integration tests use a deliberately infeasible candidate in a real worker to verify event-loop responsiveness while mining. `apps/node/test/mining-batch.test.ts` separately checks the full block/overflow boundary using real workers with injected clock and timers.
