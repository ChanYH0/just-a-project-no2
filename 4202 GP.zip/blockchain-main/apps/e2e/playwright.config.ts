// Playwright config: real node (demo profile, demo routes on, temp DATA_DIR via scripts/start-node.mjs) plus the
// explorer dev server, or an explicitly selected external stack via E2E_EXTERNAL_URL.

import { resolve } from "node:path";
import { defineConfig } from "@playwright/test";
import { CONFERENCE_ID, EXPLORER_ORIGIN, EXPLORER_PORT, HOST, NODE_ORIGIN, NODE_PORT } from "./e2e-env.js";

const explorerDir = resolve(import.meta.dirname, "../explorer");

export default defineConfig({
  testDir: "./tests",
  // The specs share one chain and one node; run them one at a time in file order.
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 180_000,
  expect: { timeout: 15_000 },
  reporter: [["list"]],
  use: {
    baseURL: EXPLORER_ORIGIN,
    trace: "retain-on-failure",
    launchOptions: process.env.E2E_CHROMIUM_PATH ? { executablePath: process.env.E2E_CHROMIUM_PATH } : {},
  },
  webServer: process.env.E2E_EXTERNAL_URL ? [] : [
    {
      command: "node scripts/start-node.mjs",
      cwd: import.meta.dirname,
      url: `${NODE_ORIGIN}/health`,
      reuseExistingServer: false,
      timeout: 60_000,
      env: { CONFERENCE_ID, PORT: String(NODE_PORT), HOST },
    },
    {
      // --port overrides server.port in vite.config.ts; strictPort stays on, so a busy port fails loudly.
      command: `pnpm exec vite --host ${HOST} --port ${EXPLORER_PORT}`,
      cwd: explorerDir,
      url: EXPLORER_ORIGIN,
      reuseExistingServer: false,
      timeout: 60_000,
      env: { NODE_API_ORIGIN: NODE_ORIGIN },
    },
  ],
});
