// Single definition of the fixed e2e ports, origins and the conference id (imported by the config and the specs).

export const NODE_PORT = 3100;
export const EXPLORER_PORT = 5273;
export const HOST = "127.0.0.1";
// An external stack is tested through its same-origin proxy; otherwise start local servers.
export const EXPLORER_ORIGIN = process.env.E2E_EXTERNAL_URL ?? `http://${HOST}:${EXPLORER_PORT}`;
export const NODE_ORIGIN = process.env.E2E_EXTERNAL_URL
  ? `${EXPLORER_ORIGIN}/api`
  : `http://${HOST}:${NODE_PORT}`;
export const CONFERENCE_ID = "conf-e2e-2026";
// Session ids come from apps/node/sessions.example.json.
export const SESSION_ID = "opening-keynote";
