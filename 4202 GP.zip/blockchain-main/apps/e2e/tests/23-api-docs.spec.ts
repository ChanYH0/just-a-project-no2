import { expect, test } from "@playwright/test";
import { EXPLORER_ORIGIN } from "../e2e-env.js";

test("23: self-hosted OpenAPI UI loads through the explorer proxy and executes a health request", async ({ page }, testInfo) => {
  const offOrigin: string[] = [];
  const browserErrors: string[] = [];
  const expectedOrigin = new URL(EXPLORER_ORIGIN).origin;
  page.on("request", (request) => {
    const url = new URL(request.url());
    if ((url.protocol === "http:" || url.protocol === "https:") && url.origin !== expectedOrigin) offOrigin.push(url.origin);
  });
  page.on("pageerror", (error) => browserErrors.push(error.message));
  await page.goto("/");
  const spec = page.waitForResponse((response) => response.url().endsWith("/api/openapi.json") && response.ok());
  await page.getByRole("link", { name: "Interactive API reference" }).click();
  await spec;
  await expect(page.getByRole("heading", { name: "Conference Chain API", exact: false })).toBeVisible();
  const health = page.locator(".opblock").filter({ has: page.locator('[data-path="/health"]') });
  await expect(health).toHaveCount(1);
  await health.locator(".opblock-summary-control").click();
  await health.getByRole("button", { name: "Try it out" }).click();
  const healthResponse = page.waitForResponse((response) => response.url().endsWith("/api/health") && response.ok());
  await health.getByRole("button", { name: "Execute", exact: true }).click();
  await healthResponse;
  await expect(health.locator(".responses-wrapper")).toContainText('"ok": true');
  expect(offOrigin).toEqual([]);
  expect(browserErrors).toEqual([]);
  await page.screenshot({ path: testInfo.outputPath("openapi-reference.png"), fullPage: true });
});
