// E2E test 18 (SPEC 14.4): check in, then Q1 (Attendee page) and Q2 (Session page) both show the record.
// Executed 2026-11-03 against a live node and explorer: passes.

import { expect, test } from "@playwright/test";
import { SESSION_ID } from "../e2e-env.js";
import { checkInInUi, registerInUi, uniqueAlias } from "./helpers.js";

test("18: check in, then Q1 and Q2 both show the record", async ({ page, request }) => {
  const alias = uniqueAlias("e2e18");
  const registered = await registerInUi(page, request, alias);
  await checkInInUi(page, request, SESSION_ID);

  // Q1: sessions attended by the attendee.
  await page.goto(`/attendees/${registered.attendeeId}`);
  await expect(page.getByRole("heading", { name: "Sessions attended" })).toBeVisible();
  await expect(page.getByRole("link", { name: SESSION_ID, exact: true })).toBeVisible();

  // Q2: attendees of the session. The attendee link shows the first 12 id characters and carries the full id in title.
  await page.goto(`/sessions/${SESSION_ID}`);
  await expect(page.getByRole("heading", { name: `Attendees of ${SESSION_ID}` })).toBeVisible();
  await expect(page.getByRole("row", { name: new RegExp(alias) })).toBeVisible();
  await expect(page.locator(`a[title="${registered.attendeeId}"]`)).toBeVisible();
});
