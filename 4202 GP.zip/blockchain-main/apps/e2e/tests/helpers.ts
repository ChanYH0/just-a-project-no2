// Shared helpers for the e2e specs. Selectors come from the explorer sources (labels, roles, element ids).

import { expect, type APIRequestContext, type Page } from "@playwright/test";
import { NODE_ORIGIN } from "../e2e-env.js";

export interface Registered {
  attendeeId: string;
  recordId: string;
  alias: string;
}

export interface LiveSnapshot {
  headIndex: number;
  headHash: string;
  validate: unknown;
}

const CONFIRM_TIMEOUT_MS = 90_000;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

export function uniqueAlias(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}`;
}

// GET /records/:recordId on the node until confirmed (the UI poll can stop earlier, e.g. on "reserved").
export async function waitConfirmed(request: APIRequestContext, recordId: string): Promise<void> {
  await expect
    .poll(
      async () => {
        const response = await request.get(`${NODE_ORIGIN}/records/${recordId}`);
        const body: unknown = await response.json();
        return isRecord(body) ? body["status"] : undefined;
      },
      { timeout: CONFIRM_TIMEOUT_MS, intervals: [1_000] },
    )
    .toBe("confirmed");
}

export async function registerInUi(page: Page, request: APIRequestContext, alias: string): Promise<Registered> {
  await page.goto("/register");
  await page.locator("#alias-input").fill(alias);
  await page.getByRole("button", { name: "Create identity and register" }).click();
  // RegisterPage prints the full ids outside the live region: "Attendee <id>" and "Record <id>" paragraphs.
  const attendeeLocator = page.locator("p", { hasText: /^Attendee / }).locator(".mono");
  const recordLocator = page.locator("p", { hasText: /^Record / }).locator(".mono");
  await expect(attendeeLocator).toHaveCount(1);
  await expect(recordLocator).toHaveCount(1);
  const attendeeId = (await attendeeLocator.textContent()) ?? "";
  const recordId = (await recordLocator.textContent()) ?? "";
  expect(attendeeId).toMatch(/^[0-9a-f]{64}$/);
  await waitConfirmed(request, recordId);
  return { attendeeId, recordId, alias };
}

export async function checkInInUi(page: Page, request: APIRequestContext, sessionId: string): Promise<string> {
  await page.goto("/check-in");
  await page.locator("#session-select").selectOption(sessionId);
  await page.getByRole("button", { name: "Sign and submit attendance" }).click();
  // CheckInPage status block has one .mono: the record id.
  const mono = page.locator('div[role="status"] .mono');
  await expect(mono).toHaveCount(1);
  const recordId = (await mono.textContent()) ?? "";
  expect(recordId).toMatch(/^[0-9a-f]{64}$/);
  await waitConfirmed(request, recordId);
  return recordId;
}

async function fetchValidate(request: APIRequestContext): Promise<unknown> {
  return (await request.get(`${NODE_ORIGIN}/chain/validate`)).json();
}

function isRateLimited(body: unknown): boolean {
  return isRecord(body) && isRecord(body["error"]) && body["error"]["code"] === "RATE_LIMITED";
}

export async function snapshotLive(request: APIRequestContext): Promise<LiveSnapshot> {
  const blocks: unknown = await (await request.get(`${NODE_ORIGIN}/blocks?limit=1`)).json();
  const head = isRecord(blocks) && Array.isArray(blocks["blocks"]) ? (blocks["blocks"][0] as unknown) : undefined;
  if (!isRecord(head) || typeof head["index"] !== "number" || typeof head["hash"] !== "string") {
    throw new Error("unexpected GET /blocks response");
  }
  let validate = await fetchValidate(request);
  if (isRateLimited(validate)) {
    // Heavy requests are limited to 6 per IP per 60 s (apps/node/src/limits.ts); wait out the window once.
    await new Promise((resolve) => setTimeout(resolve, 61_000));
    validate = await fetchValidate(request);
  }
  return { headIndex: head["index"], headHash: head["hash"], validate };
}
