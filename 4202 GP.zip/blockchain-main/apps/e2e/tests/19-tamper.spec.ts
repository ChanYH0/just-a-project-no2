// E2E test 19 (SPEC 14.4): the tamper demo returns a real-validator failure with the right block index and leaves the
// live chain unchanged (same head, /chain/validate still ok).
// Executed 2026-11-03 against a live node and explorer: passes.

import { expect, test } from "@playwright/test";
import { registerInUi, snapshotLive, uniqueAlias } from "./helpers.js";

const TAMPER_BLOCK_INDEX = 1;

test("19: tamper demo reports a real validator failure and leaves the live chain unchanged", async ({
  page,
  request,
}) => {
  // Make sure block 1 exists and has a record (independent of test order).
  await registerInUi(page, request, uniqueAlias("e2e19"));
  const before = await snapshotLive(request);
  expect(before.headIndex).toBeGreaterThanOrEqual(TAMPER_BLOCK_INDEX);
  expect(before.validate).toEqual({ ok: true });

  await page.goto("/validate");
  await expect(page.getByRole("heading", { name: "Demo: tamper check" })).toBeVisible();
  await page.locator("#mutation-select").selectOption("edit-record");
  await page.locator("#tamper-block").fill(String(TAMPER_BLOCK_INDEX));
  await page.getByRole("button", { name: "Run tamper check" }).click();

  // The page prints the node's raw JSON ({ ok, code, blockIndex, note }); nothing is faked in the browser.
  const raw = page.getByLabel("Raw tamper-check result");
  await expect(raw).toBeVisible();
  const parsed: unknown = JSON.parse((await raw.textContent()) ?? "null");
  expect(parsed).toMatchObject({ ok: false, code: "BAD_BLOCK_HASH", blockIndex: TAMPER_BLOCK_INDEX });

  // Live chain unchanged: same head, still valid (also via the UI button).
  const after = await snapshotLive(request);
  expect(after).toEqual(before);
  await page.getByRole("button", { name: "Run validation" }).click();
  await expect(page.getByText("Chain is valid.")).toBeVisible();
});
