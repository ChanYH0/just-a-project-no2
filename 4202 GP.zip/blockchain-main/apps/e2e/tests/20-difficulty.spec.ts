// E2E test 20 (SPEC 14.4): difficulty demo with intervalMs = 0 shows rising difficulty and with 120000 falling
// difficulty; afterwards registering and checking in still works and the live chain was not changed by the simulation.
// Selectors verified against a live run on 2026-11-03.

import { expect, test, type Page } from "@playwright/test";
import { SESSION_ID } from "../e2e-env.js";
import { checkInInUi, registerInUi, snapshotLive, uniqueAlias } from "./helpers.js";

const COUNT = "12";
// Blocks table columns: Index, Hash, Difficulty, Synthetic timestamp (ms); nth-child is 1-based.
const DIFFICULTY_CELL = "td:nth-child(3)";
// The node allows 6 heavy requests per IP per 60 s window (apps/node/src/limits.ts); earlier specs spend some of it.
const HEAVY_WINDOW_WAIT_MS = 61_000;

async function simulate(page: Page, intervalMs: string): Promise<number[]> {
  await page.goto("/");
  await page.getByRole("navigation", { name: "Main" }).getByRole("link", { name: "Difficulty" }).click();
  await page.locator("#count-input").fill(COUNT);
  await page.locator("#interval-input").fill(intervalMs);
  const heading = page.getByRole("heading", { name: /Simulation \(isolated chain\)/ });
  const rateLimited = page.getByRole("alert").filter({ hasText: "RATE_LIMITED" });
  await page.getByRole("button", { name: "Run simulation" }).click();
  await expect(heading.or(rateLimited)).toBeVisible();
  if (await rateLimited.isVisible()) {
    await page.waitForTimeout(HEAVY_WINDOW_WAIT_MS);
    await page.getByRole("button", { name: "Run simulation" }).click();
  }
  await expect(heading).toBeVisible();
  const rows = page.locator("h3", { hasText: "Blocks" }).locator("xpath=following-sibling::table[1]//tbody/tr");
  await expect(rows.first()).toBeVisible();
  const cells = await rows.locator(DIFFICULTY_CELL).allTextContents();
  return cells.map((text) => Number(text));
}

test("20: difficulty demo rises at 0 ms, falls at 120000 ms, live chain unaffected", async ({ page, request }) => {
  test.setTimeout(420_000);
  const before = await snapshotLive(request);

  const rising = await simulate(page, "0");
  expect(rising.length).toBeGreaterThan(1);
  expect(rising.at(-1)).toBeGreaterThan(rising[0] ?? Number.POSITIVE_INFINITY);

  const falling = await simulate(page, "120000");
  expect(falling.length).toBeGreaterThan(1);
  expect(falling.at(-1)).toBeLessThan(falling[0] ?? Number.NEGATIVE_INFINITY);

  // The simulation never touches the live chain.
  expect(await snapshotLive(request)).toEqual(before);

  // Registering and checking in still work afterwards; the chain grows only through those records.
  await registerInUi(page, request, uniqueAlias("e2e20"));
  await checkInInUi(page, request, SESSION_ID);
  const after = await snapshotLive(request);
  expect(after.headIndex).toBeGreaterThan(before.headIndex);
  expect(after.validate).toEqual({ ok: true });
});
