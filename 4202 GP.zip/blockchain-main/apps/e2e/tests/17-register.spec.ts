// E2E test 17 (SPEC 14.4): register in the UI (uses GET /chain/info), wait for the block, Attendee page shows registered.
// Executed 2026-11-03 against a live node and explorer: passes.

import { expect, test } from "@playwright/test";
import { registerInUi, uniqueAlias } from "./helpers.js";

test("17: register in the UI, wait for the block, Attendee page shows registered", async ({ page, request }) => {
  // RegisterPage fetches GET /chain/info (through the /api proxy) before signing; assert the call happens.
  const infoCall = page.waitForResponse((response) => response.url().endsWith("/api/chain/info") && response.ok());

  const alias = uniqueAlias("e2e17");
  const registered = await registerInUi(page, request, alias);
  await infoCall;
  await expect(page.getByText(/Record status: confirmed in block \d+/)).toBeVisible({ timeout: 60_000 });

  await page.goto(`/attendees/${registered.attendeeId}`);
  await expect(page.getByRole("heading", { name: "Registration" })).toBeVisible();
  await expect(page.getByRole("row", { name: /Attendee id/ })).toContainText(registered.attendeeId);
  await expect(page.getByRole("row", { name: /Alias/ })).toContainText(alias);
  await expect(page.getByRole("row", { name: /Block/ }).getByRole("link")).toHaveText(/^\d+$/);
});
