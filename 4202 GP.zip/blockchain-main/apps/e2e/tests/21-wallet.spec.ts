import { expect, test } from "@playwright/test";
import { SESSION_ID } from "../e2e-env.js";
import { checkInInUi, registerInUi, uniqueAlias } from "./helpers.js";

test("21: wallet survives reload and hide/restore; duplicate attendance is rejected", async ({ page, request }, testInfo) => {
  const identity = await registerInUi(page, request, uniqueAlias("wallet"));
  await page.reload();
  await expect(page.getByRole("link", { name: `Signed in as ${identity.alias}` })).toBeVisible();

  await page.getByRole("button", { name: "Hide identity", exact: true }).click();
  await page.reload();
  await expect(page.getByRole("button", { name: `Use identity ${identity.alias}` })).toBeVisible();
  await page.goto("/check-in");
  await expect(page.getByText("You are logged out.", { exact: false })).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign and submit attendance" })).toHaveCount(0);
  await page.getByRole("button", { name: `Use identity ${identity.alias}` }).click();
  await checkInInUi(page, request, SESSION_ID);

  await page.reload();
  await page.locator("#session-select").selectOption(SESSION_ID);
  await page.getByRole("button", { name: "Sign and submit attendance" }).click();
  await expect(page.getByRole("alert")).toContainText("already checked in");
  await expect(page.getByRole("link", { name: `Signed in as ${identity.alias}` })).toHaveAttribute(
    "href", `/attendees/${identity.attendeeId}`,
  );
  await page.screenshot({ path: testInfo.outputPath("wallet-duplicate.png"), fullPage: true });
});
