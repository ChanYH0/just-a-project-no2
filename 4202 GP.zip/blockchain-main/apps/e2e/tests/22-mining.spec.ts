// Real HTTP admission and worker mining. No worker doubles or synthetic timestamps.
import { expect, test } from "@playwright/test";
import { writeFile } from "node:fs/promises";
import {
  Block,
  MAX_RECORDS_PER_BLOCK,
  PROFILE_NAMES,
  adjustmentAt,
  computeBlockHash,
  deriveAttendeeId,
  getProfile,
  nextDifficulty,
  nodeHash,
  nodeIdentityCrypto,
  recordId,
  signPayload,
  validateChain,
  type ProfileName,
  type RegistrationPayload,
  type SignedRegistration,
} from "../../../packages/shared/src/node.js";
import { createApi } from "../../explorer/src/api.js";
import { EXPLORER_ORIGIN } from "../e2e-env.js";

test("22: real mining preserves FIFO, verifies signatures and PoW, and adjusts live difficulty", async ({ page }, testInfo) => {
  test.setTimeout(180_000);
  const api = createApi((input, init) => fetch(`${EXPLORER_ORIGIN}${input}`, init));
  const info = await api.getChainInfo();
  expect(PROFILE_NAMES).toContain(info.profile);
  const config = getProfile(info.profile as ProfileName, info.conferenceId);
  const crypto = { identity: nodeIdentityCrypto, hash: nodeHash };
  const startedAt = Date.now();
  const baseline = await api.getHealth();
  const submitted: { id: string; record: SignedRegistration }[] = [];
  const observations: unknown[] = [];
  // One initial batch plus enough later jobs to cross a real adjustment boundary.
  const keys = await Promise.all(Array.from({ length: config.adjustmentInterval + 3 }, () => nodeIdentityCrypto.generateKeyPair()));

  async function registration(index: number): Promise<SignedRegistration> {
    const key = keys[index];
    if (key === undefined) throw new Error("missing mining-demo key");
    const payload: RegistrationPayload = {
      type: "register", chainId: info.chainId,
      attendeeId: await deriveAttendeeId(key.publicKey, nodeIdentityCrypto),
      alias: `mining-${startedAt.toString(36)}-${index}`,
      publicKey: key.publicKey, timestamp: Date.now(),
    };
    return { payload, signature: await signPayload(payload, key.privateKey, nodeIdentityCrypto) };
  }

  async function submit(index: number): Promise<string> {
    const record = await registration(index);
    const accepted = await api.postRegistration(record);
    expect(accepted.recordId).toBe(recordId(record, nodeHash));
    submitted.push({ id: accepted.recordId, record });
    return accepted.recordId;
  }

  async function confirmed(id: string): Promise<void> {
    await expect.poll(async () => {
      // A healthy response while jobs are outstanding also exercises the HTTP event loop.
      const [health, status] = await Promise.all([api.getHealth(), api.getRecord(id)]);
      expect(health.ok).toBe(true);
      observations.push({ elapsedMs: Date.now() - startedAt, miner: health.miner, status: status.status });
      return status.status;
    }, { timeout: 90_000, intervals: [250, 500, 1000] }).toBe("confirmed");
  }

  // A structurally valid bad signature must never enter the pending pool.
  const invalid = await registration(0);
  invalid.signature = Buffer.alloc(256).toString("base64");
  await expect(api.postRegistration(invalid)).rejects.toMatchObject({ code: "INVALID_SIGNATURE" });

  const initialIds: string[] = [];
  for (let i = 0; i < 3; i += 1) initialIds.push(await submit(i));
  await Promise.all(initialIds.map(confirmed));
  for (let i = 3; i < keys.length; i += 1) await confirmed(await submit(i));

  const newestFirst: Block[] = [];
  let cursor: string | undefined;
  do {
    const result = await api.getBlocks({ limit: 100, cursor });
    newestFirst.push(...result.blocks);
    cursor = result.nextCursor ?? undefined;
  } while (cursor !== undefined);
  const chain = newestFirst.reverse();
  expect(await validateChain(chain, config, crypto)).toEqual({ ok: true });
  const mined = chain.filter((block) => block.index > baseline.headIndex);
  const tracked = new Set(submitted.map((item) => item.id));
  const allMinedIds = mined.flatMap((block) => block.records.map((record) => recordId(record, nodeHash)));
  const minedIds = allMinedIds.filter((id) => tracked.has(id));
  expect(minedIds).toEqual(submitted.map((item) => item.id));
  expect(allMinedIds).not.toContain(recordId(invalid, nodeHash));
  const adjustments: unknown[] = [];
  for (const block of mined) {
    expect(Block.safeParse(block).success).toBe(true);
    expect(block.records.length).toBeGreaterThan(0);
    expect(block.records.length).toBeLessThanOrEqual(MAX_RECORDS_PER_BLOCK);
    expect(computeBlockHash(block, nodeHash)).toBe(block.hash);
    expect(block.hash.startsWith("0".repeat(block.difficulty))).toBe(true);
    const prefix = chain.slice(0, block.index);
    expect(block.difficulty).toBe(nextDifficulty(prefix, config));
    const adjustment = adjustmentAt(prefix, config);
    if (adjustment !== null) adjustments.push({ blockIndex: block.index, ...adjustment });
  }
  expect(adjustments.length).toBeGreaterThan(0);
  for (const item of submitted) expect(await api.getRecord(item.id)).toMatchObject({ status: "confirmed" });
  expect((await api.getMempool()).some((record) => tracked.has(recordId(record, nodeHash)))).toBe(false);

  const head = chain.at(-1);
  if (head === undefined) throw new Error("missing mined head");
  await page.goto(`/blocks/${head.index}`);
  await expect(page.getByRole("row", { name: "Hash valid (node) yes", exact: true })).toBeVisible();
  await expect(page.getByRole("row", { name: "Proof of work valid (node) yes", exact: true })).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath("real-mined-block.png"), fullPage: true });
  const evidencePath = testInfo.outputPath("mining-evidence.json");
  await writeFile(evidencePath, JSON.stringify({
    chainId: info.chainId, profile: info.profile, baselineHead: baseline.headIndex,
    headIndex: head.index, headHash: head.hash, admittedRecords: submitted.length,
    minedBlocks: mined.map(({ index, hash, nonce, difficulty, records, timestamp }) => ({ index, hash, nonce, difficulty, recordCount: records.length, timestamp })),
    adjustments, observations,
  }, null, 2));
  await testInfo.attach("mining-evidence", { contentType: "application/json", path: evidencePath });
});
