// Starts apps/node for the e2e run with a fresh temp DATA_DIR, removed again on exit.
// The directory is created here (not in a Playwright globalSetup) because Playwright starts webServer
// processes before globalSetup runs, so the node would otherwise start without its DATA_DIR.
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

const nodeDir = resolve(import.meta.dirname, "../../node");

const required = (name) => {
  const value = process.env[name];
  if (value === undefined || value === "") {
    throw new Error(`${name} must be set`);
  }
  return value;
};

const conferenceId = required("CONFERENCE_ID");
const port = required("PORT");
const host = required("HOST");
const dataDir = mkdtempSync(join(tmpdir(), "conference-chain-e2e-"));

const child = spawn(process.execPath, ["--import", "tsx", "src/main.ts"], {
  cwd: nodeDir,
  stdio: "inherit",
  env: {
    ...process.env,
    PROFILE: "demo",
    ENABLE_DEMO_ROUTES: "true",
    CONFERENCE_ID: conferenceId,
    PORT: port,
    HOST: host,
    DATA_DIR: dataDir,
    SESSIONS_FILE: resolve(nodeDir, "sessions.example.json"),
  },
});

let cleaned = false;
const cleanup = () => {
  if (!cleaned) {
    cleaned = true;
    rmSync(dataDir, { recursive: true, force: true });
  }
};
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => child.kill(signal));
}
child.on("exit", (code) => {
  cleanup();
  process.exit(code ?? 1);
});
child.on("error", (error) => {
  cleanup();
  console.error(`failed to start node: ${error.message}`);
  process.exit(1);
});
